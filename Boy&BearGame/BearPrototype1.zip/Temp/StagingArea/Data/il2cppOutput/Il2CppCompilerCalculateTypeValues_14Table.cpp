﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "object-internals.h"

// System.Void
struct Void_t1421048318;
// System.Action`1<System.Single>
struct Action_1_t2117217084;
// System.Action
struct Action_t4042858631;




#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef VALUETYPE_T3348802692_H
#define VALUETYPE_T3348802692_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t3348802692  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t3348802692_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t3348802692_marshaled_com
{
};
#endif // VALUETYPE_T3348802692_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	IntPtr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline IntPtr_t get_Zero_1() const { return ___Zero_1; }
	inline IntPtr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(IntPtr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef OBJECT_T3267094820_H
#define OBJECT_T3267094820_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_t3267094820  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	IntPtr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_t3267094820, ___m_CachedPtr_0)); }
	inline IntPtr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline IntPtr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(IntPtr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_t3267094820_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_t3267094820_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_t3267094820_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_t3267094820_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_T3267094820_H
#ifndef COMPONENT_T21088299_H
#define COMPONENT_T21088299_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t21088299  : public Object_t3267094820
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T21088299_H
#ifndef BEHAVIOUR_T2953351352_H
#define BEHAVIOUR_T2953351352_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_t2953351352  : public Component_t21088299
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_T2953351352_H
#ifndef MONOBEHAVIOUR_T244116357_H
#define MONOBEHAVIOUR_T244116357_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.MonoBehaviour
struct  MonoBehaviour_t244116357  : public Behaviour_t2953351352
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOBEHAVIOUR_T244116357_H
#ifndef PLAYERINPUT_T3450109778_H
#define PLAYERINPUT_T3450109778_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// PlayerInput
struct  PlayerInput_t3450109778  : public MonoBehaviour_t244116357
{
public:

public:
};

struct PlayerInput_t3450109778_StaticFields
{
public:
	// System.Action`1<System.Single> PlayerInput::KeyAction
	Action_1_t2117217084 * ___KeyAction_2;
	// System.Action PlayerInput::JumpAction
	Action_t4042858631 * ___JumpAction_3;

public:
	inline static int32_t get_offset_of_KeyAction_2() { return static_cast<int32_t>(offsetof(PlayerInput_t3450109778_StaticFields, ___KeyAction_2)); }
	inline Action_1_t2117217084 * get_KeyAction_2() const { return ___KeyAction_2; }
	inline Action_1_t2117217084 ** get_address_of_KeyAction_2() { return &___KeyAction_2; }
	inline void set_KeyAction_2(Action_1_t2117217084 * value)
	{
		___KeyAction_2 = value;
		Il2CppCodeGenWriteBarrier((&___KeyAction_2), value);
	}

	inline static int32_t get_offset_of_JumpAction_3() { return static_cast<int32_t>(offsetof(PlayerInput_t3450109778_StaticFields, ___JumpAction_3)); }
	inline Action_t4042858631 * get_JumpAction_3() const { return ___JumpAction_3; }
	inline Action_t4042858631 ** get_address_of_JumpAction_3() { return &___JumpAction_3; }
	inline void set_JumpAction_3(Action_t4042858631 * value)
	{
		___JumpAction_3 = value;
		Il2CppCodeGenWriteBarrier((&___JumpAction_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYERINPUT_T3450109778_H
#ifndef PUSHOBJECT_T3539098884_H
#define PUSHOBJECT_T3539098884_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// PushObject
struct  PushObject_t3539098884  : public MonoBehaviour_t244116357
{
public:
	// System.Single PushObject::pushForce
	float ___pushForce_2;

public:
	inline static int32_t get_offset_of_pushForce_2() { return static_cast<int32_t>(offsetof(PushObject_t3539098884, ___pushForce_2)); }
	inline float get_pushForce_2() const { return ___pushForce_2; }
	inline float* get_address_of_pushForce_2() { return &___pushForce_2; }
	inline void set_pushForce_2(float value)
	{
		___pushForce_2 = value;
	}
};

struct PushObject_t3539098884_StaticFields
{
public:
	// System.Boolean PushObject::fallen
	bool ___fallen_3;

public:
	inline static int32_t get_offset_of_fallen_3() { return static_cast<int32_t>(offsetof(PushObject_t3539098884_StaticFields, ___fallen_3)); }
	inline bool get_fallen_3() const { return ___fallen_3; }
	inline bool* get_address_of_fallen_3() { return &___fallen_3; }
	inline void set_fallen_3(bool value)
	{
		___fallen_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PUSHOBJECT_T3539098884_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1400 = { sizeof (PlayerInput_t3450109778), -1, sizeof(PlayerInput_t3450109778_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1400[2] = 
{
	PlayerInput_t3450109778_StaticFields::get_offset_of_KeyAction_2(),
	PlayerInput_t3450109778_StaticFields::get_offset_of_JumpAction_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1401 = { sizeof (PushObject_t3539098884), -1, sizeof(PushObject_t3539098884_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1401[2] = 
{
	PushObject_t3539098884::get_offset_of_pushForce_2(),
	PushObject_t3539098884_StaticFields::get_offset_of_fallen_3(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
