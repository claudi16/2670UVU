﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "object-internals.h"

// System.Reflection.AssemblyFileVersionAttribute
struct AssemblyFileVersionAttribute_t1839628412;
// System.String
struct String_t;
// System.Reflection.AssemblyCompanyAttribute
struct AssemblyCompanyAttribute_t262073538;
// System.Diagnostics.DebuggableAttribute
struct DebuggableAttribute_t2636756938;
// System.Runtime.CompilerServices.StringFreezingAttribute
struct StringFreezingAttribute_t10408148;
// System.Resources.NeutralResourcesLanguageAttribute
struct NeutralResourcesLanguageAttribute_t2573722287;
// System.CLSCompliantAttribute
struct CLSCompliantAttribute_t3606053525;
// System.Reflection.AssemblyDelaySignAttribute
struct AssemblyDelaySignAttribute_t1388804811;
// System.Runtime.CompilerServices.DefaultDependencyAttribute
struct DefaultDependencyAttribute_t547142461;
// System.Runtime.CompilerServices.RuntimeCompatibilityAttribute
struct RuntimeCompatibilityAttribute_t2873331073;
// System.Reflection.AssemblyProductAttribute
struct AssemblyProductAttribute_t3079866486;
// System.Reflection.AssemblyDescriptionAttribute
struct AssemblyDescriptionAttribute_t1377417777;
// System.Resources.SatelliteContractVersionAttribute
struct SatelliteContractVersionAttribute_t3058788408;
// System.Reflection.AssemblyInformationalVersionAttribute
struct AssemblyInformationalVersionAttribute_t458211439;
// System.Reflection.AssemblyCopyrightAttribute
struct AssemblyCopyrightAttribute_t4130653132;
// System.Reflection.AssemblyDefaultAliasAttribute
struct AssemblyDefaultAliasAttribute_t3813724156;
// System.Reflection.AssemblyTitleAttribute
struct AssemblyTitleAttribute_t4032010531;
// System.Runtime.InteropServices.ComVisibleAttribute
struct ComVisibleAttribute_t3352689681;
// System.Runtime.CompilerServices.CompilationRelaxationsAttribute
struct CompilationRelaxationsAttribute_t2092844809;
// System.Runtime.InteropServices.TypeLibVersionAttribute
struct TypeLibVersionAttribute_t3563874934;
// System.Runtime.InteropServices.GuidAttribute
struct GuidAttribute_t3287193793;
// System.Reflection.AssemblyKeyFileAttribute
struct AssemblyKeyFileAttribute_t756954830;
// System.Runtime.InteropServices.ClassInterfaceAttribute
struct ClassInterfaceAttribute_t1078708468;
// System.Runtime.ConstrainedExecution.ReliabilityContractAttribute
struct ReliabilityContractAttribute_t3660264932;
// System.AttributeUsageAttribute
struct AttributeUsageAttribute_t2106699225;
// System.Runtime.InteropServices.ComDefaultInterfaceAttribute
struct ComDefaultInterfaceAttribute_t2824514219;
// System.Type
struct Type_t;
// System.Runtime.InteropServices.InterfaceTypeAttribute
struct InterfaceTypeAttribute_t931938199;
// System.Runtime.InteropServices.TypeLibImportClassAttribute
struct TypeLibImportClassAttribute_t2161063924;
// System.Runtime.InteropServices.DispIdAttribute
struct DispIdAttribute_t3051066024;
// System.Reflection.DefaultMemberAttribute
struct DefaultMemberAttribute_t296450964;
// System.ParamArrayAttribute
struct ParamArrayAttribute_t4148278418;
// System.MonoDocumentationNoteAttribute
struct MonoDocumentationNoteAttribute_t3523980758;
// System.Runtime.CompilerServices.DecimalConstantAttribute
struct DecimalConstantAttribute_t99985380;
// System.ObsoleteAttribute
struct ObsoleteAttribute_t534593266;
// System.Diagnostics.DebuggerHiddenAttribute
struct DebuggerHiddenAttribute_t177041199;
// System.Runtime.CompilerServices.CompilerGeneratedAttribute
struct CompilerGeneratedAttribute_t1456741190;
// System.MonoTODOAttribute
struct MonoTODOAttribute_t119123862;
// System.Diagnostics.DebuggerTypeProxyAttribute
struct DebuggerTypeProxyAttribute_t4230666625;
// System.Diagnostics.DebuggerDisplayAttribute
struct DebuggerDisplayAttribute_t1222375162;
// System.FlagsAttribute
struct FlagsAttribute_t2123170284;
// System.Diagnostics.DebuggerStepThroughAttribute
struct DebuggerStepThroughAttribute_t1445666285;
// System.Security.SuppressUnmanagedCodeSecurityAttribute
struct SuppressUnmanagedCodeSecurityAttribute_t712177550;
// System.ThreadStaticAttribute
struct ThreadStaticAttribute_t4044403880;
// System.Runtime.CompilerServices.InternalsVisibleToAttribute
struct InternalsVisibleToAttribute_t4106395870;
// System.MonoTODOAttribute
struct MonoTODOAttribute_t119123863;
// System.ComponentModel.TypeConverterAttribute
struct TypeConverterAttribute_t3031206686;
// System.Security.SecurityCriticalAttribute
struct SecurityCriticalAttribute_t4019023285;
// System.Security.AllowPartiallyTrustedCallersAttribute
struct AllowPartiallyTrustedCallersAttribute_t2793852185;
// System.Runtime.CompilerServices.ExtensionAttribute
struct ExtensionAttribute_t36176176;
// System.Diagnostics.DebuggerBrowsableAttribute
struct DebuggerBrowsableAttribute_t182167257;
// UnityEngine.Scripting.RequiredByNativeCodeAttribute
struct RequiredByNativeCodeAttribute_t2920332526;
// UnityEngine.Scripting.GeneratedByOldBindingsGeneratorAttribute
struct GeneratedByOldBindingsGeneratorAttribute_t1890141928;
// UnityEngine.ThreadAndSerializationSafeAttribute
struct ThreadAndSerializationSafeAttribute_t401734977;
// UnityEngine.WritableAttribute
struct WritableAttribute_t718555548;
// UnityEngine.Scripting.UsedByNativeCodeAttribute
struct UsedByNativeCodeAttribute_t2042968054;
// UnityEngine.RequireComponent
struct RequireComponent_t2231837482;
// UnityEngineInternal.TypeInferenceRuleAttribute
struct TypeInferenceRuleAttribute_t1237727610;
// System.Security.SecuritySafeCriticalAttribute
struct SecuritySafeCriticalAttribute_t3761815145;
// UnityEngine.Internal.ExcludeFromDocsAttribute
struct ExcludeFromDocsAttribute_t2642155980;
// UnityEngine.Internal.DefaultValueAttribute
struct DefaultValueAttribute_t1239497132;
// UnityEngine.NativeClassAttribute
struct NativeClassAttribute_t3768029985;
// System.ComponentModel.EditorBrowsableAttribute
struct EditorBrowsableAttribute_t1429620940;
// UnityEngine.SerializeField
struct SerializeField_t1114448220;
// UnityEngine.Serialization.FormerlySerializedAsAttribute
struct FormerlySerializedAsAttribute_t153867989;
// System.Runtime.InteropServices.UnmanagedFunctionPointerAttribute
struct UnmanagedFunctionPointerAttribute_t3672379452;
// UnityEngine.AddComponentMenu
struct AddComponentMenu_t1949136625;
// System.Char[]
struct CharU5BU5D_t2816624037;
// System.Version
struct Version_t3942069453;
// System.Void
struct Void_t1421048318;
// System.Type[]
struct TypeU5BU5D_t1722708557;
// System.Reflection.MemberFilter
struct MemberFilter_t3088556475;

extern const RuntimeType* _Attribute_t1412570690_0_0_0_var;
extern const uint32_t Attribute_t1821863933_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* Attribute_t1821863933_0_0_0_var;
extern const uint32_t _Attribute_t1412570690_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _Type_t3776473474_0_0_0_var;
extern const uint32_t Type_t_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _MemberInfo_t3276260911_0_0_0_var;
extern const uint32_t MemberInfo_t_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* MemberInfo_t_0_0_0_var;
extern const uint32_t _MemberInfo_t3276260911_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* Type_t_0_0_0_var;
extern const uint32_t _Type_t3776473474_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _Exception_t1060755997_0_0_0_var;
extern const uint32_t Exception_t2443218823_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* CollectionDebuggerView_2_t1776780061_0_0_0_var;
extern const uint32_t Dictionary_2_t1155016036_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* CollectionDebuggerView_1_t3145566263_0_0_0_var;
extern const uint32_t List_1_t2059616371_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* CollectionDebuggerView_t410077241_0_0_0_var;
extern const uint32_t ArrayList_t3384568281_CustomAttributesCacheGenerator_MetadataUsageId;
extern const uint32_t Hashtable_t1665082780_CustomAttributesCacheGenerator_MetadataUsageId;
extern const uint32_t HashKeys_t2826937142_CustomAttributesCacheGenerator_MetadataUsageId;
extern const uint32_t HashValues_t1567374944_CustomAttributesCacheGenerator_MetadataUsageId;
extern const uint32_t Stack_t830505910_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _AssemblyBuilder_t870438842_0_0_0_var;
extern const uint32_t AssemblyBuilder_t3823150316_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _ConstructorBuilder_t2590771407_0_0_0_var;
extern const uint32_t ConstructorBuilder_t1269217984_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _EnumBuilder_t1981314773_0_0_0_var;
extern const uint32_t EnumBuilder_t1686327421_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _FieldBuilder_t3411354663_0_0_0_var;
extern const uint32_t FieldBuilder_t2373739222_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _ILGenerator_t1943880346_0_0_0_var;
extern const uint32_t ILGenerator_t1182878361_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _MethodBuilder_t1063350594_0_0_0_var;
extern const uint32_t MethodBuilder_t434851514_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _ModuleBuilder_t234448247_0_0_0_var;
extern const uint32_t ModuleBuilder_t3159331943_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _ParameterBuilder_t1036287219_0_0_0_var;
extern const uint32_t ParameterBuilder_t3753085247_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _TypeBuilder_t47360046_0_0_0_var;
extern const uint32_t TypeBuilder_t3350860216_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _Assembly_t3124909478_0_0_0_var;
extern const uint32_t Assembly_t3774988722_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _AssemblyName_t139716223_0_0_0_var;
extern const uint32_t AssemblyName_t3342125713_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _ConstructorInfo_t3612455801_0_0_0_var;
extern const uint32_t ConstructorInfo_t2050809311_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _EventInfo_t626173114_0_0_0_var;
extern const uint32_t EventInfo_t_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _FieldInfo_t616591751_0_0_0_var;
extern const uint32_t FieldInfo_t_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _MethodBase_t1718158610_0_0_0_var;
extern const uint32_t MethodBase_t2010470530_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _MethodInfo_t187796706_0_0_0_var;
extern const uint32_t MethodInfo_t_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _Module_t107875809_0_0_0_var;
extern const uint32_t Module_t3479515451_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _ParameterInfo_t1133799119_0_0_0_var;
extern const uint32_t ParameterInfo_t3793757615_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _PropertyInfo_t4067770872_0_0_0_var;
extern const uint32_t PropertyInfo_t_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* Activator_t2766073353_0_0_0_var;
extern const uint32_t _Activator_t1804057808_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* Assembly_t3774988722_0_0_0_var;
extern const uint32_t _Assembly_t3124909478_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* AssemblyBuilder_t3823150316_0_0_0_var;
extern const uint32_t _AssemblyBuilder_t870438842_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* AssemblyName_t3342125713_0_0_0_var;
extern const uint32_t _AssemblyName_t139716223_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* ConstructorBuilder_t1269217984_0_0_0_var;
extern const uint32_t _ConstructorBuilder_t2590771407_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* ConstructorInfo_t2050809311_0_0_0_var;
extern const uint32_t _ConstructorInfo_t3612455801_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* EnumBuilder_t1686327421_0_0_0_var;
extern const uint32_t _EnumBuilder_t1981314773_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* EventInfo_t_0_0_0_var;
extern const uint32_t _EventInfo_t626173114_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* FieldBuilder_t2373739222_0_0_0_var;
extern const uint32_t _FieldBuilder_t3411354663_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* FieldInfo_t_0_0_0_var;
extern const uint32_t _FieldInfo_t616591751_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* ILGenerator_t1182878361_0_0_0_var;
extern const uint32_t _ILGenerator_t1943880346_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* MethodBase_t2010470530_0_0_0_var;
extern const uint32_t _MethodBase_t1718158610_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* MethodBuilder_t434851514_0_0_0_var;
extern const uint32_t _MethodBuilder_t1063350594_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* MethodInfo_t_0_0_0_var;
extern const uint32_t _MethodInfo_t187796706_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* Module_t3479515451_0_0_0_var;
extern const uint32_t _Module_t107875809_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* ModuleBuilder_t3159331943_0_0_0_var;
extern const uint32_t _ModuleBuilder_t234448247_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* ParameterBuilder_t3753085247_0_0_0_var;
extern const uint32_t _ParameterBuilder_t1036287219_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* ParameterInfo_t3793757615_0_0_0_var;
extern const uint32_t _ParameterInfo_t1133799119_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* PropertyInfo_t_0_0_0_var;
extern const uint32_t _PropertyInfo_t4067770872_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* Thread_t3822855611_0_0_0_var;
extern const uint32_t _Thread_t4076868703_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* TypeBuilder_t3350860216_0_0_0_var;
extern const uint32_t _TypeBuilder_t47360046_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _Thread_t4076868703_0_0_0_var;
extern const uint32_t Thread_t3822855611_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* _Activator_t1804057808_0_0_0_var;
extern const uint32_t Activator_t2766073353_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* UriTypeConverter_t6232145_0_0_0_var;
extern const uint32_t Uri_t4143213084_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* Transform_t2636691836_0_0_0_var;
extern const uint32_t Camera_t142011664_CustomAttributesCacheGenerator_MetadataUsageId;
extern const uint32_t GUIElement_t2816691599_CustomAttributesCacheGenerator_MetadataUsageId;
extern const RuntimeType* Camera_t142011664_0_0_0_var;
extern const uint32_t GUILayer_t3734926407_CustomAttributesCacheGenerator_MetadataUsageId;
extern const uint32_t Rigidbody_t3670484383_CustomAttributesCacheGenerator_MetadataUsageId;
extern const uint32_t Collider_t3066580567_CustomAttributesCacheGenerator_MetadataUsageId;
extern const uint32_t AudioSource_t3205450310_CustomAttributesCacheGenerator_MetadataUsageId;



#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef MEMBERINFO_T_H
#define MEMBERINFO_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.MemberInfo
struct  MemberInfo_t  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEMBERINFO_T_H
#ifndef ATTRIBUTE_T1821863933_H
#define ATTRIBUTE_T1821863933_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Attribute
struct  Attribute_t1821863933  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ATTRIBUTE_T1821863933_H
#ifndef VALUETYPE_T3348802692_H
#define VALUETYPE_T3348802692_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t3348802692  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t3348802692_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t3348802692_marshaled_com
{
};
#endif // VALUETYPE_T3348802692_H
#ifndef STRING_T_H
#define STRING_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::length
	int32_t ___length_0;
	// System.Char System.String::start_char
	Il2CppChar ___start_char_1;

public:
	inline static int32_t get_offset_of_length_0() { return static_cast<int32_t>(offsetof(String_t, ___length_0)); }
	inline int32_t get_length_0() const { return ___length_0; }
	inline int32_t* get_address_of_length_0() { return &___length_0; }
	inline void set_length_0(int32_t value)
	{
		___length_0 = value;
	}

	inline static int32_t get_offset_of_start_char_1() { return static_cast<int32_t>(offsetof(String_t, ___start_char_1)); }
	inline Il2CppChar get_start_char_1() const { return ___start_char_1; }
	inline Il2CppChar* get_address_of_start_char_1() { return &___start_char_1; }
	inline void set_start_char_1(Il2CppChar value)
	{
		___start_char_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_2;
	// System.Char[] System.String::WhiteChars
	CharU5BU5D_t2816624037* ___WhiteChars_3;

public:
	inline static int32_t get_offset_of_Empty_2() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_2)); }
	inline String_t* get_Empty_2() const { return ___Empty_2; }
	inline String_t** get_address_of_Empty_2() { return &___Empty_2; }
	inline void set_Empty_2(String_t* value)
	{
		___Empty_2 = value;
		Il2CppCodeGenWriteBarrier((&___Empty_2), value);
	}

	inline static int32_t get_offset_of_WhiteChars_3() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___WhiteChars_3)); }
	inline CharU5BU5D_t2816624037* get_WhiteChars_3() const { return ___WhiteChars_3; }
	inline CharU5BU5D_t2816624037** get_address_of_WhiteChars_3() { return &___WhiteChars_3; }
	inline void set_WhiteChars_3(CharU5BU5D_t2816624037* value)
	{
		___WhiteChars_3 = value;
		Il2CppCodeGenWriteBarrier((&___WhiteChars_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRING_T_H
#ifndef ASSEMBLYFILEVERSIONATTRIBUTE_T1839628412_H
#define ASSEMBLYFILEVERSIONATTRIBUTE_T1839628412_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyFileVersionAttribute
struct  AssemblyFileVersionAttribute_t1839628412  : public Attribute_t1821863933
{
public:
	// System.String System.Reflection.AssemblyFileVersionAttribute::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(AssemblyFileVersionAttribute_t1839628412, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYFILEVERSIONATTRIBUTE_T1839628412_H
#ifndef TYPECONVERTERATTRIBUTE_T3031206686_H
#define TYPECONVERTERATTRIBUTE_T3031206686_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ComponentModel.TypeConverterAttribute
struct  TypeConverterAttribute_t3031206686  : public Attribute_t1821863933
{
public:
	// System.String System.ComponentModel.TypeConverterAttribute::converter_type
	String_t* ___converter_type_1;

public:
	inline static int32_t get_offset_of_converter_type_1() { return static_cast<int32_t>(offsetof(TypeConverterAttribute_t3031206686, ___converter_type_1)); }
	inline String_t* get_converter_type_1() const { return ___converter_type_1; }
	inline String_t** get_address_of_converter_type_1() { return &___converter_type_1; }
	inline void set_converter_type_1(String_t* value)
	{
		___converter_type_1 = value;
		Il2CppCodeGenWriteBarrier((&___converter_type_1), value);
	}
};

struct TypeConverterAttribute_t3031206686_StaticFields
{
public:
	// System.ComponentModel.TypeConverterAttribute System.ComponentModel.TypeConverterAttribute::Default
	TypeConverterAttribute_t3031206686 * ___Default_0;

public:
	inline static int32_t get_offset_of_Default_0() { return static_cast<int32_t>(offsetof(TypeConverterAttribute_t3031206686_StaticFields, ___Default_0)); }
	inline TypeConverterAttribute_t3031206686 * get_Default_0() const { return ___Default_0; }
	inline TypeConverterAttribute_t3031206686 ** get_address_of_Default_0() { return &___Default_0; }
	inline void set_Default_0(TypeConverterAttribute_t3031206686 * value)
	{
		___Default_0 = value;
		Il2CppCodeGenWriteBarrier((&___Default_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPECONVERTERATTRIBUTE_T3031206686_H
#ifndef MONOTODOATTRIBUTE_T119123863_H
#define MONOTODOATTRIBUTE_T119123863_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MonoTODOAttribute
struct  MonoTODOAttribute_t119123863  : public Attribute_t1821863933
{
public:
	// System.String System.MonoTODOAttribute::comment
	String_t* ___comment_0;

public:
	inline static int32_t get_offset_of_comment_0() { return static_cast<int32_t>(offsetof(MonoTODOAttribute_t119123863, ___comment_0)); }
	inline String_t* get_comment_0() const { return ___comment_0; }
	inline String_t** get_address_of_comment_0() { return &___comment_0; }
	inline void set_comment_0(String_t* value)
	{
		___comment_0 = value;
		Il2CppCodeGenWriteBarrier((&___comment_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOTODOATTRIBUTE_T119123863_H
#ifndef INTERNALSVISIBLETOATTRIBUTE_T4106395870_H
#define INTERNALSVISIBLETOATTRIBUTE_T4106395870_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.CompilerServices.InternalsVisibleToAttribute
struct  InternalsVisibleToAttribute_t4106395870  : public Attribute_t1821863933
{
public:
	// System.String System.Runtime.CompilerServices.InternalsVisibleToAttribute::assemblyName
	String_t* ___assemblyName_0;
	// System.Boolean System.Runtime.CompilerServices.InternalsVisibleToAttribute::all_visible
	bool ___all_visible_1;

public:
	inline static int32_t get_offset_of_assemblyName_0() { return static_cast<int32_t>(offsetof(InternalsVisibleToAttribute_t4106395870, ___assemblyName_0)); }
	inline String_t* get_assemblyName_0() const { return ___assemblyName_0; }
	inline String_t** get_address_of_assemblyName_0() { return &___assemblyName_0; }
	inline void set_assemblyName_0(String_t* value)
	{
		___assemblyName_0 = value;
		Il2CppCodeGenWriteBarrier((&___assemblyName_0), value);
	}

	inline static int32_t get_offset_of_all_visible_1() { return static_cast<int32_t>(offsetof(InternalsVisibleToAttribute_t4106395870, ___all_visible_1)); }
	inline bool get_all_visible_1() const { return ___all_visible_1; }
	inline bool* get_address_of_all_visible_1() { return &___all_visible_1; }
	inline void set_all_visible_1(bool value)
	{
		___all_visible_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTERNALSVISIBLETOATTRIBUTE_T4106395870_H
#ifndef THREADSTATICATTRIBUTE_T4044403880_H
#define THREADSTATICATTRIBUTE_T4044403880_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ThreadStaticAttribute
struct  ThreadStaticAttribute_t4044403880  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // THREADSTATICATTRIBUTE_T4044403880_H
#ifndef SUPPRESSUNMANAGEDCODESECURITYATTRIBUTE_T712177550_H
#define SUPPRESSUNMANAGEDCODESECURITYATTRIBUTE_T712177550_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.SuppressUnmanagedCodeSecurityAttribute
struct  SuppressUnmanagedCodeSecurityAttribute_t712177550  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUPPRESSUNMANAGEDCODESECURITYATTRIBUTE_T712177550_H
#ifndef DEBUGGERSTEPTHROUGHATTRIBUTE_T1445666285_H
#define DEBUGGERSTEPTHROUGHATTRIBUTE_T1445666285_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Diagnostics.DebuggerStepThroughAttribute
struct  DebuggerStepThroughAttribute_t1445666285  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEBUGGERSTEPTHROUGHATTRIBUTE_T1445666285_H
#ifndef DEBUGGERTYPEPROXYATTRIBUTE_T4230666625_H
#define DEBUGGERTYPEPROXYATTRIBUTE_T4230666625_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Diagnostics.DebuggerTypeProxyAttribute
struct  DebuggerTypeProxyAttribute_t4230666625  : public Attribute_t1821863933
{
public:
	// System.String System.Diagnostics.DebuggerTypeProxyAttribute::proxy_type_name
	String_t* ___proxy_type_name_0;

public:
	inline static int32_t get_offset_of_proxy_type_name_0() { return static_cast<int32_t>(offsetof(DebuggerTypeProxyAttribute_t4230666625, ___proxy_type_name_0)); }
	inline String_t* get_proxy_type_name_0() const { return ___proxy_type_name_0; }
	inline String_t** get_address_of_proxy_type_name_0() { return &___proxy_type_name_0; }
	inline void set_proxy_type_name_0(String_t* value)
	{
		___proxy_type_name_0 = value;
		Il2CppCodeGenWriteBarrier((&___proxy_type_name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEBUGGERTYPEPROXYATTRIBUTE_T4230666625_H
#ifndef DEBUGGERDISPLAYATTRIBUTE_T1222375162_H
#define DEBUGGERDISPLAYATTRIBUTE_T1222375162_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Diagnostics.DebuggerDisplayAttribute
struct  DebuggerDisplayAttribute_t1222375162  : public Attribute_t1821863933
{
public:
	// System.String System.Diagnostics.DebuggerDisplayAttribute::value
	String_t* ___value_0;
	// System.String System.Diagnostics.DebuggerDisplayAttribute::type
	String_t* ___type_1;
	// System.String System.Diagnostics.DebuggerDisplayAttribute::name
	String_t* ___name_2;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(DebuggerDisplayAttribute_t1222375162, ___value_0)); }
	inline String_t* get_value_0() const { return ___value_0; }
	inline String_t** get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(String_t* value)
	{
		___value_0 = value;
		Il2CppCodeGenWriteBarrier((&___value_0), value);
	}

	inline static int32_t get_offset_of_type_1() { return static_cast<int32_t>(offsetof(DebuggerDisplayAttribute_t1222375162, ___type_1)); }
	inline String_t* get_type_1() const { return ___type_1; }
	inline String_t** get_address_of_type_1() { return &___type_1; }
	inline void set_type_1(String_t* value)
	{
		___type_1 = value;
		Il2CppCodeGenWriteBarrier((&___type_1), value);
	}

	inline static int32_t get_offset_of_name_2() { return static_cast<int32_t>(offsetof(DebuggerDisplayAttribute_t1222375162, ___name_2)); }
	inline String_t* get_name_2() const { return ___name_2; }
	inline String_t** get_address_of_name_2() { return &___name_2; }
	inline void set_name_2(String_t* value)
	{
		___name_2 = value;
		Il2CppCodeGenWriteBarrier((&___name_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEBUGGERDISPLAYATTRIBUTE_T1222375162_H
#ifndef MONOTODOATTRIBUTE_T119123862_H
#define MONOTODOATTRIBUTE_T119123862_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MonoTODOAttribute
struct  MonoTODOAttribute_t119123862  : public Attribute_t1821863933
{
public:
	// System.String System.MonoTODOAttribute::comment
	String_t* ___comment_0;

public:
	inline static int32_t get_offset_of_comment_0() { return static_cast<int32_t>(offsetof(MonoTODOAttribute_t119123862, ___comment_0)); }
	inline String_t* get_comment_0() const { return ___comment_0; }
	inline String_t** get_address_of_comment_0() { return &___comment_0; }
	inline void set_comment_0(String_t* value)
	{
		___comment_0 = value;
		Il2CppCodeGenWriteBarrier((&___comment_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOTODOATTRIBUTE_T119123862_H
#ifndef COMPILERGENERATEDATTRIBUTE_T1456741190_H
#define COMPILERGENERATEDATTRIBUTE_T1456741190_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.CompilerServices.CompilerGeneratedAttribute
struct  CompilerGeneratedAttribute_t1456741190  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPILERGENERATEDATTRIBUTE_T1456741190_H
#ifndef OBSOLETEATTRIBUTE_T534593266_H
#define OBSOLETEATTRIBUTE_T534593266_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ObsoleteAttribute
struct  ObsoleteAttribute_t534593266  : public Attribute_t1821863933
{
public:
	// System.String System.ObsoleteAttribute::_message
	String_t* ____message_0;
	// System.Boolean System.ObsoleteAttribute::_error
	bool ____error_1;

public:
	inline static int32_t get_offset_of__message_0() { return static_cast<int32_t>(offsetof(ObsoleteAttribute_t534593266, ____message_0)); }
	inline String_t* get__message_0() const { return ____message_0; }
	inline String_t** get_address_of__message_0() { return &____message_0; }
	inline void set__message_0(String_t* value)
	{
		____message_0 = value;
		Il2CppCodeGenWriteBarrier((&____message_0), value);
	}

	inline static int32_t get_offset_of__error_1() { return static_cast<int32_t>(offsetof(ObsoleteAttribute_t534593266, ____error_1)); }
	inline bool get__error_1() const { return ____error_1; }
	inline bool* get_address_of__error_1() { return &____error_1; }
	inline void set__error_1(bool value)
	{
		____error_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OBSOLETEATTRIBUTE_T534593266_H
#ifndef DECIMALCONSTANTATTRIBUTE_T99985380_H
#define DECIMALCONSTANTATTRIBUTE_T99985380_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.CompilerServices.DecimalConstantAttribute
struct  DecimalConstantAttribute_t99985380  : public Attribute_t1821863933
{
public:
	// System.Byte System.Runtime.CompilerServices.DecimalConstantAttribute::scale
	uint8_t ___scale_0;
	// System.Boolean System.Runtime.CompilerServices.DecimalConstantAttribute::sign
	bool ___sign_1;
	// System.Int32 System.Runtime.CompilerServices.DecimalConstantAttribute::hi
	int32_t ___hi_2;
	// System.Int32 System.Runtime.CompilerServices.DecimalConstantAttribute::mid
	int32_t ___mid_3;
	// System.Int32 System.Runtime.CompilerServices.DecimalConstantAttribute::low
	int32_t ___low_4;

public:
	inline static int32_t get_offset_of_scale_0() { return static_cast<int32_t>(offsetof(DecimalConstantAttribute_t99985380, ___scale_0)); }
	inline uint8_t get_scale_0() const { return ___scale_0; }
	inline uint8_t* get_address_of_scale_0() { return &___scale_0; }
	inline void set_scale_0(uint8_t value)
	{
		___scale_0 = value;
	}

	inline static int32_t get_offset_of_sign_1() { return static_cast<int32_t>(offsetof(DecimalConstantAttribute_t99985380, ___sign_1)); }
	inline bool get_sign_1() const { return ___sign_1; }
	inline bool* get_address_of_sign_1() { return &___sign_1; }
	inline void set_sign_1(bool value)
	{
		___sign_1 = value;
	}

	inline static int32_t get_offset_of_hi_2() { return static_cast<int32_t>(offsetof(DecimalConstantAttribute_t99985380, ___hi_2)); }
	inline int32_t get_hi_2() const { return ___hi_2; }
	inline int32_t* get_address_of_hi_2() { return &___hi_2; }
	inline void set_hi_2(int32_t value)
	{
		___hi_2 = value;
	}

	inline static int32_t get_offset_of_mid_3() { return static_cast<int32_t>(offsetof(DecimalConstantAttribute_t99985380, ___mid_3)); }
	inline int32_t get_mid_3() const { return ___mid_3; }
	inline int32_t* get_address_of_mid_3() { return &___mid_3; }
	inline void set_mid_3(int32_t value)
	{
		___mid_3 = value;
	}

	inline static int32_t get_offset_of_low_4() { return static_cast<int32_t>(offsetof(DecimalConstantAttribute_t99985380, ___low_4)); }
	inline int32_t get_low_4() const { return ___low_4; }
	inline int32_t* get_address_of_low_4() { return &___low_4; }
	inline void set_low_4(int32_t value)
	{
		___low_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DECIMALCONSTANTATTRIBUTE_T99985380_H
#ifndef FLAGSATTRIBUTE_T2123170284_H
#define FLAGSATTRIBUTE_T2123170284_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.FlagsAttribute
struct  FlagsAttribute_t2123170284  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FLAGSATTRIBUTE_T2123170284_H
#ifndef ALLOWPARTIALLYTRUSTEDCALLERSATTRIBUTE_T2793852185_H
#define ALLOWPARTIALLYTRUSTEDCALLERSATTRIBUTE_T2793852185_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.AllowPartiallyTrustedCallersAttribute
struct  AllowPartiallyTrustedCallersAttribute_t2793852185  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ALLOWPARTIALLYTRUSTEDCALLERSATTRIBUTE_T2793852185_H
#ifndef REQUIREDBYNATIVECODEATTRIBUTE_T2920332526_H
#define REQUIREDBYNATIVECODEATTRIBUTE_T2920332526_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Scripting.RequiredByNativeCodeAttribute
struct  RequiredByNativeCodeAttribute_t2920332526  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REQUIREDBYNATIVECODEATTRIBUTE_T2920332526_H
#ifndef PARAMARRAYATTRIBUTE_T4148278418_H
#define PARAMARRAYATTRIBUTE_T4148278418_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ParamArrayAttribute
struct  ParamArrayAttribute_t4148278418  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMARRAYATTRIBUTE_T4148278418_H
#ifndef ENUM_T4088700107_H
#define ENUM_T4088700107_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t4088700107  : public ValueType_t3348802692
{
public:

public:
};

struct Enum_t4088700107_StaticFields
{
public:
	// System.Char[] System.Enum::split_char
	CharU5BU5D_t2816624037* ___split_char_0;

public:
	inline static int32_t get_offset_of_split_char_0() { return static_cast<int32_t>(offsetof(Enum_t4088700107_StaticFields, ___split_char_0)); }
	inline CharU5BU5D_t2816624037* get_split_char_0() const { return ___split_char_0; }
	inline CharU5BU5D_t2816624037** get_address_of_split_char_0() { return &___split_char_0; }
	inline void set_split_char_0(CharU5BU5D_t2816624037* value)
	{
		___split_char_0 = value;
		Il2CppCodeGenWriteBarrier((&___split_char_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t4088700107_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t4088700107_marshaled_com
{
};
#endif // ENUM_T4088700107_H
#ifndef ADDCOMPONENTMENU_T1949136625_H
#define ADDCOMPONENTMENU_T1949136625_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.AddComponentMenu
struct  AddComponentMenu_t1949136625  : public Attribute_t1821863933
{
public:
	// System.String UnityEngine.AddComponentMenu::m_AddComponentMenu
	String_t* ___m_AddComponentMenu_0;
	// System.Int32 UnityEngine.AddComponentMenu::m_Ordering
	int32_t ___m_Ordering_1;

public:
	inline static int32_t get_offset_of_m_AddComponentMenu_0() { return static_cast<int32_t>(offsetof(AddComponentMenu_t1949136625, ___m_AddComponentMenu_0)); }
	inline String_t* get_m_AddComponentMenu_0() const { return ___m_AddComponentMenu_0; }
	inline String_t** get_address_of_m_AddComponentMenu_0() { return &___m_AddComponentMenu_0; }
	inline void set_m_AddComponentMenu_0(String_t* value)
	{
		___m_AddComponentMenu_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_AddComponentMenu_0), value);
	}

	inline static int32_t get_offset_of_m_Ordering_1() { return static_cast<int32_t>(offsetof(AddComponentMenu_t1949136625, ___m_Ordering_1)); }
	inline int32_t get_m_Ordering_1() const { return ___m_Ordering_1; }
	inline int32_t* get_address_of_m_Ordering_1() { return &___m_Ordering_1; }
	inline void set_m_Ordering_1(int32_t value)
	{
		___m_Ordering_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ADDCOMPONENTMENU_T1949136625_H
#ifndef FORMERLYSERIALIZEDASATTRIBUTE_T153867989_H
#define FORMERLYSERIALIZEDASATTRIBUTE_T153867989_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Serialization.FormerlySerializedAsAttribute
struct  FormerlySerializedAsAttribute_t153867989  : public Attribute_t1821863933
{
public:
	// System.String UnityEngine.Serialization.FormerlySerializedAsAttribute::m_oldName
	String_t* ___m_oldName_0;

public:
	inline static int32_t get_offset_of_m_oldName_0() { return static_cast<int32_t>(offsetof(FormerlySerializedAsAttribute_t153867989, ___m_oldName_0)); }
	inline String_t* get_m_oldName_0() const { return ___m_oldName_0; }
	inline String_t** get_address_of_m_oldName_0() { return &___m_oldName_0; }
	inline void set_m_oldName_0(String_t* value)
	{
		___m_oldName_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_oldName_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FORMERLYSERIALIZEDASATTRIBUTE_T153867989_H
#ifndef SERIALIZEFIELD_T1114448220_H
#define SERIALIZEFIELD_T1114448220_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.SerializeField
struct  SerializeField_t1114448220  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SERIALIZEFIELD_T1114448220_H
#ifndef NATIVECLASSATTRIBUTE_T3768029985_H
#define NATIVECLASSATTRIBUTE_T3768029985_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.NativeClassAttribute
struct  NativeClassAttribute_t3768029985  : public Attribute_t1821863933
{
public:
	// System.String UnityEngine.NativeClassAttribute::<QualifiedNativeName>k__BackingField
	String_t* ___U3CQualifiedNativeNameU3Ek__BackingField_0;

public:
	inline static int32_t get_offset_of_U3CQualifiedNativeNameU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(NativeClassAttribute_t3768029985, ___U3CQualifiedNativeNameU3Ek__BackingField_0)); }
	inline String_t* get_U3CQualifiedNativeNameU3Ek__BackingField_0() const { return ___U3CQualifiedNativeNameU3Ek__BackingField_0; }
	inline String_t** get_address_of_U3CQualifiedNativeNameU3Ek__BackingField_0() { return &___U3CQualifiedNativeNameU3Ek__BackingField_0; }
	inline void set_U3CQualifiedNativeNameU3Ek__BackingField_0(String_t* value)
	{
		___U3CQualifiedNativeNameU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CQualifiedNativeNameU3Ek__BackingField_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVECLASSATTRIBUTE_T3768029985_H
#ifndef DEFAULTVALUEATTRIBUTE_T1239497132_H
#define DEFAULTVALUEATTRIBUTE_T1239497132_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Internal.DefaultValueAttribute
struct  DefaultValueAttribute_t1239497132  : public Attribute_t1821863933
{
public:
	// System.Object UnityEngine.Internal.DefaultValueAttribute::DefaultValue
	RuntimeObject * ___DefaultValue_0;

public:
	inline static int32_t get_offset_of_DefaultValue_0() { return static_cast<int32_t>(offsetof(DefaultValueAttribute_t1239497132, ___DefaultValue_0)); }
	inline RuntimeObject * get_DefaultValue_0() const { return ___DefaultValue_0; }
	inline RuntimeObject ** get_address_of_DefaultValue_0() { return &___DefaultValue_0; }
	inline void set_DefaultValue_0(RuntimeObject * value)
	{
		___DefaultValue_0 = value;
		Il2CppCodeGenWriteBarrier((&___DefaultValue_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEFAULTVALUEATTRIBUTE_T1239497132_H
#ifndef EXTENSIONATTRIBUTE_T36176176_H
#define EXTENSIONATTRIBUTE_T36176176_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.CompilerServices.ExtensionAttribute
struct  ExtensionAttribute_t36176176  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXTENSIONATTRIBUTE_T36176176_H
#ifndef EXCLUDEFROMDOCSATTRIBUTE_T2642155980_H
#define EXCLUDEFROMDOCSATTRIBUTE_T2642155980_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Internal.ExcludeFromDocsAttribute
struct  ExcludeFromDocsAttribute_t2642155980  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXCLUDEFROMDOCSATTRIBUTE_T2642155980_H
#ifndef TYPEINFERENCERULEATTRIBUTE_T1237727610_H
#define TYPEINFERENCERULEATTRIBUTE_T1237727610_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngineInternal.TypeInferenceRuleAttribute
struct  TypeInferenceRuleAttribute_t1237727610  : public Attribute_t1821863933
{
public:
	// System.String UnityEngineInternal.TypeInferenceRuleAttribute::_rule
	String_t* ____rule_0;

public:
	inline static int32_t get_offset_of__rule_0() { return static_cast<int32_t>(offsetof(TypeInferenceRuleAttribute_t1237727610, ____rule_0)); }
	inline String_t* get__rule_0() const { return ____rule_0; }
	inline String_t** get_address_of__rule_0() { return &____rule_0; }
	inline void set__rule_0(String_t* value)
	{
		____rule_0 = value;
		Il2CppCodeGenWriteBarrier((&____rule_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPEINFERENCERULEATTRIBUTE_T1237727610_H
#ifndef REQUIRECOMPONENT_T2231837482_H
#define REQUIRECOMPONENT_T2231837482_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RequireComponent
struct  RequireComponent_t2231837482  : public Attribute_t1821863933
{
public:
	// System.Type UnityEngine.RequireComponent::m_Type0
	Type_t * ___m_Type0_0;
	// System.Type UnityEngine.RequireComponent::m_Type1
	Type_t * ___m_Type1_1;
	// System.Type UnityEngine.RequireComponent::m_Type2
	Type_t * ___m_Type2_2;

public:
	inline static int32_t get_offset_of_m_Type0_0() { return static_cast<int32_t>(offsetof(RequireComponent_t2231837482, ___m_Type0_0)); }
	inline Type_t * get_m_Type0_0() const { return ___m_Type0_0; }
	inline Type_t ** get_address_of_m_Type0_0() { return &___m_Type0_0; }
	inline void set_m_Type0_0(Type_t * value)
	{
		___m_Type0_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Type0_0), value);
	}

	inline static int32_t get_offset_of_m_Type1_1() { return static_cast<int32_t>(offsetof(RequireComponent_t2231837482, ___m_Type1_1)); }
	inline Type_t * get_m_Type1_1() const { return ___m_Type1_1; }
	inline Type_t ** get_address_of_m_Type1_1() { return &___m_Type1_1; }
	inline void set_m_Type1_1(Type_t * value)
	{
		___m_Type1_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_Type1_1), value);
	}

	inline static int32_t get_offset_of_m_Type2_2() { return static_cast<int32_t>(offsetof(RequireComponent_t2231837482, ___m_Type2_2)); }
	inline Type_t * get_m_Type2_2() const { return ___m_Type2_2; }
	inline Type_t ** get_address_of_m_Type2_2() { return &___m_Type2_2; }
	inline void set_m_Type2_2(Type_t * value)
	{
		___m_Type2_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_Type2_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REQUIRECOMPONENT_T2231837482_H
#ifndef USEDBYNATIVECODEATTRIBUTE_T2042968054_H
#define USEDBYNATIVECODEATTRIBUTE_T2042968054_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Scripting.UsedByNativeCodeAttribute
struct  UsedByNativeCodeAttribute_t2042968054  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // USEDBYNATIVECODEATTRIBUTE_T2042968054_H
#ifndef WRITABLEATTRIBUTE_T718555548_H
#define WRITABLEATTRIBUTE_T718555548_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.WritableAttribute
struct  WritableAttribute_t718555548  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WRITABLEATTRIBUTE_T718555548_H
#ifndef THREADANDSERIALIZATIONSAFEATTRIBUTE_T401734977_H
#define THREADANDSERIALIZATIONSAFEATTRIBUTE_T401734977_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.ThreadAndSerializationSafeAttribute
struct  ThreadAndSerializationSafeAttribute_t401734977  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // THREADANDSERIALIZATIONSAFEATTRIBUTE_T401734977_H
#ifndef GENERATEDBYOLDBINDINGSGENERATORATTRIBUTE_T1890141928_H
#define GENERATEDBYOLDBINDINGSGENERATORATTRIBUTE_T1890141928_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Scripting.GeneratedByOldBindingsGeneratorAttribute
struct  GeneratedByOldBindingsGeneratorAttribute_t1890141928  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GENERATEDBYOLDBINDINGSGENERATORATTRIBUTE_T1890141928_H
#ifndef SECURITYSAFECRITICALATTRIBUTE_T3761815145_H
#define SECURITYSAFECRITICALATTRIBUTE_T3761815145_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.SecuritySafeCriticalAttribute
struct  SecuritySafeCriticalAttribute_t3761815145  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SECURITYSAFECRITICALATTRIBUTE_T3761815145_H
#ifndef DEFAULTMEMBERATTRIBUTE_T296450964_H
#define DEFAULTMEMBERATTRIBUTE_T296450964_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.DefaultMemberAttribute
struct  DefaultMemberAttribute_t296450964  : public Attribute_t1821863933
{
public:
	// System.String System.Reflection.DefaultMemberAttribute::member_name
	String_t* ___member_name_0;

public:
	inline static int32_t get_offset_of_member_name_0() { return static_cast<int32_t>(offsetof(DefaultMemberAttribute_t296450964, ___member_name_0)); }
	inline String_t* get_member_name_0() const { return ___member_name_0; }
	inline String_t** get_address_of_member_name_0() { return &___member_name_0; }
	inline void set_member_name_0(String_t* value)
	{
		___member_name_0 = value;
		Il2CppCodeGenWriteBarrier((&___member_name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEFAULTMEMBERATTRIBUTE_T296450964_H
#ifndef DEBUGGERHIDDENATTRIBUTE_T177041199_H
#define DEBUGGERHIDDENATTRIBUTE_T177041199_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Diagnostics.DebuggerHiddenAttribute
struct  DebuggerHiddenAttribute_t177041199  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEBUGGERHIDDENATTRIBUTE_T177041199_H
#ifndef ASSEMBLYTITLEATTRIBUTE_T4032010531_H
#define ASSEMBLYTITLEATTRIBUTE_T4032010531_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyTitleAttribute
struct  AssemblyTitleAttribute_t4032010531  : public Attribute_t1821863933
{
public:
	// System.String System.Reflection.AssemblyTitleAttribute::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(AssemblyTitleAttribute_t4032010531, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYTITLEATTRIBUTE_T4032010531_H
#ifndef COMPILATIONRELAXATIONSATTRIBUTE_T2092844809_H
#define COMPILATIONRELAXATIONSATTRIBUTE_T2092844809_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.CompilerServices.CompilationRelaxationsAttribute
struct  CompilationRelaxationsAttribute_t2092844809  : public Attribute_t1821863933
{
public:
	// System.Int32 System.Runtime.CompilerServices.CompilationRelaxationsAttribute::relax
	int32_t ___relax_0;

public:
	inline static int32_t get_offset_of_relax_0() { return static_cast<int32_t>(offsetof(CompilationRelaxationsAttribute_t2092844809, ___relax_0)); }
	inline int32_t get_relax_0() const { return ___relax_0; }
	inline int32_t* get_address_of_relax_0() { return &___relax_0; }
	inline void set_relax_0(int32_t value)
	{
		___relax_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPILATIONRELAXATIONSATTRIBUTE_T2092844809_H
#ifndef COMVISIBLEATTRIBUTE_T3352689681_H
#define COMVISIBLEATTRIBUTE_T3352689681_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.ComVisibleAttribute
struct  ComVisibleAttribute_t3352689681  : public Attribute_t1821863933
{
public:
	// System.Boolean System.Runtime.InteropServices.ComVisibleAttribute::Visible
	bool ___Visible_0;

public:
	inline static int32_t get_offset_of_Visible_0() { return static_cast<int32_t>(offsetof(ComVisibleAttribute_t3352689681, ___Visible_0)); }
	inline bool get_Visible_0() const { return ___Visible_0; }
	inline bool* get_address_of_Visible_0() { return &___Visible_0; }
	inline void set_Visible_0(bool value)
	{
		___Visible_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMVISIBLEATTRIBUTE_T3352689681_H
#ifndef DISPIDATTRIBUTE_T3051066024_H
#define DISPIDATTRIBUTE_T3051066024_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.DispIdAttribute
struct  DispIdAttribute_t3051066024  : public Attribute_t1821863933
{
public:
	// System.Int32 System.Runtime.InteropServices.DispIdAttribute::id
	int32_t ___id_0;

public:
	inline static int32_t get_offset_of_id_0() { return static_cast<int32_t>(offsetof(DispIdAttribute_t3051066024, ___id_0)); }
	inline int32_t get_id_0() const { return ___id_0; }
	inline int32_t* get_address_of_id_0() { return &___id_0; }
	inline void set_id_0(int32_t value)
	{
		___id_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DISPIDATTRIBUTE_T3051066024_H
#ifndef ASSEMBLYDEFAULTALIASATTRIBUTE_T3813724156_H
#define ASSEMBLYDEFAULTALIASATTRIBUTE_T3813724156_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyDefaultAliasAttribute
struct  AssemblyDefaultAliasAttribute_t3813724156  : public Attribute_t1821863933
{
public:
	// System.String System.Reflection.AssemblyDefaultAliasAttribute::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(AssemblyDefaultAliasAttribute_t3813724156, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYDEFAULTALIASATTRIBUTE_T3813724156_H
#ifndef ASSEMBLYCOPYRIGHTATTRIBUTE_T4130653132_H
#define ASSEMBLYCOPYRIGHTATTRIBUTE_T4130653132_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyCopyrightAttribute
struct  AssemblyCopyrightAttribute_t4130653132  : public Attribute_t1821863933
{
public:
	// System.String System.Reflection.AssemblyCopyrightAttribute::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(AssemblyCopyrightAttribute_t4130653132, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYCOPYRIGHTATTRIBUTE_T4130653132_H
#ifndef ASSEMBLYINFORMATIONALVERSIONATTRIBUTE_T458211439_H
#define ASSEMBLYINFORMATIONALVERSIONATTRIBUTE_T458211439_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyInformationalVersionAttribute
struct  AssemblyInformationalVersionAttribute_t458211439  : public Attribute_t1821863933
{
public:
	// System.String System.Reflection.AssemblyInformationalVersionAttribute::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(AssemblyInformationalVersionAttribute_t458211439, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYINFORMATIONALVERSIONATTRIBUTE_T458211439_H
#ifndef SATELLITECONTRACTVERSIONATTRIBUTE_T3058788408_H
#define SATELLITECONTRACTVERSIONATTRIBUTE_T3058788408_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Resources.SatelliteContractVersionAttribute
struct  SatelliteContractVersionAttribute_t3058788408  : public Attribute_t1821863933
{
public:
	// System.Version System.Resources.SatelliteContractVersionAttribute::ver
	Version_t3942069453 * ___ver_0;

public:
	inline static int32_t get_offset_of_ver_0() { return static_cast<int32_t>(offsetof(SatelliteContractVersionAttribute_t3058788408, ___ver_0)); }
	inline Version_t3942069453 * get_ver_0() const { return ___ver_0; }
	inline Version_t3942069453 ** get_address_of_ver_0() { return &___ver_0; }
	inline void set_ver_0(Version_t3942069453 * value)
	{
		___ver_0 = value;
		Il2CppCodeGenWriteBarrier((&___ver_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SATELLITECONTRACTVERSIONATTRIBUTE_T3058788408_H
#ifndef ASSEMBLYDESCRIPTIONATTRIBUTE_T1377417777_H
#define ASSEMBLYDESCRIPTIONATTRIBUTE_T1377417777_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyDescriptionAttribute
struct  AssemblyDescriptionAttribute_t1377417777  : public Attribute_t1821863933
{
public:
	// System.String System.Reflection.AssemblyDescriptionAttribute::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(AssemblyDescriptionAttribute_t1377417777, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYDESCRIPTIONATTRIBUTE_T1377417777_H
#ifndef ASSEMBLYPRODUCTATTRIBUTE_T3079866486_H
#define ASSEMBLYPRODUCTATTRIBUTE_T3079866486_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyProductAttribute
struct  AssemblyProductAttribute_t3079866486  : public Attribute_t1821863933
{
public:
	// System.String System.Reflection.AssemblyProductAttribute::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(AssemblyProductAttribute_t3079866486, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYPRODUCTATTRIBUTE_T3079866486_H
#ifndef RUNTIMECOMPATIBILITYATTRIBUTE_T2873331073_H
#define RUNTIMECOMPATIBILITYATTRIBUTE_T2873331073_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.CompilerServices.RuntimeCompatibilityAttribute
struct  RuntimeCompatibilityAttribute_t2873331073  : public Attribute_t1821863933
{
public:
	// System.Boolean System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::wrap_non_exception_throws
	bool ___wrap_non_exception_throws_0;

public:
	inline static int32_t get_offset_of_wrap_non_exception_throws_0() { return static_cast<int32_t>(offsetof(RuntimeCompatibilityAttribute_t2873331073, ___wrap_non_exception_throws_0)); }
	inline bool get_wrap_non_exception_throws_0() const { return ___wrap_non_exception_throws_0; }
	inline bool* get_address_of_wrap_non_exception_throws_0() { return &___wrap_non_exception_throws_0; }
	inline void set_wrap_non_exception_throws_0(bool value)
	{
		___wrap_non_exception_throws_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMECOMPATIBILITYATTRIBUTE_T2873331073_H
#ifndef ASSEMBLYDELAYSIGNATTRIBUTE_T1388804811_H
#define ASSEMBLYDELAYSIGNATTRIBUTE_T1388804811_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyDelaySignAttribute
struct  AssemblyDelaySignAttribute_t1388804811  : public Attribute_t1821863933
{
public:
	// System.Boolean System.Reflection.AssemblyDelaySignAttribute::delay
	bool ___delay_0;

public:
	inline static int32_t get_offset_of_delay_0() { return static_cast<int32_t>(offsetof(AssemblyDelaySignAttribute_t1388804811, ___delay_0)); }
	inline bool get_delay_0() const { return ___delay_0; }
	inline bool* get_address_of_delay_0() { return &___delay_0; }
	inline void set_delay_0(bool value)
	{
		___delay_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYDELAYSIGNATTRIBUTE_T1388804811_H
#ifndef CLSCOMPLIANTATTRIBUTE_T3606053525_H
#define CLSCOMPLIANTATTRIBUTE_T3606053525_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.CLSCompliantAttribute
struct  CLSCompliantAttribute_t3606053525  : public Attribute_t1821863933
{
public:
	// System.Boolean System.CLSCompliantAttribute::is_compliant
	bool ___is_compliant_0;

public:
	inline static int32_t get_offset_of_is_compliant_0() { return static_cast<int32_t>(offsetof(CLSCompliantAttribute_t3606053525, ___is_compliant_0)); }
	inline bool get_is_compliant_0() const { return ___is_compliant_0; }
	inline bool* get_address_of_is_compliant_0() { return &___is_compliant_0; }
	inline void set_is_compliant_0(bool value)
	{
		___is_compliant_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CLSCOMPLIANTATTRIBUTE_T3606053525_H
#ifndef NEUTRALRESOURCESLANGUAGEATTRIBUTE_T2573722287_H
#define NEUTRALRESOURCESLANGUAGEATTRIBUTE_T2573722287_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Resources.NeutralResourcesLanguageAttribute
struct  NeutralResourcesLanguageAttribute_t2573722287  : public Attribute_t1821863933
{
public:
	// System.String System.Resources.NeutralResourcesLanguageAttribute::culture
	String_t* ___culture_0;

public:
	inline static int32_t get_offset_of_culture_0() { return static_cast<int32_t>(offsetof(NeutralResourcesLanguageAttribute_t2573722287, ___culture_0)); }
	inline String_t* get_culture_0() const { return ___culture_0; }
	inline String_t** get_address_of_culture_0() { return &___culture_0; }
	inline void set_culture_0(String_t* value)
	{
		___culture_0 = value;
		Il2CppCodeGenWriteBarrier((&___culture_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NEUTRALRESOURCESLANGUAGEATTRIBUTE_T2573722287_H
#ifndef STRINGFREEZINGATTRIBUTE_T10408148_H
#define STRINGFREEZINGATTRIBUTE_T10408148_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.CompilerServices.StringFreezingAttribute
struct  StringFreezingAttribute_t10408148  : public Attribute_t1821863933
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRINGFREEZINGATTRIBUTE_T10408148_H
#ifndef ASSEMBLYCOMPANYATTRIBUTE_T262073538_H
#define ASSEMBLYCOMPANYATTRIBUTE_T262073538_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyCompanyAttribute
struct  AssemblyCompanyAttribute_t262073538  : public Attribute_t1821863933
{
public:
	// System.String System.Reflection.AssemblyCompanyAttribute::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(AssemblyCompanyAttribute_t262073538, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYCOMPANYATTRIBUTE_T262073538_H
#ifndef TYPELIBVERSIONATTRIBUTE_T3563874934_H
#define TYPELIBVERSIONATTRIBUTE_T3563874934_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.TypeLibVersionAttribute
struct  TypeLibVersionAttribute_t3563874934  : public Attribute_t1821863933
{
public:
	// System.Int32 System.Runtime.InteropServices.TypeLibVersionAttribute::major
	int32_t ___major_0;
	// System.Int32 System.Runtime.InteropServices.TypeLibVersionAttribute::minor
	int32_t ___minor_1;

public:
	inline static int32_t get_offset_of_major_0() { return static_cast<int32_t>(offsetof(TypeLibVersionAttribute_t3563874934, ___major_0)); }
	inline int32_t get_major_0() const { return ___major_0; }
	inline int32_t* get_address_of_major_0() { return &___major_0; }
	inline void set_major_0(int32_t value)
	{
		___major_0 = value;
	}

	inline static int32_t get_offset_of_minor_1() { return static_cast<int32_t>(offsetof(TypeLibVersionAttribute_t3563874934, ___minor_1)); }
	inline int32_t get_minor_1() const { return ___minor_1; }
	inline int32_t* get_address_of_minor_1() { return &___minor_1; }
	inline void set_minor_1(int32_t value)
	{
		___minor_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPELIBVERSIONATTRIBUTE_T3563874934_H
#ifndef GUIDATTRIBUTE_T3287193793_H
#define GUIDATTRIBUTE_T3287193793_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.GuidAttribute
struct  GuidAttribute_t3287193793  : public Attribute_t1821863933
{
public:
	// System.String System.Runtime.InteropServices.GuidAttribute::guidValue
	String_t* ___guidValue_0;

public:
	inline static int32_t get_offset_of_guidValue_0() { return static_cast<int32_t>(offsetof(GuidAttribute_t3287193793, ___guidValue_0)); }
	inline String_t* get_guidValue_0() const { return ___guidValue_0; }
	inline String_t** get_address_of_guidValue_0() { return &___guidValue_0; }
	inline void set_guidValue_0(String_t* value)
	{
		___guidValue_0 = value;
		Il2CppCodeGenWriteBarrier((&___guidValue_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GUIDATTRIBUTE_T3287193793_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	IntPtr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline IntPtr_t get_Zero_1() const { return ___Zero_1; }
	inline IntPtr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(IntPtr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef TYPELIBIMPORTCLASSATTRIBUTE_T2161063924_H
#define TYPELIBIMPORTCLASSATTRIBUTE_T2161063924_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.TypeLibImportClassAttribute
struct  TypeLibImportClassAttribute_t2161063924  : public Attribute_t1821863933
{
public:
	// System.String System.Runtime.InteropServices.TypeLibImportClassAttribute::_importClass
	String_t* ____importClass_0;

public:
	inline static int32_t get_offset_of__importClass_0() { return static_cast<int32_t>(offsetof(TypeLibImportClassAttribute_t2161063924, ____importClass_0)); }
	inline String_t* get__importClass_0() const { return ____importClass_0; }
	inline String_t** get_address_of__importClass_0() { return &____importClass_0; }
	inline void set__importClass_0(String_t* value)
	{
		____importClass_0 = value;
		Il2CppCodeGenWriteBarrier((&____importClass_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPELIBIMPORTCLASSATTRIBUTE_T2161063924_H
#ifndef ASSEMBLYKEYFILEATTRIBUTE_T756954830_H
#define ASSEMBLYKEYFILEATTRIBUTE_T756954830_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyKeyFileAttribute
struct  AssemblyKeyFileAttribute_t756954830  : public Attribute_t1821863933
{
public:
	// System.String System.Reflection.AssemblyKeyFileAttribute::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(AssemblyKeyFileAttribute_t756954830, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYKEYFILEATTRIBUTE_T756954830_H
#ifndef COMDEFAULTINTERFACEATTRIBUTE_T2824514219_H
#define COMDEFAULTINTERFACEATTRIBUTE_T2824514219_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.ComDefaultInterfaceAttribute
struct  ComDefaultInterfaceAttribute_t2824514219  : public Attribute_t1821863933
{
public:
	// System.Type System.Runtime.InteropServices.ComDefaultInterfaceAttribute::_type
	Type_t * ____type_0;

public:
	inline static int32_t get_offset_of__type_0() { return static_cast<int32_t>(offsetof(ComDefaultInterfaceAttribute_t2824514219, ____type_0)); }
	inline Type_t * get__type_0() const { return ____type_0; }
	inline Type_t ** get_address_of__type_0() { return &____type_0; }
	inline void set__type_0(Type_t * value)
	{
		____type_0 = value;
		Il2CppCodeGenWriteBarrier((&____type_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMDEFAULTINTERFACEATTRIBUTE_T2824514219_H
#ifndef COMINTERFACETYPE_T2020494956_H
#define COMINTERFACETYPE_T2020494956_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.ComInterfaceType
struct  ComInterfaceType_t2020494956 
{
public:
	// System.Int32 System.Runtime.InteropServices.ComInterfaceType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ComInterfaceType_t2020494956, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMINTERFACETYPE_T2020494956_H
#ifndef ATTRIBUTETARGETS_T1409711436_H
#define ATTRIBUTETARGETS_T1409711436_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.AttributeTargets
struct  AttributeTargets_t1409711436 
{
public:
	// System.Int32 System.AttributeTargets::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AttributeTargets_t1409711436, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ATTRIBUTETARGETS_T1409711436_H
#ifndef EDITORBROWSABLESTATE_T2901581142_H
#define EDITORBROWSABLESTATE_T2901581142_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ComponentModel.EditorBrowsableState
struct  EditorBrowsableState_t2901581142 
{
public:
	// System.Int32 System.ComponentModel.EditorBrowsableState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(EditorBrowsableState_t2901581142, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EDITORBROWSABLESTATE_T2901581142_H
#ifndef MONODOCUMENTATIONNOTEATTRIBUTE_T3523980758_H
#define MONODOCUMENTATIONNOTEATTRIBUTE_T3523980758_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MonoDocumentationNoteAttribute
struct  MonoDocumentationNoteAttribute_t3523980758  : public MonoTODOAttribute_t119123862
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONODOCUMENTATIONNOTEATTRIBUTE_T3523980758_H
#ifndef CER_T2084220006_H
#define CER_T2084220006_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.ConstrainedExecution.Cer
struct  Cer_t2084220006 
{
public:
	// System.Int32 System.Runtime.ConstrainedExecution.Cer::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(Cer_t2084220006, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CER_T2084220006_H
#ifndef CALLINGCONVENTION_T4277045988_H
#define CALLINGCONVENTION_T4277045988_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.CallingConvention
struct  CallingConvention_t4277045988 
{
public:
	// System.Int32 System.Runtime.InteropServices.CallingConvention::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CallingConvention_t4277045988, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLINGCONVENTION_T4277045988_H
#ifndef CONSISTENCY_T2404635052_H
#define CONSISTENCY_T2404635052_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.ConstrainedExecution.Consistency
struct  Consistency_t2404635052 
{
public:
	// System.Int32 System.Runtime.ConstrainedExecution.Consistency::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(Consistency_t2404635052, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONSISTENCY_T2404635052_H
#ifndef BINDINGFLAGS_T2634920058_H
#define BINDINGFLAGS_T2634920058_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.BindingFlags
struct  BindingFlags_t2634920058 
{
public:
	// System.Int32 System.Reflection.BindingFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(BindingFlags_t2634920058, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BINDINGFLAGS_T2634920058_H
#ifndef CLASSINTERFACETYPE_T3029378045_H
#define CLASSINTERFACETYPE_T3029378045_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.ClassInterfaceType
struct  ClassInterfaceType_t3029378045 
{
public:
	// System.Int32 System.Runtime.InteropServices.ClassInterfaceType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ClassInterfaceType_t3029378045, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CLASSINTERFACETYPE_T3029378045_H
#ifndef RUNTIMETYPEHANDLE_T1361003276_H
#define RUNTIMETYPEHANDLE_T1361003276_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.RuntimeTypeHandle
struct  RuntimeTypeHandle_t1361003276 
{
public:
	// System.IntPtr System.RuntimeTypeHandle::value
	IntPtr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeTypeHandle_t1361003276, ___value_0)); }
	inline IntPtr_t get_value_0() const { return ___value_0; }
	inline IntPtr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(IntPtr_t value)
	{
		___value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMETYPEHANDLE_T1361003276_H
#ifndef COMPILATIONRELAXATIONS_T4165277783_H
#define COMPILATIONRELAXATIONS_T4165277783_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.CompilerServices.CompilationRelaxations
struct  CompilationRelaxations_t4165277783 
{
public:
	// System.Int32 System.Runtime.CompilerServices.CompilationRelaxations::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CompilationRelaxations_t4165277783, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPILATIONRELAXATIONS_T4165277783_H
#ifndef LOADHINT_T1452053703_H
#define LOADHINT_T1452053703_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.CompilerServices.LoadHint
struct  LoadHint_t1452053703 
{
public:
	// System.Int32 System.Runtime.CompilerServices.LoadHint::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(LoadHint_t1452053703, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOADHINT_T1452053703_H
#ifndef DEBUGGINGMODES_T1865971622_H
#define DEBUGGINGMODES_T1865971622_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Diagnostics.DebuggableAttribute/DebuggingModes
struct  DebuggingModes_t1865971622 
{
public:
	// System.Int32 System.Diagnostics.DebuggableAttribute/DebuggingModes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(DebuggingModes_t1865971622, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEBUGGINGMODES_T1865971622_H
#ifndef SECURITYCRITICALSCOPE_T1525069347_H
#define SECURITYCRITICALSCOPE_T1525069347_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.SecurityCriticalScope
struct  SecurityCriticalScope_t1525069347 
{
public:
	// System.Int32 System.Security.SecurityCriticalScope::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(SecurityCriticalScope_t1525069347, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SECURITYCRITICALSCOPE_T1525069347_H
#ifndef DEBUGGERBROWSABLESTATE_T853783821_H
#define DEBUGGERBROWSABLESTATE_T853783821_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Diagnostics.DebuggerBrowsableState
struct  DebuggerBrowsableState_t853783821 
{
public:
	// System.Int32 System.Diagnostics.DebuggerBrowsableState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(DebuggerBrowsableState_t853783821, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEBUGGERBROWSABLESTATE_T853783821_H
#ifndef TYPEINFERENCERULES_T4144211626_H
#define TYPEINFERENCERULES_T4144211626_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngineInternal.TypeInferenceRules
struct  TypeInferenceRules_t4144211626 
{
public:
	// System.Int32 UnityEngineInternal.TypeInferenceRules::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TypeInferenceRules_t4144211626, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPEINFERENCERULES_T4144211626_H
#ifndef DEBUGGABLEATTRIBUTE_T2636756938_H
#define DEBUGGABLEATTRIBUTE_T2636756938_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Diagnostics.DebuggableAttribute
struct  DebuggableAttribute_t2636756938  : public Attribute_t1821863933
{
public:
	// System.Boolean System.Diagnostics.DebuggableAttribute::JITTrackingEnabledFlag
	bool ___JITTrackingEnabledFlag_0;
	// System.Boolean System.Diagnostics.DebuggableAttribute::JITOptimizerDisabledFlag
	bool ___JITOptimizerDisabledFlag_1;
	// System.Diagnostics.DebuggableAttribute/DebuggingModes System.Diagnostics.DebuggableAttribute::debuggingModes
	int32_t ___debuggingModes_2;

public:
	inline static int32_t get_offset_of_JITTrackingEnabledFlag_0() { return static_cast<int32_t>(offsetof(DebuggableAttribute_t2636756938, ___JITTrackingEnabledFlag_0)); }
	inline bool get_JITTrackingEnabledFlag_0() const { return ___JITTrackingEnabledFlag_0; }
	inline bool* get_address_of_JITTrackingEnabledFlag_0() { return &___JITTrackingEnabledFlag_0; }
	inline void set_JITTrackingEnabledFlag_0(bool value)
	{
		___JITTrackingEnabledFlag_0 = value;
	}

	inline static int32_t get_offset_of_JITOptimizerDisabledFlag_1() { return static_cast<int32_t>(offsetof(DebuggableAttribute_t2636756938, ___JITOptimizerDisabledFlag_1)); }
	inline bool get_JITOptimizerDisabledFlag_1() const { return ___JITOptimizerDisabledFlag_1; }
	inline bool* get_address_of_JITOptimizerDisabledFlag_1() { return &___JITOptimizerDisabledFlag_1; }
	inline void set_JITOptimizerDisabledFlag_1(bool value)
	{
		___JITOptimizerDisabledFlag_1 = value;
	}

	inline static int32_t get_offset_of_debuggingModes_2() { return static_cast<int32_t>(offsetof(DebuggableAttribute_t2636756938, ___debuggingModes_2)); }
	inline int32_t get_debuggingModes_2() const { return ___debuggingModes_2; }
	inline int32_t* get_address_of_debuggingModes_2() { return &___debuggingModes_2; }
	inline void set_debuggingModes_2(int32_t value)
	{
		___debuggingModes_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEBUGGABLEATTRIBUTE_T2636756938_H
#ifndef INTERFACETYPEATTRIBUTE_T931938199_H
#define INTERFACETYPEATTRIBUTE_T931938199_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.InterfaceTypeAttribute
struct  InterfaceTypeAttribute_t931938199  : public Attribute_t1821863933
{
public:
	// System.Runtime.InteropServices.ComInterfaceType System.Runtime.InteropServices.InterfaceTypeAttribute::intType
	int32_t ___intType_0;

public:
	inline static int32_t get_offset_of_intType_0() { return static_cast<int32_t>(offsetof(InterfaceTypeAttribute_t931938199, ___intType_0)); }
	inline int32_t get_intType_0() const { return ___intType_0; }
	inline int32_t* get_address_of_intType_0() { return &___intType_0; }
	inline void set_intType_0(int32_t value)
	{
		___intType_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTERFACETYPEATTRIBUTE_T931938199_H
#ifndef EDITORBROWSABLEATTRIBUTE_T1429620940_H
#define EDITORBROWSABLEATTRIBUTE_T1429620940_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ComponentModel.EditorBrowsableAttribute
struct  EditorBrowsableAttribute_t1429620940  : public Attribute_t1821863933
{
public:
	// System.ComponentModel.EditorBrowsableState System.ComponentModel.EditorBrowsableAttribute::state
	int32_t ___state_0;

public:
	inline static int32_t get_offset_of_state_0() { return static_cast<int32_t>(offsetof(EditorBrowsableAttribute_t1429620940, ___state_0)); }
	inline int32_t get_state_0() const { return ___state_0; }
	inline int32_t* get_address_of_state_0() { return &___state_0; }
	inline void set_state_0(int32_t value)
	{
		___state_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EDITORBROWSABLEATTRIBUTE_T1429620940_H
#ifndef UNMANAGEDFUNCTIONPOINTERATTRIBUTE_T3672379452_H
#define UNMANAGEDFUNCTIONPOINTERATTRIBUTE_T3672379452_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.UnmanagedFunctionPointerAttribute
struct  UnmanagedFunctionPointerAttribute_t3672379452  : public Attribute_t1821863933
{
public:
	// System.Runtime.InteropServices.CallingConvention System.Runtime.InteropServices.UnmanagedFunctionPointerAttribute::call_conv
	int32_t ___call_conv_0;

public:
	inline static int32_t get_offset_of_call_conv_0() { return static_cast<int32_t>(offsetof(UnmanagedFunctionPointerAttribute_t3672379452, ___call_conv_0)); }
	inline int32_t get_call_conv_0() const { return ___call_conv_0; }
	inline int32_t* get_address_of_call_conv_0() { return &___call_conv_0; }
	inline void set_call_conv_0(int32_t value)
	{
		___call_conv_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNMANAGEDFUNCTIONPOINTERATTRIBUTE_T3672379452_H
#ifndef DEFAULTDEPENDENCYATTRIBUTE_T547142461_H
#define DEFAULTDEPENDENCYATTRIBUTE_T547142461_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.CompilerServices.DefaultDependencyAttribute
struct  DefaultDependencyAttribute_t547142461  : public Attribute_t1821863933
{
public:
	// System.Runtime.CompilerServices.LoadHint System.Runtime.CompilerServices.DefaultDependencyAttribute::hint
	int32_t ___hint_0;

public:
	inline static int32_t get_offset_of_hint_0() { return static_cast<int32_t>(offsetof(DefaultDependencyAttribute_t547142461, ___hint_0)); }
	inline int32_t get_hint_0() const { return ___hint_0; }
	inline int32_t* get_address_of_hint_0() { return &___hint_0; }
	inline void set_hint_0(int32_t value)
	{
		___hint_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEFAULTDEPENDENCYATTRIBUTE_T547142461_H
#ifndef ATTRIBUTEUSAGEATTRIBUTE_T2106699225_H
#define ATTRIBUTEUSAGEATTRIBUTE_T2106699225_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.AttributeUsageAttribute
struct  AttributeUsageAttribute_t2106699225  : public Attribute_t1821863933
{
public:
	// System.AttributeTargets System.AttributeUsageAttribute::valid_on
	int32_t ___valid_on_0;
	// System.Boolean System.AttributeUsageAttribute::allow_multiple
	bool ___allow_multiple_1;
	// System.Boolean System.AttributeUsageAttribute::inherited
	bool ___inherited_2;

public:
	inline static int32_t get_offset_of_valid_on_0() { return static_cast<int32_t>(offsetof(AttributeUsageAttribute_t2106699225, ___valid_on_0)); }
	inline int32_t get_valid_on_0() const { return ___valid_on_0; }
	inline int32_t* get_address_of_valid_on_0() { return &___valid_on_0; }
	inline void set_valid_on_0(int32_t value)
	{
		___valid_on_0 = value;
	}

	inline static int32_t get_offset_of_allow_multiple_1() { return static_cast<int32_t>(offsetof(AttributeUsageAttribute_t2106699225, ___allow_multiple_1)); }
	inline bool get_allow_multiple_1() const { return ___allow_multiple_1; }
	inline bool* get_address_of_allow_multiple_1() { return &___allow_multiple_1; }
	inline void set_allow_multiple_1(bool value)
	{
		___allow_multiple_1 = value;
	}

	inline static int32_t get_offset_of_inherited_2() { return static_cast<int32_t>(offsetof(AttributeUsageAttribute_t2106699225, ___inherited_2)); }
	inline bool get_inherited_2() const { return ___inherited_2; }
	inline bool* get_address_of_inherited_2() { return &___inherited_2; }
	inline void set_inherited_2(bool value)
	{
		___inherited_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ATTRIBUTEUSAGEATTRIBUTE_T2106699225_H
#ifndef RELIABILITYCONTRACTATTRIBUTE_T3660264932_H
#define RELIABILITYCONTRACTATTRIBUTE_T3660264932_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.ConstrainedExecution.ReliabilityContractAttribute
struct  ReliabilityContractAttribute_t3660264932  : public Attribute_t1821863933
{
public:
	// System.Runtime.ConstrainedExecution.Consistency System.Runtime.ConstrainedExecution.ReliabilityContractAttribute::consistency
	int32_t ___consistency_0;
	// System.Runtime.ConstrainedExecution.Cer System.Runtime.ConstrainedExecution.ReliabilityContractAttribute::cer
	int32_t ___cer_1;

public:
	inline static int32_t get_offset_of_consistency_0() { return static_cast<int32_t>(offsetof(ReliabilityContractAttribute_t3660264932, ___consistency_0)); }
	inline int32_t get_consistency_0() const { return ___consistency_0; }
	inline int32_t* get_address_of_consistency_0() { return &___consistency_0; }
	inline void set_consistency_0(int32_t value)
	{
		___consistency_0 = value;
	}

	inline static int32_t get_offset_of_cer_1() { return static_cast<int32_t>(offsetof(ReliabilityContractAttribute_t3660264932, ___cer_1)); }
	inline int32_t get_cer_1() const { return ___cer_1; }
	inline int32_t* get_address_of_cer_1() { return &___cer_1; }
	inline void set_cer_1(int32_t value)
	{
		___cer_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RELIABILITYCONTRACTATTRIBUTE_T3660264932_H
#ifndef CLASSINTERFACEATTRIBUTE_T1078708468_H
#define CLASSINTERFACEATTRIBUTE_T1078708468_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.ClassInterfaceAttribute
struct  ClassInterfaceAttribute_t1078708468  : public Attribute_t1821863933
{
public:
	// System.Runtime.InteropServices.ClassInterfaceType System.Runtime.InteropServices.ClassInterfaceAttribute::ciType
	int32_t ___ciType_0;

public:
	inline static int32_t get_offset_of_ciType_0() { return static_cast<int32_t>(offsetof(ClassInterfaceAttribute_t1078708468, ___ciType_0)); }
	inline int32_t get_ciType_0() const { return ___ciType_0; }
	inline int32_t* get_address_of_ciType_0() { return &___ciType_0; }
	inline void set_ciType_0(int32_t value)
	{
		___ciType_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CLASSINTERFACEATTRIBUTE_T1078708468_H
#ifndef SECURITYCRITICALATTRIBUTE_T4019023285_H
#define SECURITYCRITICALATTRIBUTE_T4019023285_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.SecurityCriticalAttribute
struct  SecurityCriticalAttribute_t4019023285  : public Attribute_t1821863933
{
public:
	// System.Security.SecurityCriticalScope System.Security.SecurityCriticalAttribute::_scope
	int32_t ____scope_0;

public:
	inline static int32_t get_offset_of__scope_0() { return static_cast<int32_t>(offsetof(SecurityCriticalAttribute_t4019023285, ____scope_0)); }
	inline int32_t get__scope_0() const { return ____scope_0; }
	inline int32_t* get_address_of__scope_0() { return &____scope_0; }
	inline void set__scope_0(int32_t value)
	{
		____scope_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SECURITYCRITICALATTRIBUTE_T4019023285_H
#ifndef TYPE_T_H
#define TYPE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Type
struct  Type_t  : public MemberInfo_t
{
public:
	// System.RuntimeTypeHandle System.Type::_impl
	RuntimeTypeHandle_t1361003276  ____impl_1;

public:
	inline static int32_t get_offset_of__impl_1() { return static_cast<int32_t>(offsetof(Type_t, ____impl_1)); }
	inline RuntimeTypeHandle_t1361003276  get__impl_1() const { return ____impl_1; }
	inline RuntimeTypeHandle_t1361003276 * get_address_of__impl_1() { return &____impl_1; }
	inline void set__impl_1(RuntimeTypeHandle_t1361003276  value)
	{
		____impl_1 = value;
	}
};

struct Type_t_StaticFields
{
public:
	// System.Char System.Type::Delimiter
	Il2CppChar ___Delimiter_2;
	// System.Type[] System.Type::EmptyTypes
	TypeU5BU5D_t1722708557* ___EmptyTypes_3;
	// System.Reflection.MemberFilter System.Type::FilterAttribute
	MemberFilter_t3088556475 * ___FilterAttribute_4;
	// System.Reflection.MemberFilter System.Type::FilterName
	MemberFilter_t3088556475 * ___FilterName_5;
	// System.Reflection.MemberFilter System.Type::FilterNameIgnoreCase
	MemberFilter_t3088556475 * ___FilterNameIgnoreCase_6;
	// System.Object System.Type::Missing
	RuntimeObject * ___Missing_7;

public:
	inline static int32_t get_offset_of_Delimiter_2() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___Delimiter_2)); }
	inline Il2CppChar get_Delimiter_2() const { return ___Delimiter_2; }
	inline Il2CppChar* get_address_of_Delimiter_2() { return &___Delimiter_2; }
	inline void set_Delimiter_2(Il2CppChar value)
	{
		___Delimiter_2 = value;
	}

	inline static int32_t get_offset_of_EmptyTypes_3() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___EmptyTypes_3)); }
	inline TypeU5BU5D_t1722708557* get_EmptyTypes_3() const { return ___EmptyTypes_3; }
	inline TypeU5BU5D_t1722708557** get_address_of_EmptyTypes_3() { return &___EmptyTypes_3; }
	inline void set_EmptyTypes_3(TypeU5BU5D_t1722708557* value)
	{
		___EmptyTypes_3 = value;
		Il2CppCodeGenWriteBarrier((&___EmptyTypes_3), value);
	}

	inline static int32_t get_offset_of_FilterAttribute_4() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterAttribute_4)); }
	inline MemberFilter_t3088556475 * get_FilterAttribute_4() const { return ___FilterAttribute_4; }
	inline MemberFilter_t3088556475 ** get_address_of_FilterAttribute_4() { return &___FilterAttribute_4; }
	inline void set_FilterAttribute_4(MemberFilter_t3088556475 * value)
	{
		___FilterAttribute_4 = value;
		Il2CppCodeGenWriteBarrier((&___FilterAttribute_4), value);
	}

	inline static int32_t get_offset_of_FilterName_5() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterName_5)); }
	inline MemberFilter_t3088556475 * get_FilterName_5() const { return ___FilterName_5; }
	inline MemberFilter_t3088556475 ** get_address_of_FilterName_5() { return &___FilterName_5; }
	inline void set_FilterName_5(MemberFilter_t3088556475 * value)
	{
		___FilterName_5 = value;
		Il2CppCodeGenWriteBarrier((&___FilterName_5), value);
	}

	inline static int32_t get_offset_of_FilterNameIgnoreCase_6() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___FilterNameIgnoreCase_6)); }
	inline MemberFilter_t3088556475 * get_FilterNameIgnoreCase_6() const { return ___FilterNameIgnoreCase_6; }
	inline MemberFilter_t3088556475 ** get_address_of_FilterNameIgnoreCase_6() { return &___FilterNameIgnoreCase_6; }
	inline void set_FilterNameIgnoreCase_6(MemberFilter_t3088556475 * value)
	{
		___FilterNameIgnoreCase_6 = value;
		Il2CppCodeGenWriteBarrier((&___FilterNameIgnoreCase_6), value);
	}

	inline static int32_t get_offset_of_Missing_7() { return static_cast<int32_t>(offsetof(Type_t_StaticFields, ___Missing_7)); }
	inline RuntimeObject * get_Missing_7() const { return ___Missing_7; }
	inline RuntimeObject ** get_address_of_Missing_7() { return &___Missing_7; }
	inline void set_Missing_7(RuntimeObject * value)
	{
		___Missing_7 = value;
		Il2CppCodeGenWriteBarrier((&___Missing_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPE_T_H
#ifndef DEBUGGERBROWSABLEATTRIBUTE_T182167257_H
#define DEBUGGERBROWSABLEATTRIBUTE_T182167257_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Diagnostics.DebuggerBrowsableAttribute
struct  DebuggerBrowsableAttribute_t182167257  : public Attribute_t1821863933
{
public:
	// System.Diagnostics.DebuggerBrowsableState System.Diagnostics.DebuggerBrowsableAttribute::state
	int32_t ___state_0;

public:
	inline static int32_t get_offset_of_state_0() { return static_cast<int32_t>(offsetof(DebuggerBrowsableAttribute_t182167257, ___state_0)); }
	inline int32_t get_state_0() const { return ___state_0; }
	inline int32_t* get_address_of_state_0() { return &___state_0; }
	inline void set_state_0(int32_t value)
	{
		___state_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEBUGGERBROWSABLEATTRIBUTE_T182167257_H



// System.Void System.Reflection.AssemblyFileVersionAttribute::.ctor(System.String)
extern "C"  void AssemblyFileVersionAttribute__ctor_m104636996 (AssemblyFileVersionAttribute_t1839628412 * __this, String_t* ___version0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Reflection.AssemblyCompanyAttribute::.ctor(System.String)
extern "C"  void AssemblyCompanyAttribute__ctor_m1961203133 (AssemblyCompanyAttribute_t262073538 * __this, String_t* ___company0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Diagnostics.DebuggableAttribute::.ctor(System.Diagnostics.DebuggableAttribute/DebuggingModes)
extern "C"  void DebuggableAttribute__ctor_m2582985872 (DebuggableAttribute_t2636756938 * __this, int32_t ___modes0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.CompilerServices.StringFreezingAttribute::.ctor()
extern "C"  void StringFreezingAttribute__ctor_m327960799 (StringFreezingAttribute_t10408148 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Resources.NeutralResourcesLanguageAttribute::.ctor(System.String)
extern "C"  void NeutralResourcesLanguageAttribute__ctor_m1705398382 (NeutralResourcesLanguageAttribute_t2573722287 * __this, String_t* ___cultureName0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.CLSCompliantAttribute::.ctor(System.Boolean)
extern "C"  void CLSCompliantAttribute__ctor_m737514648 (CLSCompliantAttribute_t3606053525 * __this, bool ___isCompliant0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Reflection.AssemblyDelaySignAttribute::.ctor(System.Boolean)
extern "C"  void AssemblyDelaySignAttribute__ctor_m792735968 (AssemblyDelaySignAttribute_t1388804811 * __this, bool ___delaySign0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.CompilerServices.DefaultDependencyAttribute::.ctor(System.Runtime.CompilerServices.LoadHint)
extern "C"  void DefaultDependencyAttribute__ctor_m2434010332 (DefaultDependencyAttribute_t547142461 * __this, int32_t ___loadHintArgument0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor()
extern "C"  void RuntimeCompatibilityAttribute__ctor_m1077459611 (RuntimeCompatibilityAttribute_t2873331073 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::set_WrapNonExceptionThrows(System.Boolean)
extern "C"  void RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2097818566 (RuntimeCompatibilityAttribute_t2873331073 * __this, bool ___value0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Reflection.AssemblyProductAttribute::.ctor(System.String)
extern "C"  void AssemblyProductAttribute__ctor_m2179734435 (AssemblyProductAttribute_t3079866486 * __this, String_t* ___product0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Reflection.AssemblyDescriptionAttribute::.ctor(System.String)
extern "C"  void AssemblyDescriptionAttribute__ctor_m863331373 (AssemblyDescriptionAttribute_t1377417777 * __this, String_t* ___description0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Resources.SatelliteContractVersionAttribute::.ctor(System.String)
extern "C"  void SatelliteContractVersionAttribute__ctor_m3848511474 (SatelliteContractVersionAttribute_t3058788408 * __this, String_t* ___version0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Reflection.AssemblyInformationalVersionAttribute::.ctor(System.String)
extern "C"  void AssemblyInformationalVersionAttribute__ctor_m2606705742 (AssemblyInformationalVersionAttribute_t458211439 * __this, String_t* ___informationalVersion0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Reflection.AssemblyCopyrightAttribute::.ctor(System.String)
extern "C"  void AssemblyCopyrightAttribute__ctor_m2442777966 (AssemblyCopyrightAttribute_t4130653132 * __this, String_t* ___copyright0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Reflection.AssemblyDefaultAliasAttribute::.ctor(System.String)
extern "C"  void AssemblyDefaultAliasAttribute__ctor_m1008481974 (AssemblyDefaultAliasAttribute_t3813724156 * __this, String_t* ___defaultAlias0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Reflection.AssemblyTitleAttribute::.ctor(System.String)
extern "C"  void AssemblyTitleAttribute__ctor_m2280157225 (AssemblyTitleAttribute_t4032010531 * __this, String_t* ___title0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.InteropServices.ComVisibleAttribute::.ctor(System.Boolean)
extern "C"  void ComVisibleAttribute__ctor_m3177107244 (ComVisibleAttribute_t3352689681 * __this, bool ___visibility0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(System.Runtime.CompilerServices.CompilationRelaxations)
extern "C"  void CompilationRelaxationsAttribute__ctor_m3343263694 (CompilationRelaxationsAttribute_t2092844809 * __this, int32_t ___relaxations0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.InteropServices.TypeLibVersionAttribute::.ctor(System.Int32,System.Int32)
extern "C"  void TypeLibVersionAttribute__ctor_m3709773259 (TypeLibVersionAttribute_t3563874934 * __this, int32_t ___major0, int32_t ___minor1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.InteropServices.GuidAttribute::.ctor(System.String)
extern "C"  void GuidAttribute__ctor_m2076129958 (GuidAttribute_t3287193793 * __this, String_t* ___guid0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Reflection.AssemblyKeyFileAttribute::.ctor(System.String)
extern "C"  void AssemblyKeyFileAttribute__ctor_m515360797 (AssemblyKeyFileAttribute_t756954830 * __this, String_t* ___keyFile0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(System.Runtime.InteropServices.ClassInterfaceType)
extern "C"  void ClassInterfaceAttribute__ctor_m1041561158 (ClassInterfaceAttribute_t1078708468 * __this, int32_t ___classInterfaceType0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.ConstrainedExecution.ReliabilityContractAttribute::.ctor(System.Runtime.ConstrainedExecution.Consistency,System.Runtime.ConstrainedExecution.Cer)
extern "C"  void ReliabilityContractAttribute__ctor_m1584311890 (ReliabilityContractAttribute_t3660264932 * __this, int32_t ___consistencyGuarantee0, int32_t ___cer1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.AttributeUsageAttribute::.ctor(System.AttributeTargets)
extern "C"  void AttributeUsageAttribute__ctor_m250482755 (AttributeUsageAttribute_t2106699225 * __this, int32_t ___validOn0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.InteropServices.ComDefaultInterfaceAttribute::.ctor(System.Type)
extern "C"  void ComDefaultInterfaceAttribute__ctor_m585413508 (ComDefaultInterfaceAttribute_t2824514219 * __this, Type_t * ___defaultInterface0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(System.Runtime.InteropServices.ComInterfaceType)
extern "C"  void InterfaceTypeAttribute__ctor_m458747174 (InterfaceTypeAttribute_t931938199 * __this, int32_t ___interfaceType0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.InteropServices.TypeLibImportClassAttribute::.ctor(System.Type)
extern "C"  void TypeLibImportClassAttribute__ctor_m1625403865 (TypeLibImportClassAttribute_t2161063924 * __this, Type_t * ___importClass0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.AttributeUsageAttribute::set_Inherited(System.Boolean)
extern "C"  void AttributeUsageAttribute_set_Inherited_m2568117843 (AttributeUsageAttribute_t2106699225 * __this, bool ___value0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.AttributeUsageAttribute::set_AllowMultiple(System.Boolean)
extern "C"  void AttributeUsageAttribute_set_AllowMultiple_m3716379228 (AttributeUsageAttribute_t2106699225 * __this, bool ___value0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.InteropServices.DispIdAttribute::.ctor(System.Int32)
extern "C"  void DispIdAttribute__ctor_m787871839 (DispIdAttribute_t3051066024 * __this, int32_t ___dispId0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Reflection.DefaultMemberAttribute::.ctor(System.String)
extern "C"  void DefaultMemberAttribute__ctor_m1668906589 (DefaultMemberAttribute_t296450964 * __this, String_t* ___memberName0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.ParamArrayAttribute::.ctor()
extern "C"  void ParamArrayAttribute__ctor_m1476893411 (ParamArrayAttribute_t4148278418 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.MonoDocumentationNoteAttribute::.ctor(System.String)
extern "C"  void MonoDocumentationNoteAttribute__ctor_m379452513 (MonoDocumentationNoteAttribute_t3523980758 * __this, String_t* ___comment0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.CompilerServices.DecimalConstantAttribute::.ctor(System.Byte,System.Byte,System.UInt32,System.UInt32,System.UInt32)
extern "C"  void DecimalConstantAttribute__ctor_m65841775 (DecimalConstantAttribute_t99985380 * __this, uint8_t ___scale0, uint8_t ___sign1, uint32_t ___hi2, uint32_t ___mid3, uint32_t ___low4, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.ObsoleteAttribute::.ctor(System.String)
extern "C"  void ObsoleteAttribute__ctor_m3649443664 (ObsoleteAttribute_t534593266 * __this, String_t* ___message0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Diagnostics.DebuggerHiddenAttribute::.ctor()
extern "C"  void DebuggerHiddenAttribute__ctor_m1902081030 (DebuggerHiddenAttribute_t177041199 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor()
extern "C"  void CompilerGeneratedAttribute__ctor_m1329859730 (CompilerGeneratedAttribute_t1456741190 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.MonoTODOAttribute::.ctor(System.String)
extern "C"  void MonoTODOAttribute__ctor_m956981832 (MonoTODOAttribute_t119123862 * __this, String_t* ___comment0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Diagnostics.DebuggerTypeProxyAttribute::.ctor(System.Type)
extern "C"  void DebuggerTypeProxyAttribute__ctor_m716875895 (DebuggerTypeProxyAttribute_t4230666625 * __this, Type_t * ___type0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Diagnostics.DebuggerDisplayAttribute::.ctor(System.String)
extern "C"  void DebuggerDisplayAttribute__ctor_m4023377227 (DebuggerDisplayAttribute_t1222375162 * __this, String_t* ___value0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Diagnostics.DebuggerDisplayAttribute::set_Name(System.String)
extern "C"  void DebuggerDisplayAttribute_set_Name_m528775879 (DebuggerDisplayAttribute_t1222375162 * __this, String_t* ___value0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.FlagsAttribute::.ctor()
extern "C"  void FlagsAttribute__ctor_m1689062726 (FlagsAttribute_t2123170284 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.MonoTODOAttribute::.ctor()
extern "C"  void MonoTODOAttribute__ctor_m2653149720 (MonoTODOAttribute_t119123862 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Diagnostics.DebuggerStepThroughAttribute::.ctor()
extern "C"  void DebuggerStepThroughAttribute__ctor_m4239143502 (DebuggerStepThroughAttribute_t1445666285 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Security.SuppressUnmanagedCodeSecurityAttribute::.ctor()
extern "C"  void SuppressUnmanagedCodeSecurityAttribute__ctor_m3765472890 (SuppressUnmanagedCodeSecurityAttribute_t712177550 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.ThreadStaticAttribute::.ctor()
extern "C"  void ThreadStaticAttribute__ctor_m406231037 (ThreadStaticAttribute_t4044403880 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.ObsoleteAttribute::.ctor()
extern "C"  void ObsoleteAttribute__ctor_m2346818104 (ObsoleteAttribute_t534593266 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.CompilerServices.InternalsVisibleToAttribute::.ctor(System.String)
extern "C"  void InternalsVisibleToAttribute__ctor_m3585987778 (InternalsVisibleToAttribute_t4106395870 * __this, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.MonoTODOAttribute::.ctor()
extern "C"  void MonoTODOAttribute__ctor_m937077758 (MonoTODOAttribute_t119123863 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.ObsoleteAttribute::.ctor(System.String,System.Boolean)
extern "C"  void ObsoleteAttribute__ctor_m74976096 (ObsoleteAttribute_t534593266 * __this, String_t* p0, bool p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.MonoTODOAttribute::.ctor(System.String)
extern "C"  void MonoTODOAttribute__ctor_m741414698 (MonoTODOAttribute_t119123863 * __this, String_t* ___comment0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.ComponentModel.TypeConverterAttribute::.ctor(System.Type)
extern "C"  void TypeConverterAttribute__ctor_m2251610938 (TypeConverterAttribute_t3031206686 * __this, Type_t * ___type0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Security.SecurityCriticalAttribute::.ctor()
extern "C"  void SecurityCriticalAttribute__ctor_m4283676607 (SecurityCriticalAttribute_t4019023285 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Security.AllowPartiallyTrustedCallersAttribute::.ctor()
extern "C"  void AllowPartiallyTrustedCallersAttribute__ctor_m3140459627 (AllowPartiallyTrustedCallersAttribute_t2793852185 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.CompilerServices.ExtensionAttribute::.ctor()
extern "C"  void ExtensionAttribute__ctor_m4086378263 (ExtensionAttribute_t36176176 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Diagnostics.DebuggerBrowsableAttribute::.ctor(System.Diagnostics.DebuggerBrowsableState)
extern "C"  void DebuggerBrowsableAttribute__ctor_m2340592270 (DebuggerBrowsableAttribute_t182167257 * __this, int32_t p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Scripting.RequiredByNativeCodeAttribute::.ctor()
extern "C"  void RequiredByNativeCodeAttribute__ctor_m3712479437 (RequiredByNativeCodeAttribute_t2920332526 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Scripting.GeneratedByOldBindingsGeneratorAttribute::.ctor()
extern "C"  void GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088 (GeneratedByOldBindingsGeneratorAttribute_t1890141928 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.ThreadAndSerializationSafeAttribute::.ctor()
extern "C"  void ThreadAndSerializationSafeAttribute__ctor_m14339559 (ThreadAndSerializationSafeAttribute_t401734977 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.WritableAttribute::.ctor()
extern "C"  void WritableAttribute__ctor_m2889669273 (WritableAttribute_t718555548 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Scripting.UsedByNativeCodeAttribute::.ctor()
extern "C"  void UsedByNativeCodeAttribute__ctor_m2169491047 (UsedByNativeCodeAttribute_t2042968054 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.RequireComponent::.ctor(System.Type)
extern "C"  void RequireComponent__ctor_m715180030 (RequireComponent_t2231837482 * __this, Type_t * ___requiredComponent0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngineInternal.TypeInferenceRuleAttribute::.ctor(UnityEngineInternal.TypeInferenceRules)
extern "C"  void TypeInferenceRuleAttribute__ctor_m273865400 (TypeInferenceRuleAttribute_t1237727610 * __this, int32_t ___rule0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Security.SecuritySafeCriticalAttribute::.ctor()
extern "C"  void SecuritySafeCriticalAttribute__ctor_m1104744884 (SecuritySafeCriticalAttribute_t3761815145 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Internal.ExcludeFromDocsAttribute::.ctor()
extern "C"  void ExcludeFromDocsAttribute__ctor_m1396943425 (ExcludeFromDocsAttribute_t2642155980 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Internal.DefaultValueAttribute::.ctor(System.String)
extern "C"  void DefaultValueAttribute__ctor_m1493972517 (DefaultValueAttribute_t1239497132 * __this, String_t* ___value0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.NativeClassAttribute::.ctor(System.String)
extern "C"  void NativeClassAttribute__ctor_m130061132 (NativeClassAttribute_t3768029985 * __this, String_t* ___qualifiedCppName0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.ComponentModel.EditorBrowsableAttribute::.ctor(System.ComponentModel.EditorBrowsableState)
extern "C"  void EditorBrowsableAttribute__ctor_m2659158224 (EditorBrowsableAttribute_t1429620940 * __this, int32_t p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.SerializeField::.ctor()
extern "C"  void SerializeField__ctor_m3105624160 (SerializeField_t1114448220 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Serialization.FormerlySerializedAsAttribute::.ctor(System.String)
extern "C"  void FormerlySerializedAsAttribute__ctor_m2819130373 (FormerlySerializedAsAttribute_t153867989 * __this, String_t* ___oldName0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Runtime.InteropServices.UnmanagedFunctionPointerAttribute::.ctor(System.Runtime.InteropServices.CallingConvention)
extern "C"  void UnmanagedFunctionPointerAttribute__ctor_m3384177810 (UnmanagedFunctionPointerAttribute_t3672379452 * __this, int32_t p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.AddComponentMenu::.ctor(System.String)
extern "C"  void AddComponentMenu__ctor_m3547895745 (AddComponentMenu_t1949136625 * __this, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
static void g_mscorlib_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AssemblyFileVersionAttribute_t1839628412 * tmp = (AssemblyFileVersionAttribute_t1839628412 *)cache->attributes[0];
		AssemblyFileVersionAttribute__ctor_m104636996(tmp, il2cpp_codegen_string_new_wrapper("2.0.50727.1433"), NULL);
	}
	{
		AssemblyCompanyAttribute_t262073538 * tmp = (AssemblyCompanyAttribute_t262073538 *)cache->attributes[1];
		AssemblyCompanyAttribute__ctor_m1961203133(tmp, il2cpp_codegen_string_new_wrapper("MONO development team"), NULL);
	}
	{
		DebuggableAttribute_t2636756938 * tmp = (DebuggableAttribute_t2636756938 *)cache->attributes[2];
		DebuggableAttribute__ctor_m2582985872(tmp, 2LL, NULL);
	}
	{
		StringFreezingAttribute_t10408148 * tmp = (StringFreezingAttribute_t10408148 *)cache->attributes[3];
		StringFreezingAttribute__ctor_m327960799(tmp, NULL);
	}
	{
		NeutralResourcesLanguageAttribute_t2573722287 * tmp = (NeutralResourcesLanguageAttribute_t2573722287 *)cache->attributes[4];
		NeutralResourcesLanguageAttribute__ctor_m1705398382(tmp, il2cpp_codegen_string_new_wrapper("en-US"), NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[5];
		CLSCompliantAttribute__ctor_m737514648(tmp, true, NULL);
	}
	{
		AssemblyDelaySignAttribute_t1388804811 * tmp = (AssemblyDelaySignAttribute_t1388804811 *)cache->attributes[6];
		AssemblyDelaySignAttribute__ctor_m792735968(tmp, true, NULL);
	}
	{
		DefaultDependencyAttribute_t547142461 * tmp = (DefaultDependencyAttribute_t547142461 *)cache->attributes[7];
		DefaultDependencyAttribute__ctor_m2434010332(tmp, 1LL, NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2873331073 * tmp = (RuntimeCompatibilityAttribute_t2873331073 *)cache->attributes[8];
		RuntimeCompatibilityAttribute__ctor_m1077459611(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2097818566(tmp, true, NULL);
	}
	{
		AssemblyProductAttribute_t3079866486 * tmp = (AssemblyProductAttribute_t3079866486 *)cache->attributes[9];
		AssemblyProductAttribute__ctor_m2179734435(tmp, il2cpp_codegen_string_new_wrapper("MONO Common language infrastructure"), NULL);
	}
	{
		AssemblyDescriptionAttribute_t1377417777 * tmp = (AssemblyDescriptionAttribute_t1377417777 *)cache->attributes[10];
		AssemblyDescriptionAttribute__ctor_m863331373(tmp, il2cpp_codegen_string_new_wrapper("mscorlib.dll"), NULL);
	}
	{
		SatelliteContractVersionAttribute_t3058788408 * tmp = (SatelliteContractVersionAttribute_t3058788408 *)cache->attributes[11];
		SatelliteContractVersionAttribute__ctor_m3848511474(tmp, il2cpp_codegen_string_new_wrapper("2.0.0.0"), NULL);
	}
	{
		AssemblyInformationalVersionAttribute_t458211439 * tmp = (AssemblyInformationalVersionAttribute_t458211439 *)cache->attributes[12];
		AssemblyInformationalVersionAttribute__ctor_m2606705742(tmp, il2cpp_codegen_string_new_wrapper("2.0.50727.1433"), NULL);
	}
	{
		AssemblyCopyrightAttribute_t4130653132 * tmp = (AssemblyCopyrightAttribute_t4130653132 *)cache->attributes[13];
		AssemblyCopyrightAttribute__ctor_m2442777966(tmp, il2cpp_codegen_string_new_wrapper("(c) various MONO Authors"), NULL);
	}
	{
		AssemblyDefaultAliasAttribute_t3813724156 * tmp = (AssemblyDefaultAliasAttribute_t3813724156 *)cache->attributes[14];
		AssemblyDefaultAliasAttribute__ctor_m1008481974(tmp, il2cpp_codegen_string_new_wrapper("mscorlib.dll"), NULL);
	}
	{
		AssemblyTitleAttribute_t4032010531 * tmp = (AssemblyTitleAttribute_t4032010531 *)cache->attributes[15];
		AssemblyTitleAttribute__ctor_m2280157225(tmp, il2cpp_codegen_string_new_wrapper("mscorlib.dll"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[16];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		CompilationRelaxationsAttribute_t2092844809 * tmp = (CompilationRelaxationsAttribute_t2092844809 *)cache->attributes[17];
		CompilationRelaxationsAttribute__ctor_m3343263694(tmp, 8LL, NULL);
	}
	{
		TypeLibVersionAttribute_t3563874934 * tmp = (TypeLibVersionAttribute_t3563874934 *)cache->attributes[18];
		TypeLibVersionAttribute__ctor_m3709773259(tmp, 2LL, 0LL, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[19];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("BED7F4EA-1A96-11D2-8F08-00A0C9A6186D"), NULL);
	}
	{
		AssemblyKeyFileAttribute_t756954830 * tmp = (AssemblyKeyFileAttribute_t756954830 *)cache->attributes[20];
		AssemblyKeyFileAttribute__ctor_m515360797(tmp, il2cpp_codegen_string_new_wrapper("../ecma.pub"), NULL);
	}
}
static void RuntimeObject_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 2LL, NULL);
	}
}
static void RuntimeObject_CustomAttributesCacheGenerator_Object__ctor_m3570689169(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeObject_CustomAttributesCacheGenerator_Object_Finalize_m3819013302(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RuntimeObject_CustomAttributesCacheGenerator_Object_ReferenceEquals_m1745896791(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void ValueType_t3348802692_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Attribute_t1821863933_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Attribute_t1821863933_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 32767LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_Attribute_t1412570690_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[3];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
}
static void _Attribute_t1412570690_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Attribute_t1412570690_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[1];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("917B14D0-2D9E-38B8-92A9-381ACF52F7C0"), NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[2];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[3];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(Attribute_t1821863933_0_0_0_var), NULL);
	}
}
static void Int32_t438220675_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IFormattable_t1615404309_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IConvertible_t893085710_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void IComparable_t242364074_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SerializableAttribute_t3604215043_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4124LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AttributeUsageAttribute_t2106699225_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ComVisibleAttribute_t3352689681_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 5597LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Int64_t3733094498_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UInt32_t1752406861_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UInt32_t1752406861_CustomAttributesCacheGenerator_UInt32_Parse_m602751418(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UInt32_t1752406861_CustomAttributesCacheGenerator_UInt32_Parse_m1560553326(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UInt32_t1752406861_CustomAttributesCacheGenerator_UInt32_TryParse_m872480584(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UInt32_t1752406861_CustomAttributesCacheGenerator_UInt32_TryParse_m2781189100(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void CLSCompliantAttribute_t3606053525_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 32767LL, NULL);
	}
}
static void UInt64_t1261996727_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UInt64_t1261996727_CustomAttributesCacheGenerator_UInt64_Parse_m2837505384(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UInt64_t1261996727_CustomAttributesCacheGenerator_UInt64_Parse_m1838157675(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UInt64_t1261996727_CustomAttributesCacheGenerator_UInt64_TryParse_m1875351864(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Byte_t1695016127_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SByte_t1526744772_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SByte_t1526744772_CustomAttributesCacheGenerator_SByte_Parse_m970256373(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void SByte_t1526744772_CustomAttributesCacheGenerator_SByte_Parse_m512031140(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void SByte_t1526744772_CustomAttributesCacheGenerator_SByte_TryParse_m2531638266(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Int16_t674212087_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UInt16_t2530548644_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UInt16_t2530548644_CustomAttributesCacheGenerator_UInt16_Parse_m821794179(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UInt16_t2530548644_CustomAttributesCacheGenerator_UInt16_Parse_m1827209548(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UInt16_t2530548644_CustomAttributesCacheGenerator_UInt16_TryParse_m2161302458(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UInt16_t2530548644_CustomAttributesCacheGenerator_UInt16_TryParse_m4175666418(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void IEnumerator_t2340204891_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[0];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("496B0ABF-CDEE-11D3-88E8-00902754C43A"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IEnumerable_t1561071510_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[0];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("496B0ABE-CDEE-11d3-88E8-00902754C43A"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IEnumerable_t1561071510_CustomAttributesCacheGenerator_IEnumerable_GetEnumerator_m470268915(CustomAttributesCache* cache)
{
	{
		DispIdAttribute_t3051066024 * tmp = (DispIdAttribute_t3051066024 *)cache->attributes[0];
		DispIdAttribute__ctor_m787871839(tmp, -4LL, NULL);
	}
}
static void IDisposable_t1854990027_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Char_t4217985068_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Chars"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String__ctor_m3613415962(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Equals_m3008033655(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Equals_m1775812447(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Split_m1027048911____separator0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Split_m752880514(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		MonoDocumentationNoteAttribute_t3523980758 * tmp = (MonoDocumentationNoteAttribute_t3523980758 *)cache->attributes[1];
		MonoDocumentationNoteAttribute__ctor_m379452513(tmp, il2cpp_codegen_string_new_wrapper("code should be moved to managed"), NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Split_m2170789228(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Split_m882935073(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Trim_m1892663701____trimChars0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_TrimStart_m923266555____trimChars0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_TrimEnd_m1178919651____trimChars0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Format_m527561873____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Format_m949849763____args2(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_FormatHelper_m266143647____args3(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Concat_m406606968____args0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Concat_m2284411301____values0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_GetHashCode_m2446182979(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void ICloneable_t3275016770_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Single_t3678960876_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Single_t3678960876_CustomAttributesCacheGenerator_Single_IsNaN_m3455339168(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Double_t3420139759_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Double_t3420139759_CustomAttributesCacheGenerator_Double_IsNaN_m372022469(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_MinValue(CustomAttributesCache* cache)
{
	{
		DecimalConstantAttribute_t99985380 * tmp = (DecimalConstantAttribute_t99985380 *)cache->attributes[0];
		DecimalConstantAttribute__ctor_m65841775(tmp, 0, 255, 4294967295LL, 4294967295LL, 4294967295LL, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_MaxValue(CustomAttributesCache* cache)
{
	{
		DecimalConstantAttribute_t99985380 * tmp = (DecimalConstantAttribute_t99985380 *)cache->attributes[0];
		DecimalConstantAttribute__ctor_m65841775(tmp, 0, 0, 4294967295LL, 4294967295LL, 4294967295LL, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_MinusOne(CustomAttributesCache* cache)
{
	{
		DecimalConstantAttribute_t99985380 * tmp = (DecimalConstantAttribute_t99985380 *)cache->attributes[0];
		DecimalConstantAttribute__ctor_m65841775(tmp, 0, 255, 0LL, 0LL, 1LL, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_One(CustomAttributesCache* cache)
{
	{
		DecimalConstantAttribute_t99985380 * tmp = (DecimalConstantAttribute_t99985380 *)cache->attributes[0];
		DecimalConstantAttribute__ctor_m65841775(tmp, 0, 0, 0LL, 0LL, 1LL, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal__ctor_m2545903267(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal__ctor_m3377077937(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_Compare_m3646660628(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Explicit_m1503313322(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Explicit_m1521124198(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Explicit_m1054949672(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Explicit_m2818597674(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Implicit_m1540208279(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Implicit_m980199957(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Implicit_m881253395(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Implicit_m809477236(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Boolean_t402932760_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m2251341938(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m2356916849(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m3657584931(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_get_Size_m2786508229(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_ToInt64_m1557689473(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_ToPointer_m237804402(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[1];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Equality_m2182604147(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Inequality_m3520486347(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m509961701(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m267845794(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m1997376062(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[1];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m2617312562(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void ISerializable_t3453043479_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UIntPtr_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr__ctor_m890287867(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_ToPointer_m2330649849(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_op_Explicit_m4118586544(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_op_Explicit_m1761774754(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void MulticastDelegate_t608486974_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Delegate_t2990640460_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 2LL, NULL);
	}
}
static void Delegate_t2990640460_CustomAttributesCacheGenerator_Delegate_Combine_m1500603169(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Delegate_t2990640460_CustomAttributesCacheGenerator_Delegate_Combine_m1500603169____delegates0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_GetName_m874261310(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_IsDefined_m680461013(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_GetUnderlyingType_m1443556329(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_Parse_m2788862954(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToString_m4269924258(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Provider is ignored, just use ToString"), NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToString_m3300782106(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Provider is ignored, just use ToString"), NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m78379513(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m4274442607(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m2048232900(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m3196673333(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m2696618385(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m887634324(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m2147101483(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m1741150068(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m3978950197(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Enum_t4088700107_CustomAttributesCacheGenerator_Enum_Format_m1584462606(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_System_Collections_IList_IndexOf_m4113384025(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_get_Length_m1237849133(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_get_LongLength_m3574060956(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_get_Rank_m4210679277(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_GetLongLength_m1831760985(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_GetLowerBound_m3549496906(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m2729068147____indices0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m3241852505____indices1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_GetUpperBound_m3033662308(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m1672823197(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m3499512431(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m170746175(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m63377824(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m485573868(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m1031266616(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_CreateInstance_m917197603____lengths1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_CreateInstance_m3507446064____lengths1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m2322609327(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m2322609327____indices0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m193787568(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m193787568____indices1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m545470185(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m2794424496(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m787838226(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m3034756551(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Clear_m3931267648(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Copy_m3083719085(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Copy_m1665823352(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Copy_m3124468677(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Copy_m795970186(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_IndexOf_m1347597055(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_IndexOf_m955672662(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_IndexOf_m4006329155(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m3392868261(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m1832984276(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m191882863(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Reverse_m1652786737(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Reverse_m2907565334(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m4258351672(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m1768924099(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2963189028(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m3451521996(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2647962771(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m4051743636(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m1552933164(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m3631368508(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m1072890388(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2260390429(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2466936610(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m1673438336(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m4275090730(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2213423065(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m3813128040(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2658527309(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 2LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_CopyTo_m3827090518(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_Resize_m2100239636(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m265843292(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m2054507326(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m2165578130(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m1225743805(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_Array_ConstrainedCopy_m2507976525(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RuntimeArray_CustomAttributesCacheGenerator_RuntimeArray____LongLength_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void ArrayReadOnlyList_1_t1478687212_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ArrayReadOnlyList_1_t1478687212_CustomAttributesCacheGenerator_ArrayReadOnlyList_1_GetEnumerator_m4253775203(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CGetEnumeratorU3Ec__Iterator0_t3090871926_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void U3CGetEnumeratorU3Ec__Iterator0_t3090871926_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CTU3E_get_Current_m2935388785(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CGetEnumeratorU3Ec__Iterator0_t3090871926_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m3813834758(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CGetEnumeratorU3Ec__Iterator0_t3090871926_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_Dispose_m3100869542(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CGetEnumeratorU3Ec__Iterator0_t3090871926_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_Reset_m2424558805(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void ICollection_t2613627688_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IList_t480837924_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void IList_1_t822657584_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Void_t1421048318_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Type_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_Type_t3776473474_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_IsSubclassOf_m3030212525(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m3166019052(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m3093596752(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m888409261(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_GetConstructors_m3058302789(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_MakeGenericType_m2741335421____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void MemberInfo_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MemberInfo_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_MemberInfo_t3276260911_0_0_0_var), NULL);
	}
}
static void ICustomAttributeProvider_t2305050174_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void _MemberInfo_t3276260911_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_MemberInfo_t3276260911_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[1];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(MemberInfo_t_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[3];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("f7102fa9-cabb-3a74-a6da-b4567ef1b079"), NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void IReflect_t3760602010_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[0];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("AFBF15E5-C37C-11d2-B88E-00A0C9B471B8"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void _Type_t3776473474_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Type_t3776473474_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[2];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(Type_t_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[3];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("BCA8B44D-AAD6-3A86-8AB7-03349F4F2DA2"), NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[4];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
}
static void Exception_t2443218823_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Exception_t2443218823_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_Exception_t1060755997_0_0_0_var), NULL);
	}
}
static void _Exception_t1060755997_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[0];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("b36b5c63-42ef-38bc-a07e-0b34c98f164a"), NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 0LL, NULL);
	}
}
static void RuntimeFieldHandle_t2492430303_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization needs tests"), NULL);
	}
}
static void RuntimeFieldHandle_t2492430303_CustomAttributesCacheGenerator_RuntimeFieldHandle_Equals_m1997721335(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RuntimeTypeHandle_t1361003276_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization needs tests"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RuntimeTypeHandle_t1361003276_CustomAttributesCacheGenerator_RuntimeTypeHandle_Equals_m3316377268(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void ParamArrayAttribute_t4148278418_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 2048LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void OutAttribute_t236430398_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 2048LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void ObsoleteAttribute_t534593266_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 6140LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DllImportAttribute_t3095387693_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MarshalAsAttribute_t2985744263_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 10496LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MarshalAsAttribute_t2985744263_CustomAttributesCacheGenerator_MarshalType(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MarshalAsAttribute_t2985744263_CustomAttributesCacheGenerator_MarshalTypeRef(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void InAttribute_t2445820094_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 2048LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SecurityAttribute_t2476648288_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("CAS support is not available with Silverlight applications."), NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 109LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void GuidAttribute_t3287193793_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 5149LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ComImportAttribute_t676731785_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1028LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void OptionalAttribute_t3596925151_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 2048LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FixedBufferAttribute_t1391295387_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void CompilerGeneratedAttribute_t1456741190_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 32767LL, NULL);
	}
}
static void InternalsVisibleToAttribute_t4106395870_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void RuntimeCompatibilityAttribute_t2873331073_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, false, NULL);
	}
}
static void DebuggerHiddenAttribute_t177041199_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 224LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void DefaultMemberAttribute_t296450964_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1036LL, NULL);
	}
}
static void DecimalConstantAttribute_t99985380_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 2304LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void DecimalConstantAttribute_t99985380_CustomAttributesCacheGenerator_DecimalConstantAttribute__ctor_m65841775(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void FieldOffsetAttribute_t2445260871_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void RuntimeArgumentHandle_t994808714_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AsyncCallback_t3133502122_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IAsyncResult_t337009442_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypedReference_t376682075_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void MarshalByRefObject_t1904561400_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Locale_t57088988_CustomAttributesCacheGenerator_Locale_GetText_m17960088____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void MonoTODOAttribute_t119123862_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 32767LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
	}
}
static void MonoDocumentationNoteAttribute_t3523980758_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 32767LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
	}
}
static void SafeHandleZeroOrMinusOneIsInvalid_t1074017661_CustomAttributesCacheGenerator_SafeHandleZeroOrMinusOneIsInvalid__ctor_m1494848290(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void SafeWaitHandle_t3151023066_CustomAttributesCacheGenerator_SafeWaitHandle__ctor_m1749943790(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void MSCompatUnicodeTable_t3914846919_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map2(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void MSCompatUnicodeTable_t3914846919_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map3(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void MSCompatUnicodeTable_t3914846919_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map4(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void SortKey_t3248894513_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void PKCS12_t192318787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map8(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void PKCS12_t192318787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map9(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void PKCS12_t192318787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapA(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void PKCS12_t192318787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapB(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void PKCS12_t192318787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509CertificateCollection_t3275414984_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509ExtensionCollection_t1736530050_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ASN1_t3432613456_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void SmallXmlParser_t184059736_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map18(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Dictionary_2_t1155016036_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Dictionary_2_t1155016036_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerTypeProxyAttribute_t4230666625 * tmp = (DebuggerTypeProxyAttribute_t4230666625 *)cache->attributes[0];
		DebuggerTypeProxyAttribute__ctor_m716875895(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_2_t1776780061_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		DebuggerDisplayAttribute_t1222375162 * tmp = (DebuggerDisplayAttribute_t1222375162 *)cache->attributes[2];
		DebuggerDisplayAttribute__ctor_m4023377227(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[3];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Dictionary_2_t1155016036_CustomAttributesCacheGenerator_U3CU3Ef__amU24cacheB(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Dictionary_2_t1155016036_CustomAttributesCacheGenerator_Dictionary_2_U3CCopyToU3Em__0_m1933852859(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void IDictionary_2_t332250678_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void KeyNotFoundException_t758703888_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void KeyValuePair_2_t3396090807_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DebuggerDisplayAttribute_t1222375162 * tmp = (DebuggerDisplayAttribute_t1222375162 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m4023377227(tmp, il2cpp_codegen_string_new_wrapper("{value}"), NULL);
		DebuggerDisplayAttribute_set_Name_m528775879(tmp, il2cpp_codegen_string_new_wrapper("[{key}]"), NULL);
	}
}
static void List_1_t2059616371_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (List_1_t2059616371_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerDisplayAttribute_t1222375162 * tmp = (DebuggerDisplayAttribute_t1222375162 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m4023377227(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		DebuggerTypeProxyAttribute_t4230666625 * tmp = (DebuggerTypeProxyAttribute_t4230666625 *)cache->attributes[2];
		DebuggerTypeProxyAttribute__ctor_m716875895(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_1_t3145566263_0_0_0_var), NULL);
	}
}
static void Collection_1_t2882572264_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ReadOnlyCollection_1_t2481933861_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ArrayList_t3384568281_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ArrayList_t3384568281_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerTypeProxyAttribute_t4230666625 * tmp = (DebuggerTypeProxyAttribute_t4230666625 *)cache->attributes[0];
		DebuggerTypeProxyAttribute__ctor_m716875895(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t410077241_0_0_0_var), NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		DebuggerDisplayAttribute_t1222375162 * tmp = (DebuggerDisplayAttribute_t1222375162 *)cache->attributes[3];
		DebuggerDisplayAttribute__ctor_m4023377227(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
}
static void ArrayListWrapper_t2285097034_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void SynchronizedArrayListWrapper_t3513142238_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ReadOnlyArrayListWrapper_t604112846_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void BitArray_t2556826475_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CaseInsensitiveComparer_t605862446_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CaseInsensitiveHashCodeProvider_t3242471571_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[1];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Please use StringComparer instead."), NULL);
	}
}
static void CollectionBase_t3261413387_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Comparer_t287245028_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DictionaryEntry_t578375704_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DebuggerDisplayAttribute_t1222375162 * tmp = (DebuggerDisplayAttribute_t1222375162 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m4023377227(tmp, il2cpp_codegen_string_new_wrapper("{_value}"), NULL);
		DebuggerDisplayAttribute_set_Name_m528775879(tmp, il2cpp_codegen_string_new_wrapper("[{_key}]"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Hashtable_t1665082780_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerDisplayAttribute_t1222375162 * tmp = (DebuggerDisplayAttribute_t1222375162 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m4023377227(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DebuggerTypeProxyAttribute_t4230666625 * tmp = (DebuggerTypeProxyAttribute_t4230666625 *)cache->attributes[1];
		DebuggerTypeProxyAttribute__ctor_m716875895(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t410077241_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[3];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable__ctor_m2531087936(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Please use Hashtable(int, float, IEqualityComparer) instead"), NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable__ctor_m4115579798(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Please use Hashtable(int, IEqualityComparer) instead"), NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable__ctor_m2991153945(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Please use Hashtable(IDictionary, float, IEqualityComparer) instead"), NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable__ctor_m3453182740(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Please use Hashtable(IDictionary, IEqualityComparer) instead"), NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable__ctor_m2767843923(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Please use Hashtable(IEqualityComparer) instead"), NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable_Clear_m4221147505(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable_Remove_m3318034014(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable_OnDeserialization_m2722627116(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialize equalityComparer"), NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable_t1665082780____comparer_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Please use EqualityComparer property."), NULL);
	}
}
static void Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable_t1665082780____hcp_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Please use EqualityComparer property."), NULL);
	}
}
static void HashKeys_t2826937142_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (HashKeys_t2826937142_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerDisplayAttribute_t1222375162 * tmp = (DebuggerDisplayAttribute_t1222375162 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m4023377227(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DebuggerTypeProxyAttribute_t4230666625 * tmp = (DebuggerTypeProxyAttribute_t4230666625 *)cache->attributes[1];
		DebuggerTypeProxyAttribute__ctor_m716875895(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t410077241_0_0_0_var), NULL);
	}
}
static void HashValues_t1567374944_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (HashValues_t1567374944_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerDisplayAttribute_t1222375162 * tmp = (DebuggerDisplayAttribute_t1222375162 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m4023377227(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DebuggerTypeProxyAttribute_t4230666625 * tmp = (DebuggerTypeProxyAttribute_t4230666625 *)cache->attributes[1];
		DebuggerTypeProxyAttribute__ctor_m716875895(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t410077241_0_0_0_var), NULL);
	}
}
static void SyncHashtable_t1353600843_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void IComparer_t2470865232_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IDictionary_t702710298_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IDictionaryEnumerator_t774440013_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IEqualityComparer_t3801883864_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IHashCodeProvider_t3066022657_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Please use IEqualityComparer instead."), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SortedList_t327151849_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		DebuggerDisplayAttribute_t1222375162 * tmp = (DebuggerDisplayAttribute_t1222375162 *)cache->attributes[1];
		DebuggerDisplayAttribute__ctor_m4023377227(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Stack_t830505910_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Stack_t830505910_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerTypeProxyAttribute_t4230666625 * tmp = (DebuggerTypeProxyAttribute_t4230666625 *)cache->attributes[0];
		DebuggerTypeProxyAttribute__ctor_m716875895(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t410077241_0_0_0_var), NULL);
	}
	{
		DebuggerDisplayAttribute_t1222375162 * tmp = (DebuggerDisplayAttribute_t1222375162 *)cache->attributes[1];
		DebuggerDisplayAttribute__ctor_m4023377227(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AssemblyHashAlgorithm_t1254885680_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AssemblyVersionCompatibility_t2721685000_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DebuggableAttribute_t2636756938_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 3LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DebuggingModes_t1865971622_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DebuggerBrowsableAttribute_t182167257_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 384LL, NULL);
	}
}
static void DebuggerBrowsableState_t853783821_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DebuggerDisplayAttribute_t1222375162_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4509LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DebuggerStepThroughAttribute_t1445666285_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 108LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DebuggerTypeProxyAttribute_t4230666625_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 13LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StackFrame_t1838224435_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialized objects are not compatible with MS.NET"), NULL);
	}
}
static void StackTrace_t2942520844_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialized objects are not compatible with .NET"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Calendar_t4269329426_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Calendar_t4269329426_CustomAttributesCacheGenerator_Calendar_Clone_m339556131(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void CompareInfo_t3378979977_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CompareOptions_t2067543004_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void CultureInfo_t1686190661_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CultureInfo_t1686190661_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map19(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void CultureInfo_t1686190661_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map1A(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void DateTimeFormatFlags_t3938781256_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void DateTimeFormatInfo_t1072385215_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DateTimeStyles_t1986540600_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DaylightTime_t3097358740_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void GregorianCalendar_t1617016020_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
}
static void GregorianCalendarTypes_t2942788655_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void NumberFormatInfo_t929205710_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void NumberStyles_t4120645497_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TextInfo_t1762234961_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("IDeserializationCallback isn't implemented."), NULL);
	}
}
static void TextInfo_t1762234961_CustomAttributesCacheGenerator_TextInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m3019484889(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void TextInfo_t1762234961_CustomAttributesCacheGenerator_TextInfo_Clone_m808132933(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void TextInfo_t1762234961_CustomAttributesCacheGenerator_TextInfo_t1762234961____CultureName_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void UnicodeCategory_t47276028_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IsolatedStorageException_t145109139_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void BinaryReader_t170336145_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void BinaryReader_t170336145_CustomAttributesCacheGenerator_BinaryReader_ReadSByte_m3974961331(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BinaryReader_t170336145_CustomAttributesCacheGenerator_BinaryReader_ReadUInt16_m1631681507(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BinaryReader_t170336145_CustomAttributesCacheGenerator_BinaryReader_ReadUInt32_m3322182293(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BinaryReader_t170336145_CustomAttributesCacheGenerator_BinaryReader_ReadUInt64_m723726215(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Directory_t1424101462_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DirectoryInfo_t3443917738_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DirectoryNotFoundException_t3956305866_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void EndOfStreamException_t1541734223_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void File_t4052853980_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FileAccess_t2890988798_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FileAttributes_t4239897840_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void FileLoadException_t291496859_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FileMode_t4081272872_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FileNotFoundException_t365835450_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FileOptions_t1048709362_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FileShare_t1227766631_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FileStream_t2128643197_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FileSystemInfo_t2214011087_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FileSystemInfo_t2214011087_CustomAttributesCacheGenerator_FileSystemInfo_GetObjectData_m2634626544(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void IOException_t547748842_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MemoryStream_t369900865_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Path_t1828237022_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Path_t1828237022_CustomAttributesCacheGenerator_InvalidPathChars(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("see GetInvalidPathChars and GetInvalidFileNameChars methods."), NULL);
	}
}
static void PathTooLongException_t3052246028_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SeekOrigin_t2962632027_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Stream_t753921337_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StreamReader_t4183606726_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StreamWriter_t293765744_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StringReader_t2316205510_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TextReader_t1942131857_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TextWriter_t2697789890_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UnmanagedMemoryStream_t264623907_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void AssemblyBuilder_t3823150316_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyBuilder_t3823150316_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_AssemblyBuilder_t870438842_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
}
static void ConstructorBuilder_t1269217984_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_t1269217984_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_ConstructorBuilder_t2590771407_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
}
static void ConstructorBuilder_t1269217984_CustomAttributesCacheGenerator_ConstructorBuilder_t1269217984____CallingConvention_PropertyInfo(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void EnumBuilder_t1686327421_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (EnumBuilder_t1686327421_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_EnumBuilder_t1981314773_0_0_0_var), NULL);
	}
}
static void EnumBuilder_t1686327421_CustomAttributesCacheGenerator_EnumBuilder_GetConstructors_m4236007330(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FieldBuilder_t2373739222_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FieldBuilder_t2373739222_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_FieldBuilder_t3411354663_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
}
static void GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_IsSubclassOf_m353142104(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_GetConstructors_m3284886085(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_Equals_m4250412984(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_GetHashCode_m2384437160(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_MakeGenericType_m92865730(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_MakeGenericType_m92865730____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void ILGenerator_t1182878361_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ILGenerator_t1182878361_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_ILGenerator_t1943880346_0_0_0_var), NULL);
	}
}
static void ILGenerator_t1182878361_CustomAttributesCacheGenerator_ILGenerator_Emit_m1397855461(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ILGenerator_t1182878361_CustomAttributesCacheGenerator_ILGenerator_Mono_GetCurrentOffset_m1965052903(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Use ILOffset"), NULL);
	}
}
static void MethodBuilder_t434851514_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_t434851514_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_MethodBuilder_t1063350594_0_0_0_var), NULL);
	}
}
static void MethodBuilder_t434851514_CustomAttributesCacheGenerator_MethodBuilder_Equals_m2649897076(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void MethodBuilder_t434851514_CustomAttributesCacheGenerator_MethodBuilder_MakeGenericMethod_m1194343307____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void MethodToken_t1418749877_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ModuleBuilder_t3159331943_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ModuleBuilder_t3159331943_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_ModuleBuilder_t234448247_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
}
static void OpCode_t1117422012_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void OpCodes_t1648843312_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void OpCodes_t1648843312_CustomAttributesCacheGenerator_Castclass(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ParameterBuilder_t3753085247_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ParameterBuilder_t3753085247_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_ParameterBuilder_t1036287219_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StackBehaviour_t2397757739_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeBuilder_t3350860216_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_t3350860216_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_TypeBuilder_t47360046_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_DefineConstructor_m3569992820(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_DefineConstructor_m467803885(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_DefineDefaultConstructor_m1244102928(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_GetConstructors_m3718991123(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_MakeGenericType_m1825409448(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_MakeGenericType_m1825409448____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_IsAssignableFrom_m3041852661(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_IsSubclassOf_m2811257152(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_IsAssignableTo_m1907754253(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("arrays"), NULL);
	}
}
static void UnmanagedMarshal_t1529067090_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("An alternate API is available: Emit the MarshalAs custom attribute instead."), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AmbiguousMatchException_t608101487_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Assembly_t3774988722_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly_t3774988722_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_Assembly_t3124909478_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
}
static void Assembly_t3774988722_CustomAttributesCacheGenerator_Assembly_GetName_m2496216313(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("copiedName == true is not supported"), NULL);
	}
}
static void AssemblyCompanyAttribute_t262073538_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void AssemblyCopyrightAttribute_t4130653132_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void AssemblyDefaultAliasAttribute_t3813724156_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AssemblyDelaySignAttribute_t1388804811_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AssemblyDescriptionAttribute_t1377417777_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AssemblyFileVersionAttribute_t1839628412_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void AssemblyInformationalVersionAttribute_t458211439_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AssemblyKeyFileAttribute_t756954830_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AssemblyName_t3342125713_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyName_t3342125713_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_AssemblyName_t139716223_0_0_0_var), NULL);
	}
}
static void AssemblyNameFlags_t1966831008_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void AssemblyProductAttribute_t3079866486_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AssemblyTitleAttribute_t4032010531_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void Binder_t1775642332_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 2LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Default_t1280323092_CustomAttributesCacheGenerator_Default_ReorderArgumentArray_m1230275780(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("This method does not do anything in Mono"), NULL);
	}
}
static void BindingFlags_t2634920058_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void CallingConventions_t369066136_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void ConstructorInfo_t2050809311_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorInfo_t2050809311_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_ConstructorInfo_t3612455801_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
}
static void ConstructorInfo_t2050809311_CustomAttributesCacheGenerator_ConstructorName(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ConstructorInfo_t2050809311_CustomAttributesCacheGenerator_TypeConstructorName(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ConstructorInfo_t2050809311_CustomAttributesCacheGenerator_ConstructorInfo_Invoke_m2121930581(CustomAttributesCache* cache)
{
	{
		DebuggerStepThroughAttribute_t1445666285 * tmp = (DebuggerStepThroughAttribute_t1445666285 *)cache->attributes[0];
		DebuggerStepThroughAttribute__ctor_m4239143502(tmp, NULL);
	}
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[1];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void ConstructorInfo_t2050809311_CustomAttributesCacheGenerator_ConstructorInfo_t2050809311____MemberType_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CustomAttributeData_t73279812_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CustomAttributeData_t73279812_CustomAttributesCacheGenerator_CustomAttributeData_t73279812____Constructor_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CustomAttributeData_t73279812_CustomAttributesCacheGenerator_CustomAttributeData_t73279812____ConstructorArguments_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CustomAttributeNamedArgument_t3456585787_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CustomAttributeTypedArgument_t2066493570_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void EventAttributes_t1919574847_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void EventInfo_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (EventInfo_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_EventInfo_t626173114_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FieldAttributes_t1558435749_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void FieldInfo_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FieldInfo_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_FieldInfo_t616591751_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FieldInfo_t_CustomAttributesCacheGenerator_FieldInfo_SetValue_m3184768154(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
	{
		DebuggerStepThroughAttribute_t1445666285 * tmp = (DebuggerStepThroughAttribute_t1445666285 *)cache->attributes[1];
		DebuggerStepThroughAttribute__ctor_m4239143502(tmp, NULL);
	}
}
static void MemberTypes_t1145889401_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MethodAttributes_t1488178787_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MethodBase_t2010470530_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBase_t2010470530_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_MethodBase_t1718158610_0_0_0_var), NULL);
	}
}
static void MethodBase_t2010470530_CustomAttributesCacheGenerator_MethodBase_Invoke_m1733031813(CustomAttributesCache* cache)
{
	{
		DebuggerStepThroughAttribute_t1445666285 * tmp = (DebuggerStepThroughAttribute_t1445666285 *)cache->attributes[0];
		DebuggerStepThroughAttribute__ctor_m4239143502(tmp, NULL);
	}
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[1];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void MethodBase_t2010470530_CustomAttributesCacheGenerator_MethodBase_GetGenericArguments_m3649313813(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MethodImplAttributes_t2411131545_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MethodInfo_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodInfo_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_MethodInfo_t187796706_0_0_0_var), NULL);
	}
}
static void MethodInfo_t_CustomAttributesCacheGenerator_MethodInfo_MakeGenericMethod_m386620528____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void MethodInfo_t_CustomAttributesCacheGenerator_MethodInfo_GetGenericArguments_m3810648776(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Missing_t3771626849_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Missing_t3771626849_CustomAttributesCacheGenerator_Missing_System_Runtime_Serialization_ISerializable_GetObjectData_m3892491128(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void Module_t3479515451_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Module_t3479515451_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_Module_t107875809_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void PInfo_t791958327_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void ParameterAttributes_t2464461462_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ParameterInfo_t3793757615_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ParameterInfo_t3793757615_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_ParameterInfo_t1133799119_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ParameterModifier_t1406754278_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Pointer_t3782621735_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void ProcessorArchitecture_t2193700292_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void PropertyAttributes_t974795916_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void PropertyInfo_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PropertyInfo_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_PropertyInfo_t4067770872_0_0_0_var), NULL);
	}
}
static void PropertyInfo_t_CustomAttributesCacheGenerator_PropertyInfo_GetValue_m3754113982(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
	{
		DebuggerStepThroughAttribute_t1445666285 * tmp = (DebuggerStepThroughAttribute_t1445666285 *)cache->attributes[1];
		DebuggerStepThroughAttribute__ctor_m4239143502(tmp, NULL);
	}
}
static void PropertyInfo_t_CustomAttributesCacheGenerator_PropertyInfo_SetValue_m3700075641(CustomAttributesCache* cache)
{
	{
		DebuggerStepThroughAttribute_t1445666285 * tmp = (DebuggerStepThroughAttribute_t1445666285 *)cache->attributes[0];
		DebuggerStepThroughAttribute__ctor_m4239143502(tmp, NULL);
	}
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[1];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void StrongNameKeyPair_t1281492991_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TargetException_t823735875_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TargetInvocationException_t3273489558_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TargetParameterCountException_t192968970_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeAttributes_t1669384266_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IResourceReader_t1132481374_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void NeutralResourcesLanguageAttribute_t2573722287_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
	}
}
static void ResourceManager_t3021742956_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ResourceReader_t3867505172_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ResourceSet_t860623208_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ResourceSet_t860623208_CustomAttributesCacheGenerator_ResourceSet_GetEnumerator_m2056913480(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void SatelliteContractVersionAttribute_t3058788408_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CompilationRelaxations_t4165277783_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CompilationRelaxationsAttribute_t2092844809_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 71LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DefaultDependencyAttribute_t547142461_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
	}
}
static void IsVolatile_t3529887306_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StringFreezingAttribute_t10408148_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void CriticalFinalizerObject_t3468242162_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CriticalFinalizerObject_t3468242162_CustomAttributesCacheGenerator_CriticalFinalizerObject__ctor_m2030151810(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void CriticalFinalizerObject_t3468242162_CustomAttributesCacheGenerator_CriticalFinalizerObject_Finalize_m1139807466(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void ReliabilityContractAttribute_t3660264932_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1133LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void ActivationArguments_t2702889135_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void COMException_t4034665014_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CallingConvention_t4277045988_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CharSet_t4260912409_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ClassInterfaceAttribute_t1078708468_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 5LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void ClassInterfaceType_t3029378045_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ComDefaultInterfaceAttribute_t2824514219_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void ComInterfaceType_t2020494956_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DispIdAttribute_t3051066024_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 960LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void ErrorWrapper_t1764365424_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ExternalException_t3184927670_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void GCHandle_t2291726809_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Struct should be [StructLayout(LayoutKind.Sequential)] but will need to be reordered for that."), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void GCHandleType_t345823425_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void InterfaceTypeAttribute_t931938199_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1024LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void Marshal_t1372080283_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		SuppressUnmanagedCodeSecurityAttribute_t712177550 * tmp = (SuppressUnmanagedCodeSecurityAttribute_t712177550 *)cache->attributes[0];
		SuppressUnmanagedCodeSecurityAttribute__ctor_m3765472890(tmp, NULL);
	}
}
static void MarshalDirectiveException_t1471159663_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void PreserveSigAttribute_t1176875346_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle__ctor_m783613520(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_Close_m1681605028(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_DangerousAddRef_m1891015601(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_DangerousGetHandle_m1375610744(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_DangerousRelease_m3378349730(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_Dispose_m2973664238(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_Dispose_m2534630911(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_ReleaseHandle_m2535948865(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_SetHandle_m662183779(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_get_IsInvalid_m2633487847(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void TypeLibImportClassAttribute_t2161063924_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1024LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeLibVersionAttribute_t3563874934_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, false, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void UnmanagedFunctionPointerAttribute_t3672379452_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4096LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UnmanagedType_t2440611772_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void _Activator_t1804057808_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Activator_t1804057808_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[3];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("03973551-57A1-3900-A2B5-9083E3FF2943"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(Activator_t2766073353_0_0_0_var), NULL);
	}
}
static void _Assembly_t3124909478_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Assembly_t3124909478_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[0];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(Assembly_t3774988722_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[1];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("17156360-2F1A-384A-BC52-FDE93C215C5B"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 0LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void _AssemblyBuilder_t870438842_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_AssemblyBuilder_t870438842_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[2];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[3];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("BEBB2505-8B54-3443-AEAD-142A16DD9CC7"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(AssemblyBuilder_t3823150316_0_0_0_var), NULL);
	}
}
static void _AssemblyName_t139716223_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_AssemblyName_t139716223_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[1];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("B42B6AAC-317E-34D5-9FA9-093BB4160C50"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[2];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(AssemblyName_t3342125713_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[4];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
}
static void _ConstructorBuilder_t2590771407_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ConstructorBuilder_t2590771407_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[0];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("ED3E4384-D7E2-3FA7-8FFD-8940D330519A"), NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[2];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(ConstructorBuilder_t1269217984_0_0_0_var), NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[4];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void _ConstructorInfo_t3612455801_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ConstructorInfo_t3612455801_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[2];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("E9A19478-9646-3679-9B10-8411AE1FD57D"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(ConstructorInfo_t2050809311_0_0_0_var), NULL);
	}
}
static void _EnumBuilder_t1981314773_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_EnumBuilder_t1981314773_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[0];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(EnumBuilder_t1686327421_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[4];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("C7BD73DE-9F85-3290-88EE-090B8BDFE2DF"), NULL);
	}
}
static void _EventInfo_t626173114_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_EventInfo_t626173114_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[1];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("9DE59C64-D889-35A1-B897-587D74469E5B"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[2];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(EventInfo_t_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void _FieldBuilder_t3411354663_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_FieldBuilder_t3411354663_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[2];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(FieldBuilder_t2373739222_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[3];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("CE1A3BF5-975E-30CC-97C9-1EF70F8F3993"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[4];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void _FieldInfo_t616591751_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_FieldInfo_t616591751_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[1];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(FieldInfo_t_0_0_0_var), NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[4];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("8A7C1442-A9FB-366B-80D8-4939FFA6DBE0"), NULL);
	}
}
static void _ILGenerator_t1943880346_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ILGenerator_t1943880346_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(ILGenerator_t1182878361_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[4];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("A4924B27-6E3B-37F7-9B83-A4501955E6A7"), NULL);
	}
}
static void _MethodBase_t1718158610_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_MethodBase_t1718158610_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(MethodBase_t2010470530_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[4];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("6240837A-707F-3181-8E98-A36AE086766B"), NULL);
	}
}
static void _MethodBuilder_t1063350594_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_MethodBuilder_t1063350594_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[0];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("007D8A14-FDF3-363E-9A0B-FEC0618260A2"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[1];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(MethodBuilder_t434851514_0_0_0_var), NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[2];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[3];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[4];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void _MethodInfo_t187796706_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_MethodInfo_t187796706_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[0];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(MethodInfo_t_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[1];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("FFCC1B5D-ECB8-38DD-9B01-3DC8ABC2AA5F"), NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[4];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void _Module_t107875809_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Module_t107875809_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[0];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(Module_t3479515451_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[1];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("D002E9BA-D9E3-3749-B1D3-D565A08B13E7"), NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[2];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[3];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[4];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void _ModuleBuilder_t234448247_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ModuleBuilder_t234448247_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[2];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("D05FFA9A-04AF-3519-8EE1-8D93AD73430B"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(ModuleBuilder_t3159331943_0_0_0_var), NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[4];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
}
static void _ParameterBuilder_t1036287219_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ParameterBuilder_t1036287219_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[0];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("36329EBA-F97A-3565-BC07-0ED5C6EF19FC"), NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[2];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(ParameterBuilder_t3753085247_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void _ParameterInfo_t1133799119_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ParameterInfo_t1133799119_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[0];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("993634C4-E47A-32CC-BE08-85F567DC27D6"), NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(ParameterInfo_t3793757615_0_0_0_var), NULL);
	}
}
static void _PropertyInfo_t4067770872_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_PropertyInfo_t4067770872_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[0];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("F59ED4E4-E68F-3218-BD77-061AA82824BF"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[1];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(PropertyInfo_t_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void _Thread_t4076868703_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Thread_t4076868703_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(Thread_t3822855611_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[4];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("C281C7F1-4AA9-3517-961A-463CFED57E75"), NULL);
	}
}
static void _TypeBuilder_t47360046_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_TypeBuilder_t47360046_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		InterfaceTypeAttribute_t931938199 * tmp = (InterfaceTypeAttribute_t931938199 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m458747174(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t3287193793 * tmp = (GuidAttribute_t3287193793 *)cache->attributes[2];
		GuidAttribute__ctor_m2076129958(tmp, il2cpp_codegen_string_new_wrapper("7E5678EE-48B3-3F83-B076-C58543498A58"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2161063924 * tmp = (TypeLibImportClassAttribute_t2161063924 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m1625403865(tmp, il2cpp_codegen_type_get_object(TypeBuilder_t3350860216_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[4];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IActivator_t3392025140_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IConstructionCallMessage_t2541862161_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UrlAttribute_t51195340_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UrlAttribute_t51195340_CustomAttributesCacheGenerator_UrlAttribute_GetPropertiesForNewContext_m1689720063(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UrlAttribute_t51195340_CustomAttributesCacheGenerator_UrlAttribute_IsContextOK_m2408897339(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ChannelServices_t1638736262_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ChannelServices_t1638736262_CustomAttributesCacheGenerator_ChannelServices_RegisterChannel_m619736505(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Use RegisterChannel(IChannel,Boolean)"), NULL);
	}
}
static void CrossAppDomainSink_t1475739759_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Handle domain unloading?"), NULL);
	}
}
static void IChannel_t4289550709_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IChannelDataStore_t3350006733_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void IChannelReceiver_t2529597353_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IChannelSender_t3210093071_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IClientChannelSinkProvider_t1548376438_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IServerChannelSinkProvider_t2031651231_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SinkProviderData_t2163625531_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Context_t836550985_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ContextAttribute_t3361256371_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IContextAttribute_t831350911_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IContextProperty_t406597577_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IContributeClientContextSink_t3362946504_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IContributeDynamicSink_t2642781930_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IContributeEnvoySink_t2491675206_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IContributeObjectSink_t2913419897_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IContributeServerContextSink_t3820488358_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IDynamicMessageSink_t133249795_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IDynamicProperty_t2092274604_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SynchronizationAttribute_t2363366576_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4LL, NULL);
	}
}
static void SynchronizationAttribute_t2363366576_CustomAttributesCacheGenerator_SynchronizationAttribute_GetPropertiesForNewContext_m3510013590(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SynchronizationAttribute_t2363366576_CustomAttributesCacheGenerator_SynchronizationAttribute_IsContextOK_m1799431817(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void LifetimeServices_t3455124952_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AsyncResult_t3211417469_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ConstructionCall_t1166029924_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void ConstructionCall_t1166029924_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map20(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void ConstructionCallDictionary_t3544640785_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map23(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void ConstructionCallDictionary_t3544640785_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map24(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Header_t867743215_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IMessage_t3459494027_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IMessageCtrl_t1530236857_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IMessageSink_t2584464463_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IMethodCallMessage_t1534722205_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IMethodMessage_t2248289403_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IMethodReturnMessage_t199276439_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IRemotingFormatter_t4057376155_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void LogicalCallContext_t2641012606_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MethodCall_t1249696419_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void MethodCall_t1249696419_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map1F(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void MethodDictionary_t2740513268_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void MethodDictionary_t2740513268_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map21(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void MethodDictionary_t2740513268_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map22(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void RemotingSurrogateSelector_t795063736_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ReturnMessage_t3772294297_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SoapAttribute_t475638499_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SoapFieldAttribute_t1770251027_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 256LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SoapMethodAttribute_t1135142028_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 64LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SoapParameterAttribute_t2303522566_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 2048LL, NULL);
	}
}
static void SoapTypeAttribute_t2542890154_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1052LL, NULL);
	}
}
static void ProxyAttribute_t1316766301_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ProxyAttribute_t1316766301_CustomAttributesCacheGenerator_ProxyAttribute_GetPropertiesForNewContext_m2921967682(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ProxyAttribute_t1316766301_CustomAttributesCacheGenerator_ProxyAttribute_IsContextOK_m2900797900(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RealProxy_t4229839841_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ITrackingHandler_t974392511_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TrackingServices_t55356278_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ActivatedClientTypeEntry_t881095867_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ActivatedServiceTypeEntry_t263082741_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IChannelInfo_t2472532987_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IEnvoyInfo_t648105343_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IRemotingTypeInfo_t618730896_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void InternalRemotingServices_t1814688636_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ObjRef_t1997854715_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ObjRef_t1997854715_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map26(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void ObjRef_t1997854715_CustomAttributesCacheGenerator_ObjRef_get_ChannelInfo_m2012758559(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RemotingConfiguration_t1345264711_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ConfigHandler_t3932699857_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map27(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void ConfigHandler_t3932699857_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map28(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void ConfigHandler_t3932699857_CustomAttributesCacheGenerator_ConfigHandler_ValidatePath_m3488759860____paths1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void RemotingException_t1173136616_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RemotingServices_t1047346230_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RemotingServices_t1047346230_CustomAttributesCacheGenerator_RemotingServices_IsTransparentProxy_m279338587(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void RemotingServices_t1047346230_CustomAttributesCacheGenerator_RemotingServices_GetRealProxy_m280469471(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void SoapServices_t3896196670_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeEntry_t975009579_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void WellKnownClientTypeEntry_t128803266_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void WellKnownObjectMode_t653959841_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void WellKnownServiceTypeEntry_t3630394316_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void BinaryFormatter_t2452830323_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void BinaryFormatter_t2452830323_CustomAttributesCacheGenerator_U3CDefaultSurrogateSelectorU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void BinaryFormatter_t2452830323_CustomAttributesCacheGenerator_BinaryFormatter_get_DefaultSurrogateSelector_m854521798(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void FormatterAssemblyStyle_t2195407324_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FormatterTypeStyle_t1127895449_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeFilterLevel_t1430716943_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FormatterConverter_t3457131633_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FormatterServices_t1887439258_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IDeserializationCallback_t706750576_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IFormatter_t3532332523_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IFormatterConverter_t2745970127_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IObjectReference_t597715029_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ISerializationSurrogate_t2988905240_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ISurrogateSelector_t1458111122_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ObjectManager_t3901639071_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void OnDeserializedAttribute_t1919362979_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void OnDeserializingAttribute_t382572488_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void OnSerializedAttribute_t559136818_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void OnSerializingAttribute_t2631507647_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SerializationBinder_t2326413375_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SerializationEntry_t2018126969_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SerializationException_t924346921_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SerializationInfo_t623100739_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SerializationInfo_t623100739_CustomAttributesCacheGenerator_SerializationInfo__ctor_m2387200337(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void SerializationInfo_t623100739_CustomAttributesCacheGenerator_SerializationInfo_AddValue_m4204157667(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void SerializationInfoEnumerator_t461782006_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StreamingContext_t885793295_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StreamingContextStates_t317203920_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void X509Certificate_t4268988265_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("X509ContentType.SerializedCert isn't supported (anywhere in the class)"), NULL);
	}
}
static void X509Certificate_t4268988265_CustomAttributesCacheGenerator_X509Certificate_GetIssuerName_m985760924(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Use the Issuer property."), NULL);
	}
}
static void X509Certificate_t4268988265_CustomAttributesCacheGenerator_X509Certificate_GetName_m839418740(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Use the Subject property."), NULL);
	}
}
static void X509Certificate_t4268988265_CustomAttributesCacheGenerator_X509Certificate_Equals_m3424353702(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void X509Certificate_t4268988265_CustomAttributesCacheGenerator_X509Certificate_Import_m2684987799(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("missing KeyStorageFlags support"), NULL);
	}
}
static void X509Certificate_t4268988265_CustomAttributesCacheGenerator_X509Certificate_Reset_m4105901662(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void X509KeyStorageFlags_t2192654159_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AsymmetricAlgorithm_t955984407_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AsymmetricKeyExchangeFormatter_t886885227_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AsymmetricSignatureDeformatter_t3604315115_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AsymmetricSignatureFormatter_t2864085280_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CipherMode_t1510653764_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CryptoConfig_t2915898687_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CryptoConfig_t2915898687_CustomAttributesCacheGenerator_CryptoConfig_CreateFromName_m3002182116____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void CryptographicException_t3065671415_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CryptographicUnexpectedOperationException_t930000052_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CspParameters_t3347918906_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CspProviderFlags_t613247746_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void DES_t3797920348_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DESCryptoServiceProvider_t1590711767_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DSA_t47143136_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DSACryptoServiceProvider_t803357635_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DSACryptoServiceProvider_t803357635_CustomAttributesCacheGenerator_DSACryptoServiceProvider_t803357635____PublicOnly_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void DSAParameters_t4013484323_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DSASignatureDeformatter_t1830026019_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DSASignatureFormatter_t2790450949_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void HMAC_t3287208588_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void HMACMD5_t877655754_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void HMACRIPEMD160_t2239679702_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void HMACSHA1_t2626692938_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void HMACSHA256_t4140074641_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void HMACSHA384_t3754767111_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void HMACSHA512_t3404524865_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void HashAlgorithm_t2798580409_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ICryptoTransform_t179341168_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ICspAsymmetricAlgorithm_t3702375355_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void KeyedHashAlgorithm_t366594456_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MACTripleDES_t1665378552_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MD5_t495647487_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MD5CryptoServiceProvider_t2490929366_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void PaddingMode_t927572615_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RC2_t3547516542_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RC2CryptoServiceProvider_t3305775543_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RIPEMD160_t170226481_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RIPEMD160Managed_t688052670_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RSA_t1831419072_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RSACryptoServiceProvider_t242930683_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RSACryptoServiceProvider_t242930683_CustomAttributesCacheGenerator_RSACryptoServiceProvider_t242930683____PublicOnly_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void RSAPKCS1KeyExchangeFormatter_t86803071_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RSAPKCS1SignatureDeformatter_t1486601497_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RSAPKCS1SignatureFormatter_t2724172344_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RSAParameters_t3314567386_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Rijndael_t24829170_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RijndaelManaged_t2499591095_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RijndaelManagedTransform_t1223567365_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SHA1_t3068583258_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SHA1CryptoServiceProvider_t2273746778_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SHA1Managed_t3616185673_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SHA256_t2880016589_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SHA256Managed_t3149068738_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SHA384_t4262120991_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SHA384Managed_t1083824740_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SHA512_t3793833733_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SHA512Managed_t579431699_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SignatureDescription_t1918251708_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SymmetricAlgorithm_t1437564452_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ToBase64Transform_t2523062884_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TripleDES_t3372534912_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TripleDESCryptoServiceProvider_t424749285_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CodeAccessSecurityAttribute_t757905721_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("CAS support is not available with Silverlight applications."), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[2];
		AttributeUsageAttribute__ctor_m250482755(tmp, 109LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void IUnrestrictedPermission_t3571481434_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SecurityPermission_t583848627_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SecurityPermissionAttribute_t387285309_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 109LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[2];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("CAS support is not available with Silverlight applications."), NULL);
	}
}
static void SecurityPermissionFlag_t3101722525_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[1];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("CAS support is not available with Silverlight applications."), NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[2];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void StrongNamePublicKeyBlob_t1772872490_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ApplicationTrust_t362751801_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Evidence_t757411348_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Evidence_t757411348_CustomAttributesCacheGenerator_Evidence_Equals_m3868193673(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void Evidence_t757411348_CustomAttributesCacheGenerator_Evidence_GetHashCode_m3660855014(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void Hash_t2853297299_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IIdentityPermissionFactory_t3494792867_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StrongName_t2472190370_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IIdentity_t1310569830_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IPrincipal_t2189726509_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void PrincipalPolicy_t4069167024_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void WindowsAccountType_t2558366604_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void WindowsIdentity_t2572034763_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void WindowsIdentity_t2572034763_CustomAttributesCacheGenerator_WindowsIdentity_Dispose_m2729980567(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void AllowPartiallyTrustedCallersAttribute_t2793852185_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, false, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CodeAccessPermission_t1722695774_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("CAS support is experimental (and unsupported)."), NULL);
	}
}
static void CodeAccessPermission_t1722695774_CustomAttributesCacheGenerator_CodeAccessPermission_Equals_m3953672351(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void CodeAccessPermission_t1722695774_CustomAttributesCacheGenerator_CodeAccessPermission_GetHashCode_m539756730(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void IPermission_t358765359_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ISecurityEncodable_t1930308172_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IStackWalk_t3386434739_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void PermissionSet_t1873340635_CustomAttributesCacheGenerator_U3CDeclarativeSecurityU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void PermissionSet_t1873340635_CustomAttributesCacheGenerator_PermissionSet_set_DeclarativeSecurity_m644410636(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void SecurityCriticalAttribute_t4019023285_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 6143LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, false, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Only supported by the runtime when CoreCLR is enabled"), NULL);
	}
}
static void SecurityElement_t3886520689_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SecurityException_t2846057857_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SecurityException_t2846057857_CustomAttributesCacheGenerator_SecurityException_t2846057857____Demanded_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void SecurityManager_t2368288763_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SecurityManager_t2368288763_CustomAttributesCacheGenerator_SecurityManager_t2368288763____SecurityEnabled_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("The security manager cannot be turned off on MS runtime"), NULL);
	}
}
static void SecuritySafeCriticalAttribute_t3761815145_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Only supported by the runtime when CoreCLR is enabled"), NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 32767LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, false, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void SuppressUnmanagedCodeSecurityAttribute_t712177550_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 5188LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void UnverifiableCodeAttribute_t2126738304_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 2LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void ASCIIEncoding_t2683426640_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
}
static void ASCIIEncoding_t2683426640_CustomAttributesCacheGenerator_ASCIIEncoding_GetBytes_m1861174925(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void ASCIIEncoding_t2683426640_CustomAttributesCacheGenerator_ASCIIEncoding_GetByteCount_m1104398450(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void ASCIIEncoding_t2683426640_CustomAttributesCacheGenerator_ASCIIEncoding_GetDecoder_m4195996369(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("we have simple override to match method signature."), NULL);
	}
}
static void Decoder_t1161719558_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Decoder_t1161719558_CustomAttributesCacheGenerator_Decoder_t1161719558____Fallback_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void Decoder_t1161719558_CustomAttributesCacheGenerator_Decoder_t1161719558____FallbackBuffer_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void DecoderReplacementFallback_t586276568_CustomAttributesCacheGenerator_DecoderReplacementFallback__ctor_m2067492076(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void EncoderReplacementFallback_t565825954_CustomAttributesCacheGenerator_EncoderReplacementFallback__ctor_m3250070966(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void Encoding_t1853649522_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_InvokeI18N_m2682327131____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_Clone_m4233455263(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_GetByteCount_m4183085963(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_GetBytes_m1474736915(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_t1853649522____IsReadOnly_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_t1853649522____DecoderFallback_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_t1853649522____EncoderFallback_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void StringBuilder_t718897314_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[2];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Chars"), NULL);
	}
}
static void StringBuilder_t718897314_CustomAttributesCacheGenerator_StringBuilder_AppendFormat_m265867772____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void StringBuilder_t718897314_CustomAttributesCacheGenerator_StringBuilder_AppendFormat_m170141315____args2(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void UTF32Encoding_t3108170857_CustomAttributesCacheGenerator_UTF32Encoding_GetByteCount_m4237185367(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("handle fallback"), NULL);
	}
}
static void UTF32Encoding_t3108170857_CustomAttributesCacheGenerator_UTF32Encoding_GetBytes_m2455949945(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("handle fallback"), NULL);
	}
}
static void UTF32Encoding_t3108170857_CustomAttributesCacheGenerator_UTF32Encoding_GetByteCount_m1376079431(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UTF32Encoding_t3108170857_CustomAttributesCacheGenerator_UTF32Encoding_GetBytes_m3225718289(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UTF7Encoding_t1676725360_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetHashCode_m2812161639(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_Equals_m1452874225(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetByteCount_m2506376274(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetByteCount_m339441067(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetBytes_m2044879498(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetBytes_m578527611(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetString_m3450959021(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void UTF8Encoding_t2750870271_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("EncoderFallback is not handled"), NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UTF8Encoding_t2750870271_CustomAttributesCacheGenerator_UTF8Encoding_GetByteCount_m2335716119(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UTF8Encoding_t2750870271_CustomAttributesCacheGenerator_UTF8Encoding_GetBytes_m1516677235(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void UTF8Encoding_t2750870271_CustomAttributesCacheGenerator_UTF8Encoding_GetString_m658301774(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void UnicodeEncoding_t289070003_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
}
static void UnicodeEncoding_t289070003_CustomAttributesCacheGenerator_UnicodeEncoding_GetByteCount_m2385439378(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void UnicodeEncoding_t289070003_CustomAttributesCacheGenerator_UnicodeEncoding_GetBytes_m1035720983(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void UnicodeEncoding_t289070003_CustomAttributesCacheGenerator_UnicodeEncoding_GetString_m2415827372(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void CompressedStack_t2266949894_CustomAttributesCacheGenerator_CompressedStack_CreateCopy_m3982422829(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void CompressedStack_t2266949894_CustomAttributesCacheGenerator_CompressedStack_GetObjectData_m690500011(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("incomplete"), NULL);
	}
}
static void EventResetMode_t3757279066_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void EventWaitHandle_t227290698_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ExecutionContext_t68001916_CustomAttributesCacheGenerator_ExecutionContext__ctor_m832962155(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void ExecutionContext_t68001916_CustomAttributesCacheGenerator_ExecutionContext_GetObjectData_m1523482666(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void Interlocked_t1682382106_CustomAttributesCacheGenerator_Interlocked_CompareExchange_m2836937338(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Interlocked_t1682382106_CustomAttributesCacheGenerator_Interlocked_CompareExchange_m2205680848(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[1];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void ManualResetEvent_t1445603037_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Monitor_t2052646250_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Monitor_t2052646250_CustomAttributesCacheGenerator_Monitor_Exit_m1806149589(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Mutex_t3929015048_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Mutex_t3929015048_CustomAttributesCacheGenerator_Mutex__ctor_m1301030505(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void Mutex_t3929015048_CustomAttributesCacheGenerator_Mutex_ReleaseMutex_m4091486119(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void SynchronizationContext_t3240649268_CustomAttributesCacheGenerator_currentContext(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t4044403880 * tmp = (ThreadStaticAttribute_t4044403880 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m406231037(tmp, NULL);
	}
}
static void SynchronizationLockException_t2471118255_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Thread_t3822855611_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Thread_t3822855611_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_Thread_t4076868703_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Thread_t3822855611_CustomAttributesCacheGenerator_local_slots(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t4044403880 * tmp = (ThreadStaticAttribute_t4044403880 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m406231037(tmp, NULL);
	}
}
static void Thread_t3822855611_CustomAttributesCacheGenerator__ec(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t4044403880 * tmp = (ThreadStaticAttribute_t4044403880 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m406231037(tmp, NULL);
	}
}
static void Thread_t3822855611_CustomAttributesCacheGenerator_Thread_get_CurrentThread_m2728607849(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void Thread_t3822855611_CustomAttributesCacheGenerator_Thread_Finalize_m1654384812(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Thread_t3822855611_CustomAttributesCacheGenerator_Thread_get_ExecutionContext_m1768813807(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 1LL, NULL);
	}
}
static void Thread_t3822855611_CustomAttributesCacheGenerator_Thread_get_ManagedThreadId_m2611241199(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Thread_t3822855611_CustomAttributesCacheGenerator_Thread_GetHashCode_m2708003321(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void Thread_t3822855611_CustomAttributesCacheGenerator_Thread_GetCompressedStack_m1386275719(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("see CompressedStack class"), NULL);
	}
}
static void Thread_t3822855611_CustomAttributesCacheGenerator_Thread_t3822855611____ExecutionContext_PropertyInfo(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("limited to CompressedStack support"), NULL);
	}
}
static void ThreadAbortException_t149492054_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ThreadInterruptedException_t34049732_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ThreadState_t3017098817_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void ThreadStateException_t1589333507_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Timer_t2664195862_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void WaitHandle_t52248909_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void WaitHandle_t52248909_CustomAttributesCacheGenerator_WaitHandle_t52248909____Handle_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("In the profiles > 2.x, use SafeHandle instead of Handle"), NULL);
	}
}
static void AccessViolationException_t621235869_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ActivationContext_t1805170213_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void ActivationContext_t1805170213_CustomAttributesCacheGenerator_ActivationContext_System_Runtime_Serialization_ISerializable_GetObjectData_m1919074653(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Missing serialization support"), NULL);
	}
}
static void Activator_t2766073353_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Activator_t2766073353_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t2824514219 * tmp = (ComDefaultInterfaceAttribute_t2824514219 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m585413508(tmp, il2cpp_codegen_type_get_object(_Activator_t1804057808_0_0_0_var), NULL);
	}
}
static void Activator_t2766073353_CustomAttributesCacheGenerator_Activator_CreateInstance_m444130951____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void AppDomain_t2648090339_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AppDomain_t2648090339_CustomAttributesCacheGenerator_type_resolve_in_progress(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t4044403880 * tmp = (ThreadStaticAttribute_t4044403880 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m406231037(tmp, NULL);
	}
}
static void AppDomain_t2648090339_CustomAttributesCacheGenerator_assembly_resolve_in_progress(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t4044403880 * tmp = (ThreadStaticAttribute_t4044403880 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m406231037(tmp, NULL);
	}
}
static void AppDomain_t2648090339_CustomAttributesCacheGenerator_assembly_resolve_in_progress_refonly(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t4044403880 * tmp = (ThreadStaticAttribute_t4044403880 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m406231037(tmp, NULL);
	}
}
static void AppDomain_t2648090339_CustomAttributesCacheGenerator__principal(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t4044403880 * tmp = (ThreadStaticAttribute_t4044403880 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m406231037(tmp, NULL);
	}
}
static void AppDomainManager_t116683013_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AppDomainSetup_t2743734351_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t1078708468 * tmp = (ClassInterfaceAttribute_t1078708468 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m1041561158(tmp, 0LL, NULL);
	}
}
static void ApplicationException_t1422262649_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ApplicationIdentity_t582625741_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void ApplicationIdentity_t582625741_CustomAttributesCacheGenerator_ApplicationIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m2267909380(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Missing serialization"), NULL);
	}
}
static void ArgumentException_t2004815231_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ArgumentNullException_t3632016946_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ArgumentOutOfRangeException_t3491990243_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ArithmeticException_t137630443_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ArrayTypeMismatchException_t1700383061_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AssemblyLoadEventArgs_t1395911814_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AttributeTargets_t1409711436_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void Buffer_t135592026_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CharEnumerator_t2602806652_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ContextBoundObject_t3291734292_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToBoolean_m1887725282(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToBoolean_m707738265(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToBoolean_m1122829536(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToBoolean_m3283955427(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToByte_m1519340743(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToByte_m1674698270(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToByte_m3099814251(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToByte_m2153487333(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToChar_m1568898469(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToChar_m337390725(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToChar_m2214938048(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToChar_m453700468(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDateTime_m3011399261(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDateTime_m1737814825(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDateTime_m3526800699(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDateTime_m1351566174(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDecimal_m3255111027(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDecimal_m362315142(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDecimal_m690090213(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDecimal_m1381390199(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDouble_m2409248499(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDouble_m2406944942(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDouble_m132850532(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDouble_m2474254574(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt16_m3142197079(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt16_m3910677062(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt16_m4194599106(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt16_m2462923612(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt32_m2414750495(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt32_m2422887349(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt32_m2545494139(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt32_m1812481528(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt64_m2719224162(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt64_m513460999(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt64_m1220027300(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt64_m3686795582(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m3654808220(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m2221295796(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m1198711592(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m4039538944(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m2255796510(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m1171878403(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m2364369564(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m2473384867(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m1899553949(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m1260639261(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m3263476780(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m621137857(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m502382709(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m1923387717(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSingle_m2927637723(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSingle_m263664334(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSingle_m108240803(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSingle_m4264044771(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m3589406227(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m262507043(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m1916842140(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m1590911059(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m1460061451(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m2605846227(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m3441577881(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m2315016985(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m3851674843(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m598870541(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m1969507677(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m271993144(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m3417160479(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m848830585(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m2890507400(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m4225679663(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m1139469487(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m899358007(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m3538128733(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m2750411885(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m1509256923(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m413938554(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m3371003386(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m1967326106(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m3357398318(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m2624224331(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m4087217800(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m441301288(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m3421432777(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m588351329(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m1305628260(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m152153280(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m1532445467(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m332078237(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2034597942(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2644784328(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m1758528004(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m4235029228(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m441916607(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2608704228(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2802651835(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2087886788(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2300482675(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void DBNull_t317552310_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DateTimeKind_t588365666_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DateTimeOffset_t3036919142_CustomAttributesCacheGenerator_DateTimeOffset_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m2865451658(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m2653149720(tmp, NULL);
	}
}
static void DayOfWeek_t1380878247_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DivideByZeroException_t830428046_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void DllNotFoundException_t2356382286_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void EntryPointNotFoundException_t762882416_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MonoEnumInfo_t2659694797_CustomAttributesCacheGenerator_cache(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t4044403880 * tmp = (ThreadStaticAttribute_t4044403880 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m406231037(tmp, NULL);
	}
}
static void Environment_t4132265847_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void SpecialFolder_t247122931_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void EventArgs_t3765086707_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ExecutionEngineException_t942644687_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FieldAccessException_t2393343644_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FlagsAttribute_t2123170284_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 16LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void FormatException_t2016869209_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void GC_t1257975953_CustomAttributesCacheGenerator_GC_SuppressFinalize_m2436602860(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Guid_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ICustomFormatter_t3048241609_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IFormatProvider_t2239227292_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void IndexOutOfRangeException_t3356532665_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void InvalidCastException_t3434725360_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void InvalidOperationException_t3413438395_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void LoaderOptimization_t1131133142_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void LoaderOptimization_t1131133142_CustomAttributesCacheGenerator_DomainMask(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2346818104(tmp, NULL);
	}
}
static void LoaderOptimization_t1131133142_CustomAttributesCacheGenerator_DisallowBindings(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2346818104(tmp, NULL);
	}
}
static void LocalDataStoreSlot_t775718540_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void Math_t2064695271_CustomAttributesCacheGenerator_Math_Max_m1737240539(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Math_t2064695271_CustomAttributesCacheGenerator_Math_Min_m2898138409(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Math_t2064695271_CustomAttributesCacheGenerator_Math_Sqrt_m2669192963(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void MemberAccessException_t3227932226_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MethodAccessException_t107138509_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MissingFieldException_t2479880909_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MissingMemberException_t2055358158_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MissingMethodException_t306141151_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MulticastNotSupportedException_t2338674854_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void NonSerializedAttribute_t2672110800_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void NotImplementedException_t3812197027_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void NotSupportedException_t3258010636_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void NullReferenceException_t3221440195_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void NumberFormatter_t2567188219_CustomAttributesCacheGenerator_threadNumberFormatter(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t4044403880 * tmp = (ThreadStaticAttribute_t4044403880 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m406231037(tmp, NULL);
	}
}
static void ObjectDisposedException_t1287406024_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void OperatingSystem_t2974600964_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void OutOfMemoryException_t3284315365_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void OverflowException_t1772151001_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void PlatformID_t1036322677_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void PlatformNotSupportedException_t1144249114_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RankException_t1412744892_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ResolveEventArgs_t1631477950_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RuntimeMethodHandle_t4063774698_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123862 * tmp = (MonoTODOAttribute_t119123862 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m956981832(tmp, il2cpp_codegen_string_new_wrapper("Serialization needs tests"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void RuntimeMethodHandle_t4063774698_CustomAttributesCacheGenerator_RuntimeMethodHandle_Equals_m694043567(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void StackOverflowException_t1229567991_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StringComparer_t2150832686_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StringComparison_t4237255105_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void StringSplitOptions_t1470633910_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[1];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void SystemException_t2605480680_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ThreadStaticAttribute_t4044403880_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void TimeSpan_t4182925364_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TimeZone_t129964036_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeCode_t842513060_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeInitializationException_t1153585075_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeLoadException_t2846187622_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UnauthorizedAccessException_t679070329_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UnhandledExceptionEventArgs_t412183538_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UnhandledExceptionEventArgs_t412183538_CustomAttributesCacheGenerator_UnhandledExceptionEventArgs_get_ExceptionObject_m4275923656(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void UnhandledExceptionEventArgs_t412183538_CustomAttributesCacheGenerator_UnhandledExceptionEventArgs_get_IsTerminating_m3714614171(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t3660264932 * tmp = (ReliabilityContractAttribute_t3660264932 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1584311890(tmp, 3LL, 2LL, NULL);
	}
}
static void Version_t3942069453_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void WeakReference_t2646405993_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void MemberFilter_t3088556475_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeFilter_t3805304870_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void CrossContextDelegate_t3119470076_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void HeaderHandler_t3298815300_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ThreadStart_t16934496_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TimerCallback_t1325839763_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void WaitCallback_t493830079_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AppDomainInitializer_t749344933_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void AssemblyLoadEventHandler_t479720079_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void EventHandler_t3645504629_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void ResolveEventHandler_t4248294491_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void UnhandledExceptionEventHandler_t3971395670_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void U3CPrivateImplementationDetailsU3E_t3192871059_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void g_System_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		NeutralResourcesLanguageAttribute_t2573722287 * tmp = (NeutralResourcesLanguageAttribute_t2573722287 *)cache->attributes[0];
		NeutralResourcesLanguageAttribute__ctor_m1705398382(tmp, il2cpp_codegen_string_new_wrapper("en-US"), NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m737514648(tmp, true, NULL);
	}
	{
		AssemblyInformationalVersionAttribute_t458211439 * tmp = (AssemblyInformationalVersionAttribute_t458211439 *)cache->attributes[2];
		AssemblyInformationalVersionAttribute__ctor_m2606705742(tmp, il2cpp_codegen_string_new_wrapper("2.0.50727.1433"), NULL);
	}
	{
		SatelliteContractVersionAttribute_t3058788408 * tmp = (SatelliteContractVersionAttribute_t3058788408 *)cache->attributes[3];
		SatelliteContractVersionAttribute__ctor_m3848511474(tmp, il2cpp_codegen_string_new_wrapper("2.0.0.0"), NULL);
	}
	{
		AssemblyCopyrightAttribute_t4130653132 * tmp = (AssemblyCopyrightAttribute_t4130653132 *)cache->attributes[4];
		AssemblyCopyrightAttribute__ctor_m2442777966(tmp, il2cpp_codegen_string_new_wrapper("(c) various MONO Authors"), NULL);
	}
	{
		AssemblyProductAttribute_t3079866486 * tmp = (AssemblyProductAttribute_t3079866486 *)cache->attributes[5];
		AssemblyProductAttribute__ctor_m2179734435(tmp, il2cpp_codegen_string_new_wrapper("MONO Common language infrastructure"), NULL);
	}
	{
		AssemblyCompanyAttribute_t262073538 * tmp = (AssemblyCompanyAttribute_t262073538 *)cache->attributes[6];
		AssemblyCompanyAttribute__ctor_m1961203133(tmp, il2cpp_codegen_string_new_wrapper("MONO development team"), NULL);
	}
	{
		AssemblyDefaultAliasAttribute_t3813724156 * tmp = (AssemblyDefaultAliasAttribute_t3813724156 *)cache->attributes[7];
		AssemblyDefaultAliasAttribute__ctor_m1008481974(tmp, il2cpp_codegen_string_new_wrapper("System.dll"), NULL);
	}
	{
		AssemblyDescriptionAttribute_t1377417777 * tmp = (AssemblyDescriptionAttribute_t1377417777 *)cache->attributes[8];
		AssemblyDescriptionAttribute__ctor_m863331373(tmp, il2cpp_codegen_string_new_wrapper("System.dll"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[9];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		AssemblyTitleAttribute_t4032010531 * tmp = (AssemblyTitleAttribute_t4032010531 *)cache->attributes[10];
		AssemblyTitleAttribute__ctor_m2280157225(tmp, il2cpp_codegen_string_new_wrapper("System.dll"), NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2873331073 * tmp = (RuntimeCompatibilityAttribute_t2873331073 *)cache->attributes[11];
		RuntimeCompatibilityAttribute__ctor_m1077459611(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2097818566(tmp, true, NULL);
	}
	{
		CompilationRelaxationsAttribute_t2092844809 * tmp = (CompilationRelaxationsAttribute_t2092844809 *)cache->attributes[12];
		CompilationRelaxationsAttribute__ctor_m3343263694(tmp, 8LL, NULL);
	}
	{
		DebuggableAttribute_t2636756938 * tmp = (DebuggableAttribute_t2636756938 *)cache->attributes[13];
		DebuggableAttribute__ctor_m2582985872(tmp, 2LL, NULL);
	}
	{
		AssemblyDelaySignAttribute_t1388804811 * tmp = (AssemblyDelaySignAttribute_t1388804811 *)cache->attributes[14];
		AssemblyDelaySignAttribute__ctor_m792735968(tmp, true, NULL);
	}
	{
		AssemblyKeyFileAttribute_t756954830 * tmp = (AssemblyKeyFileAttribute_t756954830 *)cache->attributes[15];
		AssemblyKeyFileAttribute__ctor_m515360797(tmp, il2cpp_codegen_string_new_wrapper("../ecma.pub"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[16];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("System.Net, PublicKey=00240000048000009400000006020000002400005253413100040000010001008D56C76F9E8649383049F383C44BE0EC204181822A6C31CF5EB7EF486944D032188EA1D3920763712CCB12D75FB77E9811149E6148E5D32FBAAB37611C1878DDC19E20EF135D0CB2CFF2BFEC3D115810C3D9069638FE4BE215DBF795861920E5AB6F7DB2E2CEEF136AC23D5DD2BF031700AEC232F6C6B1C785B4305C123B37AB"), NULL);
	}
	{
		AssemblyFileVersionAttribute_t1839628412 * tmp = (AssemblyFileVersionAttribute_t1839628412 *)cache->attributes[17];
		AssemblyFileVersionAttribute__ctor_m104636996(tmp, il2cpp_codegen_string_new_wrapper("2.0.50727.1433"), NULL);
	}
}
static void Locale_t57088989_CustomAttributesCacheGenerator_Locale_GetText_m3231868817____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void MonoTODOAttribute_t119123863_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 32767LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
	}
}
static void Queue_1_t3027544886_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void Stack_1_t4283693321_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
}
static void HybridDictionary_t3761704658_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ListDictionary_t222750502_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void NameObjectCollectionBase_t3546148169_CustomAttributesCacheGenerator_NameObjectCollectionBase_FindFirstMatchedItem_m2785248297(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m937077758(tmp, NULL);
	}
}
static void KeysCollection_t3858846733_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void NameValueCollection_t3172313318_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void EditorBrowsableAttribute_t1429620940_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 6140LL, NULL);
	}
}
static void TypeConverter_t186346670_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
}
static void TypeConverterAttribute_t3031206686_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 32767LL, NULL);
	}
}
static void SslPolicyErrors_t3855906214_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void FileWebRequest_t211636899_CustomAttributesCacheGenerator_FileWebRequest__ctor_m331710361(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m74976096(tmp, il2cpp_codegen_string_new_wrapper("Serialization is obsoleted for this type"), false, NULL);
	}
}
static void FtpWebRequest_t2714096550_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache1C(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void FtpWebRequest_t2714096550_CustomAttributesCacheGenerator_FtpWebRequest_U3CcallbackU3Em__B_m3498702001(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void GlobalProxySelection_t3450859545_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Use WebRequest.DefaultProxy instead"), NULL);
	}
}
static void HttpWebRequest_t3927073785_CustomAttributesCacheGenerator_HttpWebRequest__ctor_m2901044332(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m74976096(tmp, il2cpp_codegen_string_new_wrapper("Serialization is obsoleted for this type"), false, NULL);
	}
}
static void IPv6Address_t2462431949_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void SecurityProtocolType_t2871506216_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void ServicePointManager_t2286025188_CustomAttributesCacheGenerator_ServicePointManager_t2286025188____CertificatePolicy_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m74976096(tmp, il2cpp_codegen_string_new_wrapper("Use ServerCertificateValidationCallback instead"), false, NULL);
	}
}
static void ServicePointManager_t2286025188_CustomAttributesCacheGenerator_ServicePointManager_t2286025188____CheckCertificateRevocationList_PropertyInfo(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m741414698(tmp, il2cpp_codegen_string_new_wrapper("CRL checks not implemented"), NULL);
	}
}
static void WebHeaderCollection_t1256302915_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m3177107244(tmp, true, NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void WebProxy_t1311200052_CustomAttributesCacheGenerator_WebProxy_t1311200052____UseDefaultCredentials_PropertyInfo(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m741414698(tmp, il2cpp_codegen_string_new_wrapper("Does not affect Credentials, since CredentialCache.DefaultCredentials is not implemented."), NULL);
	}
}
static void WebRequest_t1162840426_CustomAttributesCacheGenerator_WebRequest_GetDefaultWebProxy_m2436480977(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m741414698(tmp, il2cpp_codegen_string_new_wrapper("Needs to respect Module, Proxy.AutoDetect, and Proxy.ScriptLocation config settings"), NULL);
	}
}
static void OpenFlags_t3075873276_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void PublicKey_t3235236034_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map9(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X500DistinguishedName_t264737722_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m741414698(tmp, il2cpp_codegen_string_new_wrapper("Some X500DistinguishedNameFlags options aren't supported, like DoNotUsePlusSign, DoNotUseQuotes and ForceUTF8Encoding"), NULL);
	}
}
static void X500DistinguishedNameFlags_t2471748252_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void X509Certificate2_t2584690363_CustomAttributesCacheGenerator_X509Certificate2_GetNameInfo_m808913113(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m741414698(tmp, il2cpp_codegen_string_new_wrapper("always return String.Empty for UpnName, DnsFromAlternativeName and UrlName"), NULL);
	}
}
static void X509Certificate2_t2584690363_CustomAttributesCacheGenerator_X509Certificate2_Import_m3534696989(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m741414698(tmp, il2cpp_codegen_string_new_wrapper("missing KeyStorageFlags support"), NULL);
	}
}
static void X509Certificate2_t2584690363_CustomAttributesCacheGenerator_X509Certificate2_Verify_m284365349(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m741414698(tmp, il2cpp_codegen_string_new_wrapper("by default this depends on the incomplete X509Chain"), NULL);
	}
}
static void X509Certificate2Collection_t2547172981_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509Certificate2Collection_t2547172981_CustomAttributesCacheGenerator_X509Certificate2Collection_AddRange_m3857728710(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m741414698(tmp, il2cpp_codegen_string_new_wrapper("Method isn't transactional (like documented)"), NULL);
	}
}
static void X509Certificate2Collection_t2547172981_CustomAttributesCacheGenerator_X509Certificate2Collection_Find_m2757621005(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m741414698(tmp, il2cpp_codegen_string_new_wrapper("Does not support X509FindType.FindByTemplateName, FindByApplicationPolicy and FindByCertificatePolicy"), NULL);
	}
}
static void X509CertificateCollection_t2058953987_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509Chain_t3669779137_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapB(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509Chain_t3669779137_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapC(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509Chain_t3669779137_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapD(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509Chain_t3669779137_CustomAttributesCacheGenerator_X509Chain_Build_m1000713326(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m741414698(tmp, il2cpp_codegen_string_new_wrapper("Not totally RFC3280 compliant, but neither is MS implementation..."), NULL);
	}
}
static void X509ChainElementCollection_t4094883155_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509ChainStatusFlags_t3387568385_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void X509EnhancedKeyUsageExtension_t2447244446_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapE(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509ExtensionCollection_t3927234224_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509KeyUsageFlags_t2405450781_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void X509Store_t3053056657_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509VerificationFlags_t2857382038_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void AsnEncodedData_t2307648400_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapA(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Oid_t2315348323_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map10(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void OidCollection_t3025304052_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void CaptureCollection_t276843680_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void GroupCollection_t3045585314_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void MatchCollection_t3895979827_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void RegexOptions_t1904484159_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void OpFlags_t871130963_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void IntervalCollection_t3208028748_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ExpressionCollection_t3117266731_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Uri_t4143213084_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Uri_t4143213084_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeConverterAttribute_t3031206686 * tmp = (TypeConverterAttribute_t3031206686 *)cache->attributes[0];
		TypeConverterAttribute__ctor_m2251610938(tmp, il2cpp_codegen_type_get_object(UriTypeConverter_t6232145_0_0_0_var), NULL);
	}
}
static void Uri_t4143213084_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map14(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Uri_t4143213084_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map15(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Uri_t4143213084_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map16(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Uri_t4143213084_CustomAttributesCacheGenerator_Uri__ctor_m3676275920(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2346818104(tmp, NULL);
	}
}
static void Uri_t4143213084_CustomAttributesCacheGenerator_Uri_EscapeString_m3040128922(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2346818104(tmp, NULL);
	}
}
static void Uri_t4143213084_CustomAttributesCacheGenerator_Uri_Unescape_m772995138(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2346818104(tmp, NULL);
	}
}
static void UriParser_t1215654776_CustomAttributesCacheGenerator_UriParser_OnRegister_m3840206273(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t119123863 * tmp = (MonoTODOAttribute_t119123863 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m937077758(tmp, NULL);
	}
}
static void U3CPrivateImplementationDetailsU3E_t3192871060_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void g_Mono_Security_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AssemblyCopyrightAttribute_t4130653132 * tmp = (AssemblyCopyrightAttribute_t4130653132 *)cache->attributes[0];
		AssemblyCopyrightAttribute__ctor_m2442777966(tmp, il2cpp_codegen_string_new_wrapper("(c) 2003-2004 Various Authors"), NULL);
	}
	{
		AssemblyDescriptionAttribute_t1377417777 * tmp = (AssemblyDescriptionAttribute_t1377417777 *)cache->attributes[1];
		AssemblyDescriptionAttribute__ctor_m863331373(tmp, il2cpp_codegen_string_new_wrapper("Mono.Security.dll"), NULL);
	}
	{
		AssemblyProductAttribute_t3079866486 * tmp = (AssemblyProductAttribute_t3079866486 *)cache->attributes[2];
		AssemblyProductAttribute__ctor_m2179734435(tmp, il2cpp_codegen_string_new_wrapper("MONO CLI"), NULL);
	}
	{
		AssemblyTitleAttribute_t4032010531 * tmp = (AssemblyTitleAttribute_t4032010531 *)cache->attributes[3];
		AssemblyTitleAttribute__ctor_m2280157225(tmp, il2cpp_codegen_string_new_wrapper("Mono.Security.dll"), NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m737514648(tmp, true, NULL);
	}
	{
		AssemblyCompanyAttribute_t262073538 * tmp = (AssemblyCompanyAttribute_t262073538 *)cache->attributes[5];
		AssemblyCompanyAttribute__ctor_m1961203133(tmp, il2cpp_codegen_string_new_wrapper("MONO development team"), NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[6];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2873331073 * tmp = (RuntimeCompatibilityAttribute_t2873331073 *)cache->attributes[7];
		RuntimeCompatibilityAttribute__ctor_m1077459611(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2097818566(tmp, true, NULL);
	}
	{
		AssemblyKeyFileAttribute_t756954830 * tmp = (AssemblyKeyFileAttribute_t756954830 *)cache->attributes[8];
		AssemblyKeyFileAttribute__ctor_m515360797(tmp, il2cpp_codegen_string_new_wrapper("../mono.pub"), NULL);
	}
	{
		AssemblyDelaySignAttribute_t1388804811 * tmp = (AssemblyDelaySignAttribute_t1388804811 *)cache->attributes[9];
		AssemblyDelaySignAttribute__ctor_m792735968(tmp, true, NULL);
	}
	{
		NeutralResourcesLanguageAttribute_t2573722287 * tmp = (NeutralResourcesLanguageAttribute_t2573722287 *)cache->attributes[10];
		NeutralResourcesLanguageAttribute__ctor_m1705398382(tmp, il2cpp_codegen_string_new_wrapper("en-US"), NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger__ctor_m3040047200(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger__ctor_m3107529596(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger__ctor_m2947591044(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_SetBit_m1548788441(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_SetBit_m2995356053(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_ToString_m974324122(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_ToString_m2613494688(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_op_Implicit_m1053202820(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_op_Modulus_m1699883937(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_op_Equality_m294921050(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_op_Inequality_m1285189855(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void ModulusRing_t1892935213_CustomAttributesCacheGenerator_ModulusRing_Pow_m4156652970(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m737514648(tmp, false, NULL);
	}
}
static void ASN1_t3432613457_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void PKCS12_t192318788_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map5(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void PKCS12_t192318788_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map6(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void PKCS12_t192318788_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map7(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void PKCS12_t192318788_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map8(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void PKCS12_t192318788_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapC(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509Certificate_t1460961154_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509Certificate_t1460961154_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map10(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509Certificate_t1460961154_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map11(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509CertificateCollection_t3275414985_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509ChainStatusFlags_t2964126077_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void X509Crl_t3265469029_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509Crl_t3265469029_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map13(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void X509ExtensionCollection_t1736530051_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ExtendedKeyUsageExtension_t2231911744_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map14(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void KeyUsages_t4089794537_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void CertTypes_t720719080_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void CipherSuiteCollection_t1115970082_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void HttpsClientStream_t1872672109_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache2(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void HttpsClientStream_t1872672109_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache3(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void HttpsClientStream_t1872672109_CustomAttributesCacheGenerator_HttpsClientStream_U3CHttpsClientStreamU3Em__0_m2170627081(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void HttpsClientStream_t1872672109_CustomAttributesCacheGenerator_HttpsClientStream_U3CHttpsClientStreamU3Em__1_m1135820886(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void RSASslSignatureDeformatter_t2727446502_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map15(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void RSASslSignatureFormatter_t879319000_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map16(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void SecurityProtocolType_t1676794907_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void U3CPrivateImplementationDetailsU3E_t3192871061_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void g_System_Core_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AssemblyCompanyAttribute_t262073538 * tmp = (AssemblyCompanyAttribute_t262073538 *)cache->attributes[0];
		AssemblyCompanyAttribute__ctor_m1961203133(tmp, il2cpp_codegen_string_new_wrapper("MONO development team"), NULL);
	}
	{
		AssemblyDelaySignAttribute_t1388804811 * tmp = (AssemblyDelaySignAttribute_t1388804811 *)cache->attributes[1];
		AssemblyDelaySignAttribute__ctor_m792735968(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t3606053525 * tmp = (CLSCompliantAttribute_t3606053525 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m737514648(tmp, true, NULL);
	}
	{
		NeutralResourcesLanguageAttribute_t2573722287 * tmp = (NeutralResourcesLanguageAttribute_t2573722287 *)cache->attributes[3];
		NeutralResourcesLanguageAttribute__ctor_m1705398382(tmp, il2cpp_codegen_string_new_wrapper("en-US"), NULL);
	}
	{
		AssemblyFileVersionAttribute_t1839628412 * tmp = (AssemblyFileVersionAttribute_t1839628412 *)cache->attributes[4];
		AssemblyFileVersionAttribute__ctor_m104636996(tmp, il2cpp_codegen_string_new_wrapper("3.5.21022.8"), NULL);
	}
	{
		AssemblyInformationalVersionAttribute_t458211439 * tmp = (AssemblyInformationalVersionAttribute_t458211439 *)cache->attributes[5];
		AssemblyInformationalVersionAttribute__ctor_m2606705742(tmp, il2cpp_codegen_string_new_wrapper("3.5.21022.8"), NULL);
	}
	{
		SatelliteContractVersionAttribute_t3058788408 * tmp = (SatelliteContractVersionAttribute_t3058788408 *)cache->attributes[6];
		SatelliteContractVersionAttribute__ctor_m3848511474(tmp, il2cpp_codegen_string_new_wrapper("3.5.0.0"), NULL);
	}
	{
		AssemblyCopyrightAttribute_t4130653132 * tmp = (AssemblyCopyrightAttribute_t4130653132 *)cache->attributes[7];
		AssemblyCopyrightAttribute__ctor_m2442777966(tmp, il2cpp_codegen_string_new_wrapper("(c) various MONO Authors"), NULL);
	}
	{
		AssemblyKeyFileAttribute_t756954830 * tmp = (AssemblyKeyFileAttribute_t756954830 *)cache->attributes[8];
		AssemblyKeyFileAttribute__ctor_m515360797(tmp, il2cpp_codegen_string_new_wrapper("../ecma.pub"), NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2873331073 * tmp = (RuntimeCompatibilityAttribute_t2873331073 *)cache->attributes[9];
		RuntimeCompatibilityAttribute__ctor_m1077459611(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2097818566(tmp, true, NULL);
	}
	{
		DebuggableAttribute_t2636756938 * tmp = (DebuggableAttribute_t2636756938 *)cache->attributes[10];
		DebuggableAttribute__ctor_m2582985872(tmp, 2LL, NULL);
	}
	{
		CompilationRelaxationsAttribute_t2092844809 * tmp = (CompilationRelaxationsAttribute_t2092844809 *)cache->attributes[11];
		CompilationRelaxationsAttribute__ctor_m3343263694(tmp, 8LL, NULL);
	}
	{
		ComVisibleAttribute_t3352689681 * tmp = (ComVisibleAttribute_t3352689681 *)cache->attributes[12];
		ComVisibleAttribute__ctor_m3177107244(tmp, false, NULL);
	}
	{
		StringFreezingAttribute_t10408148 * tmp = (StringFreezingAttribute_t10408148 *)cache->attributes[13];
		StringFreezingAttribute__ctor_m327960799(tmp, NULL);
	}
	{
		SecurityCriticalAttribute_t4019023285 * tmp = (SecurityCriticalAttribute_t4019023285 *)cache->attributes[14];
		SecurityCriticalAttribute__ctor_m4283676607(tmp, NULL);
	}
	{
		DefaultDependencyAttribute_t547142461 * tmp = (DefaultDependencyAttribute_t547142461 *)cache->attributes[15];
		DefaultDependencyAttribute__ctor_m2434010332(tmp, 1LL, NULL);
	}
	{
		AllowPartiallyTrustedCallersAttribute_t2793852185 * tmp = (AllowPartiallyTrustedCallersAttribute_t2793852185 *)cache->attributes[16];
		AllowPartiallyTrustedCallersAttribute__ctor_m3140459627(tmp, NULL);
	}
	{
		AssemblyProductAttribute_t3079866486 * tmp = (AssemblyProductAttribute_t3079866486 *)cache->attributes[17];
		AssemblyProductAttribute__ctor_m2179734435(tmp, il2cpp_codegen_string_new_wrapper("MONO Common language infrastructure"), NULL);
	}
	{
		ExtensionAttribute_t36176176 * tmp = (ExtensionAttribute_t36176176 *)cache->attributes[18];
		ExtensionAttribute__ctor_m4086378263(tmp, NULL);
	}
	{
		AssemblyDefaultAliasAttribute_t3813724156 * tmp = (AssemblyDefaultAliasAttribute_t3813724156 *)cache->attributes[19];
		AssemblyDefaultAliasAttribute__ctor_m1008481974(tmp, il2cpp_codegen_string_new_wrapper("System.Core.dll"), NULL);
	}
	{
		AssemblyDescriptionAttribute_t1377417777 * tmp = (AssemblyDescriptionAttribute_t1377417777 *)cache->attributes[20];
		AssemblyDescriptionAttribute__ctor_m863331373(tmp, il2cpp_codegen_string_new_wrapper("System.Core.dll"), NULL);
	}
	{
		AssemblyTitleAttribute_t4032010531 * tmp = (AssemblyTitleAttribute_t4032010531 *)cache->attributes[21];
		AssemblyTitleAttribute__ctor_m2280157225(tmp, il2cpp_codegen_string_new_wrapper("System.Core.dll"), NULL);
	}
}
static void ExtensionAttribute_t36176176_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 69LL, NULL);
	}
}
static void Locale_t57088991_CustomAttributesCacheGenerator_Locale_GetText_m2212416198____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void Enumerable_t3932770618_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t36176176 * tmp = (ExtensionAttribute_t36176176 *)cache->attributes[0];
		ExtensionAttribute__ctor_m4086378263(tmp, NULL);
	}
}
static void Enumerable_t3932770618_CustomAttributesCacheGenerator_Enumerable_Any_m437989361(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t36176176 * tmp = (ExtensionAttribute_t36176176 *)cache->attributes[0];
		ExtensionAttribute__ctor_m4086378263(tmp, NULL);
	}
}
static void Enumerable_t3932770618_CustomAttributesCacheGenerator_Enumerable_Where_m311029895(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t36176176 * tmp = (ExtensionAttribute_t36176176 *)cache->attributes[0];
		ExtensionAttribute__ctor_m4086378263(tmp, NULL);
	}
}
static void Enumerable_t3932770618_CustomAttributesCacheGenerator_Enumerable_CreateWhereIterator_m2574702225(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_Generic_IEnumeratorU3CTSourceU3E_get_Current_m3031864783(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_IEnumerator_get_Current_m2799052118(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_IEnumerable_GetEnumerator_m477268233(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_Generic_IEnumerableU3CTSourceU3E_GetEnumerator_m1473712349(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_Dispose_m1794745798(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_Reset_m2986643486(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t177041199 * tmp = (DebuggerHiddenAttribute_t177041199 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m1902081030(tmp, NULL);
	}
}
static void U3CPrivateImplementationDetailsU3E_t3192871062_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void g_UnityEngine_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[0];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.ClothModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[1];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.VehiclesModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[2];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Physics2DModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[3];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.PhysicsModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[4];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.ParticleSystemModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[5];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UmbraModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[6];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.RuntimeTests.Framework.Tests"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[7];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.AIModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[8];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.NScreenModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[9];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.TerrainPhysicsModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[10];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UIModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[11];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.TextRenderingModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[12];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.TerrainModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[13];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.AnimationModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[14];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.AudioModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[15];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.RuntimeTests.Framework"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[16];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Advertisements"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[17];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Analytics"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[18];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Cloud.Service"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[19];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Cloud"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[20];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Networking"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[21];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.TerrainPhysics"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[22];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Terrain"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[23];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Purchasing"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[24];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.RuntimeTests"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[25];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.IntegrationTests.Framework"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[26];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.IntegrationTests.UnityAnalytics"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[27];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.IntegrationTests"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[28];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.DeploymentTests.Services"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[29];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.Automation"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[30];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Timeline"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[31];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.JSONSerializeModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[32];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.ImageConversionModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[33];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.GameCenterModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[34];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.BaselibModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[35];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.StyleSheetsModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[36];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UIElementsModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[37];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.VideoModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[38];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.CloudWebServicesModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[39];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.WebModule"), NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2873331073 * tmp = (RuntimeCompatibilityAttribute_t2873331073 *)cache->attributes[40];
		RuntimeCompatibilityAttribute__ctor_m1077459611(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2097818566(tmp, true, NULL);
	}
	{
		DebuggableAttribute_t2636756938 * tmp = (DebuggableAttribute_t2636756938 *)cache->attributes[41];
		DebuggableAttribute__ctor_m2582985872(tmp, 258LL, NULL);
	}
	{
		ExtensionAttribute_t36176176 * tmp = (ExtensionAttribute_t36176176 *)cache->attributes[42];
		ExtensionAttribute__ctor_m4086378263(tmp, NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[43];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.SpriteMaskModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[44];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.ScreenCaptureModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[45];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.ParticlesLegacyModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[46];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.InputModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[47];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.VRModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[48];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UnityConnectModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[49];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.ClusterInputModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[50];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UnityWebRequestWWWModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[51];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UnityWebRequestTextureModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[52];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UnityWebRequestAudioModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[53];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UnityWebRequestModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[54];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.IMGUIModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[55];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.FacebookModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[56];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.ClusterRendererModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[57];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.PerformanceReportingModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[58];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.CrashReportingModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[59];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UnityAnalyticsModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[60];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.TimelineModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[61];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.DirectorModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[62];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UNETModule"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[63];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Physics"), NULL);
	}
}
static void Application_t821171777_CustomAttributesCacheGenerator_lowMemory(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void Application_t821171777_CustomAttributesCacheGenerator_onBeforeRender(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void Application_t821171777_CustomAttributesCacheGenerator_Application_CallLowMemory_m950526118(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Application_t821171777_CustomAttributesCacheGenerator_Application_CallLogCallback_m1230073937(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Application_t821171777_CustomAttributesCacheGenerator_Application_InvokeOnBeforeRender_m367288211(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AssetBundleCreateRequest_t2444460025_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AssetBundleCreateRequest_t2444460025_CustomAttributesCacheGenerator_AssetBundleCreateRequest_get_assetBundle_m1127086494(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AssetBundleCreateRequest_t2444460025_CustomAttributesCacheGenerator_AssetBundleCreateRequest_DisableCompatibilityChecks_m1123061109(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AssetBundleRequest_t988638785_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AssetBundleRequest_t988638785_CustomAttributesCacheGenerator_AssetBundleRequest_get_asset_m1618802054(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AssetBundleRequest_t988638785_CustomAttributesCacheGenerator_AssetBundleRequest_get_allAssets_m4077343547(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AsyncOperation_t1216045970_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_InternalDestroy_m989121897(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[1];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
}
static void AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_get_isDone_m2130057835(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_get_progress_m132026404(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_get_priority_m3349967333(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_set_priority_m2349794837(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_get_allowSceneActivation_m3755262598(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_set_allowSceneActivation_m384018621(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void WaitForSeconds_t2172464514_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void WaitForFixedUpdate_t231781307_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void WaitForEndOfFrame_t3943813712_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Coroutine_t56146755_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Coroutine_t56146755_CustomAttributesCacheGenerator_Coroutine_ReleaseCoroutine_m3781988635(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[0];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void ScriptableObject_t643150937_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void ScriptableObject_t643150937_CustomAttributesCacheGenerator_ScriptableObject_Internal_CreateScriptableObject_m497791512(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[0];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void ScriptableObject_t643150937_CustomAttributesCacheGenerator_ScriptableObject_Internal_CreateScriptableObject_m497791512____self0(CustomAttributesCache* cache)
{
	{
		WritableAttribute_t718555548 * tmp = (WritableAttribute_t718555548 *)cache->attributes[0];
		WritableAttribute__ctor_m2889669273(tmp, NULL);
	}
}
static void ScriptableObject_t643150937_CustomAttributesCacheGenerator_ScriptableObject_CreateInstance_m1184682349(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void ScriptableObject_t643150937_CustomAttributesCacheGenerator_ScriptableObject_CreateInstanceFromType_m1377228085(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void FailedToLoadScriptObject_t1581619330_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Behaviour_t2953351352_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Camera_t142011664_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
	{
		RequireComponent_t2231837482 * tmp = (RequireComponent_t2231837482 *)cache->attributes[1];
		RequireComponent__ctor_m715180030(tmp, il2cpp_codegen_type_get_object(Transform_t2636691836_0_0_0_var), NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_nearClipPlane_m595687364(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_farClipPlane_m672532137(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_cullingMask_m1829245964(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_eventMask_m192041623(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_INTERNAL_get_pixelRect_m3579949699(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_targetTexture_m2343817798(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_clearFlags_m4107941227(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_INTERNAL_CALL_ScreenPointToRay_m1092094677(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_allCamerasCount_m202689974(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_GetAllCameras_m14780124(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_FireOnPreCull_m2833190726(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_FireOnPreRender_m3227173956(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_FireOnPostRender_m169492450(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_INTERNAL_CALL_RaycastTry_m3176538179(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Camera_t142011664_CustomAttributesCacheGenerator_Camera_INTERNAL_CALL_RaycastTry2D_m1805928838(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_get_transform_m1991721595(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_get_gameObject_m44324674(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponent_m4065514490(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 0LL, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentFastPath_m2526947697(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponent_m3948181317(CustomAttributesCache* cache)
{
	{
		SecuritySafeCriticalAttribute_t3761815145 * tmp = (SecuritySafeCriticalAttribute_t3761815145 *)cache->attributes[0];
		SecuritySafeCriticalAttribute__ctor_m1104744884(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponent_m3003597536(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m174763428(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 0LL, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m916963883(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 0LL, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m2013229797(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m2478491131____includeInactive0(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentsInChildren_m3617139144(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentsInChildren_m155792327____includeInactive1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentInParent_m3868731529(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 0LL, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentsInParent_m218516534(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentsInParent_m1469804712____includeInactive1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentsForListInternal_m2222527641(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2783812412(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2783812412____value1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("null"), NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2783812412____options2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("SendMessageOptions.RequireReceiver"), NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2173372724(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m3268518138(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessage_m4289933507(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessage_m4289933507____value1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("null"), NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessage_m4289933507____options2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("SendMessageOptions.RequireReceiver"), NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessage_m3305852972(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessage_m872975486(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_BroadcastMessage_m3258471174(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_BroadcastMessage_m3258471174____parameter1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("null"), NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_BroadcastMessage_m3258471174____options2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("SendMessageOptions.RequireReceiver"), NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_BroadcastMessage_m2127138074(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Component_t21088299_CustomAttributesCacheGenerator_Component_BroadcastMessage_m1539754661(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void CullingGroup_t3411111508_CustomAttributesCacheGenerator_CullingGroup_Dispose_m1171631894(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CullingGroup_t3411111508_CustomAttributesCacheGenerator_CullingGroup_SendEvents_m2564931990(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
	{
		SecuritySafeCriticalAttribute_t3761815145 * tmp = (SecuritySafeCriticalAttribute_t3761815145 *)cache->attributes[1];
		SecuritySafeCriticalAttribute__ctor_m1104744884(tmp, NULL);
	}
}
static void CullingGroup_t3411111508_CustomAttributesCacheGenerator_CullingGroup_FinalizerFailure_m2017674841(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[1];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
}
static void DebugLogHandler_t1263485877_CustomAttributesCacheGenerator_DebugLogHandler_Internal_Log_m2703551542(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[0];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void DebugLogHandler_t1263485877_CustomAttributesCacheGenerator_DebugLogHandler_Internal_Log_m2703551542____obj2(CustomAttributesCache* cache)
{
	{
		WritableAttribute_t718555548 * tmp = (WritableAttribute_t718555548 *)cache->attributes[0];
		WritableAttribute__ctor_m2889669273(tmp, NULL);
	}
}
static void DebugLogHandler_t1263485877_CustomAttributesCacheGenerator_DebugLogHandler_LogFormat_m4019243538____args3(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void Display_t289224223_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void Display_t289224223_CustomAttributesCacheGenerator_onDisplaysUpdated(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Display_t289224223_CustomAttributesCacheGenerator_Display_RecreateDisplayList_m1233426626(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Display_t289224223_CustomAttributesCacheGenerator_Display_FireDisplaysUpdated_m2028285549(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponent_m2381985773(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 0LL, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponent_m2317715085(CustomAttributesCache* cache)
{
	{
		SecuritySafeCriticalAttribute_t3761815145 * tmp = (SecuritySafeCriticalAttribute_t3761815145 *)cache->attributes[0];
		SecuritySafeCriticalAttribute__ctor_m1104744884(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponentInChildren_m1168178952(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 0LL, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponentInParent_m576974860(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 0LL, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponentsInChildren_m544289345____includeInactive1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponentsInParent_m3716665394____includeInactive1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponentsInternal_m3558330862(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_get_transform_m3351892996(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_SetActive_m924703582(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_get_tag_m3253026982(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_set_tag_m2601144065(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_CompareTag_m4047912073(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_FindGameObjectWithTag_m3016707382(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_SendMessage_m1793137815(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_SendMessage_m1793137815____value1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("null"), NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_SendMessage_m1793137815____options2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("SendMessageOptions.RequireReceiver"), NULL);
	}
}
static void GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_Find_m357843493(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Gradient_t19391121_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Gradient_t19391121_CustomAttributesCacheGenerator_Gradient__ctor_m3449608876(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Gradient_t19391121_CustomAttributesCacheGenerator_Gradient_Init_m665431756(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[1];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
}
static void Gradient_t19391121_CustomAttributesCacheGenerator_Gradient_Cleanup_m3762357176(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[0];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void GUIElement_t2816691599_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GUIElement_t2816691599_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t2231837482 * tmp = (RequireComponent_t2231837482 *)cache->attributes[0];
		RequireComponent__ctor_m715180030(tmp, il2cpp_codegen_type_get_object(Transform_t2636691836_0_0_0_var), NULL);
	}
}
static void GUILayer_t3734926407_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GUILayer_t3734926407_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t2231837482 * tmp = (RequireComponent_t2231837482 *)cache->attributes[0];
		RequireComponent__ctor_m715180030(tmp, il2cpp_codegen_type_get_object(Camera_t142011664_0_0_0_var), NULL);
	}
}
static void GUILayer_t3734926407_CustomAttributesCacheGenerator_GUILayer_INTERNAL_CALL_HitTest_m169839011(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Input_t1429468892_CustomAttributesCacheGenerator_Input_GetKeyDownInt_m634892559(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Input_t1429468892_CustomAttributesCacheGenerator_Input_GetAxis_m1666418521(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Input_t1429468892_CustomAttributesCacheGenerator_Input_GetMouseButton_m3485621271(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Input_t1429468892_CustomAttributesCacheGenerator_Input_GetMouseButtonDown_m3468031552(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Input_t1429468892_CustomAttributesCacheGenerator_Input_INTERNAL_get_mousePosition_m2607797593(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Vector3_t2987449647_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[1];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void Quaternion_t895809378_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Quaternion_t895809378_CustomAttributesCacheGenerator_Quaternion_INTERNAL_CALL_Inverse_m2122284289(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Quaternion_t895809378_CustomAttributesCacheGenerator_Quaternion_INTERNAL_CALL_Internal_FromEulerRad_m1158394978(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Bounds_t1424290876_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void Keyframe_t1047575712_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AnimationCurve_t2995615556_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AnimationCurve_t2995615556_CustomAttributesCacheGenerator_AnimationCurve__ctor_m1256678767____keys0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void AnimationCurve_t2995615556_CustomAttributesCacheGenerator_AnimationCurve__ctor_m3546708367(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AnimationCurve_t2995615556_CustomAttributesCacheGenerator_AnimationCurve_Cleanup_m870304867(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[1];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
}
static void AnimationCurve_t2995615556_CustomAttributesCacheGenerator_AnimationCurve_Init_m2288700569(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[0];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_Internal_CancelInvokeAll_m134567439(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_Internal_IsInvokingAll_m2498687012(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_Invoke_m1445658415(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_InvokeRepeating_m1711920500(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_CancelInvoke_m3804726668(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_IsInvoking_m878787515(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_Auto_m597942758(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m74976096(tmp, il2cpp_codegen_string_new_wrapper("StartCoroutine_Auto has been deprecated. Use StartCoroutine instead (UnityUpgradable) -> StartCoroutine([mscorlib] System.Collections.IEnumerator)"), false, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_Auto_Internal_m1203968900(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_m1532927778(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_m1532927778____value1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("null"), NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_m2151747079(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StopCoroutine_m2372275704(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StopCoroutineViaEnumerator_Auto_m2517862605(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StopCoroutine_Auto_m1706763131(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StopAllCoroutines_m3012207369(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_get_useGUILayout_m14506679(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_set_useGUILayout_m3498661562(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_GetScriptClassName_m574979679(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void ResourceRequest_t2922114009_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Resources_t428789352_CustomAttributesCacheGenerator_Resources_Load_m3111310461(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[1];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 1LL, NULL);
	}
}
static void Texture_t3041836855_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void RenderTexture_t682290025_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void Time_t2376931198_CustomAttributesCacheGenerator_Time_get_deltaTime_m3885432000(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void HideFlags_t1270484704_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_Internal_CloneSingle_m1112466195(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_Internal_CloneSingleWithParent_m1578544937(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_INTERNAL_CALL_Internal_InstantiateSingle_m2354361480(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_INTERNAL_CALL_Internal_InstantiateSingleWithParent_m3351340621(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_GetOffsetOfInstanceIDInCPlusPlusObject_m2289052263(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[0];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_EnsureRunningOnMainThread_m2181426889(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[1];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_Destroy_m763870395(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_Destroy_m763870395____t1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("0.0F"), NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_Destroy_m2578737452(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyImmediate_m3667352557(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyImmediate_m3667352557____allowDestroyingAssets1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyImmediate_m3664569503(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_FindObjectsOfType_m4065607311(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 2LL, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_get_name_m4131808298(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_set_name_m1574609734(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_DontDestroyOnLoad_m3006908952(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_get_hideFlags_m606243072(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_set_hideFlags_m1764873955(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyObject_m3415511966(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyObject_m3415511966____t1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("0.0F"), NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyObject_m4157767402(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_FindSceneObjectsOfType_m1789838274(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[1];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("use Object.FindObjectsOfType instead."), NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_FindObjectsOfTypeIncludingAssets_m2898151650(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[1];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("use Resources.FindObjectsOfTypeAll instead."), NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_ToString_m1543712694(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_DoesObjectWithInstanceIDExist_m249218142(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[0];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_GetInstanceID_m2901521971(CustomAttributesCache* cache)
{
	{
		SecuritySafeCriticalAttribute_t3761815145 * tmp = (SecuritySafeCriticalAttribute_t3761815145 *)cache->attributes[0];
		SecuritySafeCriticalAttribute__ctor_m1104744884(tmp, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_Instantiate_m3626274236(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 3LL, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_Instantiate_m499133587(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 3LL, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_Instantiate_m2255325978(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 3LL, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_Instantiate_m1560403475(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 3LL, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_Instantiate_m2568982308(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 3LL, NULL);
	}
}
static void Object_t3267094820_CustomAttributesCacheGenerator_Object_FindObjectOfType_m1934888875(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1237727610 * tmp = (TypeInferenceRuleAttribute_t1237727610 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m273865400(tmp, 0LL, NULL);
	}
}
static void YieldInstruction_t2994650433_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void PlayableHandle_t2910061178_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_IsValidInternal_m2904663435(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_GetPlayableTypeOf_m1882865113(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_GetPlayStateInternal_m79066241(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_SetPlayStateInternal_m3501090634(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_SetTimeInternal_m207615318(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_SetDurationInternal_m2581365362(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_SetInputCountInternal_m4151268303(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Playable_t3436777522_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void PlayableGraph_t4192197450_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void PlayableGraph_t4192197450_CustomAttributesCacheGenerator_PlayableGraph_INTERNAL_CALL_CreateScriptOutputInternal_m2263530833(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void PlayableGraph_t4192197450_CustomAttributesCacheGenerator_PlayableGraph_INTERNAL_CALL_CreatePlayableHandleInternal_m848171998(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void PlayableOutputHandle_t4210482917_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void PlayableOutputHandle_t4210482917_CustomAttributesCacheGenerator_PlayableOutputHandle_INTERNAL_CALL_IsValidInternal_m2309803248(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void PlayableOutputHandle_t4210482917_CustomAttributesCacheGenerator_PlayableOutputHandle_INTERNAL_CALL_GetPlayableOutputTypeOf_m4071527298(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void PlayableOutput_t758663699_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SceneManager_t2350656246_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SceneManager_t2350656246_CustomAttributesCacheGenerator_sceneLoaded(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void SceneManager_t2350656246_CustomAttributesCacheGenerator_sceneUnloaded(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void SceneManager_t2350656246_CustomAttributesCacheGenerator_activeSceneChanged(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void SceneManager_t2350656246_CustomAttributesCacheGenerator_SceneManager_Internal_SceneLoaded_m4213089961(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SceneManager_t2350656246_CustomAttributesCacheGenerator_SceneManager_Internal_SceneUnloaded_m4274988325(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SceneManager_t2350656246_CustomAttributesCacheGenerator_SceneManager_Internal_ActiveSceneChanged_m237859709(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_get_position_m2271944548(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_set_position_m2678488908(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_get_rotation_m3993959474(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_set_rotation_m3387907152(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_get_localRotation_m420822815(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_set_localRotation_m365960821(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_Rotate_m2953437478____relativeTo1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("Space.Self"), NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_Rotate_m1099066500(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_Rotate_m678397658____relativeTo3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("Space.Self"), NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_get_childCount_m4116705935(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Transform_t2636691836_CustomAttributesCacheGenerator_Transform_GetChild_m1662106098(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void RectTransform_t243927805_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		NativeClassAttribute_t3768029985 * tmp = (NativeClassAttribute_t3768029985 *)cache->attributes[0];
		NativeClassAttribute__ctor_m130061132(tmp, il2cpp_codegen_string_new_wrapper("UI::RectTransform"), NULL);
	}
}
static void RectTransform_t243927805_CustomAttributesCacheGenerator_reapplyDrivenProperties(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void RectTransform_t243927805_CustomAttributesCacheGenerator_RectTransform_SendReapplyDrivenProperties_m1673235392(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SpriteAtlasManager_t485087596_CustomAttributesCacheGenerator_atlasRequested(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void SpriteAtlasManager_t485087596_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void SpriteAtlasManager_t485087596_CustomAttributesCacheGenerator_SpriteAtlasManager_RequestAtlas_m351979735(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SpriteAtlasManager_t485087596_CustomAttributesCacheGenerator_SpriteAtlasManager_Register_m3968478932(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void ControllerColliderHit_t3057575995_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Collision_t1992409213_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Collision_t1992409213_CustomAttributesCacheGenerator_Collision_t1992409213____impactForceSum_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m74976096(tmp, il2cpp_codegen_string_new_wrapper("Use Collision.relativeVelocity instead."), false, NULL);
	}
}
static void Collision_t1992409213_CustomAttributesCacheGenerator_Collision_t1992409213____frictionForceSum_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m74976096(tmp, il2cpp_codegen_string_new_wrapper("Will always return zero."), false, NULL);
	}
}
static void Collision_t1992409213_CustomAttributesCacheGenerator_Collision_t1992409213____other_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m74976096(tmp, il2cpp_codegen_string_new_wrapper("Please use Collision.rigidbody, Collision.transform or Collision.collider instead"), false, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3719768030(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2350840452(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m913384994(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3873687999____maxDistance2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3873687999____layerMask3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3873687999____queryTriggerInteraction4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3877441014(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3826659266(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2170746783(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2445896246____maxDistance3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2445896246____layerMask4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2445896246____queryTriggerInteraction5(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2802259901(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2419782515(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3871305434(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3013423287____maxDistance1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3013423287____layerMask2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3013423287____queryTriggerInteraction3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3076132749(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m1510999213(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m54040585(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3887300606____maxDistance2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3887300606____layerMask3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3887300606____queryTriggerInteraction4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m3686607343(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m2500737461(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m4120885497(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m1735216570____maxDistance1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m1735216570____layerMask2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m1735216570____queryTriggerInteraction3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m2296021024____maxDistance2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m2296021024____layermask3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m2296021024____queryTriggerInteraction4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m1144311404(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m98091116(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m1515184189(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_INTERNAL_CALL_RaycastAll_m3201440179(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_INTERNAL_CALL_Internal_Raycast_m2853825113(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Physics_t3588812769_CustomAttributesCacheGenerator_Physics_INTERNAL_CALL_Internal_RaycastTest_m3339338234(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void ContactPoint_t3765348581_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void Rigidbody_t3670484383_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Rigidbody_t3670484383_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t2231837482 * tmp = (RequireComponent_t2231837482 *)cache->attributes[0];
		RequireComponent__ctor_m715180030(tmp, il2cpp_codegen_type_get_object(Transform_t2636691836_0_0_0_var), NULL);
	}
}
static void Rigidbody_t3670484383_CustomAttributesCacheGenerator_Rigidbody_INTERNAL_set_velocity_m36759112(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Rigidbody_t3670484383_CustomAttributesCacheGenerator_Rigidbody_get_isKinematic_m3289074417(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Rigidbody_t3670484383_CustomAttributesCacheGenerator_Rigidbody_set_isKinematic_m3808468253(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Rigidbody_t3670484383_CustomAttributesCacheGenerator_Rigidbody_set_constraints_m1675396742(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Collider_t3066580567_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t2231837482 * tmp = (RequireComponent_t2231837482 *)cache->attributes[0];
		RequireComponent__ctor_m715180030(tmp, il2cpp_codegen_type_get_object(Transform_t2636691836_0_0_0_var), NULL);
	}
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_enabled_m1012249734(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_set_enabled_m3023772319(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_attachedRigidbody_m1223649037(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_isTrigger_m3411014092(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_set_isTrigger_m3915953166(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_contactOffset_m2439063487(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_set_contactOffset_m683432949(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_material_m1577688535(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_set_material_m1981090199(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_INTERNAL_CALL_ClosestPointOnBounds_m983298871(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_INTERNAL_CALL_ClosestPoint_m1905885810(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_sharedMaterial_m3186711189(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_set_sharedMaterial_m378738133(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_INTERNAL_get_bounds_m924372968(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Collider_t3066580567_CustomAttributesCacheGenerator_Collider_INTERNAL_CALL_Internal_Raycast_m935082044(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void BoxCollider_t1526745396_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void BoxCollider_t1526745396_CustomAttributesCacheGenerator_BoxCollider_INTERNAL_get_center_m2108458525(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void BoxCollider_t1526745396_CustomAttributesCacheGenerator_BoxCollider_INTERNAL_set_center_m1608300232(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void BoxCollider_t1526745396_CustomAttributesCacheGenerator_BoxCollider_INTERNAL_get_size_m2915107625(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void BoxCollider_t1526745396_CustomAttributesCacheGenerator_BoxCollider_INTERNAL_set_size_m1069292286(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void BoxCollider_t1526745396_CustomAttributesCacheGenerator_BoxCollider_t1526745396____extents_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("use BoxCollider.size instead."), NULL);
	}
}
static void SphereCollider_t4124484268_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SphereCollider_t4124484268_CustomAttributesCacheGenerator_SphereCollider_INTERNAL_get_center_m3462447041(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void SphereCollider_t4124484268_CustomAttributesCacheGenerator_SphereCollider_INTERNAL_set_center_m3242641947(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void SphereCollider_t4124484268_CustomAttributesCacheGenerator_SphereCollider_get_radius_m1946668759(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void SphereCollider_t4124484268_CustomAttributesCacheGenerator_SphereCollider_set_radius_m2008006599(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MeshCollider_t3573562696_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_get_sharedMesh_m3981733887(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_set_sharedMesh_m1749649964(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_get_convex_m3624458602(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_set_convex_m3852711973(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_get_inflateMesh_m3117051985(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_set_inflateMesh_m3536367144(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_get_skinWidth_m4113017802(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_set_skinWidth_m480533321(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_t3573562696____smoothSphereCollisions_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Configuring smooth sphere collisions is no longer needed. PhysX3 has a better behaviour in place."), NULL);
	}
}
static void CapsuleCollider_t4114432674_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_INTERNAL_get_center_m343696755(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_INTERNAL_set_center_m2335165673(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_get_radius_m4172507562(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_set_radius_m762145652(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_get_height_m3662458997(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_set_height_m2754457501(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_get_direction_m2169980597(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_set_direction_m3664861627(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void RaycastHit_t2786726017_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void CharacterController_t2965295687_CustomAttributesCacheGenerator_CharacterController_INTERNAL_CALL_Move_m2501923996(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CharacterController_t2965295687_CustomAttributesCacheGenerator_CharacterController_get_isGrounded_m3015943198(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioPlayableOutput_t2616039667_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AudioPlayableOutput_t2616039667_CustomAttributesCacheGenerator_AudioPlayableOutput_INTERNAL_CALL_InternalGetTarget_m3249422738(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioPlayableOutput_t2616039667_CustomAttributesCacheGenerator_AudioPlayableOutput_INTERNAL_CALL_InternalSetTarget_m3185628123(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_GetClipInternal_m317731256(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_SetClipInternal_m1813683739(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_GetLoopedInternal_m3132985087(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_SetLoopedInternal_m3163919323(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_GetIsPlayingInternal_m3248130146(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_GetStartDelayInternal_m1864145844(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_SetStartDelayInternal_m3452625175(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_GetPauseDelayInternal_m4032398432(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_SetPauseDelayInternal_m234566193(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_InternalCreateAudioClipPlayable_m496825388(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_ValidateType_m2412648730(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_Seek_m1537206734(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t2642155980 * tmp = (ExcludeFromDocsAttribute_t2642155980 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1396943425(tmp, NULL);
	}
}
static void AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_Seek_m743928150____duration2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1239497132 * tmp = (DefaultValueAttribute_t1239497132 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m1493972517(tmp, il2cpp_codegen_string_new_wrapper("0"), NULL);
	}
}
static void AudioMixerPlayable_t3345238233_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AudioMixerPlayable_t3345238233_CustomAttributesCacheGenerator_AudioMixerPlayable_INTERNAL_CALL_GetAutoNormalizeInternal_m2057364040(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioMixerPlayable_t3345238233_CustomAttributesCacheGenerator_AudioMixerPlayable_INTERNAL_CALL_SetAutoNormalizeInternal_m987980948(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioMixerPlayable_t3345238233_CustomAttributesCacheGenerator_AudioMixerPlayable_INTERNAL_CALL_CreateAudioMixerPlayableInternal_m290331118(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioSettings_t668402879_CustomAttributesCacheGenerator_OnAudioConfigurationChanged(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void AudioSettings_t668402879_CustomAttributesCacheGenerator_AudioSettings_InvokeOnAudioConfigurationChanged_m61046006(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AudioClip_t1031729136_CustomAttributesCacheGenerator_m_PCMReaderCallback(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void AudioClip_t1031729136_CustomAttributesCacheGenerator_m_PCMSetPositionCallback(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void AudioClip_t1031729136_CustomAttributesCacheGenerator_AudioClip_get_length_m2904044266(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void AudioClip_t1031729136_CustomAttributesCacheGenerator_AudioClip_InvokePCMReaderCallback_Internal_m3969674143(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AudioClip_t1031729136_CustomAttributesCacheGenerator_AudioClip_InvokePCMSetPositionCallback_Internal_m4230058079(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AudioSource_t3205450310_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AudioSource_t3205450310_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t2231837482 * tmp = (RequireComponent_t2231837482 *)cache->attributes[0];
		RequireComponent__ctor_m715180030(tmp, il2cpp_codegen_type_get_object(Transform_t2636691836_0_0_0_var), NULL);
	}
}
static void AudioPlayableGraphExtensions_t1250035765_CustomAttributesCacheGenerator_AudioPlayableGraphExtensions_INTERNAL_CALL_InternalCreateAudioOutput_m2119112406(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void Font_t208834271_CustomAttributesCacheGenerator_textureRebuilt(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void Font_t208834271_CustomAttributesCacheGenerator_m_FontTextureRebuildCallback(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void Font_t208834271_CustomAttributesCacheGenerator_Font_InvokeTextureRebuilt_Internal_m3404887950(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void FontTextureRebuildCallback_t940970719_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		EditorBrowsableAttribute_t1429620940 * tmp = (EditorBrowsableAttribute_t1429620940 *)cache->attributes[0];
		EditorBrowsableAttribute__ctor_m2659158224(tmp, 1LL, NULL);
	}
}
static void WebRequestUtils_t248386542_CustomAttributesCacheGenerator_WebRequestUtils_RedirectTo_m1519057860(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_InternalCreate_m880206285(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_InternalDestroy_m2519008968(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[0];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddString_m659451336(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddBool_m398788015(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddChar_m319900760(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddByte_m3717748694(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddSByte_m3340687799(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddInt16_m1608076704(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddUInt16_m204323820(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddInt32_m779198032(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddUInt32_m2154319333(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddInt64_m3524891666(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddUInt64_m2735082319(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddDouble_m1124663272(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void UnityAnalyticsHandler_t627637005_CustomAttributesCacheGenerator_UnityAnalyticsHandler_InternalCreate_m2671862836(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void UnityAnalyticsHandler_t627637005_CustomAttributesCacheGenerator_UnityAnalyticsHandler_InternalDestroy_m304093635(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafeAttribute_t401734977 * tmp = (ThreadAndSerializationSafeAttribute_t401734977 *)cache->attributes[0];
		ThreadAndSerializationSafeAttribute__ctor_m14339559(tmp, NULL);
	}
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[1];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void UnityAnalyticsHandler_t627637005_CustomAttributesCacheGenerator_UnityAnalyticsHandler_SendCustomEventName_m3481945465(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void UnityAnalyticsHandler_t627637005_CustomAttributesCacheGenerator_UnityAnalyticsHandler_SendCustomEvent_m3074734922(CustomAttributesCache* cache)
{
	{
		GeneratedByOldBindingsGeneratorAttribute_t1890141928 * tmp = (GeneratedByOldBindingsGeneratorAttribute_t1890141928 *)cache->attributes[0];
		GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088(tmp, NULL);
	}
}
static void RemoteSettings_t2880773625_CustomAttributesCacheGenerator_Updated(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void RemoteSettings_t2880773625_CustomAttributesCacheGenerator_RemoteSettings_CallOnUpdate_m3230028317(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AttributeHelperEngine_t1985212046_CustomAttributesCacheGenerator_AttributeHelperEngine_GetParentTypeDisallowingMultipleInclusion_m4119152402(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AttributeHelperEngine_t1985212046_CustomAttributesCacheGenerator_AttributeHelperEngine_GetRequiredComponents_m942683377(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AttributeHelperEngine_t1985212046_CustomAttributesCacheGenerator_AttributeHelperEngine_CheckIsEditorScript_m4061418281(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void AttributeHelperEngine_t1985212046_CustomAttributesCacheGenerator_AttributeHelperEngine_GetDefaultExecutionOrderFor_m3266095226(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void DisallowMultipleComponent_t1571297057_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void RequireComponent_t2231837482_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
	}
}
static void ContextMenu_t1432722795_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
	}
}
static void DefaultExecutionOrder_t1687762308_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4LL, NULL);
	}
}
static void DefaultExecutionOrder_t1687762308_CustomAttributesCacheGenerator_U3CorderU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void DefaultExecutionOrder_t1687762308_CustomAttributesCacheGenerator_DefaultExecutionOrder_get_order_m3764018895(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void NativeClassAttribute_t3768029985_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 12LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void NativeClassAttribute_t3768029985_CustomAttributesCacheGenerator_U3CQualifiedNativeNameU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void NativeClassAttribute_t3768029985_CustomAttributesCacheGenerator_NativeClassAttribute_set_QualifiedNativeName_m293935591(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void AssemblyIsEditorAssembly_t1075301690_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1LL, NULL);
	}
}
static void WritableAttribute_t718555548_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 2048LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, false, NULL);
	}
}
static void ClassLibraryInitializer_t1120328420_CustomAttributesCacheGenerator_ClassLibraryInitializer_Init_m678390546(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SetupCoroutine_t928779329_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SetupCoroutine_t928779329_CustomAttributesCacheGenerator_SetupCoroutine_InvokeMoveNext_m2573614623(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
	{
		SecuritySafeCriticalAttribute_t3761815145 * tmp = (SecuritySafeCriticalAttribute_t3761815145 *)cache->attributes[1];
		SecuritySafeCriticalAttribute__ctor_m1104744884(tmp, NULL);
	}
}
static void SetupCoroutine_t928779329_CustomAttributesCacheGenerator_SetupCoroutine_InvokeMember_m3217874590(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SendMouseEvents_t2250526872_CustomAttributesCacheGenerator_SendMouseEvents_SetMouseMoved_m1615166369(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void SendMouseEvents_t2250526872_CustomAttributesCacheGenerator_SendMouseEvents_DoSendMouseEvents_m1673877171(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Rect_t1940963286_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void SerializePrivateVariables_t2211538169_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
	{
		ObsoleteAttribute_t534593266 * tmp = (ObsoleteAttribute_t534593266 *)cache->attributes[1];
		ObsoleteAttribute__ctor_m3649443664(tmp, il2cpp_codegen_string_new_wrapper("Use SerializeField on the private variables that you want to be serialized instead"), NULL);
	}
}
static void SerializeField_t1114448220_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void PreferBinarySerialization_t3164250034_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 4LL, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void ISerializationCallbackReceiver_t3652988088_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void StackTraceUtility_t599648129_CustomAttributesCacheGenerator_StackTraceUtility_SetProjectFolder_m2868605785(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void StackTraceUtility_t599648129_CustomAttributesCacheGenerator_StackTraceUtility_ExtractStackTrace_m1508434409(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
	{
		SecuritySafeCriticalAttribute_t3761815145 * tmp = (SecuritySafeCriticalAttribute_t3761815145 *)cache->attributes[1];
		SecuritySafeCriticalAttribute__ctor_m1104744884(tmp, NULL);
	}
}
static void StackTraceUtility_t599648129_CustomAttributesCacheGenerator_StackTraceUtility_ExtractStringFromExceptionInternal_m3206191879(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
	{
		SecuritySafeCriticalAttribute_t3761815145 * tmp = (SecuritySafeCriticalAttribute_t3761815145 *)cache->attributes[1];
		SecuritySafeCriticalAttribute__ctor_m1104744884(tmp, NULL);
	}
}
static void StackTraceUtility_t599648129_CustomAttributesCacheGenerator_StackTraceUtility_PostprocessStacktrace_m8392584(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void StackTraceUtility_t599648129_CustomAttributesCacheGenerator_StackTraceUtility_ExtractFormattedStackTrace_m2968975606(CustomAttributesCache* cache)
{
	{
		SecuritySafeCriticalAttribute_t3761815145 * tmp = (SecuritySafeCriticalAttribute_t3761815145 *)cache->attributes[0];
		SecuritySafeCriticalAttribute__ctor_m1104744884(tmp, NULL);
	}
}
static void UnityException_t4124781955_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_ObjectArgument(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("objectArgument"), NULL);
	}
}
static void ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_ObjectArgumentAssemblyTypeName(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("objectArgumentAssemblyTypeName"), NULL);
	}
}
static void ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_IntArgument(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("intArgument"), NULL);
	}
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[1];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_FloatArgument(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("floatArgument"), NULL);
	}
}
static void ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_StringArgument(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("stringArgument"), NULL);
	}
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[1];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_BoolArgument(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void InvokableCall_t2172723502_CustomAttributesCacheGenerator_Delegate(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void InvokableCall_1_t3068523820_CustomAttributesCacheGenerator_Delegate(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void InvokableCall_2_t4124072994_CustomAttributesCacheGenerator_Delegate(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void InvokableCall_3_t442739363_CustomAttributesCacheGenerator_Delegate(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void InvokableCall_4_t3127597954_CustomAttributesCacheGenerator_Delegate(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void PersistentCall_t183227066_CustomAttributesCacheGenerator_m_Target(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("instance"), NULL);
	}
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[1];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void PersistentCall_t183227066_CustomAttributesCacheGenerator_m_MethodName(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("methodName"), NULL);
	}
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[1];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void PersistentCall_t183227066_CustomAttributesCacheGenerator_m_Mode(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("mode"), NULL);
	}
}
static void PersistentCall_t183227066_CustomAttributesCacheGenerator_m_Arguments(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("arguments"), NULL);
	}
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[1];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void PersistentCall_t183227066_CustomAttributesCacheGenerator_m_CallState(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("enabled"), NULL);
	}
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[2];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("m_Enabled"), NULL);
	}
}
static void PersistentCallGroup_t2134068398_CustomAttributesCacheGenerator_m_Calls(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("m_Listeners"), NULL);
	}
}
static void UnityEventBase_t376746665_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void UnityEventBase_t376746665_CustomAttributesCacheGenerator_m_PersistentCalls(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t153867989 * tmp = (FormerlySerializedAsAttribute_t153867989 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m2819130373(tmp, il2cpp_codegen_string_new_wrapper("m_PersistentListeners"), NULL);
	}
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[1];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void UnityEventBase_t376746665_CustomAttributesCacheGenerator_m_TypeName(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void UnityEvent_t2494002768_CustomAttributesCacheGenerator_UnityEvent__ctor_m709418737(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void UnityEvent_1_t664801528_CustomAttributesCacheGenerator_UnityEvent_1__ctor_m2467552359(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void UnityEvent_2_t3195527707_CustomAttributesCacheGenerator_UnityEvent_2__ctor_m2346106316(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void UnityEvent_3_t180400136_CustomAttributesCacheGenerator_UnityEvent_3__ctor_m3575999384(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void UnityEvent_4_t316486966_CustomAttributesCacheGenerator_UnityEvent_4__ctor_m4217751038(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void UnityString_t2277233379_CustomAttributesCacheGenerator_UnityString_Format_m2073054251____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void UnitySynchronizationContext_t3084095346_CustomAttributesCacheGenerator_UnitySynchronizationContext_InitializeSynchronizationContext_m3655849499(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void UnitySynchronizationContext_t3084095346_CustomAttributesCacheGenerator_UnitySynchronizationContext_ExecuteTasks_m691963302(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void Vector2_t218349997_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t296450964 * tmp = (DefaultMemberAttribute_t296450964 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m1668906589(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		UsedByNativeCodeAttribute_t2042968054 * tmp = (UsedByNativeCodeAttribute_t2042968054 *)cache->attributes[1];
		UsedByNativeCodeAttribute__ctor_m2169491047(tmp, NULL);
	}
}
static void ReadOnlyAttribute_t1337101784_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 256LL, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void ReadWriteAttribute_t2837879318_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 256LL, NULL);
	}
}
static void WriteOnlyAttribute_t1401990839_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 256LL, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void DeallocateOnJobCompletionAttribute_t609863456_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 256LL, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void NativeContainerAttribute_t4143237321_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 8LL, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void NativeContainerSupportsAtomicWriteAttribute_t2543072026_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 8LL, NULL);
	}
}
static void NativeContainerSupportsMinMaxWriteRestrictionAttribute_t1739138553_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m250482755(tmp, 8LL, NULL);
	}
}
static void Flags_t704280897_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t2123170284 * tmp = (FlagsAttribute_t2123170284 *)cache->attributes[0];
		FlagsAttribute__ctor_m1689062726(tmp, NULL);
	}
}
static void PlayableBinding_t2470704133_CustomAttributesCacheGenerator_U3CstreamNameU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void PlayableBinding_t2470704133_CustomAttributesCacheGenerator_U3CstreamTypeU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void PlayableBinding_t2470704133_CustomAttributesCacheGenerator_U3CsourceObjectU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void PlayableBinding_t2470704133_CustomAttributesCacheGenerator_U3CsourceBindingTypeU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void PlayableAsset_t2455377621_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void PlayableAsset_t2455377621_CustomAttributesCacheGenerator_PlayableAsset_Internal_CreatePlayable_m3902392072(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void PlayableAsset_t2455377621_CustomAttributesCacheGenerator_PlayableAsset_Internal_GetPlayableAssetDuration_m614503739(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void PlayableBehaviour_t4141050374_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void PlayableExtensions_t2708217748_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t36176176 * tmp = (ExtensionAttribute_t36176176 *)cache->attributes[0];
		ExtensionAttribute__ctor_m4086378263(tmp, NULL);
	}
}
static void PlayableExtensions_t2708217748_CustomAttributesCacheGenerator_PlayableExtensions_SetDuration_m3868156131(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t36176176 * tmp = (ExtensionAttribute_t36176176 *)cache->attributes[0];
		ExtensionAttribute__ctor_m4086378263(tmp, NULL);
	}
}
static void PlayableExtensions_t2708217748_CustomAttributesCacheGenerator_PlayableExtensions_SetInputCount_m410715386(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t36176176 * tmp = (ExtensionAttribute_t36176176 *)cache->attributes[0];
		ExtensionAttribute__ctor_m4086378263(tmp, NULL);
	}
}
static void ScriptPlayableOutput_t2716968363_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void DefaultValueAttribute_t1239497132_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 18432LL, NULL);
	}
}
static void ILogHandler_t4045690940_CustomAttributesCacheGenerator_ILogHandler_LogFormat_m41519313____args3(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void Logger_t475186510_CustomAttributesCacheGenerator_U3ClogHandlerU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Logger_t475186510_CustomAttributesCacheGenerator_U3ClogEnabledU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void Logger_t475186510_CustomAttributesCacheGenerator_U3CfilterLogTypeU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Logger_t475186510_CustomAttributesCacheGenerator_Logger_get_logHandler_m1001975644(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Logger_t475186510_CustomAttributesCacheGenerator_Logger_set_logHandler_m4221272157(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Logger_t475186510_CustomAttributesCacheGenerator_Logger_get_logEnabled_m1878659891(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Logger_t475186510_CustomAttributesCacheGenerator_Logger_set_logEnabled_m771198447(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Logger_t475186510_CustomAttributesCacheGenerator_Logger_get_filterLogType_m3099848982(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Logger_t475186510_CustomAttributesCacheGenerator_Logger_set_filterLogType_m602084239(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void Logger_t475186510_CustomAttributesCacheGenerator_Logger_LogFormat_m2728955062____args3(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t4148278418 * tmp = (ParamArrayAttribute_t4148278418 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m1476893411(tmp, NULL);
	}
}
static void PlayerConnection_t1218065583_CustomAttributesCacheGenerator_m_PlayerEditorConnectionEvents(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void PlayerConnection_t1218065583_CustomAttributesCacheGenerator_m_connectedPlayers(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void PlayerConnection_t1218065583_CustomAttributesCacheGenerator_PlayerConnection_MessageCallbackInternal_m2888194805(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void PlayerConnection_t1218065583_CustomAttributesCacheGenerator_PlayerConnection_ConnectedCallbackInternal_m989124288(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void PlayerConnection_t1218065583_CustomAttributesCacheGenerator_PlayerConnection_DisconnectedCallback_m571541410(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void PlayerEditorConnectionEvents_t628309064_CustomAttributesCacheGenerator_messageTypeSubscribers(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void PlayerEditorConnectionEvents_t628309064_CustomAttributesCacheGenerator_connectionEvent(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void PlayerEditorConnectionEvents_t628309064_CustomAttributesCacheGenerator_disconnectionEvent(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void MessageTypeSubscribers_t4164304980_CustomAttributesCacheGenerator_m_messageTypeId(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void U3CInvokeMessageIdSubscribersU3Ec__AnonStorey0_t3627662667_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void RenderPipelineManager_t1144978979_CustomAttributesCacheGenerator_U3CcurrentPipelineU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t182167257 * tmp = (DebuggerBrowsableAttribute_t182167257 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m2340592270(tmp, 0LL, NULL);
	}
}
static void RenderPipelineManager_t1144978979_CustomAttributesCacheGenerator_RenderPipelineManager_get_currentPipeline_m3200673172(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void RenderPipelineManager_t1144978979_CustomAttributesCacheGenerator_RenderPipelineManager_set_currentPipeline_m1673100204(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t1456741190 * tmp = (CompilerGeneratedAttribute_t1456741190 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m1329859730(tmp, NULL);
	}
}
static void RenderPipelineManager_t1144978979_CustomAttributesCacheGenerator_RenderPipelineManager_CleanupRenderPipeline_m3163400220(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void RenderPipelineManager_t1144978979_CustomAttributesCacheGenerator_RenderPipelineManager_DoRenderLoop_Internal_m2060351888(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void UsedByNativeCodeAttribute_t2042968054_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1532LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void RequiredByNativeCodeAttribute_t2920332526_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 1532LL, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
}
static void FormerlySerializedAsAttribute_t153867989_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m3716379228(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m2568117843(tmp, false, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void TypeInferenceRuleAttribute_t1237727610_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t2106699225 * tmp = (AttributeUsageAttribute_t2106699225 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m250482755(tmp, 64LL, NULL);
	}
}
static void NetFxCoreExtensions_t1693540765_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t36176176 * tmp = (ExtensionAttribute_t36176176 *)cache->attributes[0];
		ExtensionAttribute__ctor_m4086378263(tmp, NULL);
	}
}
static void NetFxCoreExtensions_t1693540765_CustomAttributesCacheGenerator_NetFxCoreExtensions_CreateDelegate_m1280007241(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t36176176 * tmp = (ExtensionAttribute_t36176176 *)cache->attributes[0];
		ExtensionAttribute__ctor_m4086378263(tmp, NULL);
	}
}
static void CSSMeasureFunc_t2981734212_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UnmanagedFunctionPointerAttribute_t3672379452 * tmp = (UnmanagedFunctionPointerAttribute_t3672379452 *)cache->attributes[0];
		UnmanagedFunctionPointerAttribute__ctor_m3384177810(tmp, 2LL, NULL);
	}
}
static void Native_t2140029580_CustomAttributesCacheGenerator_Native_CSSNodeMeasureInvoke_m215891493(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t2920332526 * tmp = (RequiredByNativeCodeAttribute_t2920332526 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m3712479437(tmp, NULL);
	}
}
static void g_UnityEngine_Analytics_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[0];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.Automation"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[1];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.IntegrationTests"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[2];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.IntegrationTests.Framework"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[3];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.RuntimeTests"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[4];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.RuntimeTests.Framework"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[5];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("Unity.RuntimeTests.Framework.Tests"), NULL);
	}
	{
		InternalsVisibleToAttribute_t4106395870 * tmp = (InternalsVisibleToAttribute_t4106395870 *)cache->attributes[6];
		InternalsVisibleToAttribute__ctor_m3585987778(tmp, il2cpp_codegen_string_new_wrapper("UnityEditor.Analytics"), NULL);
	}
	{
		DebuggableAttribute_t2636756938 * tmp = (DebuggableAttribute_t2636756938 *)cache->attributes[7];
		DebuggableAttribute__ctor_m2582985872(tmp, 258LL, NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2873331073 * tmp = (RuntimeCompatibilityAttribute_t2873331073 *)cache->attributes[8];
		RuntimeCompatibilityAttribute__ctor_m1077459611(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2097818566(tmp, true, NULL);
	}
}
static void AnalyticsTracker_t2726437861_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1949136625 * tmp = (AddComponentMenu_t1949136625 *)cache->attributes[0];
		AddComponentMenu__ctor_m3547895745(tmp, il2cpp_codegen_string_new_wrapper("Analytics/AnalyticsTracker"), NULL);
	}
}
static void AnalyticsTracker_t2726437861_CustomAttributesCacheGenerator_m_EventName(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void AnalyticsTracker_t2726437861_CustomAttributesCacheGenerator_m_TrackableProperty(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void AnalyticsTracker_t2726437861_CustomAttributesCacheGenerator_m_Trigger(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void TrackableProperty_t4178984293_CustomAttributesCacheGenerator_m_Fields(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_ParamName(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_Target(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_FieldPath(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_TypeString(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_DoStatic(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_StaticString(CustomAttributesCache* cache)
{
	{
		SerializeField_t1114448220 * tmp = (SerializeField_t1114448220 *)cache->attributes[0];
		SerializeField__ctor_m3105624160(tmp, NULL);
	}
}
static void g_AssemblyU2DCSharp_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DebuggableAttribute_t2636756938 * tmp = (DebuggableAttribute_t2636756938 *)cache->attributes[0];
		DebuggableAttribute__ctor_m2582985872(tmp, 2LL, NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2873331073 * tmp = (RuntimeCompatibilityAttribute_t2873331073 *)cache->attributes[1];
		RuntimeCompatibilityAttribute__ctor_m1077459611(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2097818566(tmp, true, NULL);
	}
}
extern const CustomAttributesCacheGenerator g_AttributeGenerators[1656] = 
{
	NULL,
	g_mscorlib_Assembly_CustomAttributesCacheGenerator,
	RuntimeObject_CustomAttributesCacheGenerator,
	RuntimeObject_CustomAttributesCacheGenerator_Object__ctor_m3570689169,
	RuntimeObject_CustomAttributesCacheGenerator_Object_Finalize_m3819013302,
	RuntimeObject_CustomAttributesCacheGenerator_Object_ReferenceEquals_m1745896791,
	ValueType_t3348802692_CustomAttributesCacheGenerator,
	Attribute_t1821863933_CustomAttributesCacheGenerator,
	_Attribute_t1412570690_CustomAttributesCacheGenerator,
	Int32_t438220675_CustomAttributesCacheGenerator,
	IFormattable_t1615404309_CustomAttributesCacheGenerator,
	IConvertible_t893085710_CustomAttributesCacheGenerator,
	IComparable_t242364074_CustomAttributesCacheGenerator,
	SerializableAttribute_t3604215043_CustomAttributesCacheGenerator,
	AttributeUsageAttribute_t2106699225_CustomAttributesCacheGenerator,
	ComVisibleAttribute_t3352689681_CustomAttributesCacheGenerator,
	Int64_t3733094498_CustomAttributesCacheGenerator,
	UInt32_t1752406861_CustomAttributesCacheGenerator,
	UInt32_t1752406861_CustomAttributesCacheGenerator_UInt32_Parse_m602751418,
	UInt32_t1752406861_CustomAttributesCacheGenerator_UInt32_Parse_m1560553326,
	UInt32_t1752406861_CustomAttributesCacheGenerator_UInt32_TryParse_m872480584,
	UInt32_t1752406861_CustomAttributesCacheGenerator_UInt32_TryParse_m2781189100,
	CLSCompliantAttribute_t3606053525_CustomAttributesCacheGenerator,
	UInt64_t1261996727_CustomAttributesCacheGenerator,
	UInt64_t1261996727_CustomAttributesCacheGenerator_UInt64_Parse_m2837505384,
	UInt64_t1261996727_CustomAttributesCacheGenerator_UInt64_Parse_m1838157675,
	UInt64_t1261996727_CustomAttributesCacheGenerator_UInt64_TryParse_m1875351864,
	Byte_t1695016127_CustomAttributesCacheGenerator,
	SByte_t1526744772_CustomAttributesCacheGenerator,
	SByte_t1526744772_CustomAttributesCacheGenerator_SByte_Parse_m970256373,
	SByte_t1526744772_CustomAttributesCacheGenerator_SByte_Parse_m512031140,
	SByte_t1526744772_CustomAttributesCacheGenerator_SByte_TryParse_m2531638266,
	Int16_t674212087_CustomAttributesCacheGenerator,
	UInt16_t2530548644_CustomAttributesCacheGenerator,
	UInt16_t2530548644_CustomAttributesCacheGenerator_UInt16_Parse_m821794179,
	UInt16_t2530548644_CustomAttributesCacheGenerator_UInt16_Parse_m1827209548,
	UInt16_t2530548644_CustomAttributesCacheGenerator_UInt16_TryParse_m2161302458,
	UInt16_t2530548644_CustomAttributesCacheGenerator_UInt16_TryParse_m4175666418,
	IEnumerator_t2340204891_CustomAttributesCacheGenerator,
	IEnumerable_t1561071510_CustomAttributesCacheGenerator,
	IEnumerable_t1561071510_CustomAttributesCacheGenerator_IEnumerable_GetEnumerator_m470268915,
	IDisposable_t1854990027_CustomAttributesCacheGenerator,
	Char_t4217985068_CustomAttributesCacheGenerator,
	String_t_CustomAttributesCacheGenerator,
	String_t_CustomAttributesCacheGenerator_String__ctor_m3613415962,
	String_t_CustomAttributesCacheGenerator_String_Equals_m3008033655,
	String_t_CustomAttributesCacheGenerator_String_Equals_m1775812447,
	String_t_CustomAttributesCacheGenerator_String_Split_m1027048911____separator0,
	String_t_CustomAttributesCacheGenerator_String_Split_m752880514,
	String_t_CustomAttributesCacheGenerator_String_Split_m2170789228,
	String_t_CustomAttributesCacheGenerator_String_Split_m882935073,
	String_t_CustomAttributesCacheGenerator_String_Trim_m1892663701____trimChars0,
	String_t_CustomAttributesCacheGenerator_String_TrimStart_m923266555____trimChars0,
	String_t_CustomAttributesCacheGenerator_String_TrimEnd_m1178919651____trimChars0,
	String_t_CustomAttributesCacheGenerator_String_Format_m527561873____args1,
	String_t_CustomAttributesCacheGenerator_String_Format_m949849763____args2,
	String_t_CustomAttributesCacheGenerator_String_FormatHelper_m266143647____args3,
	String_t_CustomAttributesCacheGenerator_String_Concat_m406606968____args0,
	String_t_CustomAttributesCacheGenerator_String_Concat_m2284411301____values0,
	String_t_CustomAttributesCacheGenerator_String_GetHashCode_m2446182979,
	ICloneable_t3275016770_CustomAttributesCacheGenerator,
	Single_t3678960876_CustomAttributesCacheGenerator,
	Single_t3678960876_CustomAttributesCacheGenerator_Single_IsNaN_m3455339168,
	Double_t3420139759_CustomAttributesCacheGenerator,
	Double_t3420139759_CustomAttributesCacheGenerator_Double_IsNaN_m372022469,
	Decimal_t2382302464_CustomAttributesCacheGenerator,
	Decimal_t2382302464_CustomAttributesCacheGenerator_MinValue,
	Decimal_t2382302464_CustomAttributesCacheGenerator_MaxValue,
	Decimal_t2382302464_CustomAttributesCacheGenerator_MinusOne,
	Decimal_t2382302464_CustomAttributesCacheGenerator_One,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal__ctor_m2545903267,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal__ctor_m3377077937,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_Compare_m3646660628,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Explicit_m1503313322,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Explicit_m1521124198,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Explicit_m1054949672,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Explicit_m2818597674,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Implicit_m1540208279,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Implicit_m980199957,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Implicit_m881253395,
	Decimal_t2382302464_CustomAttributesCacheGenerator_Decimal_op_Implicit_m809477236,
	Boolean_t402932760_CustomAttributesCacheGenerator,
	IntPtr_t_CustomAttributesCacheGenerator,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m2251341938,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m2356916849,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m3657584931,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_get_Size_m2786508229,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_ToInt64_m1557689473,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_ToPointer_m237804402,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Equality_m2182604147,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Inequality_m3520486347,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m509961701,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m267845794,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m1997376062,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m2617312562,
	ISerializable_t3453043479_CustomAttributesCacheGenerator,
	UIntPtr_t_CustomAttributesCacheGenerator,
	UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr__ctor_m890287867,
	UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_ToPointer_m2330649849,
	UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_op_Explicit_m4118586544,
	UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_op_Explicit_m1761774754,
	MulticastDelegate_t608486974_CustomAttributesCacheGenerator,
	Delegate_t2990640460_CustomAttributesCacheGenerator,
	Delegate_t2990640460_CustomAttributesCacheGenerator_Delegate_Combine_m1500603169,
	Delegate_t2990640460_CustomAttributesCacheGenerator_Delegate_Combine_m1500603169____delegates0,
	Enum_t4088700107_CustomAttributesCacheGenerator,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_GetName_m874261310,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_IsDefined_m680461013,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_GetUnderlyingType_m1443556329,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_Parse_m2788862954,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToString_m4269924258,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToString_m3300782106,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m78379513,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m4274442607,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m2048232900,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m3196673333,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m2696618385,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m887634324,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m2147101483,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m1741150068,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_ToObject_m3978950197,
	Enum_t4088700107_CustomAttributesCacheGenerator_Enum_Format_m1584462606,
	RuntimeArray_CustomAttributesCacheGenerator,
	RuntimeArray_CustomAttributesCacheGenerator_Array_System_Collections_IList_IndexOf_m4113384025,
	RuntimeArray_CustomAttributesCacheGenerator_Array_get_Length_m1237849133,
	RuntimeArray_CustomAttributesCacheGenerator_Array_get_LongLength_m3574060956,
	RuntimeArray_CustomAttributesCacheGenerator_Array_get_Rank_m4210679277,
	RuntimeArray_CustomAttributesCacheGenerator_Array_GetLongLength_m1831760985,
	RuntimeArray_CustomAttributesCacheGenerator_Array_GetLowerBound_m3549496906,
	RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m2729068147____indices0,
	RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m3241852505____indices1,
	RuntimeArray_CustomAttributesCacheGenerator_Array_GetUpperBound_m3033662308,
	RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m1672823197,
	RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m3499512431,
	RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m170746175,
	RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m63377824,
	RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m485573868,
	RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m1031266616,
	RuntimeArray_CustomAttributesCacheGenerator_Array_CreateInstance_m917197603____lengths1,
	RuntimeArray_CustomAttributesCacheGenerator_Array_CreateInstance_m3507446064____lengths1,
	RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m2322609327,
	RuntimeArray_CustomAttributesCacheGenerator_Array_GetValue_m2322609327____indices0,
	RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m193787568,
	RuntimeArray_CustomAttributesCacheGenerator_Array_SetValue_m193787568____indices1,
	RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m545470185,
	RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m2794424496,
	RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m787838226,
	RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m3034756551,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Clear_m3931267648,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Copy_m3083719085,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Copy_m1665823352,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Copy_m3124468677,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Copy_m795970186,
	RuntimeArray_CustomAttributesCacheGenerator_Array_IndexOf_m1347597055,
	RuntimeArray_CustomAttributesCacheGenerator_Array_IndexOf_m955672662,
	RuntimeArray_CustomAttributesCacheGenerator_Array_IndexOf_m4006329155,
	RuntimeArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m3392868261,
	RuntimeArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m1832984276,
	RuntimeArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m191882863,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Reverse_m1652786737,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Reverse_m2907565334,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m4258351672,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m1768924099,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2963189028,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m3451521996,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2647962771,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m4051743636,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m1552933164,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m3631368508,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m1072890388,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2260390429,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2466936610,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m1673438336,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m4275090730,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2213423065,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m3813128040,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Sort_m2658527309,
	RuntimeArray_CustomAttributesCacheGenerator_Array_CopyTo_m3827090518,
	RuntimeArray_CustomAttributesCacheGenerator_Array_Resize_m2100239636,
	RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m265843292,
	RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m2054507326,
	RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m2165578130,
	RuntimeArray_CustomAttributesCacheGenerator_Array_BinarySearch_m1225743805,
	RuntimeArray_CustomAttributesCacheGenerator_Array_ConstrainedCopy_m2507976525,
	RuntimeArray_CustomAttributesCacheGenerator_RuntimeArray____LongLength_PropertyInfo,
	ArrayReadOnlyList_1_t1478687212_CustomAttributesCacheGenerator,
	ArrayReadOnlyList_1_t1478687212_CustomAttributesCacheGenerator_ArrayReadOnlyList_1_GetEnumerator_m4253775203,
	U3CGetEnumeratorU3Ec__Iterator0_t3090871926_CustomAttributesCacheGenerator,
	U3CGetEnumeratorU3Ec__Iterator0_t3090871926_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CTU3E_get_Current_m2935388785,
	U3CGetEnumeratorU3Ec__Iterator0_t3090871926_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m3813834758,
	U3CGetEnumeratorU3Ec__Iterator0_t3090871926_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_Dispose_m3100869542,
	U3CGetEnumeratorU3Ec__Iterator0_t3090871926_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_Reset_m2424558805,
	ICollection_t2613627688_CustomAttributesCacheGenerator,
	IList_t480837924_CustomAttributesCacheGenerator,
	IList_1_t822657584_CustomAttributesCacheGenerator,
	Void_t1421048318_CustomAttributesCacheGenerator,
	Type_t_CustomAttributesCacheGenerator,
	Type_t_CustomAttributesCacheGenerator_Type_IsSubclassOf_m3030212525,
	Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m3166019052,
	Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m3093596752,
	Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m888409261,
	Type_t_CustomAttributesCacheGenerator_Type_GetConstructors_m3058302789,
	Type_t_CustomAttributesCacheGenerator_Type_MakeGenericType_m2741335421____typeArguments0,
	MemberInfo_t_CustomAttributesCacheGenerator,
	ICustomAttributeProvider_t2305050174_CustomAttributesCacheGenerator,
	_MemberInfo_t3276260911_CustomAttributesCacheGenerator,
	IReflect_t3760602010_CustomAttributesCacheGenerator,
	_Type_t3776473474_CustomAttributesCacheGenerator,
	Exception_t2443218823_CustomAttributesCacheGenerator,
	_Exception_t1060755997_CustomAttributesCacheGenerator,
	RuntimeFieldHandle_t2492430303_CustomAttributesCacheGenerator,
	RuntimeFieldHandle_t2492430303_CustomAttributesCacheGenerator_RuntimeFieldHandle_Equals_m1997721335,
	RuntimeTypeHandle_t1361003276_CustomAttributesCacheGenerator,
	RuntimeTypeHandle_t1361003276_CustomAttributesCacheGenerator_RuntimeTypeHandle_Equals_m3316377268,
	ParamArrayAttribute_t4148278418_CustomAttributesCacheGenerator,
	OutAttribute_t236430398_CustomAttributesCacheGenerator,
	ObsoleteAttribute_t534593266_CustomAttributesCacheGenerator,
	DllImportAttribute_t3095387693_CustomAttributesCacheGenerator,
	MarshalAsAttribute_t2985744263_CustomAttributesCacheGenerator,
	MarshalAsAttribute_t2985744263_CustomAttributesCacheGenerator_MarshalType,
	MarshalAsAttribute_t2985744263_CustomAttributesCacheGenerator_MarshalTypeRef,
	InAttribute_t2445820094_CustomAttributesCacheGenerator,
	SecurityAttribute_t2476648288_CustomAttributesCacheGenerator,
	GuidAttribute_t3287193793_CustomAttributesCacheGenerator,
	ComImportAttribute_t676731785_CustomAttributesCacheGenerator,
	OptionalAttribute_t3596925151_CustomAttributesCacheGenerator,
	FixedBufferAttribute_t1391295387_CustomAttributesCacheGenerator,
	CompilerGeneratedAttribute_t1456741190_CustomAttributesCacheGenerator,
	InternalsVisibleToAttribute_t4106395870_CustomAttributesCacheGenerator,
	RuntimeCompatibilityAttribute_t2873331073_CustomAttributesCacheGenerator,
	DebuggerHiddenAttribute_t177041199_CustomAttributesCacheGenerator,
	DefaultMemberAttribute_t296450964_CustomAttributesCacheGenerator,
	DecimalConstantAttribute_t99985380_CustomAttributesCacheGenerator,
	DecimalConstantAttribute_t99985380_CustomAttributesCacheGenerator_DecimalConstantAttribute__ctor_m65841775,
	FieldOffsetAttribute_t2445260871_CustomAttributesCacheGenerator,
	RuntimeArgumentHandle_t994808714_CustomAttributesCacheGenerator,
	AsyncCallback_t3133502122_CustomAttributesCacheGenerator,
	IAsyncResult_t337009442_CustomAttributesCacheGenerator,
	TypedReference_t376682075_CustomAttributesCacheGenerator,
	MarshalByRefObject_t1904561400_CustomAttributesCacheGenerator,
	Locale_t57088988_CustomAttributesCacheGenerator_Locale_GetText_m17960088____args1,
	MonoTODOAttribute_t119123862_CustomAttributesCacheGenerator,
	MonoDocumentationNoteAttribute_t3523980758_CustomAttributesCacheGenerator,
	SafeHandleZeroOrMinusOneIsInvalid_t1074017661_CustomAttributesCacheGenerator_SafeHandleZeroOrMinusOneIsInvalid__ctor_m1494848290,
	SafeWaitHandle_t3151023066_CustomAttributesCacheGenerator_SafeWaitHandle__ctor_m1749943790,
	MSCompatUnicodeTable_t3914846919_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map2,
	MSCompatUnicodeTable_t3914846919_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map3,
	MSCompatUnicodeTable_t3914846919_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map4,
	SortKey_t3248894513_CustomAttributesCacheGenerator,
	PKCS12_t192318787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map8,
	PKCS12_t192318787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map9,
	PKCS12_t192318787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapA,
	PKCS12_t192318787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapB,
	PKCS12_t192318787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF,
	X509CertificateCollection_t3275414984_CustomAttributesCacheGenerator,
	X509ExtensionCollection_t1736530050_CustomAttributesCacheGenerator,
	ASN1_t3432613456_CustomAttributesCacheGenerator,
	SmallXmlParser_t184059736_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map18,
	Dictionary_2_t1155016036_CustomAttributesCacheGenerator,
	Dictionary_2_t1155016036_CustomAttributesCacheGenerator_U3CU3Ef__amU24cacheB,
	Dictionary_2_t1155016036_CustomAttributesCacheGenerator_Dictionary_2_U3CCopyToU3Em__0_m1933852859,
	IDictionary_2_t332250678_CustomAttributesCacheGenerator,
	KeyNotFoundException_t758703888_CustomAttributesCacheGenerator,
	KeyValuePair_2_t3396090807_CustomAttributesCacheGenerator,
	List_1_t2059616371_CustomAttributesCacheGenerator,
	Collection_1_t2882572264_CustomAttributesCacheGenerator,
	ReadOnlyCollection_1_t2481933861_CustomAttributesCacheGenerator,
	ArrayList_t3384568281_CustomAttributesCacheGenerator,
	ArrayListWrapper_t2285097034_CustomAttributesCacheGenerator,
	SynchronizedArrayListWrapper_t3513142238_CustomAttributesCacheGenerator,
	ReadOnlyArrayListWrapper_t604112846_CustomAttributesCacheGenerator,
	BitArray_t2556826475_CustomAttributesCacheGenerator,
	CaseInsensitiveComparer_t605862446_CustomAttributesCacheGenerator,
	CaseInsensitiveHashCodeProvider_t3242471571_CustomAttributesCacheGenerator,
	CollectionBase_t3261413387_CustomAttributesCacheGenerator,
	Comparer_t287245028_CustomAttributesCacheGenerator,
	DictionaryEntry_t578375704_CustomAttributesCacheGenerator,
	Hashtable_t1665082780_CustomAttributesCacheGenerator,
	Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable__ctor_m2531087936,
	Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable__ctor_m4115579798,
	Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable__ctor_m2991153945,
	Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable__ctor_m3453182740,
	Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable__ctor_m2767843923,
	Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable_Clear_m4221147505,
	Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable_Remove_m3318034014,
	Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable_OnDeserialization_m2722627116,
	Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable_t1665082780____comparer_PropertyInfo,
	Hashtable_t1665082780_CustomAttributesCacheGenerator_Hashtable_t1665082780____hcp_PropertyInfo,
	HashKeys_t2826937142_CustomAttributesCacheGenerator,
	HashValues_t1567374944_CustomAttributesCacheGenerator,
	SyncHashtable_t1353600843_CustomAttributesCacheGenerator,
	IComparer_t2470865232_CustomAttributesCacheGenerator,
	IDictionary_t702710298_CustomAttributesCacheGenerator,
	IDictionaryEnumerator_t774440013_CustomAttributesCacheGenerator,
	IEqualityComparer_t3801883864_CustomAttributesCacheGenerator,
	IHashCodeProvider_t3066022657_CustomAttributesCacheGenerator,
	SortedList_t327151849_CustomAttributesCacheGenerator,
	Stack_t830505910_CustomAttributesCacheGenerator,
	AssemblyHashAlgorithm_t1254885680_CustomAttributesCacheGenerator,
	AssemblyVersionCompatibility_t2721685000_CustomAttributesCacheGenerator,
	DebuggableAttribute_t2636756938_CustomAttributesCacheGenerator,
	DebuggingModes_t1865971622_CustomAttributesCacheGenerator,
	DebuggerBrowsableAttribute_t182167257_CustomAttributesCacheGenerator,
	DebuggerBrowsableState_t853783821_CustomAttributesCacheGenerator,
	DebuggerDisplayAttribute_t1222375162_CustomAttributesCacheGenerator,
	DebuggerStepThroughAttribute_t1445666285_CustomAttributesCacheGenerator,
	DebuggerTypeProxyAttribute_t4230666625_CustomAttributesCacheGenerator,
	StackFrame_t1838224435_CustomAttributesCacheGenerator,
	StackTrace_t2942520844_CustomAttributesCacheGenerator,
	Calendar_t4269329426_CustomAttributesCacheGenerator,
	Calendar_t4269329426_CustomAttributesCacheGenerator_Calendar_Clone_m339556131,
	CompareInfo_t3378979977_CustomAttributesCacheGenerator,
	CompareOptions_t2067543004_CustomAttributesCacheGenerator,
	CultureInfo_t1686190661_CustomAttributesCacheGenerator,
	CultureInfo_t1686190661_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map19,
	CultureInfo_t1686190661_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map1A,
	DateTimeFormatFlags_t3938781256_CustomAttributesCacheGenerator,
	DateTimeFormatInfo_t1072385215_CustomAttributesCacheGenerator,
	DateTimeStyles_t1986540600_CustomAttributesCacheGenerator,
	DaylightTime_t3097358740_CustomAttributesCacheGenerator,
	GregorianCalendar_t1617016020_CustomAttributesCacheGenerator,
	GregorianCalendarTypes_t2942788655_CustomAttributesCacheGenerator,
	NumberFormatInfo_t929205710_CustomAttributesCacheGenerator,
	NumberStyles_t4120645497_CustomAttributesCacheGenerator,
	TextInfo_t1762234961_CustomAttributesCacheGenerator,
	TextInfo_t1762234961_CustomAttributesCacheGenerator_TextInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m3019484889,
	TextInfo_t1762234961_CustomAttributesCacheGenerator_TextInfo_Clone_m808132933,
	TextInfo_t1762234961_CustomAttributesCacheGenerator_TextInfo_t1762234961____CultureName_PropertyInfo,
	UnicodeCategory_t47276028_CustomAttributesCacheGenerator,
	IsolatedStorageException_t145109139_CustomAttributesCacheGenerator,
	BinaryReader_t170336145_CustomAttributesCacheGenerator,
	BinaryReader_t170336145_CustomAttributesCacheGenerator_BinaryReader_ReadSByte_m3974961331,
	BinaryReader_t170336145_CustomAttributesCacheGenerator_BinaryReader_ReadUInt16_m1631681507,
	BinaryReader_t170336145_CustomAttributesCacheGenerator_BinaryReader_ReadUInt32_m3322182293,
	BinaryReader_t170336145_CustomAttributesCacheGenerator_BinaryReader_ReadUInt64_m723726215,
	Directory_t1424101462_CustomAttributesCacheGenerator,
	DirectoryInfo_t3443917738_CustomAttributesCacheGenerator,
	DirectoryNotFoundException_t3956305866_CustomAttributesCacheGenerator,
	EndOfStreamException_t1541734223_CustomAttributesCacheGenerator,
	File_t4052853980_CustomAttributesCacheGenerator,
	FileAccess_t2890988798_CustomAttributesCacheGenerator,
	FileAttributes_t4239897840_CustomAttributesCacheGenerator,
	FileLoadException_t291496859_CustomAttributesCacheGenerator,
	FileMode_t4081272872_CustomAttributesCacheGenerator,
	FileNotFoundException_t365835450_CustomAttributesCacheGenerator,
	FileOptions_t1048709362_CustomAttributesCacheGenerator,
	FileShare_t1227766631_CustomAttributesCacheGenerator,
	FileStream_t2128643197_CustomAttributesCacheGenerator,
	FileSystemInfo_t2214011087_CustomAttributesCacheGenerator,
	FileSystemInfo_t2214011087_CustomAttributesCacheGenerator_FileSystemInfo_GetObjectData_m2634626544,
	IOException_t547748842_CustomAttributesCacheGenerator,
	MemoryStream_t369900865_CustomAttributesCacheGenerator,
	Path_t1828237022_CustomAttributesCacheGenerator,
	Path_t1828237022_CustomAttributesCacheGenerator_InvalidPathChars,
	PathTooLongException_t3052246028_CustomAttributesCacheGenerator,
	SeekOrigin_t2962632027_CustomAttributesCacheGenerator,
	Stream_t753921337_CustomAttributesCacheGenerator,
	StreamReader_t4183606726_CustomAttributesCacheGenerator,
	StreamWriter_t293765744_CustomAttributesCacheGenerator,
	StringReader_t2316205510_CustomAttributesCacheGenerator,
	TextReader_t1942131857_CustomAttributesCacheGenerator,
	TextWriter_t2697789890_CustomAttributesCacheGenerator,
	UnmanagedMemoryStream_t264623907_CustomAttributesCacheGenerator,
	AssemblyBuilder_t3823150316_CustomAttributesCacheGenerator,
	ConstructorBuilder_t1269217984_CustomAttributesCacheGenerator,
	ConstructorBuilder_t1269217984_CustomAttributesCacheGenerator_ConstructorBuilder_t1269217984____CallingConvention_PropertyInfo,
	EnumBuilder_t1686327421_CustomAttributesCacheGenerator,
	EnumBuilder_t1686327421_CustomAttributesCacheGenerator_EnumBuilder_GetConstructors_m4236007330,
	FieldBuilder_t2373739222_CustomAttributesCacheGenerator,
	GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator,
	GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_IsSubclassOf_m353142104,
	GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_GetConstructors_m3284886085,
	GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_Equals_m4250412984,
	GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_GetHashCode_m2384437160,
	GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_MakeGenericType_m92865730,
	GenericTypeParameterBuilder_t1019212843_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_MakeGenericType_m92865730____typeArguments0,
	ILGenerator_t1182878361_CustomAttributesCacheGenerator,
	ILGenerator_t1182878361_CustomAttributesCacheGenerator_ILGenerator_Emit_m1397855461,
	ILGenerator_t1182878361_CustomAttributesCacheGenerator_ILGenerator_Mono_GetCurrentOffset_m1965052903,
	MethodBuilder_t434851514_CustomAttributesCacheGenerator,
	MethodBuilder_t434851514_CustomAttributesCacheGenerator_MethodBuilder_Equals_m2649897076,
	MethodBuilder_t434851514_CustomAttributesCacheGenerator_MethodBuilder_MakeGenericMethod_m1194343307____typeArguments0,
	MethodToken_t1418749877_CustomAttributesCacheGenerator,
	ModuleBuilder_t3159331943_CustomAttributesCacheGenerator,
	OpCode_t1117422012_CustomAttributesCacheGenerator,
	OpCodes_t1648843312_CustomAttributesCacheGenerator,
	OpCodes_t1648843312_CustomAttributesCacheGenerator_Castclass,
	ParameterBuilder_t3753085247_CustomAttributesCacheGenerator,
	StackBehaviour_t2397757739_CustomAttributesCacheGenerator,
	TypeBuilder_t3350860216_CustomAttributesCacheGenerator,
	TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_DefineConstructor_m3569992820,
	TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_DefineConstructor_m467803885,
	TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_DefineDefaultConstructor_m1244102928,
	TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_GetConstructors_m3718991123,
	TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_MakeGenericType_m1825409448,
	TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_MakeGenericType_m1825409448____typeArguments0,
	TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_IsAssignableFrom_m3041852661,
	TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_IsSubclassOf_m2811257152,
	TypeBuilder_t3350860216_CustomAttributesCacheGenerator_TypeBuilder_IsAssignableTo_m1907754253,
	UnmanagedMarshal_t1529067090_CustomAttributesCacheGenerator,
	AmbiguousMatchException_t608101487_CustomAttributesCacheGenerator,
	Assembly_t3774988722_CustomAttributesCacheGenerator,
	Assembly_t3774988722_CustomAttributesCacheGenerator_Assembly_GetName_m2496216313,
	AssemblyCompanyAttribute_t262073538_CustomAttributesCacheGenerator,
	AssemblyCopyrightAttribute_t4130653132_CustomAttributesCacheGenerator,
	AssemblyDefaultAliasAttribute_t3813724156_CustomAttributesCacheGenerator,
	AssemblyDelaySignAttribute_t1388804811_CustomAttributesCacheGenerator,
	AssemblyDescriptionAttribute_t1377417777_CustomAttributesCacheGenerator,
	AssemblyFileVersionAttribute_t1839628412_CustomAttributesCacheGenerator,
	AssemblyInformationalVersionAttribute_t458211439_CustomAttributesCacheGenerator,
	AssemblyKeyFileAttribute_t756954830_CustomAttributesCacheGenerator,
	AssemblyName_t3342125713_CustomAttributesCacheGenerator,
	AssemblyNameFlags_t1966831008_CustomAttributesCacheGenerator,
	AssemblyProductAttribute_t3079866486_CustomAttributesCacheGenerator,
	AssemblyTitleAttribute_t4032010531_CustomAttributesCacheGenerator,
	Binder_t1775642332_CustomAttributesCacheGenerator,
	Default_t1280323092_CustomAttributesCacheGenerator_Default_ReorderArgumentArray_m1230275780,
	BindingFlags_t2634920058_CustomAttributesCacheGenerator,
	CallingConventions_t369066136_CustomAttributesCacheGenerator,
	ConstructorInfo_t2050809311_CustomAttributesCacheGenerator,
	ConstructorInfo_t2050809311_CustomAttributesCacheGenerator_ConstructorName,
	ConstructorInfo_t2050809311_CustomAttributesCacheGenerator_TypeConstructorName,
	ConstructorInfo_t2050809311_CustomAttributesCacheGenerator_ConstructorInfo_Invoke_m2121930581,
	ConstructorInfo_t2050809311_CustomAttributesCacheGenerator_ConstructorInfo_t2050809311____MemberType_PropertyInfo,
	CustomAttributeData_t73279812_CustomAttributesCacheGenerator,
	CustomAttributeData_t73279812_CustomAttributesCacheGenerator_CustomAttributeData_t73279812____Constructor_PropertyInfo,
	CustomAttributeData_t73279812_CustomAttributesCacheGenerator_CustomAttributeData_t73279812____ConstructorArguments_PropertyInfo,
	CustomAttributeNamedArgument_t3456585787_CustomAttributesCacheGenerator,
	CustomAttributeTypedArgument_t2066493570_CustomAttributesCacheGenerator,
	EventAttributes_t1919574847_CustomAttributesCacheGenerator,
	EventInfo_t_CustomAttributesCacheGenerator,
	FieldAttributes_t1558435749_CustomAttributesCacheGenerator,
	FieldInfo_t_CustomAttributesCacheGenerator,
	FieldInfo_t_CustomAttributesCacheGenerator_FieldInfo_SetValue_m3184768154,
	MemberTypes_t1145889401_CustomAttributesCacheGenerator,
	MethodAttributes_t1488178787_CustomAttributesCacheGenerator,
	MethodBase_t2010470530_CustomAttributesCacheGenerator,
	MethodBase_t2010470530_CustomAttributesCacheGenerator_MethodBase_Invoke_m1733031813,
	MethodBase_t2010470530_CustomAttributesCacheGenerator_MethodBase_GetGenericArguments_m3649313813,
	MethodImplAttributes_t2411131545_CustomAttributesCacheGenerator,
	MethodInfo_t_CustomAttributesCacheGenerator,
	MethodInfo_t_CustomAttributesCacheGenerator_MethodInfo_MakeGenericMethod_m386620528____typeArguments0,
	MethodInfo_t_CustomAttributesCacheGenerator_MethodInfo_GetGenericArguments_m3810648776,
	Missing_t3771626849_CustomAttributesCacheGenerator,
	Missing_t3771626849_CustomAttributesCacheGenerator_Missing_System_Runtime_Serialization_ISerializable_GetObjectData_m3892491128,
	Module_t3479515451_CustomAttributesCacheGenerator,
	PInfo_t791958327_CustomAttributesCacheGenerator,
	ParameterAttributes_t2464461462_CustomAttributesCacheGenerator,
	ParameterInfo_t3793757615_CustomAttributesCacheGenerator,
	ParameterModifier_t1406754278_CustomAttributesCacheGenerator,
	Pointer_t3782621735_CustomAttributesCacheGenerator,
	ProcessorArchitecture_t2193700292_CustomAttributesCacheGenerator,
	PropertyAttributes_t974795916_CustomAttributesCacheGenerator,
	PropertyInfo_t_CustomAttributesCacheGenerator,
	PropertyInfo_t_CustomAttributesCacheGenerator_PropertyInfo_GetValue_m3754113982,
	PropertyInfo_t_CustomAttributesCacheGenerator_PropertyInfo_SetValue_m3700075641,
	StrongNameKeyPair_t1281492991_CustomAttributesCacheGenerator,
	TargetException_t823735875_CustomAttributesCacheGenerator,
	TargetInvocationException_t3273489558_CustomAttributesCacheGenerator,
	TargetParameterCountException_t192968970_CustomAttributesCacheGenerator,
	TypeAttributes_t1669384266_CustomAttributesCacheGenerator,
	IResourceReader_t1132481374_CustomAttributesCacheGenerator,
	NeutralResourcesLanguageAttribute_t2573722287_CustomAttributesCacheGenerator,
	ResourceManager_t3021742956_CustomAttributesCacheGenerator,
	ResourceReader_t3867505172_CustomAttributesCacheGenerator,
	ResourceSet_t860623208_CustomAttributesCacheGenerator,
	ResourceSet_t860623208_CustomAttributesCacheGenerator_ResourceSet_GetEnumerator_m2056913480,
	SatelliteContractVersionAttribute_t3058788408_CustomAttributesCacheGenerator,
	CompilationRelaxations_t4165277783_CustomAttributesCacheGenerator,
	CompilationRelaxationsAttribute_t2092844809_CustomAttributesCacheGenerator,
	DefaultDependencyAttribute_t547142461_CustomAttributesCacheGenerator,
	IsVolatile_t3529887306_CustomAttributesCacheGenerator,
	StringFreezingAttribute_t10408148_CustomAttributesCacheGenerator,
	CriticalFinalizerObject_t3468242162_CustomAttributesCacheGenerator,
	CriticalFinalizerObject_t3468242162_CustomAttributesCacheGenerator_CriticalFinalizerObject__ctor_m2030151810,
	CriticalFinalizerObject_t3468242162_CustomAttributesCacheGenerator_CriticalFinalizerObject_Finalize_m1139807466,
	ReliabilityContractAttribute_t3660264932_CustomAttributesCacheGenerator,
	ActivationArguments_t2702889135_CustomAttributesCacheGenerator,
	COMException_t4034665014_CustomAttributesCacheGenerator,
	CallingConvention_t4277045988_CustomAttributesCacheGenerator,
	CharSet_t4260912409_CustomAttributesCacheGenerator,
	ClassInterfaceAttribute_t1078708468_CustomAttributesCacheGenerator,
	ClassInterfaceType_t3029378045_CustomAttributesCacheGenerator,
	ComDefaultInterfaceAttribute_t2824514219_CustomAttributesCacheGenerator,
	ComInterfaceType_t2020494956_CustomAttributesCacheGenerator,
	DispIdAttribute_t3051066024_CustomAttributesCacheGenerator,
	ErrorWrapper_t1764365424_CustomAttributesCacheGenerator,
	ExternalException_t3184927670_CustomAttributesCacheGenerator,
	GCHandle_t2291726809_CustomAttributesCacheGenerator,
	GCHandleType_t345823425_CustomAttributesCacheGenerator,
	InterfaceTypeAttribute_t931938199_CustomAttributesCacheGenerator,
	Marshal_t1372080283_CustomAttributesCacheGenerator,
	MarshalDirectiveException_t1471159663_CustomAttributesCacheGenerator,
	PreserveSigAttribute_t1176875346_CustomAttributesCacheGenerator,
	SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle__ctor_m783613520,
	SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_Close_m1681605028,
	SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_DangerousAddRef_m1891015601,
	SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_DangerousGetHandle_m1375610744,
	SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_DangerousRelease_m3378349730,
	SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_Dispose_m2973664238,
	SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_Dispose_m2534630911,
	SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_ReleaseHandle_m2535948865,
	SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_SetHandle_m662183779,
	SafeHandle_t3592269898_CustomAttributesCacheGenerator_SafeHandle_get_IsInvalid_m2633487847,
	TypeLibImportClassAttribute_t2161063924_CustomAttributesCacheGenerator,
	TypeLibVersionAttribute_t3563874934_CustomAttributesCacheGenerator,
	UnmanagedFunctionPointerAttribute_t3672379452_CustomAttributesCacheGenerator,
	UnmanagedType_t2440611772_CustomAttributesCacheGenerator,
	_Activator_t1804057808_CustomAttributesCacheGenerator,
	_Assembly_t3124909478_CustomAttributesCacheGenerator,
	_AssemblyBuilder_t870438842_CustomAttributesCacheGenerator,
	_AssemblyName_t139716223_CustomAttributesCacheGenerator,
	_ConstructorBuilder_t2590771407_CustomAttributesCacheGenerator,
	_ConstructorInfo_t3612455801_CustomAttributesCacheGenerator,
	_EnumBuilder_t1981314773_CustomAttributesCacheGenerator,
	_EventInfo_t626173114_CustomAttributesCacheGenerator,
	_FieldBuilder_t3411354663_CustomAttributesCacheGenerator,
	_FieldInfo_t616591751_CustomAttributesCacheGenerator,
	_ILGenerator_t1943880346_CustomAttributesCacheGenerator,
	_MethodBase_t1718158610_CustomAttributesCacheGenerator,
	_MethodBuilder_t1063350594_CustomAttributesCacheGenerator,
	_MethodInfo_t187796706_CustomAttributesCacheGenerator,
	_Module_t107875809_CustomAttributesCacheGenerator,
	_ModuleBuilder_t234448247_CustomAttributesCacheGenerator,
	_ParameterBuilder_t1036287219_CustomAttributesCacheGenerator,
	_ParameterInfo_t1133799119_CustomAttributesCacheGenerator,
	_PropertyInfo_t4067770872_CustomAttributesCacheGenerator,
	_Thread_t4076868703_CustomAttributesCacheGenerator,
	_TypeBuilder_t47360046_CustomAttributesCacheGenerator,
	IActivator_t3392025140_CustomAttributesCacheGenerator,
	IConstructionCallMessage_t2541862161_CustomAttributesCacheGenerator,
	UrlAttribute_t51195340_CustomAttributesCacheGenerator,
	UrlAttribute_t51195340_CustomAttributesCacheGenerator_UrlAttribute_GetPropertiesForNewContext_m1689720063,
	UrlAttribute_t51195340_CustomAttributesCacheGenerator_UrlAttribute_IsContextOK_m2408897339,
	ChannelServices_t1638736262_CustomAttributesCacheGenerator,
	ChannelServices_t1638736262_CustomAttributesCacheGenerator_ChannelServices_RegisterChannel_m619736505,
	CrossAppDomainSink_t1475739759_CustomAttributesCacheGenerator,
	IChannel_t4289550709_CustomAttributesCacheGenerator,
	IChannelDataStore_t3350006733_CustomAttributesCacheGenerator,
	IChannelReceiver_t2529597353_CustomAttributesCacheGenerator,
	IChannelSender_t3210093071_CustomAttributesCacheGenerator,
	IClientChannelSinkProvider_t1548376438_CustomAttributesCacheGenerator,
	IServerChannelSinkProvider_t2031651231_CustomAttributesCacheGenerator,
	SinkProviderData_t2163625531_CustomAttributesCacheGenerator,
	Context_t836550985_CustomAttributesCacheGenerator,
	ContextAttribute_t3361256371_CustomAttributesCacheGenerator,
	IContextAttribute_t831350911_CustomAttributesCacheGenerator,
	IContextProperty_t406597577_CustomAttributesCacheGenerator,
	IContributeClientContextSink_t3362946504_CustomAttributesCacheGenerator,
	IContributeDynamicSink_t2642781930_CustomAttributesCacheGenerator,
	IContributeEnvoySink_t2491675206_CustomAttributesCacheGenerator,
	IContributeObjectSink_t2913419897_CustomAttributesCacheGenerator,
	IContributeServerContextSink_t3820488358_CustomAttributesCacheGenerator,
	IDynamicMessageSink_t133249795_CustomAttributesCacheGenerator,
	IDynamicProperty_t2092274604_CustomAttributesCacheGenerator,
	SynchronizationAttribute_t2363366576_CustomAttributesCacheGenerator,
	SynchronizationAttribute_t2363366576_CustomAttributesCacheGenerator_SynchronizationAttribute_GetPropertiesForNewContext_m3510013590,
	SynchronizationAttribute_t2363366576_CustomAttributesCacheGenerator_SynchronizationAttribute_IsContextOK_m1799431817,
	LifetimeServices_t3455124952_CustomAttributesCacheGenerator,
	AsyncResult_t3211417469_CustomAttributesCacheGenerator,
	ConstructionCall_t1166029924_CustomAttributesCacheGenerator,
	ConstructionCall_t1166029924_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map20,
	ConstructionCallDictionary_t3544640785_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map23,
	ConstructionCallDictionary_t3544640785_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map24,
	Header_t867743215_CustomAttributesCacheGenerator,
	IMessage_t3459494027_CustomAttributesCacheGenerator,
	IMessageCtrl_t1530236857_CustomAttributesCacheGenerator,
	IMessageSink_t2584464463_CustomAttributesCacheGenerator,
	IMethodCallMessage_t1534722205_CustomAttributesCacheGenerator,
	IMethodMessage_t2248289403_CustomAttributesCacheGenerator,
	IMethodReturnMessage_t199276439_CustomAttributesCacheGenerator,
	IRemotingFormatter_t4057376155_CustomAttributesCacheGenerator,
	LogicalCallContext_t2641012606_CustomAttributesCacheGenerator,
	MethodCall_t1249696419_CustomAttributesCacheGenerator,
	MethodCall_t1249696419_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map1F,
	MethodDictionary_t2740513268_CustomAttributesCacheGenerator,
	MethodDictionary_t2740513268_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map21,
	MethodDictionary_t2740513268_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map22,
	RemotingSurrogateSelector_t795063736_CustomAttributesCacheGenerator,
	ReturnMessage_t3772294297_CustomAttributesCacheGenerator,
	SoapAttribute_t475638499_CustomAttributesCacheGenerator,
	SoapFieldAttribute_t1770251027_CustomAttributesCacheGenerator,
	SoapMethodAttribute_t1135142028_CustomAttributesCacheGenerator,
	SoapParameterAttribute_t2303522566_CustomAttributesCacheGenerator,
	SoapTypeAttribute_t2542890154_CustomAttributesCacheGenerator,
	ProxyAttribute_t1316766301_CustomAttributesCacheGenerator,
	ProxyAttribute_t1316766301_CustomAttributesCacheGenerator_ProxyAttribute_GetPropertiesForNewContext_m2921967682,
	ProxyAttribute_t1316766301_CustomAttributesCacheGenerator_ProxyAttribute_IsContextOK_m2900797900,
	RealProxy_t4229839841_CustomAttributesCacheGenerator,
	ITrackingHandler_t974392511_CustomAttributesCacheGenerator,
	TrackingServices_t55356278_CustomAttributesCacheGenerator,
	ActivatedClientTypeEntry_t881095867_CustomAttributesCacheGenerator,
	ActivatedServiceTypeEntry_t263082741_CustomAttributesCacheGenerator,
	IChannelInfo_t2472532987_CustomAttributesCacheGenerator,
	IEnvoyInfo_t648105343_CustomAttributesCacheGenerator,
	IRemotingTypeInfo_t618730896_CustomAttributesCacheGenerator,
	InternalRemotingServices_t1814688636_CustomAttributesCacheGenerator,
	ObjRef_t1997854715_CustomAttributesCacheGenerator,
	ObjRef_t1997854715_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map26,
	ObjRef_t1997854715_CustomAttributesCacheGenerator_ObjRef_get_ChannelInfo_m2012758559,
	RemotingConfiguration_t1345264711_CustomAttributesCacheGenerator,
	ConfigHandler_t3932699857_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map27,
	ConfigHandler_t3932699857_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map28,
	ConfigHandler_t3932699857_CustomAttributesCacheGenerator_ConfigHandler_ValidatePath_m3488759860____paths1,
	RemotingException_t1173136616_CustomAttributesCacheGenerator,
	RemotingServices_t1047346230_CustomAttributesCacheGenerator,
	RemotingServices_t1047346230_CustomAttributesCacheGenerator_RemotingServices_IsTransparentProxy_m279338587,
	RemotingServices_t1047346230_CustomAttributesCacheGenerator_RemotingServices_GetRealProxy_m280469471,
	SoapServices_t3896196670_CustomAttributesCacheGenerator,
	TypeEntry_t975009579_CustomAttributesCacheGenerator,
	WellKnownClientTypeEntry_t128803266_CustomAttributesCacheGenerator,
	WellKnownObjectMode_t653959841_CustomAttributesCacheGenerator,
	WellKnownServiceTypeEntry_t3630394316_CustomAttributesCacheGenerator,
	BinaryFormatter_t2452830323_CustomAttributesCacheGenerator,
	BinaryFormatter_t2452830323_CustomAttributesCacheGenerator_U3CDefaultSurrogateSelectorU3Ek__BackingField,
	BinaryFormatter_t2452830323_CustomAttributesCacheGenerator_BinaryFormatter_get_DefaultSurrogateSelector_m854521798,
	FormatterAssemblyStyle_t2195407324_CustomAttributesCacheGenerator,
	FormatterTypeStyle_t1127895449_CustomAttributesCacheGenerator,
	TypeFilterLevel_t1430716943_CustomAttributesCacheGenerator,
	FormatterConverter_t3457131633_CustomAttributesCacheGenerator,
	FormatterServices_t1887439258_CustomAttributesCacheGenerator,
	IDeserializationCallback_t706750576_CustomAttributesCacheGenerator,
	IFormatter_t3532332523_CustomAttributesCacheGenerator,
	IFormatterConverter_t2745970127_CustomAttributesCacheGenerator,
	IObjectReference_t597715029_CustomAttributesCacheGenerator,
	ISerializationSurrogate_t2988905240_CustomAttributesCacheGenerator,
	ISurrogateSelector_t1458111122_CustomAttributesCacheGenerator,
	ObjectManager_t3901639071_CustomAttributesCacheGenerator,
	OnDeserializedAttribute_t1919362979_CustomAttributesCacheGenerator,
	OnDeserializingAttribute_t382572488_CustomAttributesCacheGenerator,
	OnSerializedAttribute_t559136818_CustomAttributesCacheGenerator,
	OnSerializingAttribute_t2631507647_CustomAttributesCacheGenerator,
	SerializationBinder_t2326413375_CustomAttributesCacheGenerator,
	SerializationEntry_t2018126969_CustomAttributesCacheGenerator,
	SerializationException_t924346921_CustomAttributesCacheGenerator,
	SerializationInfo_t623100739_CustomAttributesCacheGenerator,
	SerializationInfo_t623100739_CustomAttributesCacheGenerator_SerializationInfo__ctor_m2387200337,
	SerializationInfo_t623100739_CustomAttributesCacheGenerator_SerializationInfo_AddValue_m4204157667,
	SerializationInfoEnumerator_t461782006_CustomAttributesCacheGenerator,
	StreamingContext_t885793295_CustomAttributesCacheGenerator,
	StreamingContextStates_t317203920_CustomAttributesCacheGenerator,
	X509Certificate_t4268988265_CustomAttributesCacheGenerator,
	X509Certificate_t4268988265_CustomAttributesCacheGenerator_X509Certificate_GetIssuerName_m985760924,
	X509Certificate_t4268988265_CustomAttributesCacheGenerator_X509Certificate_GetName_m839418740,
	X509Certificate_t4268988265_CustomAttributesCacheGenerator_X509Certificate_Equals_m3424353702,
	X509Certificate_t4268988265_CustomAttributesCacheGenerator_X509Certificate_Import_m2684987799,
	X509Certificate_t4268988265_CustomAttributesCacheGenerator_X509Certificate_Reset_m4105901662,
	X509KeyStorageFlags_t2192654159_CustomAttributesCacheGenerator,
	AsymmetricAlgorithm_t955984407_CustomAttributesCacheGenerator,
	AsymmetricKeyExchangeFormatter_t886885227_CustomAttributesCacheGenerator,
	AsymmetricSignatureDeformatter_t3604315115_CustomAttributesCacheGenerator,
	AsymmetricSignatureFormatter_t2864085280_CustomAttributesCacheGenerator,
	CipherMode_t1510653764_CustomAttributesCacheGenerator,
	CryptoConfig_t2915898687_CustomAttributesCacheGenerator,
	CryptoConfig_t2915898687_CustomAttributesCacheGenerator_CryptoConfig_CreateFromName_m3002182116____args1,
	CryptographicException_t3065671415_CustomAttributesCacheGenerator,
	CryptographicUnexpectedOperationException_t930000052_CustomAttributesCacheGenerator,
	CspParameters_t3347918906_CustomAttributesCacheGenerator,
	CspProviderFlags_t613247746_CustomAttributesCacheGenerator,
	DES_t3797920348_CustomAttributesCacheGenerator,
	DESCryptoServiceProvider_t1590711767_CustomAttributesCacheGenerator,
	DSA_t47143136_CustomAttributesCacheGenerator,
	DSACryptoServiceProvider_t803357635_CustomAttributesCacheGenerator,
	DSACryptoServiceProvider_t803357635_CustomAttributesCacheGenerator_DSACryptoServiceProvider_t803357635____PublicOnly_PropertyInfo,
	DSAParameters_t4013484323_CustomAttributesCacheGenerator,
	DSASignatureDeformatter_t1830026019_CustomAttributesCacheGenerator,
	DSASignatureFormatter_t2790450949_CustomAttributesCacheGenerator,
	HMAC_t3287208588_CustomAttributesCacheGenerator,
	HMACMD5_t877655754_CustomAttributesCacheGenerator,
	HMACRIPEMD160_t2239679702_CustomAttributesCacheGenerator,
	HMACSHA1_t2626692938_CustomAttributesCacheGenerator,
	HMACSHA256_t4140074641_CustomAttributesCacheGenerator,
	HMACSHA384_t3754767111_CustomAttributesCacheGenerator,
	HMACSHA512_t3404524865_CustomAttributesCacheGenerator,
	HashAlgorithm_t2798580409_CustomAttributesCacheGenerator,
	ICryptoTransform_t179341168_CustomAttributesCacheGenerator,
	ICspAsymmetricAlgorithm_t3702375355_CustomAttributesCacheGenerator,
	KeyedHashAlgorithm_t366594456_CustomAttributesCacheGenerator,
	MACTripleDES_t1665378552_CustomAttributesCacheGenerator,
	MD5_t495647487_CustomAttributesCacheGenerator,
	MD5CryptoServiceProvider_t2490929366_CustomAttributesCacheGenerator,
	PaddingMode_t927572615_CustomAttributesCacheGenerator,
	RC2_t3547516542_CustomAttributesCacheGenerator,
	RC2CryptoServiceProvider_t3305775543_CustomAttributesCacheGenerator,
	RIPEMD160_t170226481_CustomAttributesCacheGenerator,
	RIPEMD160Managed_t688052670_CustomAttributesCacheGenerator,
	RSA_t1831419072_CustomAttributesCacheGenerator,
	RSACryptoServiceProvider_t242930683_CustomAttributesCacheGenerator,
	RSACryptoServiceProvider_t242930683_CustomAttributesCacheGenerator_RSACryptoServiceProvider_t242930683____PublicOnly_PropertyInfo,
	RSAPKCS1KeyExchangeFormatter_t86803071_CustomAttributesCacheGenerator,
	RSAPKCS1SignatureDeformatter_t1486601497_CustomAttributesCacheGenerator,
	RSAPKCS1SignatureFormatter_t2724172344_CustomAttributesCacheGenerator,
	RSAParameters_t3314567386_CustomAttributesCacheGenerator,
	Rijndael_t24829170_CustomAttributesCacheGenerator,
	RijndaelManaged_t2499591095_CustomAttributesCacheGenerator,
	RijndaelManagedTransform_t1223567365_CustomAttributesCacheGenerator,
	SHA1_t3068583258_CustomAttributesCacheGenerator,
	SHA1CryptoServiceProvider_t2273746778_CustomAttributesCacheGenerator,
	SHA1Managed_t3616185673_CustomAttributesCacheGenerator,
	SHA256_t2880016589_CustomAttributesCacheGenerator,
	SHA256Managed_t3149068738_CustomAttributesCacheGenerator,
	SHA384_t4262120991_CustomAttributesCacheGenerator,
	SHA384Managed_t1083824740_CustomAttributesCacheGenerator,
	SHA512_t3793833733_CustomAttributesCacheGenerator,
	SHA512Managed_t579431699_CustomAttributesCacheGenerator,
	SignatureDescription_t1918251708_CustomAttributesCacheGenerator,
	SymmetricAlgorithm_t1437564452_CustomAttributesCacheGenerator,
	ToBase64Transform_t2523062884_CustomAttributesCacheGenerator,
	TripleDES_t3372534912_CustomAttributesCacheGenerator,
	TripleDESCryptoServiceProvider_t424749285_CustomAttributesCacheGenerator,
	CodeAccessSecurityAttribute_t757905721_CustomAttributesCacheGenerator,
	IUnrestrictedPermission_t3571481434_CustomAttributesCacheGenerator,
	SecurityPermission_t583848627_CustomAttributesCacheGenerator,
	SecurityPermissionAttribute_t387285309_CustomAttributesCacheGenerator,
	SecurityPermissionFlag_t3101722525_CustomAttributesCacheGenerator,
	StrongNamePublicKeyBlob_t1772872490_CustomAttributesCacheGenerator,
	ApplicationTrust_t362751801_CustomAttributesCacheGenerator,
	Evidence_t757411348_CustomAttributesCacheGenerator,
	Evidence_t757411348_CustomAttributesCacheGenerator_Evidence_Equals_m3868193673,
	Evidence_t757411348_CustomAttributesCacheGenerator_Evidence_GetHashCode_m3660855014,
	Hash_t2853297299_CustomAttributesCacheGenerator,
	IIdentityPermissionFactory_t3494792867_CustomAttributesCacheGenerator,
	StrongName_t2472190370_CustomAttributesCacheGenerator,
	IIdentity_t1310569830_CustomAttributesCacheGenerator,
	IPrincipal_t2189726509_CustomAttributesCacheGenerator,
	PrincipalPolicy_t4069167024_CustomAttributesCacheGenerator,
	WindowsAccountType_t2558366604_CustomAttributesCacheGenerator,
	WindowsIdentity_t2572034763_CustomAttributesCacheGenerator,
	WindowsIdentity_t2572034763_CustomAttributesCacheGenerator_WindowsIdentity_Dispose_m2729980567,
	AllowPartiallyTrustedCallersAttribute_t2793852185_CustomAttributesCacheGenerator,
	CodeAccessPermission_t1722695774_CustomAttributesCacheGenerator,
	CodeAccessPermission_t1722695774_CustomAttributesCacheGenerator_CodeAccessPermission_Equals_m3953672351,
	CodeAccessPermission_t1722695774_CustomAttributesCacheGenerator_CodeAccessPermission_GetHashCode_m539756730,
	IPermission_t358765359_CustomAttributesCacheGenerator,
	ISecurityEncodable_t1930308172_CustomAttributesCacheGenerator,
	IStackWalk_t3386434739_CustomAttributesCacheGenerator,
	PermissionSet_t1873340635_CustomAttributesCacheGenerator_U3CDeclarativeSecurityU3Ek__BackingField,
	PermissionSet_t1873340635_CustomAttributesCacheGenerator_PermissionSet_set_DeclarativeSecurity_m644410636,
	SecurityCriticalAttribute_t4019023285_CustomAttributesCacheGenerator,
	SecurityElement_t3886520689_CustomAttributesCacheGenerator,
	SecurityException_t2846057857_CustomAttributesCacheGenerator,
	SecurityException_t2846057857_CustomAttributesCacheGenerator_SecurityException_t2846057857____Demanded_PropertyInfo,
	SecurityManager_t2368288763_CustomAttributesCacheGenerator,
	SecurityManager_t2368288763_CustomAttributesCacheGenerator_SecurityManager_t2368288763____SecurityEnabled_PropertyInfo,
	SecuritySafeCriticalAttribute_t3761815145_CustomAttributesCacheGenerator,
	SuppressUnmanagedCodeSecurityAttribute_t712177550_CustomAttributesCacheGenerator,
	UnverifiableCodeAttribute_t2126738304_CustomAttributesCacheGenerator,
	ASCIIEncoding_t2683426640_CustomAttributesCacheGenerator,
	ASCIIEncoding_t2683426640_CustomAttributesCacheGenerator_ASCIIEncoding_GetBytes_m1861174925,
	ASCIIEncoding_t2683426640_CustomAttributesCacheGenerator_ASCIIEncoding_GetByteCount_m1104398450,
	ASCIIEncoding_t2683426640_CustomAttributesCacheGenerator_ASCIIEncoding_GetDecoder_m4195996369,
	Decoder_t1161719558_CustomAttributesCacheGenerator,
	Decoder_t1161719558_CustomAttributesCacheGenerator_Decoder_t1161719558____Fallback_PropertyInfo,
	Decoder_t1161719558_CustomAttributesCacheGenerator_Decoder_t1161719558____FallbackBuffer_PropertyInfo,
	DecoderReplacementFallback_t586276568_CustomAttributesCacheGenerator_DecoderReplacementFallback__ctor_m2067492076,
	EncoderReplacementFallback_t565825954_CustomAttributesCacheGenerator_EncoderReplacementFallback__ctor_m3250070966,
	Encoding_t1853649522_CustomAttributesCacheGenerator,
	Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_InvokeI18N_m2682327131____args1,
	Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_Clone_m4233455263,
	Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_GetByteCount_m4183085963,
	Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_GetBytes_m1474736915,
	Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_t1853649522____IsReadOnly_PropertyInfo,
	Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_t1853649522____DecoderFallback_PropertyInfo,
	Encoding_t1853649522_CustomAttributesCacheGenerator_Encoding_t1853649522____EncoderFallback_PropertyInfo,
	StringBuilder_t718897314_CustomAttributesCacheGenerator,
	StringBuilder_t718897314_CustomAttributesCacheGenerator_StringBuilder_AppendFormat_m265867772____args1,
	StringBuilder_t718897314_CustomAttributesCacheGenerator_StringBuilder_AppendFormat_m170141315____args2,
	UTF32Encoding_t3108170857_CustomAttributesCacheGenerator_UTF32Encoding_GetByteCount_m4237185367,
	UTF32Encoding_t3108170857_CustomAttributesCacheGenerator_UTF32Encoding_GetBytes_m2455949945,
	UTF32Encoding_t3108170857_CustomAttributesCacheGenerator_UTF32Encoding_GetByteCount_m1376079431,
	UTF32Encoding_t3108170857_CustomAttributesCacheGenerator_UTF32Encoding_GetBytes_m3225718289,
	UTF7Encoding_t1676725360_CustomAttributesCacheGenerator,
	UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetHashCode_m2812161639,
	UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_Equals_m1452874225,
	UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetByteCount_m2506376274,
	UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetByteCount_m339441067,
	UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetBytes_m2044879498,
	UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetBytes_m578527611,
	UTF7Encoding_t1676725360_CustomAttributesCacheGenerator_UTF7Encoding_GetString_m3450959021,
	UTF8Encoding_t2750870271_CustomAttributesCacheGenerator,
	UTF8Encoding_t2750870271_CustomAttributesCacheGenerator_UTF8Encoding_GetByteCount_m2335716119,
	UTF8Encoding_t2750870271_CustomAttributesCacheGenerator_UTF8Encoding_GetBytes_m1516677235,
	UTF8Encoding_t2750870271_CustomAttributesCacheGenerator_UTF8Encoding_GetString_m658301774,
	UnicodeEncoding_t289070003_CustomAttributesCacheGenerator,
	UnicodeEncoding_t289070003_CustomAttributesCacheGenerator_UnicodeEncoding_GetByteCount_m2385439378,
	UnicodeEncoding_t289070003_CustomAttributesCacheGenerator_UnicodeEncoding_GetBytes_m1035720983,
	UnicodeEncoding_t289070003_CustomAttributesCacheGenerator_UnicodeEncoding_GetString_m2415827372,
	CompressedStack_t2266949894_CustomAttributesCacheGenerator_CompressedStack_CreateCopy_m3982422829,
	CompressedStack_t2266949894_CustomAttributesCacheGenerator_CompressedStack_GetObjectData_m690500011,
	EventResetMode_t3757279066_CustomAttributesCacheGenerator,
	EventWaitHandle_t227290698_CustomAttributesCacheGenerator,
	ExecutionContext_t68001916_CustomAttributesCacheGenerator_ExecutionContext__ctor_m832962155,
	ExecutionContext_t68001916_CustomAttributesCacheGenerator_ExecutionContext_GetObjectData_m1523482666,
	Interlocked_t1682382106_CustomAttributesCacheGenerator_Interlocked_CompareExchange_m2836937338,
	Interlocked_t1682382106_CustomAttributesCacheGenerator_Interlocked_CompareExchange_m2205680848,
	ManualResetEvent_t1445603037_CustomAttributesCacheGenerator,
	Monitor_t2052646250_CustomAttributesCacheGenerator,
	Monitor_t2052646250_CustomAttributesCacheGenerator_Monitor_Exit_m1806149589,
	Mutex_t3929015048_CustomAttributesCacheGenerator,
	Mutex_t3929015048_CustomAttributesCacheGenerator_Mutex__ctor_m1301030505,
	Mutex_t3929015048_CustomAttributesCacheGenerator_Mutex_ReleaseMutex_m4091486119,
	SynchronizationContext_t3240649268_CustomAttributesCacheGenerator_currentContext,
	SynchronizationLockException_t2471118255_CustomAttributesCacheGenerator,
	Thread_t3822855611_CustomAttributesCacheGenerator,
	Thread_t3822855611_CustomAttributesCacheGenerator_local_slots,
	Thread_t3822855611_CustomAttributesCacheGenerator__ec,
	Thread_t3822855611_CustomAttributesCacheGenerator_Thread_get_CurrentThread_m2728607849,
	Thread_t3822855611_CustomAttributesCacheGenerator_Thread_Finalize_m1654384812,
	Thread_t3822855611_CustomAttributesCacheGenerator_Thread_get_ExecutionContext_m1768813807,
	Thread_t3822855611_CustomAttributesCacheGenerator_Thread_get_ManagedThreadId_m2611241199,
	Thread_t3822855611_CustomAttributesCacheGenerator_Thread_GetHashCode_m2708003321,
	Thread_t3822855611_CustomAttributesCacheGenerator_Thread_GetCompressedStack_m1386275719,
	Thread_t3822855611_CustomAttributesCacheGenerator_Thread_t3822855611____ExecutionContext_PropertyInfo,
	ThreadAbortException_t149492054_CustomAttributesCacheGenerator,
	ThreadInterruptedException_t34049732_CustomAttributesCacheGenerator,
	ThreadState_t3017098817_CustomAttributesCacheGenerator,
	ThreadStateException_t1589333507_CustomAttributesCacheGenerator,
	Timer_t2664195862_CustomAttributesCacheGenerator,
	WaitHandle_t52248909_CustomAttributesCacheGenerator,
	WaitHandle_t52248909_CustomAttributesCacheGenerator_WaitHandle_t52248909____Handle_PropertyInfo,
	AccessViolationException_t621235869_CustomAttributesCacheGenerator,
	ActivationContext_t1805170213_CustomAttributesCacheGenerator,
	ActivationContext_t1805170213_CustomAttributesCacheGenerator_ActivationContext_System_Runtime_Serialization_ISerializable_GetObjectData_m1919074653,
	Activator_t2766073353_CustomAttributesCacheGenerator,
	Activator_t2766073353_CustomAttributesCacheGenerator_Activator_CreateInstance_m444130951____args1,
	AppDomain_t2648090339_CustomAttributesCacheGenerator,
	AppDomain_t2648090339_CustomAttributesCacheGenerator_type_resolve_in_progress,
	AppDomain_t2648090339_CustomAttributesCacheGenerator_assembly_resolve_in_progress,
	AppDomain_t2648090339_CustomAttributesCacheGenerator_assembly_resolve_in_progress_refonly,
	AppDomain_t2648090339_CustomAttributesCacheGenerator__principal,
	AppDomainManager_t116683013_CustomAttributesCacheGenerator,
	AppDomainSetup_t2743734351_CustomAttributesCacheGenerator,
	ApplicationException_t1422262649_CustomAttributesCacheGenerator,
	ApplicationIdentity_t582625741_CustomAttributesCacheGenerator,
	ApplicationIdentity_t582625741_CustomAttributesCacheGenerator_ApplicationIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m2267909380,
	ArgumentException_t2004815231_CustomAttributesCacheGenerator,
	ArgumentNullException_t3632016946_CustomAttributesCacheGenerator,
	ArgumentOutOfRangeException_t3491990243_CustomAttributesCacheGenerator,
	ArithmeticException_t137630443_CustomAttributesCacheGenerator,
	ArrayTypeMismatchException_t1700383061_CustomAttributesCacheGenerator,
	AssemblyLoadEventArgs_t1395911814_CustomAttributesCacheGenerator,
	AttributeTargets_t1409711436_CustomAttributesCacheGenerator,
	Buffer_t135592026_CustomAttributesCacheGenerator,
	CharEnumerator_t2602806652_CustomAttributesCacheGenerator,
	ContextBoundObject_t3291734292_CustomAttributesCacheGenerator,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToBoolean_m1887725282,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToBoolean_m707738265,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToBoolean_m1122829536,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToBoolean_m3283955427,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToByte_m1519340743,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToByte_m1674698270,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToByte_m3099814251,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToByte_m2153487333,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToChar_m1568898469,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToChar_m337390725,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToChar_m2214938048,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToChar_m453700468,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDateTime_m3011399261,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDateTime_m1737814825,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDateTime_m3526800699,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDateTime_m1351566174,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDecimal_m3255111027,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDecimal_m362315142,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDecimal_m690090213,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDecimal_m1381390199,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDouble_m2409248499,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDouble_m2406944942,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDouble_m132850532,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToDouble_m2474254574,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt16_m3142197079,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt16_m3910677062,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt16_m4194599106,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt16_m2462923612,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt32_m2414750495,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt32_m2422887349,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt32_m2545494139,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt32_m1812481528,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt64_m2719224162,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt64_m513460999,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt64_m1220027300,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToInt64_m3686795582,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m3654808220,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m2221295796,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m1198711592,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m4039538944,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m2255796510,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m1171878403,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m2364369564,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m2473384867,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m1899553949,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m1260639261,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m3263476780,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m621137857,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m502382709,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSByte_m1923387717,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSingle_m2927637723,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSingle_m263664334,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSingle_m108240803,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToSingle_m4264044771,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m3589406227,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m262507043,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m1916842140,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m1590911059,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m1460061451,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m2605846227,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m3441577881,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m2315016985,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m3851674843,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m598870541,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m1969507677,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m271993144,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m3417160479,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt16_m848830585,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m2890507400,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m4225679663,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m1139469487,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m899358007,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m3538128733,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m2750411885,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m1509256923,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m413938554,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m3371003386,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m1967326106,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m3357398318,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m2624224331,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m4087217800,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt32_m441301288,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m3421432777,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m588351329,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m1305628260,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m152153280,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m1532445467,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m332078237,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2034597942,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2644784328,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m1758528004,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m4235029228,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m441916607,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2608704228,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2802651835,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2087886788,
	Convert_t3458710757_CustomAttributesCacheGenerator_Convert_ToUInt64_m2300482675,
	DBNull_t317552310_CustomAttributesCacheGenerator,
	DateTimeKind_t588365666_CustomAttributesCacheGenerator,
	DateTimeOffset_t3036919142_CustomAttributesCacheGenerator_DateTimeOffset_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m2865451658,
	DayOfWeek_t1380878247_CustomAttributesCacheGenerator,
	DivideByZeroException_t830428046_CustomAttributesCacheGenerator,
	DllNotFoundException_t2356382286_CustomAttributesCacheGenerator,
	EntryPointNotFoundException_t762882416_CustomAttributesCacheGenerator,
	MonoEnumInfo_t2659694797_CustomAttributesCacheGenerator_cache,
	Environment_t4132265847_CustomAttributesCacheGenerator,
	SpecialFolder_t247122931_CustomAttributesCacheGenerator,
	EventArgs_t3765086707_CustomAttributesCacheGenerator,
	ExecutionEngineException_t942644687_CustomAttributesCacheGenerator,
	FieldAccessException_t2393343644_CustomAttributesCacheGenerator,
	FlagsAttribute_t2123170284_CustomAttributesCacheGenerator,
	FormatException_t2016869209_CustomAttributesCacheGenerator,
	GC_t1257975953_CustomAttributesCacheGenerator_GC_SuppressFinalize_m2436602860,
	Guid_t_CustomAttributesCacheGenerator,
	ICustomFormatter_t3048241609_CustomAttributesCacheGenerator,
	IFormatProvider_t2239227292_CustomAttributesCacheGenerator,
	IndexOutOfRangeException_t3356532665_CustomAttributesCacheGenerator,
	InvalidCastException_t3434725360_CustomAttributesCacheGenerator,
	InvalidOperationException_t3413438395_CustomAttributesCacheGenerator,
	LoaderOptimization_t1131133142_CustomAttributesCacheGenerator,
	LoaderOptimization_t1131133142_CustomAttributesCacheGenerator_DomainMask,
	LoaderOptimization_t1131133142_CustomAttributesCacheGenerator_DisallowBindings,
	LocalDataStoreSlot_t775718540_CustomAttributesCacheGenerator,
	Math_t2064695271_CustomAttributesCacheGenerator_Math_Max_m1737240539,
	Math_t2064695271_CustomAttributesCacheGenerator_Math_Min_m2898138409,
	Math_t2064695271_CustomAttributesCacheGenerator_Math_Sqrt_m2669192963,
	MemberAccessException_t3227932226_CustomAttributesCacheGenerator,
	MethodAccessException_t107138509_CustomAttributesCacheGenerator,
	MissingFieldException_t2479880909_CustomAttributesCacheGenerator,
	MissingMemberException_t2055358158_CustomAttributesCacheGenerator,
	MissingMethodException_t306141151_CustomAttributesCacheGenerator,
	MulticastNotSupportedException_t2338674854_CustomAttributesCacheGenerator,
	NonSerializedAttribute_t2672110800_CustomAttributesCacheGenerator,
	NotImplementedException_t3812197027_CustomAttributesCacheGenerator,
	NotSupportedException_t3258010636_CustomAttributesCacheGenerator,
	NullReferenceException_t3221440195_CustomAttributesCacheGenerator,
	NumberFormatter_t2567188219_CustomAttributesCacheGenerator_threadNumberFormatter,
	ObjectDisposedException_t1287406024_CustomAttributesCacheGenerator,
	OperatingSystem_t2974600964_CustomAttributesCacheGenerator,
	OutOfMemoryException_t3284315365_CustomAttributesCacheGenerator,
	OverflowException_t1772151001_CustomAttributesCacheGenerator,
	PlatformID_t1036322677_CustomAttributesCacheGenerator,
	PlatformNotSupportedException_t1144249114_CustomAttributesCacheGenerator,
	RankException_t1412744892_CustomAttributesCacheGenerator,
	ResolveEventArgs_t1631477950_CustomAttributesCacheGenerator,
	RuntimeMethodHandle_t4063774698_CustomAttributesCacheGenerator,
	RuntimeMethodHandle_t4063774698_CustomAttributesCacheGenerator_RuntimeMethodHandle_Equals_m694043567,
	StackOverflowException_t1229567991_CustomAttributesCacheGenerator,
	StringComparer_t2150832686_CustomAttributesCacheGenerator,
	StringComparison_t4237255105_CustomAttributesCacheGenerator,
	StringSplitOptions_t1470633910_CustomAttributesCacheGenerator,
	SystemException_t2605480680_CustomAttributesCacheGenerator,
	ThreadStaticAttribute_t4044403880_CustomAttributesCacheGenerator,
	TimeSpan_t4182925364_CustomAttributesCacheGenerator,
	TimeZone_t129964036_CustomAttributesCacheGenerator,
	TypeCode_t842513060_CustomAttributesCacheGenerator,
	TypeInitializationException_t1153585075_CustomAttributesCacheGenerator,
	TypeLoadException_t2846187622_CustomAttributesCacheGenerator,
	UnauthorizedAccessException_t679070329_CustomAttributesCacheGenerator,
	UnhandledExceptionEventArgs_t412183538_CustomAttributesCacheGenerator,
	UnhandledExceptionEventArgs_t412183538_CustomAttributesCacheGenerator_UnhandledExceptionEventArgs_get_ExceptionObject_m4275923656,
	UnhandledExceptionEventArgs_t412183538_CustomAttributesCacheGenerator_UnhandledExceptionEventArgs_get_IsTerminating_m3714614171,
	Version_t3942069453_CustomAttributesCacheGenerator,
	WeakReference_t2646405993_CustomAttributesCacheGenerator,
	MemberFilter_t3088556475_CustomAttributesCacheGenerator,
	TypeFilter_t3805304870_CustomAttributesCacheGenerator,
	CrossContextDelegate_t3119470076_CustomAttributesCacheGenerator,
	HeaderHandler_t3298815300_CustomAttributesCacheGenerator,
	ThreadStart_t16934496_CustomAttributesCacheGenerator,
	TimerCallback_t1325839763_CustomAttributesCacheGenerator,
	WaitCallback_t493830079_CustomAttributesCacheGenerator,
	AppDomainInitializer_t749344933_CustomAttributesCacheGenerator,
	AssemblyLoadEventHandler_t479720079_CustomAttributesCacheGenerator,
	EventHandler_t3645504629_CustomAttributesCacheGenerator,
	ResolveEventHandler_t4248294491_CustomAttributesCacheGenerator,
	UnhandledExceptionEventHandler_t3971395670_CustomAttributesCacheGenerator,
	U3CPrivateImplementationDetailsU3E_t3192871059_CustomAttributesCacheGenerator,
	g_System_Assembly_CustomAttributesCacheGenerator,
	Locale_t57088989_CustomAttributesCacheGenerator_Locale_GetText_m3231868817____args1,
	MonoTODOAttribute_t119123863_CustomAttributesCacheGenerator,
	Queue_1_t3027544886_CustomAttributesCacheGenerator,
	Stack_1_t4283693321_CustomAttributesCacheGenerator,
	HybridDictionary_t3761704658_CustomAttributesCacheGenerator,
	ListDictionary_t222750502_CustomAttributesCacheGenerator,
	NameObjectCollectionBase_t3546148169_CustomAttributesCacheGenerator_NameObjectCollectionBase_FindFirstMatchedItem_m2785248297,
	KeysCollection_t3858846733_CustomAttributesCacheGenerator,
	NameValueCollection_t3172313318_CustomAttributesCacheGenerator,
	EditorBrowsableAttribute_t1429620940_CustomAttributesCacheGenerator,
	TypeConverter_t186346670_CustomAttributesCacheGenerator,
	TypeConverterAttribute_t3031206686_CustomAttributesCacheGenerator,
	SslPolicyErrors_t3855906214_CustomAttributesCacheGenerator,
	FileWebRequest_t211636899_CustomAttributesCacheGenerator_FileWebRequest__ctor_m331710361,
	FtpWebRequest_t2714096550_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache1C,
	FtpWebRequest_t2714096550_CustomAttributesCacheGenerator_FtpWebRequest_U3CcallbackU3Em__B_m3498702001,
	GlobalProxySelection_t3450859545_CustomAttributesCacheGenerator,
	HttpWebRequest_t3927073785_CustomAttributesCacheGenerator_HttpWebRequest__ctor_m2901044332,
	IPv6Address_t2462431949_CustomAttributesCacheGenerator,
	SecurityProtocolType_t2871506216_CustomAttributesCacheGenerator,
	ServicePointManager_t2286025188_CustomAttributesCacheGenerator_ServicePointManager_t2286025188____CertificatePolicy_PropertyInfo,
	ServicePointManager_t2286025188_CustomAttributesCacheGenerator_ServicePointManager_t2286025188____CheckCertificateRevocationList_PropertyInfo,
	WebHeaderCollection_t1256302915_CustomAttributesCacheGenerator,
	WebProxy_t1311200052_CustomAttributesCacheGenerator_WebProxy_t1311200052____UseDefaultCredentials_PropertyInfo,
	WebRequest_t1162840426_CustomAttributesCacheGenerator_WebRequest_GetDefaultWebProxy_m2436480977,
	OpenFlags_t3075873276_CustomAttributesCacheGenerator,
	PublicKey_t3235236034_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map9,
	X500DistinguishedName_t264737722_CustomAttributesCacheGenerator,
	X500DistinguishedNameFlags_t2471748252_CustomAttributesCacheGenerator,
	X509Certificate2_t2584690363_CustomAttributesCacheGenerator_X509Certificate2_GetNameInfo_m808913113,
	X509Certificate2_t2584690363_CustomAttributesCacheGenerator_X509Certificate2_Import_m3534696989,
	X509Certificate2_t2584690363_CustomAttributesCacheGenerator_X509Certificate2_Verify_m284365349,
	X509Certificate2Collection_t2547172981_CustomAttributesCacheGenerator,
	X509Certificate2Collection_t2547172981_CustomAttributesCacheGenerator_X509Certificate2Collection_AddRange_m3857728710,
	X509Certificate2Collection_t2547172981_CustomAttributesCacheGenerator_X509Certificate2Collection_Find_m2757621005,
	X509CertificateCollection_t2058953987_CustomAttributesCacheGenerator,
	X509Chain_t3669779137_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapB,
	X509Chain_t3669779137_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapC,
	X509Chain_t3669779137_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapD,
	X509Chain_t3669779137_CustomAttributesCacheGenerator_X509Chain_Build_m1000713326,
	X509ChainElementCollection_t4094883155_CustomAttributesCacheGenerator,
	X509ChainStatusFlags_t3387568385_CustomAttributesCacheGenerator,
	X509EnhancedKeyUsageExtension_t2447244446_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapE,
	X509ExtensionCollection_t3927234224_CustomAttributesCacheGenerator,
	X509KeyUsageFlags_t2405450781_CustomAttributesCacheGenerator,
	X509Store_t3053056657_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF,
	X509VerificationFlags_t2857382038_CustomAttributesCacheGenerator,
	AsnEncodedData_t2307648400_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapA,
	Oid_t2315348323_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map10,
	OidCollection_t3025304052_CustomAttributesCacheGenerator,
	CaptureCollection_t276843680_CustomAttributesCacheGenerator,
	GroupCollection_t3045585314_CustomAttributesCacheGenerator,
	MatchCollection_t3895979827_CustomAttributesCacheGenerator,
	RegexOptions_t1904484159_CustomAttributesCacheGenerator,
	OpFlags_t871130963_CustomAttributesCacheGenerator,
	IntervalCollection_t3208028748_CustomAttributesCacheGenerator,
	ExpressionCollection_t3117266731_CustomAttributesCacheGenerator,
	Uri_t4143213084_CustomAttributesCacheGenerator,
	Uri_t4143213084_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map14,
	Uri_t4143213084_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map15,
	Uri_t4143213084_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map16,
	Uri_t4143213084_CustomAttributesCacheGenerator_Uri__ctor_m3676275920,
	Uri_t4143213084_CustomAttributesCacheGenerator_Uri_EscapeString_m3040128922,
	Uri_t4143213084_CustomAttributesCacheGenerator_Uri_Unescape_m772995138,
	UriParser_t1215654776_CustomAttributesCacheGenerator_UriParser_OnRegister_m3840206273,
	U3CPrivateImplementationDetailsU3E_t3192871060_CustomAttributesCacheGenerator,
	g_Mono_Security_Assembly_CustomAttributesCacheGenerator,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger__ctor_m3040047200,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger__ctor_m3107529596,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger__ctor_m2947591044,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_SetBit_m1548788441,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_SetBit_m2995356053,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_ToString_m974324122,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_ToString_m2613494688,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_op_Implicit_m1053202820,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_op_Modulus_m1699883937,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_op_Equality_m294921050,
	BigInteger_t964697201_CustomAttributesCacheGenerator_BigInteger_op_Inequality_m1285189855,
	ModulusRing_t1892935213_CustomAttributesCacheGenerator_ModulusRing_Pow_m4156652970,
	ASN1_t3432613457_CustomAttributesCacheGenerator,
	PKCS12_t192318788_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map5,
	PKCS12_t192318788_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map6,
	PKCS12_t192318788_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map7,
	PKCS12_t192318788_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map8,
	PKCS12_t192318788_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapC,
	X509Certificate_t1460961154_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF,
	X509Certificate_t1460961154_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map10,
	X509Certificate_t1460961154_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map11,
	X509CertificateCollection_t3275414985_CustomAttributesCacheGenerator,
	X509ChainStatusFlags_t2964126077_CustomAttributesCacheGenerator,
	X509Crl_t3265469029_CustomAttributesCacheGenerator,
	X509Crl_t3265469029_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map13,
	X509ExtensionCollection_t1736530051_CustomAttributesCacheGenerator,
	ExtendedKeyUsageExtension_t2231911744_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map14,
	KeyUsages_t4089794537_CustomAttributesCacheGenerator,
	CertTypes_t720719080_CustomAttributesCacheGenerator,
	CipherSuiteCollection_t1115970082_CustomAttributesCacheGenerator,
	HttpsClientStream_t1872672109_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache2,
	HttpsClientStream_t1872672109_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache3,
	HttpsClientStream_t1872672109_CustomAttributesCacheGenerator_HttpsClientStream_U3CHttpsClientStreamU3Em__0_m2170627081,
	HttpsClientStream_t1872672109_CustomAttributesCacheGenerator_HttpsClientStream_U3CHttpsClientStreamU3Em__1_m1135820886,
	RSASslSignatureDeformatter_t2727446502_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map15,
	RSASslSignatureFormatter_t879319000_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map16,
	SecurityProtocolType_t1676794907_CustomAttributesCacheGenerator,
	U3CPrivateImplementationDetailsU3E_t3192871061_CustomAttributesCacheGenerator,
	g_System_Core_Assembly_CustomAttributesCacheGenerator,
	ExtensionAttribute_t36176176_CustomAttributesCacheGenerator,
	Locale_t57088991_CustomAttributesCacheGenerator_Locale_GetText_m2212416198____args1,
	Enumerable_t3932770618_CustomAttributesCacheGenerator,
	Enumerable_t3932770618_CustomAttributesCacheGenerator_Enumerable_Any_m437989361,
	Enumerable_t3932770618_CustomAttributesCacheGenerator_Enumerable_Where_m311029895,
	Enumerable_t3932770618_CustomAttributesCacheGenerator_Enumerable_CreateWhereIterator_m2574702225,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_Generic_IEnumeratorU3CTSourceU3E_get_Current_m3031864783,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_IEnumerator_get_Current_m2799052118,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_IEnumerable_GetEnumerator_m477268233,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_Generic_IEnumerableU3CTSourceU3E_GetEnumerator_m1473712349,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_Dispose_m1794745798,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_Reset_m2986643486,
	U3CPrivateImplementationDetailsU3E_t3192871062_CustomAttributesCacheGenerator,
	g_UnityEngine_Assembly_CustomAttributesCacheGenerator,
	Application_t821171777_CustomAttributesCacheGenerator_lowMemory,
	Application_t821171777_CustomAttributesCacheGenerator_onBeforeRender,
	Application_t821171777_CustomAttributesCacheGenerator_Application_CallLowMemory_m950526118,
	Application_t821171777_CustomAttributesCacheGenerator_Application_CallLogCallback_m1230073937,
	Application_t821171777_CustomAttributesCacheGenerator_Application_InvokeOnBeforeRender_m367288211,
	AssetBundleCreateRequest_t2444460025_CustomAttributesCacheGenerator,
	AssetBundleCreateRequest_t2444460025_CustomAttributesCacheGenerator_AssetBundleCreateRequest_get_assetBundle_m1127086494,
	AssetBundleCreateRequest_t2444460025_CustomAttributesCacheGenerator_AssetBundleCreateRequest_DisableCompatibilityChecks_m1123061109,
	AssetBundleRequest_t988638785_CustomAttributesCacheGenerator,
	AssetBundleRequest_t988638785_CustomAttributesCacheGenerator_AssetBundleRequest_get_asset_m1618802054,
	AssetBundleRequest_t988638785_CustomAttributesCacheGenerator_AssetBundleRequest_get_allAssets_m4077343547,
	AsyncOperation_t1216045970_CustomAttributesCacheGenerator,
	AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_InternalDestroy_m989121897,
	AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_get_isDone_m2130057835,
	AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_get_progress_m132026404,
	AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_get_priority_m3349967333,
	AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_set_priority_m2349794837,
	AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_get_allowSceneActivation_m3755262598,
	AsyncOperation_t1216045970_CustomAttributesCacheGenerator_AsyncOperation_set_allowSceneActivation_m384018621,
	WaitForSeconds_t2172464514_CustomAttributesCacheGenerator,
	WaitForFixedUpdate_t231781307_CustomAttributesCacheGenerator,
	WaitForEndOfFrame_t3943813712_CustomAttributesCacheGenerator,
	Coroutine_t56146755_CustomAttributesCacheGenerator,
	Coroutine_t56146755_CustomAttributesCacheGenerator_Coroutine_ReleaseCoroutine_m3781988635,
	ScriptableObject_t643150937_CustomAttributesCacheGenerator,
	ScriptableObject_t643150937_CustomAttributesCacheGenerator_ScriptableObject_Internal_CreateScriptableObject_m497791512,
	ScriptableObject_t643150937_CustomAttributesCacheGenerator_ScriptableObject_Internal_CreateScriptableObject_m497791512____self0,
	ScriptableObject_t643150937_CustomAttributesCacheGenerator_ScriptableObject_CreateInstance_m1184682349,
	ScriptableObject_t643150937_CustomAttributesCacheGenerator_ScriptableObject_CreateInstanceFromType_m1377228085,
	FailedToLoadScriptObject_t1581619330_CustomAttributesCacheGenerator,
	Behaviour_t2953351352_CustomAttributesCacheGenerator,
	Camera_t142011664_CustomAttributesCacheGenerator,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_nearClipPlane_m595687364,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_farClipPlane_m672532137,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_cullingMask_m1829245964,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_eventMask_m192041623,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_INTERNAL_get_pixelRect_m3579949699,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_targetTexture_m2343817798,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_clearFlags_m4107941227,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_INTERNAL_CALL_ScreenPointToRay_m1092094677,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_get_allCamerasCount_m202689974,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_GetAllCameras_m14780124,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_FireOnPreCull_m2833190726,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_FireOnPreRender_m3227173956,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_FireOnPostRender_m169492450,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_INTERNAL_CALL_RaycastTry_m3176538179,
	Camera_t142011664_CustomAttributesCacheGenerator_Camera_INTERNAL_CALL_RaycastTry2D_m1805928838,
	Component_t21088299_CustomAttributesCacheGenerator,
	Component_t21088299_CustomAttributesCacheGenerator_Component_get_transform_m1991721595,
	Component_t21088299_CustomAttributesCacheGenerator_Component_get_gameObject_m44324674,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponent_m4065514490,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentFastPath_m2526947697,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponent_m3948181317,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponent_m3003597536,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m174763428,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m916963883,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m2013229797,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m2478491131____includeInactive0,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentsInChildren_m3617139144,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentsInChildren_m155792327____includeInactive1,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentInParent_m3868731529,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentsInParent_m218516534,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentsInParent_m1469804712____includeInactive1,
	Component_t21088299_CustomAttributesCacheGenerator_Component_GetComponentsForListInternal_m2222527641,
	Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2783812412,
	Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2783812412____value1,
	Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2783812412____options2,
	Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2173372724,
	Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m3268518138,
	Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessage_m4289933507,
	Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessage_m4289933507____value1,
	Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessage_m4289933507____options2,
	Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessage_m3305852972,
	Component_t21088299_CustomAttributesCacheGenerator_Component_SendMessage_m872975486,
	Component_t21088299_CustomAttributesCacheGenerator_Component_BroadcastMessage_m3258471174,
	Component_t21088299_CustomAttributesCacheGenerator_Component_BroadcastMessage_m3258471174____parameter1,
	Component_t21088299_CustomAttributesCacheGenerator_Component_BroadcastMessage_m3258471174____options2,
	Component_t21088299_CustomAttributesCacheGenerator_Component_BroadcastMessage_m2127138074,
	Component_t21088299_CustomAttributesCacheGenerator_Component_BroadcastMessage_m1539754661,
	CullingGroup_t3411111508_CustomAttributesCacheGenerator_CullingGroup_Dispose_m1171631894,
	CullingGroup_t3411111508_CustomAttributesCacheGenerator_CullingGroup_SendEvents_m2564931990,
	CullingGroup_t3411111508_CustomAttributesCacheGenerator_CullingGroup_FinalizerFailure_m2017674841,
	DebugLogHandler_t1263485877_CustomAttributesCacheGenerator_DebugLogHandler_Internal_Log_m2703551542,
	DebugLogHandler_t1263485877_CustomAttributesCacheGenerator_DebugLogHandler_Internal_Log_m2703551542____obj2,
	DebugLogHandler_t1263485877_CustomAttributesCacheGenerator_DebugLogHandler_LogFormat_m4019243538____args3,
	Display_t289224223_CustomAttributesCacheGenerator,
	Display_t289224223_CustomAttributesCacheGenerator_onDisplaysUpdated,
	Display_t289224223_CustomAttributesCacheGenerator_Display_RecreateDisplayList_m1233426626,
	Display_t289224223_CustomAttributesCacheGenerator_Display_FireDisplaysUpdated_m2028285549,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponent_m2381985773,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponent_m2317715085,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponentInChildren_m1168178952,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponentInParent_m576974860,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponentsInChildren_m544289345____includeInactive1,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponentsInParent_m3716665394____includeInactive1,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_GetComponentsInternal_m3558330862,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_get_transform_m3351892996,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_SetActive_m924703582,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_get_tag_m3253026982,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_set_tag_m2601144065,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_CompareTag_m4047912073,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_FindGameObjectWithTag_m3016707382,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_SendMessage_m1793137815,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_SendMessage_m1793137815____value1,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_SendMessage_m1793137815____options2,
	GameObject_t2602266141_CustomAttributesCacheGenerator_GameObject_Find_m357843493,
	Gradient_t19391121_CustomAttributesCacheGenerator,
	Gradient_t19391121_CustomAttributesCacheGenerator_Gradient__ctor_m3449608876,
	Gradient_t19391121_CustomAttributesCacheGenerator_Gradient_Init_m665431756,
	Gradient_t19391121_CustomAttributesCacheGenerator_Gradient_Cleanup_m3762357176,
	GUIElement_t2816691599_CustomAttributesCacheGenerator,
	GUILayer_t3734926407_CustomAttributesCacheGenerator,
	GUILayer_t3734926407_CustomAttributesCacheGenerator_GUILayer_INTERNAL_CALL_HitTest_m169839011,
	Input_t1429468892_CustomAttributesCacheGenerator_Input_GetKeyDownInt_m634892559,
	Input_t1429468892_CustomAttributesCacheGenerator_Input_GetAxis_m1666418521,
	Input_t1429468892_CustomAttributesCacheGenerator_Input_GetMouseButton_m3485621271,
	Input_t1429468892_CustomAttributesCacheGenerator_Input_GetMouseButtonDown_m3468031552,
	Input_t1429468892_CustomAttributesCacheGenerator_Input_INTERNAL_get_mousePosition_m2607797593,
	Vector3_t2987449647_CustomAttributesCacheGenerator,
	Quaternion_t895809378_CustomAttributesCacheGenerator,
	Quaternion_t895809378_CustomAttributesCacheGenerator_Quaternion_INTERNAL_CALL_Inverse_m2122284289,
	Quaternion_t895809378_CustomAttributesCacheGenerator_Quaternion_INTERNAL_CALL_Internal_FromEulerRad_m1158394978,
	Bounds_t1424290876_CustomAttributesCacheGenerator,
	Keyframe_t1047575712_CustomAttributesCacheGenerator,
	AnimationCurve_t2995615556_CustomAttributesCacheGenerator,
	AnimationCurve_t2995615556_CustomAttributesCacheGenerator_AnimationCurve__ctor_m1256678767____keys0,
	AnimationCurve_t2995615556_CustomAttributesCacheGenerator_AnimationCurve__ctor_m3546708367,
	AnimationCurve_t2995615556_CustomAttributesCacheGenerator_AnimationCurve_Cleanup_m870304867,
	AnimationCurve_t2995615556_CustomAttributesCacheGenerator_AnimationCurve_Init_m2288700569,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_Internal_CancelInvokeAll_m134567439,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_Internal_IsInvokingAll_m2498687012,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_Invoke_m1445658415,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_InvokeRepeating_m1711920500,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_CancelInvoke_m3804726668,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_IsInvoking_m878787515,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_Auto_m597942758,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_Auto_Internal_m1203968900,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_m1532927778,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_m1532927778____value1,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_m2151747079,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StopCoroutine_m2372275704,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StopCoroutineViaEnumerator_Auto_m2517862605,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StopCoroutine_Auto_m1706763131,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_StopAllCoroutines_m3012207369,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_get_useGUILayout_m14506679,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_set_useGUILayout_m3498661562,
	MonoBehaviour_t244116357_CustomAttributesCacheGenerator_MonoBehaviour_GetScriptClassName_m574979679,
	ResourceRequest_t2922114009_CustomAttributesCacheGenerator,
	Resources_t428789352_CustomAttributesCacheGenerator_Resources_Load_m3111310461,
	Texture_t3041836855_CustomAttributesCacheGenerator,
	RenderTexture_t682290025_CustomAttributesCacheGenerator,
	Time_t2376931198_CustomAttributesCacheGenerator_Time_get_deltaTime_m3885432000,
	HideFlags_t1270484704_CustomAttributesCacheGenerator,
	Object_t3267094820_CustomAttributesCacheGenerator,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_Internal_CloneSingle_m1112466195,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_Internal_CloneSingleWithParent_m1578544937,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_INTERNAL_CALL_Internal_InstantiateSingle_m2354361480,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_INTERNAL_CALL_Internal_InstantiateSingleWithParent_m3351340621,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_GetOffsetOfInstanceIDInCPlusPlusObject_m2289052263,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_EnsureRunningOnMainThread_m2181426889,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_Destroy_m763870395,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_Destroy_m763870395____t1,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_Destroy_m2578737452,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyImmediate_m3667352557,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyImmediate_m3667352557____allowDestroyingAssets1,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyImmediate_m3664569503,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_FindObjectsOfType_m4065607311,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_get_name_m4131808298,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_set_name_m1574609734,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_DontDestroyOnLoad_m3006908952,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_get_hideFlags_m606243072,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_set_hideFlags_m1764873955,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyObject_m3415511966,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyObject_m3415511966____t1,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_DestroyObject_m4157767402,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_FindSceneObjectsOfType_m1789838274,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_FindObjectsOfTypeIncludingAssets_m2898151650,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_ToString_m1543712694,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_DoesObjectWithInstanceIDExist_m249218142,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_GetInstanceID_m2901521971,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_Instantiate_m3626274236,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_Instantiate_m499133587,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_Instantiate_m2255325978,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_Instantiate_m1560403475,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_Instantiate_m2568982308,
	Object_t3267094820_CustomAttributesCacheGenerator_Object_FindObjectOfType_m1934888875,
	YieldInstruction_t2994650433_CustomAttributesCacheGenerator,
	PlayableHandle_t2910061178_CustomAttributesCacheGenerator,
	PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_IsValidInternal_m2904663435,
	PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_GetPlayableTypeOf_m1882865113,
	PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_GetPlayStateInternal_m79066241,
	PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_SetPlayStateInternal_m3501090634,
	PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_SetTimeInternal_m207615318,
	PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_SetDurationInternal_m2581365362,
	PlayableHandle_t2910061178_CustomAttributesCacheGenerator_PlayableHandle_INTERNAL_CALL_SetInputCountInternal_m4151268303,
	Playable_t3436777522_CustomAttributesCacheGenerator,
	PlayableGraph_t4192197450_CustomAttributesCacheGenerator,
	PlayableGraph_t4192197450_CustomAttributesCacheGenerator_PlayableGraph_INTERNAL_CALL_CreateScriptOutputInternal_m2263530833,
	PlayableGraph_t4192197450_CustomAttributesCacheGenerator_PlayableGraph_INTERNAL_CALL_CreatePlayableHandleInternal_m848171998,
	PlayableOutputHandle_t4210482917_CustomAttributesCacheGenerator,
	PlayableOutputHandle_t4210482917_CustomAttributesCacheGenerator_PlayableOutputHandle_INTERNAL_CALL_IsValidInternal_m2309803248,
	PlayableOutputHandle_t4210482917_CustomAttributesCacheGenerator_PlayableOutputHandle_INTERNAL_CALL_GetPlayableOutputTypeOf_m4071527298,
	PlayableOutput_t758663699_CustomAttributesCacheGenerator,
	SceneManager_t2350656246_CustomAttributesCacheGenerator,
	SceneManager_t2350656246_CustomAttributesCacheGenerator_sceneLoaded,
	SceneManager_t2350656246_CustomAttributesCacheGenerator_sceneUnloaded,
	SceneManager_t2350656246_CustomAttributesCacheGenerator_activeSceneChanged,
	SceneManager_t2350656246_CustomAttributesCacheGenerator_SceneManager_Internal_SceneLoaded_m4213089961,
	SceneManager_t2350656246_CustomAttributesCacheGenerator_SceneManager_Internal_SceneUnloaded_m4274988325,
	SceneManager_t2350656246_CustomAttributesCacheGenerator_SceneManager_Internal_ActiveSceneChanged_m237859709,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_get_position_m2271944548,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_set_position_m2678488908,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_get_rotation_m3993959474,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_set_rotation_m3387907152,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_get_localRotation_m420822815,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_INTERNAL_set_localRotation_m365960821,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_Rotate_m2953437478____relativeTo1,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_Rotate_m1099066500,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_Rotate_m678397658____relativeTo3,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_get_childCount_m4116705935,
	Transform_t2636691836_CustomAttributesCacheGenerator_Transform_GetChild_m1662106098,
	RectTransform_t243927805_CustomAttributesCacheGenerator,
	RectTransform_t243927805_CustomAttributesCacheGenerator_reapplyDrivenProperties,
	RectTransform_t243927805_CustomAttributesCacheGenerator_RectTransform_SendReapplyDrivenProperties_m1673235392,
	SpriteAtlasManager_t485087596_CustomAttributesCacheGenerator_atlasRequested,
	SpriteAtlasManager_t485087596_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0,
	SpriteAtlasManager_t485087596_CustomAttributesCacheGenerator_SpriteAtlasManager_RequestAtlas_m351979735,
	SpriteAtlasManager_t485087596_CustomAttributesCacheGenerator_SpriteAtlasManager_Register_m3968478932,
	ControllerColliderHit_t3057575995_CustomAttributesCacheGenerator,
	Collision_t1992409213_CustomAttributesCacheGenerator,
	Collision_t1992409213_CustomAttributesCacheGenerator_Collision_t1992409213____impactForceSum_PropertyInfo,
	Collision_t1992409213_CustomAttributesCacheGenerator_Collision_t1992409213____frictionForceSum_PropertyInfo,
	Collision_t1992409213_CustomAttributesCacheGenerator_Collision_t1992409213____other_PropertyInfo,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3719768030,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2350840452,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m913384994,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3873687999____maxDistance2,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3873687999____layerMask3,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3873687999____queryTriggerInteraction4,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3877441014,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3826659266,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2170746783,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2445896246____maxDistance3,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2445896246____layerMask4,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2445896246____queryTriggerInteraction5,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2802259901,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m2419782515,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3871305434,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3013423287____maxDistance1,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3013423287____layerMask2,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3013423287____queryTriggerInteraction3,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3076132749,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m1510999213,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m54040585,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3887300606____maxDistance2,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3887300606____layerMask3,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_Raycast_m3887300606____queryTriggerInteraction4,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m3686607343,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m2500737461,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m4120885497,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m1735216570____maxDistance1,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m1735216570____layerMask2,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m1735216570____queryTriggerInteraction3,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m2296021024____maxDistance2,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m2296021024____layermask3,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m2296021024____queryTriggerInteraction4,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m1144311404,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m98091116,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_RaycastAll_m1515184189,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_INTERNAL_CALL_RaycastAll_m3201440179,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_INTERNAL_CALL_Internal_Raycast_m2853825113,
	Physics_t3588812769_CustomAttributesCacheGenerator_Physics_INTERNAL_CALL_Internal_RaycastTest_m3339338234,
	ContactPoint_t3765348581_CustomAttributesCacheGenerator,
	Rigidbody_t3670484383_CustomAttributesCacheGenerator,
	Rigidbody_t3670484383_CustomAttributesCacheGenerator_Rigidbody_INTERNAL_set_velocity_m36759112,
	Rigidbody_t3670484383_CustomAttributesCacheGenerator_Rigidbody_get_isKinematic_m3289074417,
	Rigidbody_t3670484383_CustomAttributesCacheGenerator_Rigidbody_set_isKinematic_m3808468253,
	Rigidbody_t3670484383_CustomAttributesCacheGenerator_Rigidbody_set_constraints_m1675396742,
	Collider_t3066580567_CustomAttributesCacheGenerator,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_enabled_m1012249734,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_set_enabled_m3023772319,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_attachedRigidbody_m1223649037,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_isTrigger_m3411014092,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_set_isTrigger_m3915953166,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_contactOffset_m2439063487,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_set_contactOffset_m683432949,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_material_m1577688535,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_set_material_m1981090199,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_INTERNAL_CALL_ClosestPointOnBounds_m983298871,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_INTERNAL_CALL_ClosestPoint_m1905885810,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_get_sharedMaterial_m3186711189,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_set_sharedMaterial_m378738133,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_INTERNAL_get_bounds_m924372968,
	Collider_t3066580567_CustomAttributesCacheGenerator_Collider_INTERNAL_CALL_Internal_Raycast_m935082044,
	BoxCollider_t1526745396_CustomAttributesCacheGenerator,
	BoxCollider_t1526745396_CustomAttributesCacheGenerator_BoxCollider_INTERNAL_get_center_m2108458525,
	BoxCollider_t1526745396_CustomAttributesCacheGenerator_BoxCollider_INTERNAL_set_center_m1608300232,
	BoxCollider_t1526745396_CustomAttributesCacheGenerator_BoxCollider_INTERNAL_get_size_m2915107625,
	BoxCollider_t1526745396_CustomAttributesCacheGenerator_BoxCollider_INTERNAL_set_size_m1069292286,
	BoxCollider_t1526745396_CustomAttributesCacheGenerator_BoxCollider_t1526745396____extents_PropertyInfo,
	SphereCollider_t4124484268_CustomAttributesCacheGenerator,
	SphereCollider_t4124484268_CustomAttributesCacheGenerator_SphereCollider_INTERNAL_get_center_m3462447041,
	SphereCollider_t4124484268_CustomAttributesCacheGenerator_SphereCollider_INTERNAL_set_center_m3242641947,
	SphereCollider_t4124484268_CustomAttributesCacheGenerator_SphereCollider_get_radius_m1946668759,
	SphereCollider_t4124484268_CustomAttributesCacheGenerator_SphereCollider_set_radius_m2008006599,
	MeshCollider_t3573562696_CustomAttributesCacheGenerator,
	MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_get_sharedMesh_m3981733887,
	MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_set_sharedMesh_m1749649964,
	MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_get_convex_m3624458602,
	MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_set_convex_m3852711973,
	MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_get_inflateMesh_m3117051985,
	MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_set_inflateMesh_m3536367144,
	MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_get_skinWidth_m4113017802,
	MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_set_skinWidth_m480533321,
	MeshCollider_t3573562696_CustomAttributesCacheGenerator_MeshCollider_t3573562696____smoothSphereCollisions_PropertyInfo,
	CapsuleCollider_t4114432674_CustomAttributesCacheGenerator,
	CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_INTERNAL_get_center_m343696755,
	CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_INTERNAL_set_center_m2335165673,
	CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_get_radius_m4172507562,
	CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_set_radius_m762145652,
	CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_get_height_m3662458997,
	CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_set_height_m2754457501,
	CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_get_direction_m2169980597,
	CapsuleCollider_t4114432674_CustomAttributesCacheGenerator_CapsuleCollider_set_direction_m3664861627,
	RaycastHit_t2786726017_CustomAttributesCacheGenerator,
	CharacterController_t2965295687_CustomAttributesCacheGenerator_CharacterController_INTERNAL_CALL_Move_m2501923996,
	CharacterController_t2965295687_CustomAttributesCacheGenerator_CharacterController_get_isGrounded_m3015943198,
	AudioPlayableOutput_t2616039667_CustomAttributesCacheGenerator,
	AudioPlayableOutput_t2616039667_CustomAttributesCacheGenerator_AudioPlayableOutput_INTERNAL_CALL_InternalGetTarget_m3249422738,
	AudioPlayableOutput_t2616039667_CustomAttributesCacheGenerator_AudioPlayableOutput_INTERNAL_CALL_InternalSetTarget_m3185628123,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_GetClipInternal_m317731256,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_SetClipInternal_m1813683739,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_GetLoopedInternal_m3132985087,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_SetLoopedInternal_m3163919323,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_GetIsPlayingInternal_m3248130146,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_GetStartDelayInternal_m1864145844,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_SetStartDelayInternal_m3452625175,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_GetPauseDelayInternal_m4032398432,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_SetPauseDelayInternal_m234566193,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_InternalCreateAudioClipPlayable_m496825388,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_INTERNAL_CALL_ValidateType_m2412648730,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_Seek_m1537206734,
	AudioClipPlayable_t3295732336_CustomAttributesCacheGenerator_AudioClipPlayable_Seek_m743928150____duration2,
	AudioMixerPlayable_t3345238233_CustomAttributesCacheGenerator,
	AudioMixerPlayable_t3345238233_CustomAttributesCacheGenerator_AudioMixerPlayable_INTERNAL_CALL_GetAutoNormalizeInternal_m2057364040,
	AudioMixerPlayable_t3345238233_CustomAttributesCacheGenerator_AudioMixerPlayable_INTERNAL_CALL_SetAutoNormalizeInternal_m987980948,
	AudioMixerPlayable_t3345238233_CustomAttributesCacheGenerator_AudioMixerPlayable_INTERNAL_CALL_CreateAudioMixerPlayableInternal_m290331118,
	AudioSettings_t668402879_CustomAttributesCacheGenerator_OnAudioConfigurationChanged,
	AudioSettings_t668402879_CustomAttributesCacheGenerator_AudioSettings_InvokeOnAudioConfigurationChanged_m61046006,
	AudioClip_t1031729136_CustomAttributesCacheGenerator_m_PCMReaderCallback,
	AudioClip_t1031729136_CustomAttributesCacheGenerator_m_PCMSetPositionCallback,
	AudioClip_t1031729136_CustomAttributesCacheGenerator_AudioClip_get_length_m2904044266,
	AudioClip_t1031729136_CustomAttributesCacheGenerator_AudioClip_InvokePCMReaderCallback_Internal_m3969674143,
	AudioClip_t1031729136_CustomAttributesCacheGenerator_AudioClip_InvokePCMSetPositionCallback_Internal_m4230058079,
	AudioSource_t3205450310_CustomAttributesCacheGenerator,
	AudioPlayableGraphExtensions_t1250035765_CustomAttributesCacheGenerator_AudioPlayableGraphExtensions_INTERNAL_CALL_InternalCreateAudioOutput_m2119112406,
	Font_t208834271_CustomAttributesCacheGenerator_textureRebuilt,
	Font_t208834271_CustomAttributesCacheGenerator_m_FontTextureRebuildCallback,
	Font_t208834271_CustomAttributesCacheGenerator_Font_InvokeTextureRebuilt_Internal_m3404887950,
	FontTextureRebuildCallback_t940970719_CustomAttributesCacheGenerator,
	WebRequestUtils_t248386542_CustomAttributesCacheGenerator_WebRequestUtils_RedirectTo_m1519057860,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_InternalCreate_m880206285,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_InternalDestroy_m2519008968,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddString_m659451336,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddBool_m398788015,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddChar_m319900760,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddByte_m3717748694,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddSByte_m3340687799,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddInt16_m1608076704,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddUInt16_m204323820,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddInt32_m779198032,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddUInt32_m2154319333,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddInt64_m3524891666,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddUInt64_m2735082319,
	CustomEventData_t4212110146_CustomAttributesCacheGenerator_CustomEventData_AddDouble_m1124663272,
	UnityAnalyticsHandler_t627637005_CustomAttributesCacheGenerator_UnityAnalyticsHandler_InternalCreate_m2671862836,
	UnityAnalyticsHandler_t627637005_CustomAttributesCacheGenerator_UnityAnalyticsHandler_InternalDestroy_m304093635,
	UnityAnalyticsHandler_t627637005_CustomAttributesCacheGenerator_UnityAnalyticsHandler_SendCustomEventName_m3481945465,
	UnityAnalyticsHandler_t627637005_CustomAttributesCacheGenerator_UnityAnalyticsHandler_SendCustomEvent_m3074734922,
	RemoteSettings_t2880773625_CustomAttributesCacheGenerator_Updated,
	RemoteSettings_t2880773625_CustomAttributesCacheGenerator_RemoteSettings_CallOnUpdate_m3230028317,
	AttributeHelperEngine_t1985212046_CustomAttributesCacheGenerator_AttributeHelperEngine_GetParentTypeDisallowingMultipleInclusion_m4119152402,
	AttributeHelperEngine_t1985212046_CustomAttributesCacheGenerator_AttributeHelperEngine_GetRequiredComponents_m942683377,
	AttributeHelperEngine_t1985212046_CustomAttributesCacheGenerator_AttributeHelperEngine_CheckIsEditorScript_m4061418281,
	AttributeHelperEngine_t1985212046_CustomAttributesCacheGenerator_AttributeHelperEngine_GetDefaultExecutionOrderFor_m3266095226,
	DisallowMultipleComponent_t1571297057_CustomAttributesCacheGenerator,
	RequireComponent_t2231837482_CustomAttributesCacheGenerator,
	ContextMenu_t1432722795_CustomAttributesCacheGenerator,
	DefaultExecutionOrder_t1687762308_CustomAttributesCacheGenerator,
	DefaultExecutionOrder_t1687762308_CustomAttributesCacheGenerator_U3CorderU3Ek__BackingField,
	DefaultExecutionOrder_t1687762308_CustomAttributesCacheGenerator_DefaultExecutionOrder_get_order_m3764018895,
	NativeClassAttribute_t3768029985_CustomAttributesCacheGenerator,
	NativeClassAttribute_t3768029985_CustomAttributesCacheGenerator_U3CQualifiedNativeNameU3Ek__BackingField,
	NativeClassAttribute_t3768029985_CustomAttributesCacheGenerator_NativeClassAttribute_set_QualifiedNativeName_m293935591,
	AssemblyIsEditorAssembly_t1075301690_CustomAttributesCacheGenerator,
	WritableAttribute_t718555548_CustomAttributesCacheGenerator,
	ClassLibraryInitializer_t1120328420_CustomAttributesCacheGenerator_ClassLibraryInitializer_Init_m678390546,
	SetupCoroutine_t928779329_CustomAttributesCacheGenerator,
	SetupCoroutine_t928779329_CustomAttributesCacheGenerator_SetupCoroutine_InvokeMoveNext_m2573614623,
	SetupCoroutine_t928779329_CustomAttributesCacheGenerator_SetupCoroutine_InvokeMember_m3217874590,
	SendMouseEvents_t2250526872_CustomAttributesCacheGenerator_SendMouseEvents_SetMouseMoved_m1615166369,
	SendMouseEvents_t2250526872_CustomAttributesCacheGenerator_SendMouseEvents_DoSendMouseEvents_m1673877171,
	Rect_t1940963286_CustomAttributesCacheGenerator,
	SerializePrivateVariables_t2211538169_CustomAttributesCacheGenerator,
	SerializeField_t1114448220_CustomAttributesCacheGenerator,
	PreferBinarySerialization_t3164250034_CustomAttributesCacheGenerator,
	ISerializationCallbackReceiver_t3652988088_CustomAttributesCacheGenerator,
	StackTraceUtility_t599648129_CustomAttributesCacheGenerator_StackTraceUtility_SetProjectFolder_m2868605785,
	StackTraceUtility_t599648129_CustomAttributesCacheGenerator_StackTraceUtility_ExtractStackTrace_m1508434409,
	StackTraceUtility_t599648129_CustomAttributesCacheGenerator_StackTraceUtility_ExtractStringFromExceptionInternal_m3206191879,
	StackTraceUtility_t599648129_CustomAttributesCacheGenerator_StackTraceUtility_PostprocessStacktrace_m8392584,
	StackTraceUtility_t599648129_CustomAttributesCacheGenerator_StackTraceUtility_ExtractFormattedStackTrace_m2968975606,
	UnityException_t4124781955_CustomAttributesCacheGenerator,
	ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_ObjectArgument,
	ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_ObjectArgumentAssemblyTypeName,
	ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_IntArgument,
	ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_FloatArgument,
	ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_StringArgument,
	ArgumentCache_t1174943143_CustomAttributesCacheGenerator_m_BoolArgument,
	InvokableCall_t2172723502_CustomAttributesCacheGenerator_Delegate,
	InvokableCall_1_t3068523820_CustomAttributesCacheGenerator_Delegate,
	InvokableCall_2_t4124072994_CustomAttributesCacheGenerator_Delegate,
	InvokableCall_3_t442739363_CustomAttributesCacheGenerator_Delegate,
	InvokableCall_4_t3127597954_CustomAttributesCacheGenerator_Delegate,
	PersistentCall_t183227066_CustomAttributesCacheGenerator_m_Target,
	PersistentCall_t183227066_CustomAttributesCacheGenerator_m_MethodName,
	PersistentCall_t183227066_CustomAttributesCacheGenerator_m_Mode,
	PersistentCall_t183227066_CustomAttributesCacheGenerator_m_Arguments,
	PersistentCall_t183227066_CustomAttributesCacheGenerator_m_CallState,
	PersistentCallGroup_t2134068398_CustomAttributesCacheGenerator_m_Calls,
	UnityEventBase_t376746665_CustomAttributesCacheGenerator,
	UnityEventBase_t376746665_CustomAttributesCacheGenerator_m_PersistentCalls,
	UnityEventBase_t376746665_CustomAttributesCacheGenerator_m_TypeName,
	UnityEvent_t2494002768_CustomAttributesCacheGenerator_UnityEvent__ctor_m709418737,
	UnityEvent_1_t664801528_CustomAttributesCacheGenerator_UnityEvent_1__ctor_m2467552359,
	UnityEvent_2_t3195527707_CustomAttributesCacheGenerator_UnityEvent_2__ctor_m2346106316,
	UnityEvent_3_t180400136_CustomAttributesCacheGenerator_UnityEvent_3__ctor_m3575999384,
	UnityEvent_4_t316486966_CustomAttributesCacheGenerator_UnityEvent_4__ctor_m4217751038,
	UnityString_t2277233379_CustomAttributesCacheGenerator_UnityString_Format_m2073054251____args1,
	UnitySynchronizationContext_t3084095346_CustomAttributesCacheGenerator_UnitySynchronizationContext_InitializeSynchronizationContext_m3655849499,
	UnitySynchronizationContext_t3084095346_CustomAttributesCacheGenerator_UnitySynchronizationContext_ExecuteTasks_m691963302,
	Vector2_t218349997_CustomAttributesCacheGenerator,
	ReadOnlyAttribute_t1337101784_CustomAttributesCacheGenerator,
	ReadWriteAttribute_t2837879318_CustomAttributesCacheGenerator,
	WriteOnlyAttribute_t1401990839_CustomAttributesCacheGenerator,
	DeallocateOnJobCompletionAttribute_t609863456_CustomAttributesCacheGenerator,
	NativeContainerAttribute_t4143237321_CustomAttributesCacheGenerator,
	NativeContainerSupportsAtomicWriteAttribute_t2543072026_CustomAttributesCacheGenerator,
	NativeContainerSupportsMinMaxWriteRestrictionAttribute_t1739138553_CustomAttributesCacheGenerator,
	Flags_t704280897_CustomAttributesCacheGenerator,
	PlayableBinding_t2470704133_CustomAttributesCacheGenerator_U3CstreamNameU3Ek__BackingField,
	PlayableBinding_t2470704133_CustomAttributesCacheGenerator_U3CstreamTypeU3Ek__BackingField,
	PlayableBinding_t2470704133_CustomAttributesCacheGenerator_U3CsourceObjectU3Ek__BackingField,
	PlayableBinding_t2470704133_CustomAttributesCacheGenerator_U3CsourceBindingTypeU3Ek__BackingField,
	PlayableAsset_t2455377621_CustomAttributesCacheGenerator,
	PlayableAsset_t2455377621_CustomAttributesCacheGenerator_PlayableAsset_Internal_CreatePlayable_m3902392072,
	PlayableAsset_t2455377621_CustomAttributesCacheGenerator_PlayableAsset_Internal_GetPlayableAssetDuration_m614503739,
	PlayableBehaviour_t4141050374_CustomAttributesCacheGenerator,
	PlayableExtensions_t2708217748_CustomAttributesCacheGenerator,
	PlayableExtensions_t2708217748_CustomAttributesCacheGenerator_PlayableExtensions_SetDuration_m3868156131,
	PlayableExtensions_t2708217748_CustomAttributesCacheGenerator_PlayableExtensions_SetInputCount_m410715386,
	ScriptPlayableOutput_t2716968363_CustomAttributesCacheGenerator,
	DefaultValueAttribute_t1239497132_CustomAttributesCacheGenerator,
	ILogHandler_t4045690940_CustomAttributesCacheGenerator_ILogHandler_LogFormat_m41519313____args3,
	Logger_t475186510_CustomAttributesCacheGenerator_U3ClogHandlerU3Ek__BackingField,
	Logger_t475186510_CustomAttributesCacheGenerator_U3ClogEnabledU3Ek__BackingField,
	Logger_t475186510_CustomAttributesCacheGenerator_U3CfilterLogTypeU3Ek__BackingField,
	Logger_t475186510_CustomAttributesCacheGenerator_Logger_get_logHandler_m1001975644,
	Logger_t475186510_CustomAttributesCacheGenerator_Logger_set_logHandler_m4221272157,
	Logger_t475186510_CustomAttributesCacheGenerator_Logger_get_logEnabled_m1878659891,
	Logger_t475186510_CustomAttributesCacheGenerator_Logger_set_logEnabled_m771198447,
	Logger_t475186510_CustomAttributesCacheGenerator_Logger_get_filterLogType_m3099848982,
	Logger_t475186510_CustomAttributesCacheGenerator_Logger_set_filterLogType_m602084239,
	Logger_t475186510_CustomAttributesCacheGenerator_Logger_LogFormat_m2728955062____args3,
	PlayerConnection_t1218065583_CustomAttributesCacheGenerator_m_PlayerEditorConnectionEvents,
	PlayerConnection_t1218065583_CustomAttributesCacheGenerator_m_connectedPlayers,
	PlayerConnection_t1218065583_CustomAttributesCacheGenerator_PlayerConnection_MessageCallbackInternal_m2888194805,
	PlayerConnection_t1218065583_CustomAttributesCacheGenerator_PlayerConnection_ConnectedCallbackInternal_m989124288,
	PlayerConnection_t1218065583_CustomAttributesCacheGenerator_PlayerConnection_DisconnectedCallback_m571541410,
	PlayerEditorConnectionEvents_t628309064_CustomAttributesCacheGenerator_messageTypeSubscribers,
	PlayerEditorConnectionEvents_t628309064_CustomAttributesCacheGenerator_connectionEvent,
	PlayerEditorConnectionEvents_t628309064_CustomAttributesCacheGenerator_disconnectionEvent,
	MessageTypeSubscribers_t4164304980_CustomAttributesCacheGenerator_m_messageTypeId,
	U3CInvokeMessageIdSubscribersU3Ec__AnonStorey0_t3627662667_CustomAttributesCacheGenerator,
	RenderPipelineManager_t1144978979_CustomAttributesCacheGenerator_U3CcurrentPipelineU3Ek__BackingField,
	RenderPipelineManager_t1144978979_CustomAttributesCacheGenerator_RenderPipelineManager_get_currentPipeline_m3200673172,
	RenderPipelineManager_t1144978979_CustomAttributesCacheGenerator_RenderPipelineManager_set_currentPipeline_m1673100204,
	RenderPipelineManager_t1144978979_CustomAttributesCacheGenerator_RenderPipelineManager_CleanupRenderPipeline_m3163400220,
	RenderPipelineManager_t1144978979_CustomAttributesCacheGenerator_RenderPipelineManager_DoRenderLoop_Internal_m2060351888,
	UsedByNativeCodeAttribute_t2042968054_CustomAttributesCacheGenerator,
	RequiredByNativeCodeAttribute_t2920332526_CustomAttributesCacheGenerator,
	FormerlySerializedAsAttribute_t153867989_CustomAttributesCacheGenerator,
	TypeInferenceRuleAttribute_t1237727610_CustomAttributesCacheGenerator,
	NetFxCoreExtensions_t1693540765_CustomAttributesCacheGenerator,
	NetFxCoreExtensions_t1693540765_CustomAttributesCacheGenerator_NetFxCoreExtensions_CreateDelegate_m1280007241,
	CSSMeasureFunc_t2981734212_CustomAttributesCacheGenerator,
	Native_t2140029580_CustomAttributesCacheGenerator_Native_CSSNodeMeasureInvoke_m215891493,
	g_UnityEngine_Analytics_Assembly_CustomAttributesCacheGenerator,
	AnalyticsTracker_t2726437861_CustomAttributesCacheGenerator,
	AnalyticsTracker_t2726437861_CustomAttributesCacheGenerator_m_EventName,
	AnalyticsTracker_t2726437861_CustomAttributesCacheGenerator_m_TrackableProperty,
	AnalyticsTracker_t2726437861_CustomAttributesCacheGenerator_m_Trigger,
	TrackableProperty_t4178984293_CustomAttributesCacheGenerator_m_Fields,
	FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_ParamName,
	FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_Target,
	FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_FieldPath,
	FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_TypeString,
	FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_DoStatic,
	FieldWithTarget_t2257325677_CustomAttributesCacheGenerator_m_StaticString,
	g_AssemblyU2DCSharp_Assembly_CustomAttributesCacheGenerator,
};
