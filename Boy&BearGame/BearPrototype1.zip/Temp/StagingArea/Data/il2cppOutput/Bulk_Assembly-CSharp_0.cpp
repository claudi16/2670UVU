﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "object-internals.h"

// BoxTrigger
struct BoxTrigger_t730900964;
// UnityEngine.MonoBehaviour
struct MonoBehaviour_t244116357;
// UnityEngine.GameObject
struct GameObject_t2602266141;
// System.String
struct String_t;
// UnityEngine.Collider
struct Collider_t3066580567;
// UnityEngine.Object
struct Object_t3267094820;
// UnityEngine.Transform
struct Transform_t2636691836;
// CameraScript
struct CameraScript_t2676235949;
// UnityEngine.Component
struct Component_t21088299;
// FlipCharacter
struct FlipCharacter_t1403884062;
// System.Action`1<System.Single>
struct Action_1_t2117217084;
// System.Delegate
struct Delegate_t2990640460;
// LedgeTrigger
struct LedgeTrigger_t2111245965;
// UnityEngine.Rigidbody
struct Rigidbody_t3670484383;
// MoveCharacter
struct MoveCharacter_t2492455991;
// UnityEngine.CharacterController
struct CharacterController_t2965295687;
// System.Action
struct Action_t4042858631;
// MoveObject
struct MoveObject_t260185650;
// UnityEngine.ControllerColliderHit
struct ControllerColliderHit_t3057575995;
// PlatformTrigger
struct PlatformTrigger_t1464797062;
// System.Collections.IEnumerator
struct IEnumerator_t2340204891;
// PlayerInput
struct PlayerInput_t3450109778;
// PushObject
struct PushObject_t3539098884;
// System.Char[]
struct CharU5BU5D_t2816624037;
// System.Void
struct Void_t1421048318;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.DelegateData
struct DelegateData_t2320928782;
// System.IAsyncResult
struct IAsyncResult_t337009442;
// System.AsyncCallback
struct AsyncCallback_t3133502122;

extern Il2CppCodeGenString* _stringLiteral1083277759;
extern Il2CppCodeGenString* _stringLiteral1654921415;
extern const uint32_t BoxTrigger_Start_m1361771495_MetadataUsageId;
extern RuntimeClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3152098533;
extern Il2CppCodeGenString* _stringLiteral4197525387;
extern const uint32_t BoxTrigger_OnTriggerEnter_m1134727060_MetadataUsageId;
extern const uint32_t BoxTrigger_OnTriggerExit_m1026518603_MetadataUsageId;
extern RuntimeClass* Vector3_t2987449647_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral542685270;
extern const uint32_t CameraScript_Start_m70798908_MetadataUsageId;
extern const uint32_t CameraScript_LateUpdate_m3780720276_MetadataUsageId;
extern RuntimeClass* PlayerInput_t3450109778_il2cpp_TypeInfo_var;
extern RuntimeClass* Action_1_t2117217084_il2cpp_TypeInfo_var;
extern const RuntimeMethod* FlipCharacter_Flip_m936201690_RuntimeMethod_var;
extern const RuntimeMethod* Action_1__ctor_m3685619994_RuntimeMethod_var;
extern const uint32_t FlipCharacter_Start_m1352720864_MetadataUsageId;
extern const RuntimeMethod* GameObject_GetComponent_TisRigidbody_t3670484383_m3822479057_RuntimeMethod_var;
extern Il2CppCodeGenString* _stringLiteral79956717;
extern const uint32_t LedgeTrigger_Start_m3492426325_MetadataUsageId;
extern const uint32_t LedgeTrigger_OnTriggerEnter_m4103365985_MetadataUsageId;
extern RuntimeClass* Action_t4042858631_il2cpp_TypeInfo_var;
extern const RuntimeMethod* Component_GetComponent_TisCharacterController_t2965295687_m2123869853_RuntimeMethod_var;
extern const RuntimeMethod* MoveCharacter_Move_m3498876582_RuntimeMethod_var;
extern const RuntimeMethod* MoveCharacter_Jump_m768547604_RuntimeMethod_var;
extern const uint32_t MoveCharacter_Start_m3159237758_MetadataUsageId;
extern RuntimeClass* Int32_t438220675_il2cpp_TypeInfo_var;
extern const uint32_t MoveCharacter_Jump_m768547604_MetadataUsageId;
extern RuntimeClass* Object_t3267094820_il2cpp_TypeInfo_var;
extern const uint32_t MoveObject_OnControllerColliderHit_m4083205808_MetadataUsageId;
extern Il2CppCodeGenString* _stringLiteral3502315773;
extern const uint32_t PlatformTrigger_Start_m434823051_MetadataUsageId;
extern RuntimeClass* IEnumerator_t2340204891_il2cpp_TypeInfo_var;
extern RuntimeClass* Transform_t2636691836_il2cpp_TypeInfo_var;
extern RuntimeClass* IDisposable_t1854990027_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1248389808;
extern const uint32_t PlatformTrigger_OnTriggerEnter_m1123801430_MetadataUsageId;
extern RuntimeClass* Input_t1429468892_il2cpp_TypeInfo_var;
extern const RuntimeMethod* Action_1_Invoke_m1323436125_RuntimeMethod_var;
extern Il2CppCodeGenString* _stringLiteral3687474370;
extern const uint32_t PlayerInput_Update_m1542141274_MetadataUsageId;
extern RuntimeClass* PushObject_t3539098884_il2cpp_TypeInfo_var;
extern const uint32_t PushObject_OnControllerColliderHit_m3319051333_MetadataUsageId;
extern const RuntimeMethod* Component_GetComponent_TisRigidbody_t3670484383_m1187311617_RuntimeMethod_var;
extern const uint32_t PushObject_test_m2222389076_MetadataUsageId;



#ifndef U3CMODULEU3E_T1452121116_H
#define U3CMODULEU3E_T1452121116_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t1452121116 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T1452121116_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
struct Il2CppArrayBounds;
#ifndef RUNTIMEARRAY_H
#define RUNTIMEARRAY_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Array

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEARRAY_H
#ifndef VALUETYPE_T3348802692_H
#define VALUETYPE_T3348802692_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t3348802692  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t3348802692_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t3348802692_marshaled_com
{
};
#endif // VALUETYPE_T3348802692_H
#ifndef STRING_T_H
#define STRING_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::length
	int32_t ___length_0;
	// System.Char System.String::start_char
	Il2CppChar ___start_char_1;

public:
	inline static int32_t get_offset_of_length_0() { return static_cast<int32_t>(offsetof(String_t, ___length_0)); }
	inline int32_t get_length_0() const { return ___length_0; }
	inline int32_t* get_address_of_length_0() { return &___length_0; }
	inline void set_length_0(int32_t value)
	{
		___length_0 = value;
	}

	inline static int32_t get_offset_of_start_char_1() { return static_cast<int32_t>(offsetof(String_t, ___start_char_1)); }
	inline Il2CppChar get_start_char_1() const { return ___start_char_1; }
	inline Il2CppChar* get_address_of_start_char_1() { return &___start_char_1; }
	inline void set_start_char_1(Il2CppChar value)
	{
		___start_char_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_2;
	// System.Char[] System.String::WhiteChars
	CharU5BU5D_t2816624037* ___WhiteChars_3;

public:
	inline static int32_t get_offset_of_Empty_2() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_2)); }
	inline String_t* get_Empty_2() const { return ___Empty_2; }
	inline String_t** get_address_of_Empty_2() { return &___Empty_2; }
	inline void set_Empty_2(String_t* value)
	{
		___Empty_2 = value;
		Il2CppCodeGenWriteBarrier((&___Empty_2), value);
	}

	inline static int32_t get_offset_of_WhiteChars_3() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___WhiteChars_3)); }
	inline CharU5BU5D_t2816624037* get_WhiteChars_3() const { return ___WhiteChars_3; }
	inline CharU5BU5D_t2816624037** get_address_of_WhiteChars_3() { return &___WhiteChars_3; }
	inline void set_WhiteChars_3(CharU5BU5D_t2816624037* value)
	{
		___WhiteChars_3 = value;
		Il2CppCodeGenWriteBarrier((&___WhiteChars_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRING_T_H
#ifndef INT32_T438220675_H
#define INT32_T438220675_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int32
struct  Int32_t438220675 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Int32_t438220675, ___m_value_2)); }
	inline int32_t get_m_value_2() const { return ___m_value_2; }
	inline int32_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(int32_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT32_T438220675_H
#ifndef QUATERNION_T895809378_H
#define QUATERNION_T895809378_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Quaternion
struct  Quaternion_t895809378 
{
public:
	// System.Single UnityEngine.Quaternion::x
	float ___x_0;
	// System.Single UnityEngine.Quaternion::y
	float ___y_1;
	// System.Single UnityEngine.Quaternion::z
	float ___z_2;
	// System.Single UnityEngine.Quaternion::w
	float ___w_3;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Quaternion_t895809378, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Quaternion_t895809378, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(Quaternion_t895809378, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}

	inline static int32_t get_offset_of_w_3() { return static_cast<int32_t>(offsetof(Quaternion_t895809378, ___w_3)); }
	inline float get_w_3() const { return ___w_3; }
	inline float* get_address_of_w_3() { return &___w_3; }
	inline void set_w_3(float value)
	{
		___w_3 = value;
	}
};

struct Quaternion_t895809378_StaticFields
{
public:
	// UnityEngine.Quaternion UnityEngine.Quaternion::identityQuaternion
	Quaternion_t895809378  ___identityQuaternion_4;

public:
	inline static int32_t get_offset_of_identityQuaternion_4() { return static_cast<int32_t>(offsetof(Quaternion_t895809378_StaticFields, ___identityQuaternion_4)); }
	inline Quaternion_t895809378  get_identityQuaternion_4() const { return ___identityQuaternion_4; }
	inline Quaternion_t895809378 * get_address_of_identityQuaternion_4() { return &___identityQuaternion_4; }
	inline void set_identityQuaternion_4(Quaternion_t895809378  value)
	{
		___identityQuaternion_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // QUATERNION_T895809378_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	IntPtr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline IntPtr_t get_Zero_1() const { return ___Zero_1; }
	inline IntPtr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(IntPtr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef VECTOR3_T2987449647_H
#define VECTOR3_T2987449647_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector3
struct  Vector3_t2987449647 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_1;
	// System.Single UnityEngine.Vector3::y
	float ___y_2;
	// System.Single UnityEngine.Vector3::z
	float ___z_3;

public:
	inline static int32_t get_offset_of_x_1() { return static_cast<int32_t>(offsetof(Vector3_t2987449647, ___x_1)); }
	inline float get_x_1() const { return ___x_1; }
	inline float* get_address_of_x_1() { return &___x_1; }
	inline void set_x_1(float value)
	{
		___x_1 = value;
	}

	inline static int32_t get_offset_of_y_2() { return static_cast<int32_t>(offsetof(Vector3_t2987449647, ___y_2)); }
	inline float get_y_2() const { return ___y_2; }
	inline float* get_address_of_y_2() { return &___y_2; }
	inline void set_y_2(float value)
	{
		___y_2 = value;
	}

	inline static int32_t get_offset_of_z_3() { return static_cast<int32_t>(offsetof(Vector3_t2987449647, ___z_3)); }
	inline float get_z_3() const { return ___z_3; }
	inline float* get_address_of_z_3() { return &___z_3; }
	inline void set_z_3(float value)
	{
		___z_3 = value;
	}
};

struct Vector3_t2987449647_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t2987449647  ___zeroVector_4;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t2987449647  ___oneVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t2987449647  ___upVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t2987449647  ___downVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t2987449647  ___leftVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t2987449647  ___rightVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t2987449647  ___forwardVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t2987449647  ___backVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t2987449647  ___positiveInfinityVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t2987449647  ___negativeInfinityVector_13;

public:
	inline static int32_t get_offset_of_zeroVector_4() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___zeroVector_4)); }
	inline Vector3_t2987449647  get_zeroVector_4() const { return ___zeroVector_4; }
	inline Vector3_t2987449647 * get_address_of_zeroVector_4() { return &___zeroVector_4; }
	inline void set_zeroVector_4(Vector3_t2987449647  value)
	{
		___zeroVector_4 = value;
	}

	inline static int32_t get_offset_of_oneVector_5() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___oneVector_5)); }
	inline Vector3_t2987449647  get_oneVector_5() const { return ___oneVector_5; }
	inline Vector3_t2987449647 * get_address_of_oneVector_5() { return &___oneVector_5; }
	inline void set_oneVector_5(Vector3_t2987449647  value)
	{
		___oneVector_5 = value;
	}

	inline static int32_t get_offset_of_upVector_6() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___upVector_6)); }
	inline Vector3_t2987449647  get_upVector_6() const { return ___upVector_6; }
	inline Vector3_t2987449647 * get_address_of_upVector_6() { return &___upVector_6; }
	inline void set_upVector_6(Vector3_t2987449647  value)
	{
		___upVector_6 = value;
	}

	inline static int32_t get_offset_of_downVector_7() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___downVector_7)); }
	inline Vector3_t2987449647  get_downVector_7() const { return ___downVector_7; }
	inline Vector3_t2987449647 * get_address_of_downVector_7() { return &___downVector_7; }
	inline void set_downVector_7(Vector3_t2987449647  value)
	{
		___downVector_7 = value;
	}

	inline static int32_t get_offset_of_leftVector_8() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___leftVector_8)); }
	inline Vector3_t2987449647  get_leftVector_8() const { return ___leftVector_8; }
	inline Vector3_t2987449647 * get_address_of_leftVector_8() { return &___leftVector_8; }
	inline void set_leftVector_8(Vector3_t2987449647  value)
	{
		___leftVector_8 = value;
	}

	inline static int32_t get_offset_of_rightVector_9() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___rightVector_9)); }
	inline Vector3_t2987449647  get_rightVector_9() const { return ___rightVector_9; }
	inline Vector3_t2987449647 * get_address_of_rightVector_9() { return &___rightVector_9; }
	inline void set_rightVector_9(Vector3_t2987449647  value)
	{
		___rightVector_9 = value;
	}

	inline static int32_t get_offset_of_forwardVector_10() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___forwardVector_10)); }
	inline Vector3_t2987449647  get_forwardVector_10() const { return ___forwardVector_10; }
	inline Vector3_t2987449647 * get_address_of_forwardVector_10() { return &___forwardVector_10; }
	inline void set_forwardVector_10(Vector3_t2987449647  value)
	{
		___forwardVector_10 = value;
	}

	inline static int32_t get_offset_of_backVector_11() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___backVector_11)); }
	inline Vector3_t2987449647  get_backVector_11() const { return ___backVector_11; }
	inline Vector3_t2987449647 * get_address_of_backVector_11() { return &___backVector_11; }
	inline void set_backVector_11(Vector3_t2987449647  value)
	{
		___backVector_11 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_12() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___positiveInfinityVector_12)); }
	inline Vector3_t2987449647  get_positiveInfinityVector_12() const { return ___positiveInfinityVector_12; }
	inline Vector3_t2987449647 * get_address_of_positiveInfinityVector_12() { return &___positiveInfinityVector_12; }
	inline void set_positiveInfinityVector_12(Vector3_t2987449647  value)
	{
		___positiveInfinityVector_12 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___negativeInfinityVector_13)); }
	inline Vector3_t2987449647  get_negativeInfinityVector_13() const { return ___negativeInfinityVector_13; }
	inline Vector3_t2987449647 * get_address_of_negativeInfinityVector_13() { return &___negativeInfinityVector_13; }
	inline void set_negativeInfinityVector_13(Vector3_t2987449647  value)
	{
		___negativeInfinityVector_13 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR3_T2987449647_H
#ifndef SINGLE_T3678960876_H
#define SINGLE_T3678960876_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Single
struct  Single_t3678960876 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_7;

public:
	inline static int32_t get_offset_of_m_value_7() { return static_cast<int32_t>(offsetof(Single_t3678960876, ___m_value_7)); }
	inline float get_m_value_7() const { return ___m_value_7; }
	inline float* get_address_of_m_value_7() { return &___m_value_7; }
	inline void set_m_value_7(float value)
	{
		___m_value_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SINGLE_T3678960876_H
#ifndef ENUM_T4088700107_H
#define ENUM_T4088700107_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t4088700107  : public ValueType_t3348802692
{
public:

public:
};

struct Enum_t4088700107_StaticFields
{
public:
	// System.Char[] System.Enum::split_char
	CharU5BU5D_t2816624037* ___split_char_0;

public:
	inline static int32_t get_offset_of_split_char_0() { return static_cast<int32_t>(offsetof(Enum_t4088700107_StaticFields, ___split_char_0)); }
	inline CharU5BU5D_t2816624037* get_split_char_0() const { return ___split_char_0; }
	inline CharU5BU5D_t2816624037** get_address_of_split_char_0() { return &___split_char_0; }
	inline void set_split_char_0(CharU5BU5D_t2816624037* value)
	{
		___split_char_0 = value;
		Il2CppCodeGenWriteBarrier((&___split_char_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t4088700107_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t4088700107_marshaled_com
{
};
#endif // ENUM_T4088700107_H
#ifndef BOOLEAN_T402932760_H
#define BOOLEAN_T402932760_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Boolean
struct  Boolean_t402932760 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Boolean_t402932760, ___m_value_2)); }
	inline bool get_m_value_2() const { return ___m_value_2; }
	inline bool* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(bool value)
	{
		___m_value_2 = value;
	}
};

struct Boolean_t402932760_StaticFields
{
public:
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_0;
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_1;

public:
	inline static int32_t get_offset_of_FalseString_0() { return static_cast<int32_t>(offsetof(Boolean_t402932760_StaticFields, ___FalseString_0)); }
	inline String_t* get_FalseString_0() const { return ___FalseString_0; }
	inline String_t** get_address_of_FalseString_0() { return &___FalseString_0; }
	inline void set_FalseString_0(String_t* value)
	{
		___FalseString_0 = value;
		Il2CppCodeGenWriteBarrier((&___FalseString_0), value);
	}

	inline static int32_t get_offset_of_TrueString_1() { return static_cast<int32_t>(offsetof(Boolean_t402932760_StaticFields, ___TrueString_1)); }
	inline String_t* get_TrueString_1() const { return ___TrueString_1; }
	inline String_t** get_address_of_TrueString_1() { return &___TrueString_1; }
	inline void set_TrueString_1(String_t* value)
	{
		___TrueString_1 = value;
		Il2CppCodeGenWriteBarrier((&___TrueString_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOOLEAN_T402932760_H
#ifndef VOID_T1421048318_H
#define VOID_T1421048318_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Void
struct  Void_t1421048318 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VOID_T1421048318_H
#ifndef COLLISIONFLAGS_T2921713114_H
#define COLLISIONFLAGS_T2921713114_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CollisionFlags
struct  CollisionFlags_t2921713114 
{
public:
	// System.Int32 UnityEngine.CollisionFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CollisionFlags_t2921713114, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLLISIONFLAGS_T2921713114_H
#ifndef RIGIDBODYCONSTRAINTS_T947276696_H
#define RIGIDBODYCONSTRAINTS_T947276696_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RigidbodyConstraints
struct  RigidbodyConstraints_t947276696 
{
public:
	// System.Int32 UnityEngine.RigidbodyConstraints::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(RigidbodyConstraints_t947276696, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RIGIDBODYCONSTRAINTS_T947276696_H
#ifndef CONTROLLERCOLLIDERHIT_T3057575995_H
#define CONTROLLERCOLLIDERHIT_T3057575995_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.ControllerColliderHit
struct  ControllerColliderHit_t3057575995  : public RuntimeObject
{
public:
	// UnityEngine.CharacterController UnityEngine.ControllerColliderHit::m_Controller
	CharacterController_t2965295687 * ___m_Controller_0;
	// UnityEngine.Collider UnityEngine.ControllerColliderHit::m_Collider
	Collider_t3066580567 * ___m_Collider_1;
	// UnityEngine.Vector3 UnityEngine.ControllerColliderHit::m_Point
	Vector3_t2987449647  ___m_Point_2;
	// UnityEngine.Vector3 UnityEngine.ControllerColliderHit::m_Normal
	Vector3_t2987449647  ___m_Normal_3;
	// UnityEngine.Vector3 UnityEngine.ControllerColliderHit::m_MoveDirection
	Vector3_t2987449647  ___m_MoveDirection_4;
	// System.Single UnityEngine.ControllerColliderHit::m_MoveLength
	float ___m_MoveLength_5;
	// System.Int32 UnityEngine.ControllerColliderHit::m_Push
	int32_t ___m_Push_6;

public:
	inline static int32_t get_offset_of_m_Controller_0() { return static_cast<int32_t>(offsetof(ControllerColliderHit_t3057575995, ___m_Controller_0)); }
	inline CharacterController_t2965295687 * get_m_Controller_0() const { return ___m_Controller_0; }
	inline CharacterController_t2965295687 ** get_address_of_m_Controller_0() { return &___m_Controller_0; }
	inline void set_m_Controller_0(CharacterController_t2965295687 * value)
	{
		___m_Controller_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Controller_0), value);
	}

	inline static int32_t get_offset_of_m_Collider_1() { return static_cast<int32_t>(offsetof(ControllerColliderHit_t3057575995, ___m_Collider_1)); }
	inline Collider_t3066580567 * get_m_Collider_1() const { return ___m_Collider_1; }
	inline Collider_t3066580567 ** get_address_of_m_Collider_1() { return &___m_Collider_1; }
	inline void set_m_Collider_1(Collider_t3066580567 * value)
	{
		___m_Collider_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_Collider_1), value);
	}

	inline static int32_t get_offset_of_m_Point_2() { return static_cast<int32_t>(offsetof(ControllerColliderHit_t3057575995, ___m_Point_2)); }
	inline Vector3_t2987449647  get_m_Point_2() const { return ___m_Point_2; }
	inline Vector3_t2987449647 * get_address_of_m_Point_2() { return &___m_Point_2; }
	inline void set_m_Point_2(Vector3_t2987449647  value)
	{
		___m_Point_2 = value;
	}

	inline static int32_t get_offset_of_m_Normal_3() { return static_cast<int32_t>(offsetof(ControllerColliderHit_t3057575995, ___m_Normal_3)); }
	inline Vector3_t2987449647  get_m_Normal_3() const { return ___m_Normal_3; }
	inline Vector3_t2987449647 * get_address_of_m_Normal_3() { return &___m_Normal_3; }
	inline void set_m_Normal_3(Vector3_t2987449647  value)
	{
		___m_Normal_3 = value;
	}

	inline static int32_t get_offset_of_m_MoveDirection_4() { return static_cast<int32_t>(offsetof(ControllerColliderHit_t3057575995, ___m_MoveDirection_4)); }
	inline Vector3_t2987449647  get_m_MoveDirection_4() const { return ___m_MoveDirection_4; }
	inline Vector3_t2987449647 * get_address_of_m_MoveDirection_4() { return &___m_MoveDirection_4; }
	inline void set_m_MoveDirection_4(Vector3_t2987449647  value)
	{
		___m_MoveDirection_4 = value;
	}

	inline static int32_t get_offset_of_m_MoveLength_5() { return static_cast<int32_t>(offsetof(ControllerColliderHit_t3057575995, ___m_MoveLength_5)); }
	inline float get_m_MoveLength_5() const { return ___m_MoveLength_5; }
	inline float* get_address_of_m_MoveLength_5() { return &___m_MoveLength_5; }
	inline void set_m_MoveLength_5(float value)
	{
		___m_MoveLength_5 = value;
	}

	inline static int32_t get_offset_of_m_Push_6() { return static_cast<int32_t>(offsetof(ControllerColliderHit_t3057575995, ___m_Push_6)); }
	inline int32_t get_m_Push_6() const { return ___m_Push_6; }
	inline int32_t* get_address_of_m_Push_6() { return &___m_Push_6; }
	inline void set_m_Push_6(int32_t value)
	{
		___m_Push_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.ControllerColliderHit
struct ControllerColliderHit_t3057575995_marshaled_pinvoke
{
	CharacterController_t2965295687 * ___m_Controller_0;
	Collider_t3066580567 * ___m_Collider_1;
	Vector3_t2987449647  ___m_Point_2;
	Vector3_t2987449647  ___m_Normal_3;
	Vector3_t2987449647  ___m_MoveDirection_4;
	float ___m_MoveLength_5;
	int32_t ___m_Push_6;
};
// Native definition for COM marshalling of UnityEngine.ControllerColliderHit
struct ControllerColliderHit_t3057575995_marshaled_com
{
	CharacterController_t2965295687 * ___m_Controller_0;
	Collider_t3066580567 * ___m_Collider_1;
	Vector3_t2987449647  ___m_Point_2;
	Vector3_t2987449647  ___m_Normal_3;
	Vector3_t2987449647  ___m_MoveDirection_4;
	float ___m_MoveLength_5;
	int32_t ___m_Push_6;
};
#endif // CONTROLLERCOLLIDERHIT_T3057575995_H
#ifndef DELEGATE_T2990640460_H
#define DELEGATE_T2990640460_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t2990640460  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	IntPtr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	IntPtr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	IntPtr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::method_code
	IntPtr_t ___method_code_5;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_6;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_7;
	// System.DelegateData System.Delegate::data
	DelegateData_t2320928782 * ___data_8;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___invoke_impl_1)); }
	inline IntPtr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline IntPtr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(IntPtr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___method_3)); }
	inline IntPtr_t get_method_3() const { return ___method_3; }
	inline IntPtr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(IntPtr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___delegate_trampoline_4)); }
	inline IntPtr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline IntPtr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(IntPtr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_method_code_5() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___method_code_5)); }
	inline IntPtr_t get_method_code_5() const { return ___method_code_5; }
	inline IntPtr_t* get_address_of_method_code_5() { return &___method_code_5; }
	inline void set_method_code_5(IntPtr_t value)
	{
		___method_code_5 = value;
	}

	inline static int32_t get_offset_of_method_info_6() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___method_info_6)); }
	inline MethodInfo_t * get_method_info_6() const { return ___method_info_6; }
	inline MethodInfo_t ** get_address_of_method_info_6() { return &___method_info_6; }
	inline void set_method_info_6(MethodInfo_t * value)
	{
		___method_info_6 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_6), value);
	}

	inline static int32_t get_offset_of_original_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___original_method_info_7)); }
	inline MethodInfo_t * get_original_method_info_7() const { return ___original_method_info_7; }
	inline MethodInfo_t ** get_address_of_original_method_info_7() { return &___original_method_info_7; }
	inline void set_original_method_info_7(MethodInfo_t * value)
	{
		___original_method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_7), value);
	}

	inline static int32_t get_offset_of_data_8() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___data_8)); }
	inline DelegateData_t2320928782 * get_data_8() const { return ___data_8; }
	inline DelegateData_t2320928782 ** get_address_of_data_8() { return &___data_8; }
	inline void set_data_8(DelegateData_t2320928782 * value)
	{
		___data_8 = value;
		Il2CppCodeGenWriteBarrier((&___data_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DELEGATE_T2990640460_H
#ifndef KEYCODE_T3937766085_H
#define KEYCODE_T3937766085_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.KeyCode
struct  KeyCode_t3937766085 
{
public:
	// System.Int32 UnityEngine.KeyCode::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(KeyCode_t3937766085, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYCODE_T3937766085_H
#ifndef OBJECT_T3267094820_H
#define OBJECT_T3267094820_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_t3267094820  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	IntPtr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_t3267094820, ___m_CachedPtr_0)); }
	inline IntPtr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline IntPtr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(IntPtr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_t3267094820_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_t3267094820_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_t3267094820_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_t3267094820_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_T3267094820_H
#ifndef MULTICASTDELEGATE_T608486974_H
#define MULTICASTDELEGATE_T608486974_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t608486974  : public Delegate_t2990640460
{
public:
	// System.MulticastDelegate System.MulticastDelegate::prev
	MulticastDelegate_t608486974 * ___prev_9;
	// System.MulticastDelegate System.MulticastDelegate::kpm_next
	MulticastDelegate_t608486974 * ___kpm_next_10;

public:
	inline static int32_t get_offset_of_prev_9() { return static_cast<int32_t>(offsetof(MulticastDelegate_t608486974, ___prev_9)); }
	inline MulticastDelegate_t608486974 * get_prev_9() const { return ___prev_9; }
	inline MulticastDelegate_t608486974 ** get_address_of_prev_9() { return &___prev_9; }
	inline void set_prev_9(MulticastDelegate_t608486974 * value)
	{
		___prev_9 = value;
		Il2CppCodeGenWriteBarrier((&___prev_9), value);
	}

	inline static int32_t get_offset_of_kpm_next_10() { return static_cast<int32_t>(offsetof(MulticastDelegate_t608486974, ___kpm_next_10)); }
	inline MulticastDelegate_t608486974 * get_kpm_next_10() const { return ___kpm_next_10; }
	inline MulticastDelegate_t608486974 ** get_address_of_kpm_next_10() { return &___kpm_next_10; }
	inline void set_kpm_next_10(MulticastDelegate_t608486974 * value)
	{
		___kpm_next_10 = value;
		Il2CppCodeGenWriteBarrier((&___kpm_next_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MULTICASTDELEGATE_T608486974_H
#ifndef COMPONENT_T21088299_H
#define COMPONENT_T21088299_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t21088299  : public Object_t3267094820
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T21088299_H
#ifndef GAMEOBJECT_T2602266141_H
#define GAMEOBJECT_T2602266141_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.GameObject
struct  GameObject_t2602266141  : public Object_t3267094820
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GAMEOBJECT_T2602266141_H
#ifndef COLLIDER_T3066580567_H
#define COLLIDER_T3066580567_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Collider
struct  Collider_t3066580567  : public Component_t21088299
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLLIDER_T3066580567_H
#ifndef ACTION_1_T2117217084_H
#define ACTION_1_T2117217084_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`1<System.Single>
struct  Action_1_t2117217084  : public MulticastDelegate_t608486974
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_1_T2117217084_H
#ifndef RIGIDBODY_T3670484383_H
#define RIGIDBODY_T3670484383_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rigidbody
struct  Rigidbody_t3670484383  : public Component_t21088299
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RIGIDBODY_T3670484383_H
#ifndef TRANSFORM_T2636691836_H
#define TRANSFORM_T2636691836_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Transform
struct  Transform_t2636691836  : public Component_t21088299
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRANSFORM_T2636691836_H
#ifndef ACTION_T4042858631_H
#define ACTION_T4042858631_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action
struct  Action_t4042858631  : public MulticastDelegate_t608486974
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_T4042858631_H
#ifndef BEHAVIOUR_T2953351352_H
#define BEHAVIOUR_T2953351352_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_t2953351352  : public Component_t21088299
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_T2953351352_H
#ifndef CHARACTERCONTROLLER_T2965295687_H
#define CHARACTERCONTROLLER_T2965295687_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CharacterController
struct  CharacterController_t2965295687  : public Collider_t3066580567
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHARACTERCONTROLLER_T2965295687_H
#ifndef MONOBEHAVIOUR_T244116357_H
#define MONOBEHAVIOUR_T244116357_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.MonoBehaviour
struct  MonoBehaviour_t244116357  : public Behaviour_t2953351352
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOBEHAVIOUR_T244116357_H
#ifndef BOXTRIGGER_T730900964_H
#define BOXTRIGGER_T730900964_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// BoxTrigger
struct  BoxTrigger_t730900964  : public MonoBehaviour_t244116357
{
public:
	// UnityEngine.GameObject BoxTrigger::Lever
	GameObject_t2602266141 * ___Lever_2;
	// UnityEngine.GameObject BoxTrigger::Lever2
	GameObject_t2602266141 * ___Lever2_3;
	// UnityEngine.GameObject BoxTrigger::Tree
	GameObject_t2602266141 * ___Tree_4;
	// UnityEngine.Rigidbody BoxTrigger::rb
	Rigidbody_t3670484383 * ___rb_5;

public:
	inline static int32_t get_offset_of_Lever_2() { return static_cast<int32_t>(offsetof(BoxTrigger_t730900964, ___Lever_2)); }
	inline GameObject_t2602266141 * get_Lever_2() const { return ___Lever_2; }
	inline GameObject_t2602266141 ** get_address_of_Lever_2() { return &___Lever_2; }
	inline void set_Lever_2(GameObject_t2602266141 * value)
	{
		___Lever_2 = value;
		Il2CppCodeGenWriteBarrier((&___Lever_2), value);
	}

	inline static int32_t get_offset_of_Lever2_3() { return static_cast<int32_t>(offsetof(BoxTrigger_t730900964, ___Lever2_3)); }
	inline GameObject_t2602266141 * get_Lever2_3() const { return ___Lever2_3; }
	inline GameObject_t2602266141 ** get_address_of_Lever2_3() { return &___Lever2_3; }
	inline void set_Lever2_3(GameObject_t2602266141 * value)
	{
		___Lever2_3 = value;
		Il2CppCodeGenWriteBarrier((&___Lever2_3), value);
	}

	inline static int32_t get_offset_of_Tree_4() { return static_cast<int32_t>(offsetof(BoxTrigger_t730900964, ___Tree_4)); }
	inline GameObject_t2602266141 * get_Tree_4() const { return ___Tree_4; }
	inline GameObject_t2602266141 ** get_address_of_Tree_4() { return &___Tree_4; }
	inline void set_Tree_4(GameObject_t2602266141 * value)
	{
		___Tree_4 = value;
		Il2CppCodeGenWriteBarrier((&___Tree_4), value);
	}

	inline static int32_t get_offset_of_rb_5() { return static_cast<int32_t>(offsetof(BoxTrigger_t730900964, ___rb_5)); }
	inline Rigidbody_t3670484383 * get_rb_5() const { return ___rb_5; }
	inline Rigidbody_t3670484383 ** get_address_of_rb_5() { return &___rb_5; }
	inline void set_rb_5(Rigidbody_t3670484383 * value)
	{
		___rb_5 = value;
		Il2CppCodeGenWriteBarrier((&___rb_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOXTRIGGER_T730900964_H
#ifndef PUSHOBJECT_T3539098884_H
#define PUSHOBJECT_T3539098884_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// PushObject
struct  PushObject_t3539098884  : public MonoBehaviour_t244116357
{
public:
	// System.Single PushObject::pushForce
	float ___pushForce_2;

public:
	inline static int32_t get_offset_of_pushForce_2() { return static_cast<int32_t>(offsetof(PushObject_t3539098884, ___pushForce_2)); }
	inline float get_pushForce_2() const { return ___pushForce_2; }
	inline float* get_address_of_pushForce_2() { return &___pushForce_2; }
	inline void set_pushForce_2(float value)
	{
		___pushForce_2 = value;
	}
};

struct PushObject_t3539098884_StaticFields
{
public:
	// System.Boolean PushObject::fallen
	bool ___fallen_3;

public:
	inline static int32_t get_offset_of_fallen_3() { return static_cast<int32_t>(offsetof(PushObject_t3539098884_StaticFields, ___fallen_3)); }
	inline bool get_fallen_3() const { return ___fallen_3; }
	inline bool* get_address_of_fallen_3() { return &___fallen_3; }
	inline void set_fallen_3(bool value)
	{
		___fallen_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PUSHOBJECT_T3539098884_H
#ifndef MOVECHARACTER_T2492455991_H
#define MOVECHARACTER_T2492455991_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MoveCharacter
struct  MoveCharacter_t2492455991  : public MonoBehaviour_t244116357
{
public:
	// UnityEngine.CharacterController MoveCharacter::cc
	CharacterController_t2965295687 * ___cc_2;
	// UnityEngine.Vector3 MoveCharacter::tempMove
	Vector3_t2987449647  ___tempMove_3;
	// System.Single MoveCharacter::speed
	float ___speed_4;
	// System.Single MoveCharacter::gravity
	float ___gravity_5;
	// System.Single MoveCharacter::jumpHeight
	float ___jumpHeight_6;
	// System.Int32 MoveCharacter::jumpScore
	int32_t ___jumpScore_7;
	// System.Int32 MoveCharacter::maxJump
	int32_t ___maxJump_8;

public:
	inline static int32_t get_offset_of_cc_2() { return static_cast<int32_t>(offsetof(MoveCharacter_t2492455991, ___cc_2)); }
	inline CharacterController_t2965295687 * get_cc_2() const { return ___cc_2; }
	inline CharacterController_t2965295687 ** get_address_of_cc_2() { return &___cc_2; }
	inline void set_cc_2(CharacterController_t2965295687 * value)
	{
		___cc_2 = value;
		Il2CppCodeGenWriteBarrier((&___cc_2), value);
	}

	inline static int32_t get_offset_of_tempMove_3() { return static_cast<int32_t>(offsetof(MoveCharacter_t2492455991, ___tempMove_3)); }
	inline Vector3_t2987449647  get_tempMove_3() const { return ___tempMove_3; }
	inline Vector3_t2987449647 * get_address_of_tempMove_3() { return &___tempMove_3; }
	inline void set_tempMove_3(Vector3_t2987449647  value)
	{
		___tempMove_3 = value;
	}

	inline static int32_t get_offset_of_speed_4() { return static_cast<int32_t>(offsetof(MoveCharacter_t2492455991, ___speed_4)); }
	inline float get_speed_4() const { return ___speed_4; }
	inline float* get_address_of_speed_4() { return &___speed_4; }
	inline void set_speed_4(float value)
	{
		___speed_4 = value;
	}

	inline static int32_t get_offset_of_gravity_5() { return static_cast<int32_t>(offsetof(MoveCharacter_t2492455991, ___gravity_5)); }
	inline float get_gravity_5() const { return ___gravity_5; }
	inline float* get_address_of_gravity_5() { return &___gravity_5; }
	inline void set_gravity_5(float value)
	{
		___gravity_5 = value;
	}

	inline static int32_t get_offset_of_jumpHeight_6() { return static_cast<int32_t>(offsetof(MoveCharacter_t2492455991, ___jumpHeight_6)); }
	inline float get_jumpHeight_6() const { return ___jumpHeight_6; }
	inline float* get_address_of_jumpHeight_6() { return &___jumpHeight_6; }
	inline void set_jumpHeight_6(float value)
	{
		___jumpHeight_6 = value;
	}

	inline static int32_t get_offset_of_jumpScore_7() { return static_cast<int32_t>(offsetof(MoveCharacter_t2492455991, ___jumpScore_7)); }
	inline int32_t get_jumpScore_7() const { return ___jumpScore_7; }
	inline int32_t* get_address_of_jumpScore_7() { return &___jumpScore_7; }
	inline void set_jumpScore_7(int32_t value)
	{
		___jumpScore_7 = value;
	}

	inline static int32_t get_offset_of_maxJump_8() { return static_cast<int32_t>(offsetof(MoveCharacter_t2492455991, ___maxJump_8)); }
	inline int32_t get_maxJump_8() const { return ___maxJump_8; }
	inline int32_t* get_address_of_maxJump_8() { return &___maxJump_8; }
	inline void set_maxJump_8(int32_t value)
	{
		___maxJump_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MOVECHARACTER_T2492455991_H
#ifndef MOVEOBJECT_T260185650_H
#define MOVEOBJECT_T260185650_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MoveObject
struct  MoveObject_t260185650  : public MonoBehaviour_t244116357
{
public:
	// System.Single MoveObject::pushForce
	float ___pushForce_2;

public:
	inline static int32_t get_offset_of_pushForce_2() { return static_cast<int32_t>(offsetof(MoveObject_t260185650, ___pushForce_2)); }
	inline float get_pushForce_2() const { return ___pushForce_2; }
	inline float* get_address_of_pushForce_2() { return &___pushForce_2; }
	inline void set_pushForce_2(float value)
	{
		___pushForce_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MOVEOBJECT_T260185650_H
#ifndef LEDGETRIGGER_T2111245965_H
#define LEDGETRIGGER_T2111245965_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LedgeTrigger
struct  LedgeTrigger_t2111245965  : public MonoBehaviour_t244116357
{
public:
	// UnityEngine.GameObject LedgeTrigger::Tree
	GameObject_t2602266141 * ___Tree_2;
	// UnityEngine.Rigidbody LedgeTrigger::rb
	Rigidbody_t3670484383 * ___rb_3;

public:
	inline static int32_t get_offset_of_Tree_2() { return static_cast<int32_t>(offsetof(LedgeTrigger_t2111245965, ___Tree_2)); }
	inline GameObject_t2602266141 * get_Tree_2() const { return ___Tree_2; }
	inline GameObject_t2602266141 ** get_address_of_Tree_2() { return &___Tree_2; }
	inline void set_Tree_2(GameObject_t2602266141 * value)
	{
		___Tree_2 = value;
		Il2CppCodeGenWriteBarrier((&___Tree_2), value);
	}

	inline static int32_t get_offset_of_rb_3() { return static_cast<int32_t>(offsetof(LedgeTrigger_t2111245965, ___rb_3)); }
	inline Rigidbody_t3670484383 * get_rb_3() const { return ___rb_3; }
	inline Rigidbody_t3670484383 ** get_address_of_rb_3() { return &___rb_3; }
	inline void set_rb_3(Rigidbody_t3670484383 * value)
	{
		___rb_3 = value;
		Il2CppCodeGenWriteBarrier((&___rb_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LEDGETRIGGER_T2111245965_H
#ifndef FLIPCHARACTER_T1403884062_H
#define FLIPCHARACTER_T1403884062_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// FlipCharacter
struct  FlipCharacter_t1403884062  : public MonoBehaviour_t244116357
{
public:
	// UnityEngine.Quaternion FlipCharacter::myRotate
	Quaternion_t895809378  ___myRotate_2;
	// UnityEngine.Vector3 FlipCharacter::rotValue
	Vector3_t2987449647  ___rotValue_3;

public:
	inline static int32_t get_offset_of_myRotate_2() { return static_cast<int32_t>(offsetof(FlipCharacter_t1403884062, ___myRotate_2)); }
	inline Quaternion_t895809378  get_myRotate_2() const { return ___myRotate_2; }
	inline Quaternion_t895809378 * get_address_of_myRotate_2() { return &___myRotate_2; }
	inline void set_myRotate_2(Quaternion_t895809378  value)
	{
		___myRotate_2 = value;
	}

	inline static int32_t get_offset_of_rotValue_3() { return static_cast<int32_t>(offsetof(FlipCharacter_t1403884062, ___rotValue_3)); }
	inline Vector3_t2987449647  get_rotValue_3() const { return ___rotValue_3; }
	inline Vector3_t2987449647 * get_address_of_rotValue_3() { return &___rotValue_3; }
	inline void set_rotValue_3(Vector3_t2987449647  value)
	{
		___rotValue_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FLIPCHARACTER_T1403884062_H
#ifndef CAMERASCRIPT_T2676235949_H
#define CAMERASCRIPT_T2676235949_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CameraScript
struct  CameraScript_t2676235949  : public MonoBehaviour_t244116357
{
public:
	// UnityEngine.GameObject CameraScript::Boy
	GameObject_t2602266141 * ___Boy_2;
	// UnityEngine.Vector3 CameraScript::offset
	Vector3_t2987449647  ___offset_3;

public:
	inline static int32_t get_offset_of_Boy_2() { return static_cast<int32_t>(offsetof(CameraScript_t2676235949, ___Boy_2)); }
	inline GameObject_t2602266141 * get_Boy_2() const { return ___Boy_2; }
	inline GameObject_t2602266141 ** get_address_of_Boy_2() { return &___Boy_2; }
	inline void set_Boy_2(GameObject_t2602266141 * value)
	{
		___Boy_2 = value;
		Il2CppCodeGenWriteBarrier((&___Boy_2), value);
	}

	inline static int32_t get_offset_of_offset_3() { return static_cast<int32_t>(offsetof(CameraScript_t2676235949, ___offset_3)); }
	inline Vector3_t2987449647  get_offset_3() const { return ___offset_3; }
	inline Vector3_t2987449647 * get_address_of_offset_3() { return &___offset_3; }
	inline void set_offset_3(Vector3_t2987449647  value)
	{
		___offset_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CAMERASCRIPT_T2676235949_H
#ifndef PLATFORMTRIGGER_T1464797062_H
#define PLATFORMTRIGGER_T1464797062_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// PlatformTrigger
struct  PlatformTrigger_t1464797062  : public MonoBehaviour_t244116357
{
public:
	// UnityEngine.GameObject PlatformTrigger::pp
	GameObject_t2602266141 * ___pp_2;

public:
	inline static int32_t get_offset_of_pp_2() { return static_cast<int32_t>(offsetof(PlatformTrigger_t1464797062, ___pp_2)); }
	inline GameObject_t2602266141 * get_pp_2() const { return ___pp_2; }
	inline GameObject_t2602266141 ** get_address_of_pp_2() { return &___pp_2; }
	inline void set_pp_2(GameObject_t2602266141 * value)
	{
		___pp_2 = value;
		Il2CppCodeGenWriteBarrier((&___pp_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLATFORMTRIGGER_T1464797062_H
#ifndef PLAYERINPUT_T3450109778_H
#define PLAYERINPUT_T3450109778_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// PlayerInput
struct  PlayerInput_t3450109778  : public MonoBehaviour_t244116357
{
public:

public:
};

struct PlayerInput_t3450109778_StaticFields
{
public:
	// System.Action`1<System.Single> PlayerInput::KeyAction
	Action_1_t2117217084 * ___KeyAction_2;
	// System.Action PlayerInput::JumpAction
	Action_t4042858631 * ___JumpAction_3;

public:
	inline static int32_t get_offset_of_KeyAction_2() { return static_cast<int32_t>(offsetof(PlayerInput_t3450109778_StaticFields, ___KeyAction_2)); }
	inline Action_1_t2117217084 * get_KeyAction_2() const { return ___KeyAction_2; }
	inline Action_1_t2117217084 ** get_address_of_KeyAction_2() { return &___KeyAction_2; }
	inline void set_KeyAction_2(Action_1_t2117217084 * value)
	{
		___KeyAction_2 = value;
		Il2CppCodeGenWriteBarrier((&___KeyAction_2), value);
	}

	inline static int32_t get_offset_of_JumpAction_3() { return static_cast<int32_t>(offsetof(PlayerInput_t3450109778_StaticFields, ___JumpAction_3)); }
	inline Action_t4042858631 * get_JumpAction_3() const { return ___JumpAction_3; }
	inline Action_t4042858631 ** get_address_of_JumpAction_3() { return &___JumpAction_3; }
	inline void set_JumpAction_3(Action_t4042858631 * value)
	{
		___JumpAction_3 = value;
		Il2CppCodeGenWriteBarrier((&___JumpAction_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYERINPUT_T3450109778_H


// System.Void System.Action`1<System.Single>::.ctor(System.Object,System.IntPtr)
extern "C"  void Action_1__ctor_m3685619994_gshared (Action_1_t2117217084 * __this, RuntimeObject * p0, IntPtr_t p1, const RuntimeMethod* method);
// !!0 UnityEngine.GameObject::GetComponent<System.Object>()
extern "C"  RuntimeObject * GameObject_GetComponent_TisRuntimeObject_m3465827492_gshared (GameObject_t2602266141 * __this, const RuntimeMethod* method);
// !!0 UnityEngine.Component::GetComponent<System.Object>()
extern "C"  RuntimeObject * Component_GetComponent_TisRuntimeObject_m3554061376_gshared (Component_t21088299 * __this, const RuntimeMethod* method);
// System.Void System.Action`1<System.Single>::Invoke(!0)
extern "C"  void Action_1_Invoke_m1323436125_gshared (Action_1_t2117217084 * __this, float p0, const RuntimeMethod* method);

// System.Void UnityEngine.MonoBehaviour::.ctor()
extern "C"  void MonoBehaviour__ctor_m1236242179 (MonoBehaviour_t244116357 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.GameObject UnityEngine.GameObject::FindGameObjectWithTag(System.String)
extern "C"  GameObject_t2602266141 * GameObject_FindGameObjectWithTag_m3016707382 (RuntimeObject * __this /* static, unused */, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.GameObject UnityEngine.GameObject::Find(System.String)
extern "C"  GameObject_t2602266141 * GameObject_Find_m357843493 (RuntimeObject * __this /* static, unused */, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String UnityEngine.Object::get_name()
extern "C"  String_t* Object_get_name_m4131808298 (Object_t3267094820 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean System.String::op_Equality(System.String,System.String)
extern "C"  bool String_op_Equality_m2935810047 (RuntimeObject * __this /* static, unused */, String_t* p0, String_t* p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.Transform UnityEngine.GameObject::get_transform()
extern "C"  Transform_t2636691836 * GameObject_get_transform_m3351892996 (GameObject_t2602266141 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Transform::Rotate(System.Single,System.Single,System.Single)
extern "C"  void Transform_Rotate_m1099066500 (Transform_t2636691836 * __this, float p0, float p1, float p2, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.Transform UnityEngine.Component::get_transform()
extern "C"  Transform_t2636691836 * Component_get_transform_m1991721595 (Component_t21088299 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.Vector3 UnityEngine.Transform::get_position()
extern "C"  Vector3_t2987449647  Transform_get_position_m711175457 (Transform_t2636691836 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Subtraction(UnityEngine.Vector3,UnityEngine.Vector3)
extern "C"  Vector3_t2987449647  Vector3_op_Subtraction_m107949794 (RuntimeObject * __this /* static, unused */, Vector3_t2987449647  p0, Vector3_t2987449647  p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Addition(UnityEngine.Vector3,UnityEngine.Vector3)
extern "C"  Vector3_t2987449647  Vector3_op_Addition_m1168168007 (RuntimeObject * __this /* static, unused */, Vector3_t2987449647  p0, Vector3_t2987449647  p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Transform::set_position(UnityEngine.Vector3)
extern "C"  void Transform_set_position_m3893147833 (Transform_t2636691836 * __this, Vector3_t2987449647  p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Action`1<System.Single>::.ctor(System.Object,System.IntPtr)
#define Action_1__ctor_m3685619994(__this, p0, p1, method) ((  void (*) (Action_1_t2117217084 *, RuntimeObject *, IntPtr_t, const RuntimeMethod*))Action_1__ctor_m3685619994_gshared)(__this, p0, p1, method)
// System.Delegate System.Delegate::Combine(System.Delegate,System.Delegate)
extern "C"  Delegate_t2990640460 * Delegate_Combine_m1818817617 (RuntimeObject * __this /* static, unused */, Delegate_t2990640460 * p0, Delegate_t2990640460 * p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Quaternion::set_eulerAngles(UnityEngine.Vector3)
extern "C"  void Quaternion_set_eulerAngles_m1585488089 (Quaternion_t895809378 * __this, Vector3_t2987449647  p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Transform::set_rotation(UnityEngine.Quaternion)
extern "C"  void Transform_set_rotation_m3616398901 (Transform_t2636691836 * __this, Quaternion_t895809378  p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// !!0 UnityEngine.GameObject::GetComponent<UnityEngine.Rigidbody>()
#define GameObject_GetComponent_TisRigidbody_t3670484383_m3822479057(__this, method) ((  Rigidbody_t3670484383 * (*) (GameObject_t2602266141 *, const RuntimeMethod*))GameObject_GetComponent_TisRuntimeObject_m3465827492_gshared)(__this, method)
// System.Void UnityEngine.Rigidbody::set_isKinematic(System.Boolean)
extern "C"  void Rigidbody_set_isKinematic_m3808468253 (Rigidbody_t3670484383 * __this, bool p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// !!0 UnityEngine.Component::GetComponent<UnityEngine.CharacterController>()
#define Component_GetComponent_TisCharacterController_t2965295687_m2123869853(__this, method) ((  CharacterController_t2965295687 * (*) (Component_t21088299 *, const RuntimeMethod*))Component_GetComponent_TisRuntimeObject_m3554061376_gshared)(__this, method)
// System.Void System.Action::.ctor(System.Object,System.IntPtr)
extern "C"  void Action__ctor_m2628370505 (Action_t4042858631 * __this, RuntimeObject * p0, IntPtr_t p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Single UnityEngine.Time::get_deltaTime()
extern "C"  float Time_get_deltaTime_m3885432000 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.CollisionFlags UnityEngine.CharacterController::Move(UnityEngine.Vector3)
extern "C"  int32_t CharacterController_Move_m900161214 (CharacterController_t2965295687 * __this, Vector3_t2987449647  p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean UnityEngine.CharacterController::get_isGrounded()
extern "C"  bool CharacterController_get_isGrounded_m3015943198 (CharacterController_t2965295687 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.MonoBehaviour::print(System.Object)
extern "C"  void MonoBehaviour_print_m134029734 (RuntimeObject * __this /* static, unused */, RuntimeObject * p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.Collider UnityEngine.ControllerColliderHit::get_collider()
extern "C"  Collider_t3066580567 * ControllerColliderHit_get_collider_m2056607443 (ControllerColliderHit_t3057575995 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.Rigidbody UnityEngine.Collider::get_attachedRigidbody()
extern "C"  Rigidbody_t3670484383 * Collider_get_attachedRigidbody_m1223649037 (Collider_t3066580567 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean UnityEngine.Object::op_Equality(UnityEngine.Object,UnityEngine.Object)
extern "C"  bool Object_op_Equality_m1841232993 (RuntimeObject * __this /* static, unused */, Object_t3267094820 * p0, Object_t3267094820 * p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean UnityEngine.Rigidbody::get_isKinematic()
extern "C"  bool Rigidbody_get_isKinematic_m3289074417 (Rigidbody_t3670484383 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.Vector3 UnityEngine.ControllerColliderHit::get_moveDirection()
extern "C"  Vector3_t2987449647  ControllerColliderHit_get_moveDirection_m1063174902 (ControllerColliderHit_t3057575995 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Vector3::.ctor(System.Single,System.Single,System.Single)
extern "C"  void Vector3__ctor_m4052953749 (Vector3_t2987449647 * __this, float p0, float p1, float p2, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Multiply(System.Single,UnityEngine.Vector3)
extern "C"  Vector3_t2987449647  Vector3_op_Multiply_m3725125284 (RuntimeObject * __this /* static, unused */, float p0, Vector3_t2987449647  p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.Rigidbody::set_velocity(UnityEngine.Vector3)
extern "C"  void Rigidbody_set_velocity_m44238466 (Rigidbody_t3670484383 * __this, Vector3_t2987449647  p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.GameObject UnityEngine.GameObject::get_gameObject()
extern "C"  GameObject_t2602266141 * GameObject_get_gameObject_m1404374750 (GameObject_t2602266141 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.GameObject::SetActive(System.Boolean)
extern "C"  void GameObject_SetActive_m924703582 (GameObject_t2602266141 * __this, bool p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Collections.IEnumerator UnityEngine.Transform::GetEnumerator()
extern "C"  RuntimeObject* Transform_GetEnumerator_m454680747 (Transform_t2636691836 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Single UnityEngine.Input::GetAxis(System.String)
extern "C"  float Input_GetAxis_m1666418521 (RuntimeObject * __this /* static, unused */, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Action`1<System.Single>::Invoke(!0)
#define Action_1_Invoke_m1323436125(__this, p0, method) ((  void (*) (Action_1_t2117217084 *, float, const RuntimeMethod*))Action_1_Invoke_m1323436125_gshared)(__this, p0, method)
// System.Boolean UnityEngine.Input::GetKeyDown(UnityEngine.KeyCode)
extern "C"  bool Input_GetKeyDown_m1509524102 (RuntimeObject * __this /* static, unused */, int32_t p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Action::Invoke()
extern "C"  void Action_Invoke_m461827263 (Action_t4042858631 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void PushObject::test()
extern "C"  void PushObject_test_m2222389076 (PushObject_t3539098884 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// !!0 UnityEngine.Component::GetComponent<UnityEngine.Rigidbody>()
#define Component_GetComponent_TisRigidbody_t3670484383_m1187311617(__this, method) ((  Rigidbody_t3670484383 * (*) (Component_t21088299 *, const RuntimeMethod*))Component_GetComponent_TisRuntimeObject_m3554061376_gshared)(__this, method)
// System.Void UnityEngine.Rigidbody::set_constraints(UnityEngine.RigidbodyConstraints)
extern "C"  void Rigidbody_set_constraints_m1675396742 (Rigidbody_t3670484383 * __this, int32_t p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void BoxTrigger::.ctor()
extern "C"  void BoxTrigger__ctor_m910405003 (BoxTrigger_t730900964 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_m1236242179(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void BoxTrigger::Start()
extern "C"  void BoxTrigger_Start_m1361771495 (BoxTrigger_t730900964 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BoxTrigger_Start_m1361771495_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GameObject_t2602266141 * L_0 = GameObject_FindGameObjectWithTag_m3016707382(NULL /*static, unused*/, _stringLiteral1083277759, /*hidden argument*/NULL);
		__this->set_Lever_2(L_0);
		GameObject_t2602266141 * L_1 = GameObject_Find_m357843493(NULL /*static, unused*/, _stringLiteral1654921415, /*hidden argument*/NULL);
		__this->set_Lever2_3(L_1);
		return;
	}
}
// System.Void BoxTrigger::OnTriggerEnter(UnityEngine.Collider)
extern "C"  void BoxTrigger_OnTriggerEnter_m1134727060 (BoxTrigger_t730900964 * __this, Collider_t3066580567 * ___Box0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BoxTrigger_OnTriggerEnter_m1134727060_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Collider_t3066580567 * L_0 = ___Box0;
		String_t* L_1 = Object_get_name_m4131808298(L_0, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_2 = String_op_Equality_m2935810047(NULL /*static, unused*/, L_1, _stringLiteral3152098533, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0034;
		}
	}
	{
		GameObject_t2602266141 * L_3 = __this->get_Lever_2();
		Transform_t2636691836 * L_4 = GameObject_get_transform_m3351892996(L_3, /*hidden argument*/NULL);
		Transform_Rotate_m1099066500(L_4, (0.0f), (0.0f), (90.0f), /*hidden argument*/NULL);
	}

IL_0034:
	{
		Collider_t3066580567 * L_5 = ___Box0;
		String_t* L_6 = Object_get_name_m4131808298(L_5, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_7 = String_op_Equality_m2935810047(NULL /*static, unused*/, L_6, _stringLiteral4197525387, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_0068;
		}
	}
	{
		GameObject_t2602266141 * L_8 = __this->get_Lever2_3();
		Transform_t2636691836 * L_9 = GameObject_get_transform_m3351892996(L_8, /*hidden argument*/NULL);
		Transform_Rotate_m1099066500(L_9, (0.0f), (0.0f), (90.0f), /*hidden argument*/NULL);
	}

IL_0068:
	{
		return;
	}
}
// System.Void BoxTrigger::OnTriggerExit(UnityEngine.Collider)
extern "C"  void BoxTrigger_OnTriggerExit_m1026518603 (BoxTrigger_t730900964 * __this, Collider_t3066580567 * ___Box0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BoxTrigger_OnTriggerExit_m1026518603_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Collider_t3066580567 * L_0 = ___Box0;
		String_t* L_1 = Object_get_name_m4131808298(L_0, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_2 = String_op_Equality_m2935810047(NULL /*static, unused*/, L_1, _stringLiteral3152098533, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0034;
		}
	}
	{
		GameObject_t2602266141 * L_3 = __this->get_Lever_2();
		Transform_t2636691836 * L_4 = GameObject_get_transform_m3351892996(L_3, /*hidden argument*/NULL);
		Transform_Rotate_m1099066500(L_4, (0.0f), (0.0f), (-90.0f), /*hidden argument*/NULL);
	}

IL_0034:
	{
		Collider_t3066580567 * L_5 = ___Box0;
		String_t* L_6 = Object_get_name_m4131808298(L_5, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_7 = String_op_Equality_m2935810047(NULL /*static, unused*/, L_6, _stringLiteral4197525387, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_0068;
		}
	}
	{
		GameObject_t2602266141 * L_8 = __this->get_Lever2_3();
		Transform_t2636691836 * L_9 = GameObject_get_transform_m3351892996(L_8, /*hidden argument*/NULL);
		Transform_Rotate_m1099066500(L_9, (0.0f), (0.0f), (-90.0f), /*hidden argument*/NULL);
	}

IL_0068:
	{
		return;
	}
}
// System.Void CameraScript::.ctor()
extern "C"  void CameraScript__ctor_m2074972760 (CameraScript_t2676235949 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_m1236242179(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void CameraScript::Start()
extern "C"  void CameraScript_Start_m70798908 (CameraScript_t2676235949 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraScript_Start_m70798908_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GameObject_t2602266141 * L_0 = GameObject_Find_m357843493(NULL /*static, unused*/, _stringLiteral542685270, /*hidden argument*/NULL);
		__this->set_Boy_2(L_0);
		Transform_t2636691836 * L_1 = Component_get_transform_m1991721595(__this, /*hidden argument*/NULL);
		Vector3_t2987449647  L_2 = Transform_get_position_m711175457(L_1, /*hidden argument*/NULL);
		GameObject_t2602266141 * L_3 = __this->get_Boy_2();
		Transform_t2636691836 * L_4 = GameObject_get_transform_m3351892996(L_3, /*hidden argument*/NULL);
		Vector3_t2987449647  L_5 = Transform_get_position_m711175457(L_4, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Vector3_t2987449647_il2cpp_TypeInfo_var);
		Vector3_t2987449647  L_6 = Vector3_op_Subtraction_m107949794(NULL /*static, unused*/, L_2, L_5, /*hidden argument*/NULL);
		__this->set_offset_3(L_6);
		return;
	}
}
// System.Void CameraScript::LateUpdate()
extern "C"  void CameraScript_LateUpdate_m3780720276 (CameraScript_t2676235949 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CameraScript_LateUpdate_m3780720276_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Transform_t2636691836 * L_0 = Component_get_transform_m1991721595(__this, /*hidden argument*/NULL);
		GameObject_t2602266141 * L_1 = __this->get_Boy_2();
		Transform_t2636691836 * L_2 = GameObject_get_transform_m3351892996(L_1, /*hidden argument*/NULL);
		Vector3_t2987449647  L_3 = Transform_get_position_m711175457(L_2, /*hidden argument*/NULL);
		Vector3_t2987449647  L_4 = __this->get_offset_3();
		IL2CPP_RUNTIME_CLASS_INIT(Vector3_t2987449647_il2cpp_TypeInfo_var);
		Vector3_t2987449647  L_5 = Vector3_op_Addition_m1168168007(NULL /*static, unused*/, L_3, L_4, /*hidden argument*/NULL);
		Transform_set_position_m3893147833(L_0, L_5, /*hidden argument*/NULL);
		return;
	}
}
// System.Void FlipCharacter::.ctor()
extern "C"  void FlipCharacter__ctor_m2323846137 (FlipCharacter_t1403884062 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_m1236242179(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void FlipCharacter::Start()
extern "C"  void FlipCharacter_Start_m1352720864 (FlipCharacter_t1403884062 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FlipCharacter_Start_m1352720864_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Action_1_t2117217084 * L_0 = ((PlayerInput_t3450109778_StaticFields*)il2cpp_codegen_static_fields_for(PlayerInput_t3450109778_il2cpp_TypeInfo_var))->get_KeyAction_2();
		IntPtr_t L_1;
		L_1.set_m_value_0((void*)(void*)FlipCharacter_Flip_m936201690_RuntimeMethod_var);
		Action_1_t2117217084 * L_2 = (Action_1_t2117217084 *)il2cpp_codegen_object_new(Action_1_t2117217084_il2cpp_TypeInfo_var);
		Action_1__ctor_m3685619994(L_2, __this, L_1, /*hidden argument*/Action_1__ctor_m3685619994_RuntimeMethod_var);
		Delegate_t2990640460 * L_3 = Delegate_Combine_m1818817617(NULL /*static, unused*/, L_0, L_2, /*hidden argument*/NULL);
		((PlayerInput_t3450109778_StaticFields*)il2cpp_codegen_static_fields_for(PlayerInput_t3450109778_il2cpp_TypeInfo_var))->set_KeyAction_2(((Action_1_t2117217084 *)CastclassSealed((RuntimeObject*)L_3, Action_1_t2117217084_il2cpp_TypeInfo_var)));
		return;
	}
}
// System.Void FlipCharacter::Flip(System.Single)
extern "C"  void FlipCharacter_Flip_m936201690 (FlipCharacter_t1403884062 * __this, float ___obj0, const RuntimeMethod* method)
{
	{
		float L_0 = ___obj0;
		if ((!(((float)L_0) > ((float)(0.0f)))))
		{
			goto IL_001b;
		}
	}
	{
		Vector3_t2987449647 * L_1 = __this->get_address_of_rotValue_3();
		L_1->set_y_2((0.0f));
	}

IL_001b:
	{
		float L_2 = ___obj0;
		if ((!(((float)L_2) < ((float)(0.0f)))))
		{
			goto IL_0036;
		}
	}
	{
		Vector3_t2987449647 * L_3 = __this->get_address_of_rotValue_3();
		L_3->set_y_2((180.0f));
	}

IL_0036:
	{
		Quaternion_t895809378 * L_4 = __this->get_address_of_myRotate_2();
		Vector3_t2987449647  L_5 = __this->get_rotValue_3();
		Quaternion_set_eulerAngles_m1585488089(L_4, L_5, /*hidden argument*/NULL);
		Transform_t2636691836 * L_6 = Component_get_transform_m1991721595(__this, /*hidden argument*/NULL);
		Quaternion_t895809378  L_7 = __this->get_myRotate_2();
		Transform_set_rotation_m3616398901(L_6, L_7, /*hidden argument*/NULL);
		return;
	}
}
// System.Void LedgeTrigger::.ctor()
extern "C"  void LedgeTrigger__ctor_m3541567390 (LedgeTrigger_t2111245965 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_m1236242179(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void LedgeTrigger::Start()
extern "C"  void LedgeTrigger_Start_m3492426325 (LedgeTrigger_t2111245965 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LedgeTrigger_Start_m3492426325_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GameObject_t2602266141 * L_0 = GameObject_Find_m357843493(NULL /*static, unused*/, _stringLiteral79956717, /*hidden argument*/NULL);
		__this->set_Tree_2(L_0);
		GameObject_t2602266141 * L_1 = __this->get_Tree_2();
		Rigidbody_t3670484383 * L_2 = GameObject_GetComponent_TisRigidbody_t3670484383_m3822479057(L_1, /*hidden argument*/GameObject_GetComponent_TisRigidbody_t3670484383_m3822479057_RuntimeMethod_var);
		__this->set_rb_3(L_2);
		return;
	}
}
// System.Void LedgeTrigger::OnTriggerEnter(UnityEngine.Collider)
extern "C"  void LedgeTrigger_OnTriggerEnter_m4103365985 (LedgeTrigger_t2111245965 * __this, Collider_t3066580567 * ___Tree0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LedgeTrigger_OnTriggerEnter_m4103365985_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Collider_t3066580567 * L_0 = ___Tree0;
		String_t* L_1 = Object_get_name_m4131808298(L_0, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_2 = String_op_Equality_m2935810047(NULL /*static, unused*/, L_1, _stringLiteral79956717, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0021;
		}
	}
	{
		Rigidbody_t3670484383 * L_3 = __this->get_rb_3();
		Rigidbody_set_isKinematic_m3808468253(L_3, (bool)1, /*hidden argument*/NULL);
	}

IL_0021:
	{
		return;
	}
}
// System.Void MoveCharacter::.ctor()
extern "C"  void MoveCharacter__ctor_m940492633 (MoveCharacter_t2492455991 * __this, const RuntimeMethod* method)
{
	{
		__this->set_speed_4((4.0f));
		__this->set_gravity_5((1.0f));
		__this->set_jumpHeight_6((0.3f));
		__this->set_maxJump_8(1);
		MonoBehaviour__ctor_m1236242179(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void MoveCharacter::Start()
extern "C"  void MoveCharacter_Start_m3159237758 (MoveCharacter_t2492455991 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MoveCharacter_Start_m3159237758_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		CharacterController_t2965295687 * L_0 = Component_GetComponent_TisCharacterController_t2965295687_m2123869853(__this, /*hidden argument*/Component_GetComponent_TisCharacterController_t2965295687_m2123869853_RuntimeMethod_var);
		__this->set_cc_2(L_0);
		Action_1_t2117217084 * L_1 = ((PlayerInput_t3450109778_StaticFields*)il2cpp_codegen_static_fields_for(PlayerInput_t3450109778_il2cpp_TypeInfo_var))->get_KeyAction_2();
		IntPtr_t L_2;
		L_2.set_m_value_0((void*)(void*)MoveCharacter_Move_m3498876582_RuntimeMethod_var);
		Action_1_t2117217084 * L_3 = (Action_1_t2117217084 *)il2cpp_codegen_object_new(Action_1_t2117217084_il2cpp_TypeInfo_var);
		Action_1__ctor_m3685619994(L_3, __this, L_2, /*hidden argument*/Action_1__ctor_m3685619994_RuntimeMethod_var);
		Delegate_t2990640460 * L_4 = Delegate_Combine_m1818817617(NULL /*static, unused*/, L_1, L_3, /*hidden argument*/NULL);
		((PlayerInput_t3450109778_StaticFields*)il2cpp_codegen_static_fields_for(PlayerInput_t3450109778_il2cpp_TypeInfo_var))->set_KeyAction_2(((Action_1_t2117217084 *)CastclassSealed((RuntimeObject*)L_4, Action_1_t2117217084_il2cpp_TypeInfo_var)));
		IntPtr_t L_5;
		L_5.set_m_value_0((void*)(void*)MoveCharacter_Jump_m768547604_RuntimeMethod_var);
		Action_t4042858631 * L_6 = (Action_t4042858631 *)il2cpp_codegen_object_new(Action_t4042858631_il2cpp_TypeInfo_var);
		Action__ctor_m2628370505(L_6, __this, L_5, /*hidden argument*/NULL);
		((PlayerInput_t3450109778_StaticFields*)il2cpp_codegen_static_fields_for(PlayerInput_t3450109778_il2cpp_TypeInfo_var))->set_JumpAction_3(L_6);
		return;
	}
}
// System.Void MoveCharacter::Move(System.Single)
extern "C"  void MoveCharacter_Move_m3498876582 (MoveCharacter_t2492455991 * __this, float ____movement0, const RuntimeMethod* method)
{
	{
		Vector3_t2987449647 * L_0 = __this->get_address_of_tempMove_3();
		Vector3_t2987449647 * L_1 = L_0;
		float L_2 = L_1->get_y_2();
		float L_3 = __this->get_gravity_5();
		float L_4 = Time_get_deltaTime_m3885432000(NULL /*static, unused*/, /*hidden argument*/NULL);
		L_1->set_y_2(((float)((float)L_2-(float)((float)((float)L_3*(float)L_4)))));
		Vector3_t2987449647 * L_5 = __this->get_address_of_tempMove_3();
		float L_6 = ____movement0;
		float L_7 = __this->get_speed_4();
		float L_8 = Time_get_deltaTime_m3885432000(NULL /*static, unused*/, /*hidden argument*/NULL);
		L_5->set_x_1(((float)((float)((float)((float)L_6*(float)L_7))*(float)L_8)));
		CharacterController_t2965295687 * L_9 = __this->get_cc_2();
		Vector3_t2987449647  L_10 = __this->get_tempMove_3();
		CharacterController_Move_m900161214(L_9, L_10, /*hidden argument*/NULL);
		return;
	}
}
// System.Void MoveCharacter::Jump()
extern "C"  void MoveCharacter_Jump_m768547604 (MoveCharacter_t2492455991 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MoveCharacter_Jump_m768547604_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Vector3_t2987449647 * L_0 = __this->get_address_of_tempMove_3();
		float L_1 = __this->get_jumpHeight_6();
		L_0->set_y_2(L_1);
		int32_t L_2 = __this->get_jumpScore_7();
		__this->set_jumpScore_7(((int32_t)((int32_t)L_2+(int32_t)1)));
		CharacterController_t2965295687 * L_3 = __this->get_cc_2();
		bool L_4 = CharacterController_get_isGrounded_m3015943198(L_3, /*hidden argument*/NULL);
		if (!L_4)
		{
			goto IL_0051;
		}
	}
	{
		__this->set_jumpScore_7(0);
		__this->set_jumpHeight_6((0.3f));
		int32_t L_5 = __this->get_jumpScore_7();
		int32_t L_6 = L_5;
		RuntimeObject * L_7 = Box(Int32_t438220675_il2cpp_TypeInfo_var, &L_6);
		MonoBehaviour_print_m134029734(NULL /*static, unused*/, L_7, /*hidden argument*/NULL);
	}

IL_0051:
	{
		CharacterController_t2965295687 * L_8 = __this->get_cc_2();
		bool L_9 = CharacterController_get_isGrounded_m3015943198(L_8, /*hidden argument*/NULL);
		if (L_9)
		{
			goto IL_0080;
		}
	}
	{
		int32_t L_10 = __this->get_jumpScore_7();
		int32_t L_11 = __this->get_maxJump_8();
		if ((((int32_t)L_10) >= ((int32_t)L_11)))
		{
			goto IL_0080;
		}
	}
	{
		int32_t L_12 = __this->get_jumpScore_7();
		__this->set_jumpScore_7(((int32_t)((int32_t)L_12+(int32_t)1)));
	}

IL_0080:
	{
		CharacterController_t2965295687 * L_13 = __this->get_cc_2();
		bool L_14 = CharacterController_get_isGrounded_m3015943198(L_13, /*hidden argument*/NULL);
		if (L_14)
		{
			goto IL_00ac;
		}
	}
	{
		int32_t L_15 = __this->get_jumpScore_7();
		int32_t L_16 = __this->get_maxJump_8();
		if ((((int32_t)L_15) < ((int32_t)L_16)))
		{
			goto IL_00ac;
		}
	}
	{
		__this->set_jumpHeight_6((0.0f));
	}

IL_00ac:
	{
		return;
	}
}
// System.Void MoveObject::.ctor()
extern "C"  void MoveObject__ctor_m403285747 (MoveObject_t260185650 * __this, const RuntimeMethod* method)
{
	{
		__this->set_pushForce_2((2.0f));
		MonoBehaviour__ctor_m1236242179(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void MoveObject::OnControllerColliderHit(UnityEngine.ControllerColliderHit)
extern "C"  void MoveObject_OnControllerColliderHit_m4083205808 (MoveObject_t260185650 * __this, ControllerColliderHit_t3057575995 * ___hit0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MoveObject_OnControllerColliderHit_m4083205808_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Rigidbody_t3670484383 * V_0 = NULL;
	Vector3_t2987449647  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Vector3_t2987449647  V_2;
	memset(&V_2, 0, sizeof(V_2));
	Vector3_t2987449647  V_3;
	memset(&V_3, 0, sizeof(V_3));
	Vector3_t2987449647  V_4;
	memset(&V_4, 0, sizeof(V_4));
	{
		ControllerColliderHit_t3057575995 * L_0 = ___hit0;
		Collider_t3066580567 * L_1 = ControllerColliderHit_get_collider_m2056607443(L_0, /*hidden argument*/NULL);
		Rigidbody_t3670484383 * L_2 = Collider_get_attachedRigidbody_m1223649037(L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		Rigidbody_t3670484383 * L_3 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_t3267094820_il2cpp_TypeInfo_var);
		bool L_4 = Object_op_Equality_m1841232993(NULL /*static, unused*/, L_3, (Object_t3267094820 *)NULL, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_0023;
		}
	}
	{
		Rigidbody_t3670484383 * L_5 = V_0;
		bool L_6 = Rigidbody_get_isKinematic_m3289074417(L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0024;
		}
	}

IL_0023:
	{
		return;
	}

IL_0024:
	{
		ControllerColliderHit_t3057575995 * L_7 = ___hit0;
		Vector3_t2987449647  L_8 = ControllerColliderHit_get_moveDirection_m1063174902(L_7, /*hidden argument*/NULL);
		V_1 = L_8;
		float L_9 = (&V_1)->get_y_2();
		if ((!(((float)L_9) < ((float)(-0.3f)))))
		{
			goto IL_003d;
		}
	}
	{
		return;
	}

IL_003d:
	{
		ControllerColliderHit_t3057575995 * L_10 = ___hit0;
		Vector3_t2987449647  L_11 = ControllerColliderHit_get_moveDirection_m1063174902(L_10, /*hidden argument*/NULL);
		V_3 = L_11;
		float L_12 = (&V_3)->get_x_1();
		ControllerColliderHit_t3057575995 * L_13 = ___hit0;
		Vector3_t2987449647  L_14 = ControllerColliderHit_get_moveDirection_m1063174902(L_13, /*hidden argument*/NULL);
		V_4 = L_14;
		float L_15 = (&V_4)->get_y_2();
		Vector3__ctor_m4052953749((&V_2), L_12, (0.0f), L_15, /*hidden argument*/NULL);
		Rigidbody_t3670484383 * L_16 = V_0;
		float L_17 = __this->get_pushForce_2();
		Vector3_t2987449647  L_18 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(Vector3_t2987449647_il2cpp_TypeInfo_var);
		Vector3_t2987449647  L_19 = Vector3_op_Multiply_m3725125284(NULL /*static, unused*/, L_17, L_18, /*hidden argument*/NULL);
		Rigidbody_set_velocity_m44238466(L_16, L_19, /*hidden argument*/NULL);
		return;
	}
}
// System.Void PlatformTrigger::.ctor()
extern "C"  void PlatformTrigger__ctor_m684306013 (PlatformTrigger_t1464797062 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_m1236242179(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void PlatformTrigger::Start()
extern "C"  void PlatformTrigger_Start_m434823051 (PlatformTrigger_t1464797062 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PlatformTrigger_Start_m434823051_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GameObject_t2602266141 * L_0 = GameObject_Find_m357843493(NULL /*static, unused*/, _stringLiteral3502315773, /*hidden argument*/NULL);
		__this->set_pp_2(L_0);
		GameObject_t2602266141 * L_1 = __this->get_pp_2();
		GameObject_t2602266141 * L_2 = GameObject_get_gameObject_m1404374750(L_1, /*hidden argument*/NULL);
		GameObject_SetActive_m924703582(L_2, (bool)0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void PlatformTrigger::OnTriggerEnter(UnityEngine.Collider)
extern "C"  void PlatformTrigger_OnTriggerEnter_m1123801430 (PlatformTrigger_t1464797062 * __this, Collider_t3066580567 * ___other0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PlatformTrigger_OnTriggerEnter_m1123801430_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Transform_t2636691836 * V_0 = NULL;
	RuntimeObject* V_1 = NULL;
	RuntimeObject* V_2 = NULL;
	Exception_t2443218823 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t2443218823 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		Collider_t3066580567 * L_0 = ___other0;
		String_t* L_1 = Object_get_name_m4131808298(L_0, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_2 = String_op_Equality_m2935810047(NULL /*static, unused*/, L_1, _stringLiteral542685270, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0076;
		}
	}
	{
		MonoBehaviour_print_m134029734(NULL /*static, unused*/, _stringLiteral1248389808, /*hidden argument*/NULL);
		GameObject_t2602266141 * L_3 = __this->get_pp_2();
		Transform_t2636691836 * L_4 = GameObject_get_transform_m3351892996(L_3, /*hidden argument*/NULL);
		RuntimeObject* L_5 = Transform_GetEnumerator_m454680747(L_4, /*hidden argument*/NULL);
		V_1 = L_5;
	}

IL_0030:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0052;
		}

IL_0035:
		{
			RuntimeObject* L_6 = V_1;
			RuntimeObject * L_7 = InterfaceFuncInvoker0< RuntimeObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t2340204891_il2cpp_TypeInfo_var, L_6);
			V_0 = ((Transform_t2636691836 *)CastclassClass((RuntimeObject*)L_7, Transform_t2636691836_il2cpp_TypeInfo_var));
			GameObject_t2602266141 * L_8 = __this->get_pp_2();
			GameObject_t2602266141 * L_9 = GameObject_get_gameObject_m1404374750(L_8, /*hidden argument*/NULL);
			GameObject_SetActive_m924703582(L_9, (bool)1, /*hidden argument*/NULL);
		}

IL_0052:
		{
			RuntimeObject* L_10 = V_1;
			bool L_11 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t2340204891_il2cpp_TypeInfo_var, L_10);
			if (L_11)
			{
				goto IL_0035;
			}
		}

IL_005d:
		{
			IL2CPP_LEAVE(0x76, FINALLY_0062);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t2443218823 *)e.ex;
		goto FINALLY_0062;
	}

FINALLY_0062:
	{ // begin finally (depth: 1)
		{
			RuntimeObject* L_12 = V_1;
			RuntimeObject* L_13 = ((RuntimeObject*)IsInst((RuntimeObject*)L_12, IDisposable_t1854990027_il2cpp_TypeInfo_var));
			V_2 = L_13;
			if (!L_13)
			{
				goto IL_0075;
			}
		}

IL_006f:
		{
			RuntimeObject* L_14 = V_2;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t1854990027_il2cpp_TypeInfo_var, L_14);
		}

IL_0075:
		{
			IL2CPP_END_FINALLY(98)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(98)
	{
		IL2CPP_JUMP_TBL(0x76, IL_0076)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t2443218823 *)
	}

IL_0076:
	{
		return;
	}
}
// System.Void PlayerInput::.ctor()
extern "C"  void PlayerInput__ctor_m634196471 (PlayerInput_t3450109778 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_m1236242179(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void PlayerInput::Update()
extern "C"  void PlayerInput_Update_m1542141274 (PlayerInput_t3450109778 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PlayerInput_Update_m1542141274_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Action_1_t2117217084 * L_0 = ((PlayerInput_t3450109778_StaticFields*)il2cpp_codegen_static_fields_for(PlayerInput_t3450109778_il2cpp_TypeInfo_var))->get_KeyAction_2();
		if (!L_0)
		{
			goto IL_001e;
		}
	}
	{
		Action_1_t2117217084 * L_1 = ((PlayerInput_t3450109778_StaticFields*)il2cpp_codegen_static_fields_for(PlayerInput_t3450109778_il2cpp_TypeInfo_var))->get_KeyAction_2();
		IL2CPP_RUNTIME_CLASS_INIT(Input_t1429468892_il2cpp_TypeInfo_var);
		float L_2 = Input_GetAxis_m1666418521(NULL /*static, unused*/, _stringLiteral3687474370, /*hidden argument*/NULL);
		Action_1_Invoke_m1323436125(L_1, L_2, /*hidden argument*/Action_1_Invoke_m1323436125_RuntimeMethod_var);
	}

IL_001e:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Input_t1429468892_il2cpp_TypeInfo_var);
		bool L_3 = Input_GetKeyDown_m1509524102(NULL /*static, unused*/, ((int32_t)32), /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0034;
		}
	}
	{
		Action_t4042858631 * L_4 = ((PlayerInput_t3450109778_StaticFields*)il2cpp_codegen_static_fields_for(PlayerInput_t3450109778_il2cpp_TypeInfo_var))->get_JumpAction_3();
		Action_Invoke_m461827263(L_4, /*hidden argument*/NULL);
	}

IL_0034:
	{
		return;
	}
}
// System.Void PushObject::.ctor()
extern "C"  void PushObject__ctor_m3866911932 (PushObject_t3539098884 * __this, const RuntimeMethod* method)
{
	{
		__this->set_pushForce_2((3.0f));
		MonoBehaviour__ctor_m1236242179(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void PushObject::OnControllerColliderHit(UnityEngine.ControllerColliderHit)
extern "C"  void PushObject_OnControllerColliderHit_m3319051333 (PushObject_t3539098884 * __this, ControllerColliderHit_t3057575995 * ___hit0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PushObject_OnControllerColliderHit_m3319051333_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Rigidbody_t3670484383 * V_0 = NULL;
	Vector3_t2987449647  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Vector3_t2987449647  V_2;
	memset(&V_2, 0, sizeof(V_2));
	Vector3_t2987449647  V_3;
	memset(&V_3, 0, sizeof(V_3));
	Vector3_t2987449647  V_4;
	memset(&V_4, 0, sizeof(V_4));
	{
		IL2CPP_RUNTIME_CLASS_INIT(PushObject_t3539098884_il2cpp_TypeInfo_var);
		((PushObject_t3539098884_StaticFields*)il2cpp_codegen_static_fields_for(PushObject_t3539098884_il2cpp_TypeInfo_var))->set_fallen_3((bool)1);
		ControllerColliderHit_t3057575995 * L_0 = ___hit0;
		Collider_t3066580567 * L_1 = ControllerColliderHit_get_collider_m2056607443(L_0, /*hidden argument*/NULL);
		Rigidbody_t3670484383 * L_2 = Collider_get_attachedRigidbody_m1223649037(L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		Rigidbody_t3670484383 * L_3 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Object_t3267094820_il2cpp_TypeInfo_var);
		bool L_4 = Object_op_Equality_m1841232993(NULL /*static, unused*/, L_3, (Object_t3267094820 *)NULL, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_0029;
		}
	}
	{
		Rigidbody_t3670484383 * L_5 = V_0;
		bool L_6 = Rigidbody_get_isKinematic_m3289074417(L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_002a;
		}
	}

IL_0029:
	{
		return;
	}

IL_002a:
	{
		ControllerColliderHit_t3057575995 * L_7 = ___hit0;
		Vector3_t2987449647  L_8 = ControllerColliderHit_get_moveDirection_m1063174902(L_7, /*hidden argument*/NULL);
		V_1 = L_8;
		float L_9 = (&V_1)->get_y_2();
		if ((!(((float)L_9) < ((float)(-0.3f)))))
		{
			goto IL_0043;
		}
	}
	{
		return;
	}

IL_0043:
	{
		ControllerColliderHit_t3057575995 * L_10 = ___hit0;
		Vector3_t2987449647  L_11 = ControllerColliderHit_get_moveDirection_m1063174902(L_10, /*hidden argument*/NULL);
		V_3 = L_11;
		float L_12 = (&V_3)->get_x_1();
		ControllerColliderHit_t3057575995 * L_13 = ___hit0;
		Vector3_t2987449647  L_14 = ControllerColliderHit_get_moveDirection_m1063174902(L_13, /*hidden argument*/NULL);
		V_4 = L_14;
		float L_15 = (&V_4)->get_y_2();
		Vector3__ctor_m4052953749((&V_2), L_12, (0.0f), L_15, /*hidden argument*/NULL);
		Rigidbody_t3670484383 * L_16 = V_0;
		float L_17 = __this->get_pushForce_2();
		Vector3_t2987449647  L_18 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(Vector3_t2987449647_il2cpp_TypeInfo_var);
		Vector3_t2987449647  L_19 = Vector3_op_Multiply_m3725125284(NULL /*static, unused*/, L_17, L_18, /*hidden argument*/NULL);
		Rigidbody_set_velocity_m44238466(L_16, L_19, /*hidden argument*/NULL);
		PushObject_test_m2222389076(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void PushObject::test()
extern "C"  void PushObject_test_m2222389076 (PushObject_t3539098884 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PushObject_test_m2222389076_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(PushObject_t3539098884_il2cpp_TypeInfo_var);
		bool L_0 = ((PushObject_t3539098884_StaticFields*)il2cpp_codegen_static_fields_for(PushObject_t3539098884_il2cpp_TypeInfo_var))->get_fallen_3();
		if (!L_0)
		{
			goto IL_0017;
		}
	}
	{
		Rigidbody_t3670484383 * L_1 = Component_GetComponent_TisRigidbody_t3670484383_m1187311617(__this, /*hidden argument*/Component_GetComponent_TisRigidbody_t3670484383_m1187311617_RuntimeMethod_var);
		Rigidbody_set_constraints_m1675396742(L_1, ((int32_t)80), /*hidden argument*/NULL);
	}

IL_0017:
	{
		return;
	}
}
// System.Void PushObject::.cctor()
extern "C"  void PushObject__cctor_m933835445 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method)
{
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
