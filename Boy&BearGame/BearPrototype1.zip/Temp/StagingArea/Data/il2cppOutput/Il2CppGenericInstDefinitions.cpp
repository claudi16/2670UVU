﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"




extern const Il2CppType RuntimeObject_0_0_0;
extern const Il2CppType Int32_t438220675_0_0_0;
extern const Il2CppType Char_t4217985068_0_0_0;
extern const Il2CppType Int64_t3733094498_0_0_0;
extern const Il2CppType UInt32_t1752406861_0_0_0;
extern const Il2CppType UInt64_t1261996727_0_0_0;
extern const Il2CppType Byte_t1695016127_0_0_0;
extern const Il2CppType SByte_t1526744772_0_0_0;
extern const Il2CppType Int16_t674212087_0_0_0;
extern const Il2CppType UInt16_t2530548644_0_0_0;
extern const Il2CppType String_t_0_0_0;
extern const Il2CppType IConvertible_t893085710_0_0_0;
extern const Il2CppType IComparable_t242364074_0_0_0;
extern const Il2CppType IEnumerable_t1561071510_0_0_0;
extern const Il2CppType ICloneable_t3275016770_0_0_0;
extern const Il2CppType IComparable_1_t1512452349_0_0_0;
extern const Il2CppType IEquatable_1_t3218538922_0_0_0;
extern const Il2CppType Type_t_0_0_0;
extern const Il2CppType IReflect_t3760602010_0_0_0;
extern const Il2CppType _Type_t3776473474_0_0_0;
extern const Il2CppType MemberInfo_t_0_0_0;
extern const Il2CppType ICustomAttributeProvider_t2305050174_0_0_0;
extern const Il2CppType _MemberInfo_t3276260911_0_0_0;
extern const Il2CppType Single_t3678960876_0_0_0;
extern const Il2CppType Double_t3420139759_0_0_0;
extern const Il2CppType Decimal_t2382302464_0_0_0;
extern const Il2CppType Boolean_t402932760_0_0_0;
extern const Il2CppType Delegate_t2990640460_0_0_0;
extern const Il2CppType ISerializable_t3453043479_0_0_0;
extern const Il2CppType ParameterInfo_t3793757615_0_0_0;
extern const Il2CppType _ParameterInfo_t1133799119_0_0_0;
extern const Il2CppType ParameterModifier_t1406754278_0_0_0;
extern const Il2CppType FieldInfo_t_0_0_0;
extern const Il2CppType _FieldInfo_t616591751_0_0_0;
extern const Il2CppType MethodInfo_t_0_0_0;
extern const Il2CppType _MethodInfo_t187796706_0_0_0;
extern const Il2CppType MethodBase_t2010470530_0_0_0;
extern const Il2CppType _MethodBase_t1718158610_0_0_0;
extern const Il2CppType ConstructorInfo_t2050809311_0_0_0;
extern const Il2CppType _ConstructorInfo_t3612455801_0_0_0;
extern const Il2CppType IntPtr_t_0_0_0;
extern const Il2CppType TableRange_t2080199027_0_0_0;
extern const Il2CppType TailoringInfo_t3419808840_0_0_0;
extern const Il2CppType KeyValuePair_2_t3710135120_0_0_0;
extern const Il2CppType Link_t808767725_0_0_0;
extern const Il2CppType DictionaryEntry_t578375704_0_0_0;
extern const Il2CppType KeyValuePair_2_t1201597358_0_0_0;
extern const Il2CppType Contraction_t3155759031_0_0_0;
extern const Il2CppType Level2Map_t2835147305_0_0_0;
extern const Il2CppType BigInteger_t964697200_0_0_0;
extern const Il2CppType KeySizes_t45689487_0_0_0;
extern const Il2CppType KeyValuePair_2_t3369932832_0_0_0;
extern const Il2CppType Slot_t2703514113_0_0_0;
extern const Il2CppType Slot_t2810825829_0_0_0;
extern const Il2CppType StackFrame_t1838224435_0_0_0;
extern const Il2CppType Calendar_t4269329426_0_0_0;
extern const Il2CppType ModuleBuilder_t3159331943_0_0_0;
extern const Il2CppType _ModuleBuilder_t234448247_0_0_0;
extern const Il2CppType Module_t3479515451_0_0_0;
extern const Il2CppType _Module_t107875809_0_0_0;
extern const Il2CppType ParameterBuilder_t3753085247_0_0_0;
extern const Il2CppType _ParameterBuilder_t1036287219_0_0_0;
extern const Il2CppType TypeU5BU5D_t1722708557_0_0_0;
extern const Il2CppType RuntimeArray_0_0_0;
extern const Il2CppType ICollection_t2613627688_0_0_0;
extern const Il2CppType IList_t480837924_0_0_0;
extern const Il2CppType IList_1_t90195417_0_0_0;
extern const Il2CppType ICollection_1_t3264224467_0_0_0;
extern const Il2CppType IEnumerable_1_t2120654357_0_0_0;
extern const Il2CppType IList_1_t1605682895_0_0_0;
extern const Il2CppType ICollection_1_t484744649_0_0_0;
extern const Il2CppType IEnumerable_1_t3636141835_0_0_0;
extern const Il2CppType IList_1_t1621554359_0_0_0;
extern const Il2CppType ICollection_1_t500616113_0_0_0;
extern const Il2CppType IEnumerable_1_t3652013299_0_0_0;
extern const Il2CppType IList_1_t2289122548_0_0_0;
extern const Il2CppType ICollection_1_t1168184302_0_0_0;
extern const Il2CppType IEnumerable_1_t24614192_0_0_0;
extern const Il2CppType IList_1_t150131059_0_0_0;
extern const Il2CppType ICollection_1_t3324160109_0_0_0;
extern const Il2CppType IEnumerable_1_t2180589999_0_0_0;
extern const Il2CppType IList_1_t1121341796_0_0_0;
extern const Il2CppType ICollection_1_t403550_0_0_0;
extern const Il2CppType IEnumerable_1_t3151800736_0_0_0;
extern const Il2CppType IList_1_t2238066568_0_0_0;
extern const Il2CppType ICollection_1_t1117128322_0_0_0;
extern const Il2CppType IEnumerable_1_t4268525508_0_0_0;
extern const Il2CppType ILTokenInfo_t3857000042_0_0_0;
extern const Il2CppType LabelData_t2222154365_0_0_0;
extern const Il2CppType LabelFixup_t426630335_0_0_0;
extern const Il2CppType GenericTypeParameterBuilder_t1019212843_0_0_0;
extern const Il2CppType TypeBuilder_t3350860216_0_0_0;
extern const Il2CppType _TypeBuilder_t47360046_0_0_0;
extern const Il2CppType MethodBuilder_t434851514_0_0_0;
extern const Il2CppType _MethodBuilder_t1063350594_0_0_0;
extern const Il2CppType ConstructorBuilder_t1269217984_0_0_0;
extern const Il2CppType _ConstructorBuilder_t2590771407_0_0_0;
extern const Il2CppType FieldBuilder_t2373739222_0_0_0;
extern const Il2CppType _FieldBuilder_t3411354663_0_0_0;
extern const Il2CppType PropertyInfo_t_0_0_0;
extern const Il2CppType _PropertyInfo_t4067770872_0_0_0;
extern const Il2CppType CustomAttributeTypedArgument_t2066493570_0_0_0;
extern const Il2CppType CustomAttributeNamedArgument_t3456585787_0_0_0;
extern const Il2CppType CustomAttributeData_t73279812_0_0_0;
extern const Il2CppType ResourceInfo_t1067968749_0_0_0;
extern const Il2CppType ResourceCacheItem_t2576962992_0_0_0;
extern const Il2CppType IContextProperty_t406597577_0_0_0;
extern const Il2CppType Header_t867743215_0_0_0;
extern const Il2CppType ITrackingHandler_t974392511_0_0_0;
extern const Il2CppType IContextAttribute_t831350911_0_0_0;
extern const Il2CppType DateTime_t3836236387_0_0_0;
extern const Il2CppType TimeSpan_t4182925364_0_0_0;
extern const Il2CppType TypeTag_t1823465210_0_0_0;
extern const Il2CppType MonoType_t_0_0_0;
extern const Il2CppType StrongName_t2472190370_0_0_0;
extern const Il2CppType IBuiltInEvidence_t2042430021_0_0_0;
extern const Il2CppType IIdentityPermissionFactory_t3494792867_0_0_0;
extern const Il2CppType DateTimeOffset_t3036919142_0_0_0;
extern const Il2CppType Guid_t_0_0_0;
extern const Il2CppType Version_t3942069453_0_0_0;
extern const Il2CppType KeyValuePair_2_t3674847205_0_0_0;
extern const Il2CppType KeyValuePair_2_t1166309443_0_0_0;
extern const Il2CppType X509Certificate_t4268988265_0_0_0;
extern const Il2CppType IDeserializationCallback_t706750576_0_0_0;
extern const Il2CppType X509ChainStatus_t2329993372_0_0_0;
extern const Il2CppType Capture_t1091228552_0_0_0;
extern const Il2CppType Group_t2387438183_0_0_0;
extern const Il2CppType Mark_t3306160088_0_0_0;
extern const Il2CppType UriScheme_t2520867868_0_0_0;
extern const Il2CppType BigInteger_t964697201_0_0_0;
extern const Il2CppType ByteU5BU5D_t3003616614_0_0_0;
extern const Il2CppType IList_1_t3835064308_0_0_0;
extern const Il2CppType ICollection_1_t2714126062_0_0_0;
extern const Il2CppType IEnumerable_1_t1570555952_0_0_0;
extern const Il2CppType ClientCertificateType_t2095209863_0_0_0;
extern const Il2CppType Object_t3267094820_0_0_0;
extern const Il2CppType Camera_t142011664_0_0_0;
extern const Il2CppType Behaviour_t2953351352_0_0_0;
extern const Il2CppType Component_t21088299_0_0_0;
extern const Il2CppType Display_t289224223_0_0_0;
extern const Il2CppType Keyframe_t1047575712_0_0_0;
extern const Il2CppType Playable_t3436777522_0_0_0;
extern const Il2CppType PlayableOutput_t758663699_0_0_0;
extern const Il2CppType Scene_t2009218140_0_0_0;
extern const Il2CppType LoadSceneMode_t136971723_0_0_0;
extern const Il2CppType SpriteAtlas_t2914147186_0_0_0;
extern const Il2CppType ContactPoint_t3765348581_0_0_0;
extern const Il2CppType RaycastHit_t2786726017_0_0_0;
extern const Il2CppType AudioClipPlayable_t3295732336_0_0_0;
extern const Il2CppType AudioMixerPlayable_t3345238233_0_0_0;
extern const Il2CppType Font_t208834271_0_0_0;
extern const Il2CppType KeyValuePair_2_t861395070_0_0_0;
extern const Il2CppType DisallowMultipleComponent_t1571297057_0_0_0;
extern const Il2CppType Attribute_t1821863933_0_0_0;
extern const Il2CppType _Attribute_t1412570690_0_0_0;
extern const Il2CppType ExecuteInEditMode_t2292583052_0_0_0;
extern const Il2CppType RequireComponent_t2231837482_0_0_0;
extern const Il2CppType HitInfo_t2681867412_0_0_0;
extern const Il2CppType PersistentCall_t183227066_0_0_0;
extern const Il2CppType BaseInvokableCall_t2607094378_0_0_0;
extern const Il2CppType WorkRequest_t3203378897_0_0_0;
extern const Il2CppType PlayableBinding_t2470704133_0_0_0;
extern const Il2CppType MessageTypeSubscribers_t4164304980_0_0_0;
extern const Il2CppType MessageEventArgs_t1276058715_0_0_0;
extern const Il2CppType WeakReference_t2646405993_0_0_0;
extern const Il2CppType KeyValuePair_2_t2173232590_0_0_0;
extern const Il2CppType KeyValuePair_2_t426652900_0_0_0;
extern const Il2CppType FieldWithTarget_t2257325677_0_0_0;
extern const Il2CppType IEnumerable_1_t1022578892_gp_0_0_0_0;
extern const Il2CppType Array_InternalArray__IEnumerable_GetEnumerator_m1669952694_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m1072890388_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m2260390429_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m2260390429_gp_1_0_0_0;
extern const Il2CppType Array_Sort_m2466936610_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m1673438336_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m1673438336_gp_1_0_0_0;
extern const Il2CppType Array_Sort_m4275090730_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m2213423065_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m2213423065_gp_1_0_0_0;
extern const Il2CppType Array_Sort_m3813128040_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m2658527309_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m2658527309_gp_1_0_0_0;
extern const Il2CppType Array_Sort_m972389192_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m649440607_gp_0_0_0_0;
extern const Il2CppType Array_qsort_m209006070_gp_0_0_0_0;
extern const Il2CppType Array_qsort_m209006070_gp_1_0_0_0;
extern const Il2CppType Array_compare_m4182503070_gp_0_0_0_0;
extern const Il2CppType Array_qsort_m2221164107_gp_0_0_0_0;
extern const Il2CppType Array_Resize_m2100239636_gp_0_0_0_0;
extern const Il2CppType Array_TrueForAll_m3027858380_gp_0_0_0_0;
extern const Il2CppType Array_ForEach_m3706321912_gp_0_0_0_0;
extern const Il2CppType Array_ConvertAll_m3519299715_gp_0_0_0_0;
extern const Il2CppType Array_ConvertAll_m3519299715_gp_1_0_0_0;
extern const Il2CppType Array_FindLastIndex_m2214885193_gp_0_0_0_0;
extern const Il2CppType Array_FindLastIndex_m860191247_gp_0_0_0_0;
extern const Il2CppType Array_FindLastIndex_m1827158888_gp_0_0_0_0;
extern const Il2CppType Array_FindIndex_m2875137143_gp_0_0_0_0;
extern const Il2CppType Array_FindIndex_m2010363940_gp_0_0_0_0;
extern const Il2CppType Array_FindIndex_m3203021108_gp_0_0_0_0;
extern const Il2CppType Array_BinarySearch_m265843292_gp_0_0_0_0;
extern const Il2CppType Array_BinarySearch_m2054507326_gp_0_0_0_0;
extern const Il2CppType Array_BinarySearch_m2165578130_gp_0_0_0_0;
extern const Il2CppType Array_BinarySearch_m1225743805_gp_0_0_0_0;
extern const Il2CppType Array_IndexOf_m326784914_gp_0_0_0_0;
extern const Il2CppType Array_IndexOf_m4162377550_gp_0_0_0_0;
extern const Il2CppType Array_IndexOf_m1433803741_gp_0_0_0_0;
extern const Il2CppType Array_LastIndexOf_m1870232505_gp_0_0_0_0;
extern const Il2CppType Array_LastIndexOf_m1925872913_gp_0_0_0_0;
extern const Il2CppType Array_LastIndexOf_m1095612650_gp_0_0_0_0;
extern const Il2CppType Array_FindAll_m4056086111_gp_0_0_0_0;
extern const Il2CppType Array_Exists_m3820198506_gp_0_0_0_0;
extern const Il2CppType Array_AsReadOnly_m2538139719_gp_0_0_0_0;
extern const Il2CppType Array_Find_m2107862747_gp_0_0_0_0;
extern const Il2CppType Array_FindLast_m1630072226_gp_0_0_0_0;
extern const Il2CppType InternalEnumerator_1_t511305203_gp_0_0_0_0;
extern const Il2CppType ArrayReadOnlyList_1_t1478687212_gp_0_0_0_0;
extern const Il2CppType U3CGetEnumeratorU3Ec__Iterator0_t3090871926_gp_0_0_0_0;
extern const Il2CppType IList_1_t822657584_gp_0_0_0_0;
extern const Il2CppType ICollection_1_t299879354_gp_0_0_0_0;
extern const Il2CppType Nullable_1_t3171292327_gp_0_0_0_0;
extern const Il2CppType Comparer_1_t612255760_gp_0_0_0_0;
extern const Il2CppType DefaultComparer_t4070014030_gp_0_0_0_0;
extern const Il2CppType GenericComparer_1_t1749919386_gp_0_0_0_0;
extern const Il2CppType Dictionary_2_t1155016036_gp_0_0_0_0;
extern const Il2CppType Dictionary_2_t1155016036_gp_1_0_0_0;
extern const Il2CppType KeyValuePair_2_t249753073_0_0_0;
extern const Il2CppType Dictionary_2_Do_CopyTo_m2742623902_gp_0_0_0_0;
extern const Il2CppType Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0;
extern const Il2CppType ShimEnumerator_t2146408712_gp_0_0_0_0;
extern const Il2CppType ShimEnumerator_t2146408712_gp_1_0_0_0;
extern const Il2CppType Enumerator_t1186497974_gp_0_0_0_0;
extern const Il2CppType Enumerator_t1186497974_gp_1_0_0_0;
extern const Il2CppType KeyValuePair_2_t2965215337_0_0_0;
extern const Il2CppType EqualityComparer_1_t3917655132_gp_0_0_0_0;
extern const Il2CppType DefaultComparer_t2413763153_gp_0_0_0_0;
extern const Il2CppType GenericEqualityComparer_1_t2616639575_gp_0_0_0_0;
extern const Il2CppType KeyValuePair_2_t2310743657_0_0_0;
extern const Il2CppType IDictionary_2_t332250678_gp_0_0_0_0;
extern const Il2CppType IDictionary_2_t332250678_gp_1_0_0_0;
extern const Il2CppType KeyValuePair_2_t3396090807_gp_0_0_0_0;
extern const Il2CppType KeyValuePair_2_t3396090807_gp_1_0_0_0;
extern const Il2CppType List_1_t2059616371_gp_0_0_0_0;
extern const Il2CppType Enumerator_t548538204_gp_0_0_0_0;
extern const Il2CppType Collection_1_t2882572264_gp_0_0_0_0;
extern const Il2CppType ReadOnlyCollection_1_t2481933861_gp_0_0_0_0;
extern const Il2CppType MonoProperty_GetterAdapterFrame_m1385778246_gp_0_0_0_0;
extern const Il2CppType MonoProperty_GetterAdapterFrame_m1385778246_gp_1_0_0_0;
extern const Il2CppType MonoProperty_StaticGetterAdapterFrame_m917416377_gp_0_0_0_0;
extern const Il2CppType Queue_1_t3027544886_gp_0_0_0_0;
extern const Il2CppType Enumerator_t1097944946_gp_0_0_0_0;
extern const Il2CppType Stack_1_t4283693321_gp_0_0_0_0;
extern const Il2CppType Enumerator_t3903841341_gp_0_0_0_0;
extern const Il2CppType Enumerable_Any_m437989361_gp_0_0_0_0;
extern const Il2CppType Enumerable_Where_m311029895_gp_0_0_0_0;
extern const Il2CppType Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0;
extern const Il2CppType U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentInChildren_m2013229797_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentsInChildren_m3349813871_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentsInChildren_m3768785598_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentsInChildren_m1145032281_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentsInChildren_m4128002223_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentsInParent_m1346221865_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentsInParent_m4108781761_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentsInParent_m704351154_gp_0_0_0_0;
extern const Il2CppType Component_GetComponents_m3735850386_gp_0_0_0_0;
extern const Il2CppType Component_GetComponents_m2761802573_gp_0_0_0_0;
extern const Il2CppType GameObject_GetComponentsInChildren_m3043092117_gp_0_0_0_0;
extern const Il2CppType GameObject_GetComponentsInParent_m2509003192_gp_0_0_0_0;
extern const Il2CppType Object_Instantiate_m620518311_gp_0_0_0_0;
extern const Il2CppType Object_FindObjectsOfType_m2502297032_gp_0_0_0_0;
extern const Il2CppType Playable_IsPlayableOfType_m3325280013_gp_0_0_0_0;
extern const Il2CppType PlayableOutput_IsPlayableOutputOfType_m3768091146_gp_0_0_0_0;
extern const Il2CppType InvokableCall_1_t3068523820_gp_0_0_0_0;
extern const Il2CppType UnityAction_1_t575283959_0_0_0;
extern const Il2CppType InvokableCall_2_t4124072994_gp_0_0_0_0;
extern const Il2CppType InvokableCall_2_t4124072994_gp_1_0_0_0;
extern const Il2CppType InvokableCall_3_t442739363_gp_0_0_0_0;
extern const Il2CppType InvokableCall_3_t442739363_gp_1_0_0_0;
extern const Il2CppType InvokableCall_3_t442739363_gp_2_0_0_0;
extern const Il2CppType InvokableCall_4_t3127597954_gp_0_0_0_0;
extern const Il2CppType InvokableCall_4_t3127597954_gp_1_0_0_0;
extern const Il2CppType InvokableCall_4_t3127597954_gp_2_0_0_0;
extern const Il2CppType InvokableCall_4_t3127597954_gp_3_0_0_0;
extern const Il2CppType CachedInvokableCall_1_t2741087613_gp_0_0_0_0;
extern const Il2CppType UnityEvent_1_t664801528_gp_0_0_0_0;
extern const Il2CppType UnityEvent_2_t3195527707_gp_0_0_0_0;
extern const Il2CppType UnityEvent_2_t3195527707_gp_1_0_0_0;
extern const Il2CppType UnityEvent_3_t180400136_gp_0_0_0_0;
extern const Il2CppType UnityEvent_3_t180400136_gp_1_0_0_0;
extern const Il2CppType UnityEvent_3_t180400136_gp_2_0_0_0;
extern const Il2CppType UnityEvent_4_t316486966_gp_0_0_0_0;
extern const Il2CppType UnityEvent_4_t316486966_gp_1_0_0_0;
extern const Il2CppType UnityEvent_4_t316486966_gp_2_0_0_0;
extern const Il2CppType UnityEvent_4_t316486966_gp_3_0_0_0;
extern const Il2CppType DefaultExecutionOrder_t1687762308_0_0_0;
extern const Il2CppType AudioPlayableOutput_t2616039667_0_0_0;
extern const Il2CppType PlayerConnection_t1218065583_0_0_0;
extern const Il2CppType ScriptPlayableOutput_t2716968363_0_0_0;
extern const Il2CppType GUILayer_t3734926407_0_0_0;
extern const Il2CppType Rigidbody_t3670484383_0_0_0;
extern const Il2CppType CharacterController_t2965295687_0_0_0;




static const RuntimeType* GenInst_RuntimeObject_0_0_0_Types[] = { (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0 = { 1, GenInst_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t438220675_0_0_0_Types[] = { (&Int32_t438220675_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t438220675_0_0_0 = { 1, GenInst_Int32_t438220675_0_0_0_Types };
static const RuntimeType* GenInst_Char_t4217985068_0_0_0_Types[] = { (&Char_t4217985068_0_0_0) };
extern const Il2CppGenericInst GenInst_Char_t4217985068_0_0_0 = { 1, GenInst_Char_t4217985068_0_0_0_Types };
static const RuntimeType* GenInst_Int64_t3733094498_0_0_0_Types[] = { (&Int64_t3733094498_0_0_0) };
extern const Il2CppGenericInst GenInst_Int64_t3733094498_0_0_0 = { 1, GenInst_Int64_t3733094498_0_0_0_Types };
static const RuntimeType* GenInst_UInt32_t1752406861_0_0_0_Types[] = { (&UInt32_t1752406861_0_0_0) };
extern const Il2CppGenericInst GenInst_UInt32_t1752406861_0_0_0 = { 1, GenInst_UInt32_t1752406861_0_0_0_Types };
static const RuntimeType* GenInst_UInt64_t1261996727_0_0_0_Types[] = { (&UInt64_t1261996727_0_0_0) };
extern const Il2CppGenericInst GenInst_UInt64_t1261996727_0_0_0 = { 1, GenInst_UInt64_t1261996727_0_0_0_Types };
static const RuntimeType* GenInst_Byte_t1695016127_0_0_0_Types[] = { (&Byte_t1695016127_0_0_0) };
extern const Il2CppGenericInst GenInst_Byte_t1695016127_0_0_0 = { 1, GenInst_Byte_t1695016127_0_0_0_Types };
static const RuntimeType* GenInst_SByte_t1526744772_0_0_0_Types[] = { (&SByte_t1526744772_0_0_0) };
extern const Il2CppGenericInst GenInst_SByte_t1526744772_0_0_0 = { 1, GenInst_SByte_t1526744772_0_0_0_Types };
static const RuntimeType* GenInst_Int16_t674212087_0_0_0_Types[] = { (&Int16_t674212087_0_0_0) };
extern const Il2CppGenericInst GenInst_Int16_t674212087_0_0_0 = { 1, GenInst_Int16_t674212087_0_0_0_Types };
static const RuntimeType* GenInst_UInt16_t2530548644_0_0_0_Types[] = { (&UInt16_t2530548644_0_0_0) };
extern const Il2CppGenericInst GenInst_UInt16_t2530548644_0_0_0 = { 1, GenInst_UInt16_t2530548644_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Types[] = { (&String_t_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0 = { 1, GenInst_String_t_0_0_0_Types };
static const RuntimeType* GenInst_IConvertible_t893085710_0_0_0_Types[] = { (&IConvertible_t893085710_0_0_0) };
extern const Il2CppGenericInst GenInst_IConvertible_t893085710_0_0_0 = { 1, GenInst_IConvertible_t893085710_0_0_0_Types };
static const RuntimeType* GenInst_IComparable_t242364074_0_0_0_Types[] = { (&IComparable_t242364074_0_0_0) };
extern const Il2CppGenericInst GenInst_IComparable_t242364074_0_0_0 = { 1, GenInst_IComparable_t242364074_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_t1561071510_0_0_0_Types[] = { (&IEnumerable_t1561071510_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_t1561071510_0_0_0 = { 1, GenInst_IEnumerable_t1561071510_0_0_0_Types };
static const RuntimeType* GenInst_ICloneable_t3275016770_0_0_0_Types[] = { (&ICloneable_t3275016770_0_0_0) };
extern const Il2CppGenericInst GenInst_ICloneable_t3275016770_0_0_0 = { 1, GenInst_ICloneable_t3275016770_0_0_0_Types };
static const RuntimeType* GenInst_IComparable_1_t1512452349_0_0_0_Types[] = { (&IComparable_1_t1512452349_0_0_0) };
extern const Il2CppGenericInst GenInst_IComparable_1_t1512452349_0_0_0 = { 1, GenInst_IComparable_1_t1512452349_0_0_0_Types };
static const RuntimeType* GenInst_IEquatable_1_t3218538922_0_0_0_Types[] = { (&IEquatable_1_t3218538922_0_0_0) };
extern const Il2CppGenericInst GenInst_IEquatable_1_t3218538922_0_0_0 = { 1, GenInst_IEquatable_1_t3218538922_0_0_0_Types };
static const RuntimeType* GenInst_Type_t_0_0_0_Types[] = { (&Type_t_0_0_0) };
extern const Il2CppGenericInst GenInst_Type_t_0_0_0 = { 1, GenInst_Type_t_0_0_0_Types };
static const RuntimeType* GenInst_IReflect_t3760602010_0_0_0_Types[] = { (&IReflect_t3760602010_0_0_0) };
extern const Il2CppGenericInst GenInst_IReflect_t3760602010_0_0_0 = { 1, GenInst_IReflect_t3760602010_0_0_0_Types };
static const RuntimeType* GenInst__Type_t3776473474_0_0_0_Types[] = { (&_Type_t3776473474_0_0_0) };
extern const Il2CppGenericInst GenInst__Type_t3776473474_0_0_0 = { 1, GenInst__Type_t3776473474_0_0_0_Types };
static const RuntimeType* GenInst_MemberInfo_t_0_0_0_Types[] = { (&MemberInfo_t_0_0_0) };
extern const Il2CppGenericInst GenInst_MemberInfo_t_0_0_0 = { 1, GenInst_MemberInfo_t_0_0_0_Types };
static const RuntimeType* GenInst_ICustomAttributeProvider_t2305050174_0_0_0_Types[] = { (&ICustomAttributeProvider_t2305050174_0_0_0) };
extern const Il2CppGenericInst GenInst_ICustomAttributeProvider_t2305050174_0_0_0 = { 1, GenInst_ICustomAttributeProvider_t2305050174_0_0_0_Types };
static const RuntimeType* GenInst__MemberInfo_t3276260911_0_0_0_Types[] = { (&_MemberInfo_t3276260911_0_0_0) };
extern const Il2CppGenericInst GenInst__MemberInfo_t3276260911_0_0_0 = { 1, GenInst__MemberInfo_t3276260911_0_0_0_Types };
static const RuntimeType* GenInst_Single_t3678960876_0_0_0_Types[] = { (&Single_t3678960876_0_0_0) };
extern const Il2CppGenericInst GenInst_Single_t3678960876_0_0_0 = { 1, GenInst_Single_t3678960876_0_0_0_Types };
static const RuntimeType* GenInst_Double_t3420139759_0_0_0_Types[] = { (&Double_t3420139759_0_0_0) };
extern const Il2CppGenericInst GenInst_Double_t3420139759_0_0_0 = { 1, GenInst_Double_t3420139759_0_0_0_Types };
static const RuntimeType* GenInst_Decimal_t2382302464_0_0_0_Types[] = { (&Decimal_t2382302464_0_0_0) };
extern const Il2CppGenericInst GenInst_Decimal_t2382302464_0_0_0 = { 1, GenInst_Decimal_t2382302464_0_0_0_Types };
static const RuntimeType* GenInst_Boolean_t402932760_0_0_0_Types[] = { (&Boolean_t402932760_0_0_0) };
extern const Il2CppGenericInst GenInst_Boolean_t402932760_0_0_0 = { 1, GenInst_Boolean_t402932760_0_0_0_Types };
static const RuntimeType* GenInst_Delegate_t2990640460_0_0_0_Types[] = { (&Delegate_t2990640460_0_0_0) };
extern const Il2CppGenericInst GenInst_Delegate_t2990640460_0_0_0 = { 1, GenInst_Delegate_t2990640460_0_0_0_Types };
static const RuntimeType* GenInst_ISerializable_t3453043479_0_0_0_Types[] = { (&ISerializable_t3453043479_0_0_0) };
extern const Il2CppGenericInst GenInst_ISerializable_t3453043479_0_0_0 = { 1, GenInst_ISerializable_t3453043479_0_0_0_Types };
static const RuntimeType* GenInst_ParameterInfo_t3793757615_0_0_0_Types[] = { (&ParameterInfo_t3793757615_0_0_0) };
extern const Il2CppGenericInst GenInst_ParameterInfo_t3793757615_0_0_0 = { 1, GenInst_ParameterInfo_t3793757615_0_0_0_Types };
static const RuntimeType* GenInst__ParameterInfo_t1133799119_0_0_0_Types[] = { (&_ParameterInfo_t1133799119_0_0_0) };
extern const Il2CppGenericInst GenInst__ParameterInfo_t1133799119_0_0_0 = { 1, GenInst__ParameterInfo_t1133799119_0_0_0_Types };
static const RuntimeType* GenInst_ParameterModifier_t1406754278_0_0_0_Types[] = { (&ParameterModifier_t1406754278_0_0_0) };
extern const Il2CppGenericInst GenInst_ParameterModifier_t1406754278_0_0_0 = { 1, GenInst_ParameterModifier_t1406754278_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_FieldInfo_t_0_0_0_Types[] = { (&FieldInfo_t_0_0_0) };
extern const Il2CppGenericInst GenInst_FieldInfo_t_0_0_0 = { 1, GenInst_FieldInfo_t_0_0_0_Types };
static const RuntimeType* GenInst__FieldInfo_t616591751_0_0_0_Types[] = { (&_FieldInfo_t616591751_0_0_0) };
extern const Il2CppGenericInst GenInst__FieldInfo_t616591751_0_0_0 = { 1, GenInst__FieldInfo_t616591751_0_0_0_Types };
static const RuntimeType* GenInst_MethodInfo_t_0_0_0_Types[] = { (&MethodInfo_t_0_0_0) };
extern const Il2CppGenericInst GenInst_MethodInfo_t_0_0_0 = { 1, GenInst_MethodInfo_t_0_0_0_Types };
static const RuntimeType* GenInst__MethodInfo_t187796706_0_0_0_Types[] = { (&_MethodInfo_t187796706_0_0_0) };
extern const Il2CppGenericInst GenInst__MethodInfo_t187796706_0_0_0 = { 1, GenInst__MethodInfo_t187796706_0_0_0_Types };
static const RuntimeType* GenInst_MethodBase_t2010470530_0_0_0_Types[] = { (&MethodBase_t2010470530_0_0_0) };
extern const Il2CppGenericInst GenInst_MethodBase_t2010470530_0_0_0 = { 1, GenInst_MethodBase_t2010470530_0_0_0_Types };
static const RuntimeType* GenInst__MethodBase_t1718158610_0_0_0_Types[] = { (&_MethodBase_t1718158610_0_0_0) };
extern const Il2CppGenericInst GenInst__MethodBase_t1718158610_0_0_0 = { 1, GenInst__MethodBase_t1718158610_0_0_0_Types };
static const RuntimeType* GenInst_ConstructorInfo_t2050809311_0_0_0_Types[] = { (&ConstructorInfo_t2050809311_0_0_0) };
extern const Il2CppGenericInst GenInst_ConstructorInfo_t2050809311_0_0_0 = { 1, GenInst_ConstructorInfo_t2050809311_0_0_0_Types };
static const RuntimeType* GenInst__ConstructorInfo_t3612455801_0_0_0_Types[] = { (&_ConstructorInfo_t3612455801_0_0_0) };
extern const Il2CppGenericInst GenInst__ConstructorInfo_t3612455801_0_0_0 = { 1, GenInst__ConstructorInfo_t3612455801_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_Types[] = { (&IntPtr_t_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0 = { 1, GenInst_IntPtr_t_0_0_0_Types };
static const RuntimeType* GenInst_TableRange_t2080199027_0_0_0_Types[] = { (&TableRange_t2080199027_0_0_0) };
extern const Il2CppGenericInst GenInst_TableRange_t2080199027_0_0_0 = { 1, GenInst_TableRange_t2080199027_0_0_0_Types };
static const RuntimeType* GenInst_TailoringInfo_t3419808840_0_0_0_Types[] = { (&TailoringInfo_t3419808840_0_0_0) };
extern const Il2CppGenericInst GenInst_TailoringInfo_t3419808840_0_0_0 = { 1, GenInst_TailoringInfo_t3419808840_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Int32_t438220675_0_0_0_Types[] = { (&String_t_0_0_0), (&Int32_t438220675_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Int32_t438220675_0_0_0 = { 2, GenInst_String_t_0_0_0_Int32_t438220675_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Int32_t438220675_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0 = { 2, GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3710135120_0_0_0_Types[] = { (&KeyValuePair_2_t3710135120_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3710135120_0_0_0 = { 1, GenInst_KeyValuePair_2_t3710135120_0_0_0_Types };
static const RuntimeType* GenInst_Link_t808767725_0_0_0_Types[] = { (&Link_t808767725_0_0_0) };
extern const Il2CppGenericInst GenInst_Link_t808767725_0_0_0 = { 1, GenInst_Link_t808767725_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0_DictionaryEntry_t578375704_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Int32_t438220675_0_0_0), (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0_DictionaryEntry_t578375704_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_DictionaryEntry_t578375704_0_0_0_Types[] = { (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_DictionaryEntry_t578375704_0_0_0 = { 1, GenInst_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0_KeyValuePair_2_t3710135120_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Int32_t438220675_0_0_0), (&KeyValuePair_2_t3710135120_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0_KeyValuePair_2_t3710135120_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0_KeyValuePair_2_t3710135120_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Int32_t438220675_0_0_0_DictionaryEntry_t578375704_0_0_0_Types[] = { (&String_t_0_0_0), (&Int32_t438220675_0_0_0), (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Int32_t438220675_0_0_0_DictionaryEntry_t578375704_0_0_0 = { 3, GenInst_String_t_0_0_0_Int32_t438220675_0_0_0_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Int32_t438220675_0_0_0_KeyValuePair_2_t1201597358_0_0_0_Types[] = { (&String_t_0_0_0), (&Int32_t438220675_0_0_0), (&KeyValuePair_2_t1201597358_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Int32_t438220675_0_0_0_KeyValuePair_2_t1201597358_0_0_0 = { 3, GenInst_String_t_0_0_0_Int32_t438220675_0_0_0_KeyValuePair_2_t1201597358_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t1201597358_0_0_0_Types[] = { (&KeyValuePair_2_t1201597358_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t1201597358_0_0_0 = { 1, GenInst_KeyValuePair_2_t1201597358_0_0_0_Types };
static const RuntimeType* GenInst_Contraction_t3155759031_0_0_0_Types[] = { (&Contraction_t3155759031_0_0_0) };
extern const Il2CppGenericInst GenInst_Contraction_t3155759031_0_0_0 = { 1, GenInst_Contraction_t3155759031_0_0_0_Types };
static const RuntimeType* GenInst_Level2Map_t2835147305_0_0_0_Types[] = { (&Level2Map_t2835147305_0_0_0) };
extern const Il2CppGenericInst GenInst_Level2Map_t2835147305_0_0_0 = { 1, GenInst_Level2Map_t2835147305_0_0_0_Types };
static const RuntimeType* GenInst_BigInteger_t964697200_0_0_0_Types[] = { (&BigInteger_t964697200_0_0_0) };
extern const Il2CppGenericInst GenInst_BigInteger_t964697200_0_0_0 = { 1, GenInst_BigInteger_t964697200_0_0_0_Types };
static const RuntimeType* GenInst_KeySizes_t45689487_0_0_0_Types[] = { (&KeySizes_t45689487_0_0_0) };
extern const Il2CppGenericInst GenInst_KeySizes_t45689487_0_0_0 = { 1, GenInst_KeySizes_t45689487_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3369932832_0_0_0_Types[] = { (&KeyValuePair_2_t3369932832_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3369932832_0_0_0 = { 1, GenInst_KeyValuePair_2_t3369932832_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0), (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t3369932832_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0), (&KeyValuePair_2_t3369932832_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t3369932832_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t3369932832_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_Slot_t2703514113_0_0_0_Types[] = { (&Slot_t2703514113_0_0_0) };
extern const Il2CppGenericInst GenInst_Slot_t2703514113_0_0_0 = { 1, GenInst_Slot_t2703514113_0_0_0_Types };
static const RuntimeType* GenInst_Slot_t2810825829_0_0_0_Types[] = { (&Slot_t2810825829_0_0_0) };
extern const Il2CppGenericInst GenInst_Slot_t2810825829_0_0_0 = { 1, GenInst_Slot_t2810825829_0_0_0_Types };
static const RuntimeType* GenInst_StackFrame_t1838224435_0_0_0_Types[] = { (&StackFrame_t1838224435_0_0_0) };
extern const Il2CppGenericInst GenInst_StackFrame_t1838224435_0_0_0 = { 1, GenInst_StackFrame_t1838224435_0_0_0_Types };
static const RuntimeType* GenInst_Calendar_t4269329426_0_0_0_Types[] = { (&Calendar_t4269329426_0_0_0) };
extern const Il2CppGenericInst GenInst_Calendar_t4269329426_0_0_0 = { 1, GenInst_Calendar_t4269329426_0_0_0_Types };
static const RuntimeType* GenInst_ModuleBuilder_t3159331943_0_0_0_Types[] = { (&ModuleBuilder_t3159331943_0_0_0) };
extern const Il2CppGenericInst GenInst_ModuleBuilder_t3159331943_0_0_0 = { 1, GenInst_ModuleBuilder_t3159331943_0_0_0_Types };
static const RuntimeType* GenInst__ModuleBuilder_t234448247_0_0_0_Types[] = { (&_ModuleBuilder_t234448247_0_0_0) };
extern const Il2CppGenericInst GenInst__ModuleBuilder_t234448247_0_0_0 = { 1, GenInst__ModuleBuilder_t234448247_0_0_0_Types };
static const RuntimeType* GenInst_Module_t3479515451_0_0_0_Types[] = { (&Module_t3479515451_0_0_0) };
extern const Il2CppGenericInst GenInst_Module_t3479515451_0_0_0 = { 1, GenInst_Module_t3479515451_0_0_0_Types };
static const RuntimeType* GenInst__Module_t107875809_0_0_0_Types[] = { (&_Module_t107875809_0_0_0) };
extern const Il2CppGenericInst GenInst__Module_t107875809_0_0_0 = { 1, GenInst__Module_t107875809_0_0_0_Types };
static const RuntimeType* GenInst_ParameterBuilder_t3753085247_0_0_0_Types[] = { (&ParameterBuilder_t3753085247_0_0_0) };
extern const Il2CppGenericInst GenInst_ParameterBuilder_t3753085247_0_0_0 = { 1, GenInst_ParameterBuilder_t3753085247_0_0_0_Types };
static const RuntimeType* GenInst__ParameterBuilder_t1036287219_0_0_0_Types[] = { (&_ParameterBuilder_t1036287219_0_0_0) };
extern const Il2CppGenericInst GenInst__ParameterBuilder_t1036287219_0_0_0 = { 1, GenInst__ParameterBuilder_t1036287219_0_0_0_Types };
static const RuntimeType* GenInst_TypeU5BU5D_t1722708557_0_0_0_Types[] = { (&TypeU5BU5D_t1722708557_0_0_0) };
extern const Il2CppGenericInst GenInst_TypeU5BU5D_t1722708557_0_0_0 = { 1, GenInst_TypeU5BU5D_t1722708557_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeArray_0_0_0_Types[] = { (&RuntimeArray_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeArray_0_0_0 = { 1, GenInst_RuntimeArray_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_t2613627688_0_0_0_Types[] = { (&ICollection_t2613627688_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_t2613627688_0_0_0 = { 1, GenInst_ICollection_t2613627688_0_0_0_Types };
static const RuntimeType* GenInst_IList_t480837924_0_0_0_Types[] = { (&IList_t480837924_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_t480837924_0_0_0 = { 1, GenInst_IList_t480837924_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t90195417_0_0_0_Types[] = { (&IList_1_t90195417_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t90195417_0_0_0 = { 1, GenInst_IList_1_t90195417_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t3264224467_0_0_0_Types[] = { (&ICollection_1_t3264224467_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t3264224467_0_0_0 = { 1, GenInst_ICollection_1_t3264224467_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t2120654357_0_0_0_Types[] = { (&IEnumerable_1_t2120654357_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t2120654357_0_0_0 = { 1, GenInst_IEnumerable_1_t2120654357_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t1605682895_0_0_0_Types[] = { (&IList_1_t1605682895_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t1605682895_0_0_0 = { 1, GenInst_IList_1_t1605682895_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t484744649_0_0_0_Types[] = { (&ICollection_1_t484744649_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t484744649_0_0_0 = { 1, GenInst_ICollection_1_t484744649_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t3636141835_0_0_0_Types[] = { (&IEnumerable_1_t3636141835_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t3636141835_0_0_0 = { 1, GenInst_IEnumerable_1_t3636141835_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t1621554359_0_0_0_Types[] = { (&IList_1_t1621554359_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t1621554359_0_0_0 = { 1, GenInst_IList_1_t1621554359_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t500616113_0_0_0_Types[] = { (&ICollection_1_t500616113_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t500616113_0_0_0 = { 1, GenInst_ICollection_1_t500616113_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t3652013299_0_0_0_Types[] = { (&IEnumerable_1_t3652013299_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t3652013299_0_0_0 = { 1, GenInst_IEnumerable_1_t3652013299_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t2289122548_0_0_0_Types[] = { (&IList_1_t2289122548_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t2289122548_0_0_0 = { 1, GenInst_IList_1_t2289122548_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t1168184302_0_0_0_Types[] = { (&ICollection_1_t1168184302_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t1168184302_0_0_0 = { 1, GenInst_ICollection_1_t1168184302_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t24614192_0_0_0_Types[] = { (&IEnumerable_1_t24614192_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t24614192_0_0_0 = { 1, GenInst_IEnumerable_1_t24614192_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t150131059_0_0_0_Types[] = { (&IList_1_t150131059_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t150131059_0_0_0 = { 1, GenInst_IList_1_t150131059_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t3324160109_0_0_0_Types[] = { (&ICollection_1_t3324160109_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t3324160109_0_0_0 = { 1, GenInst_ICollection_1_t3324160109_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t2180589999_0_0_0_Types[] = { (&IEnumerable_1_t2180589999_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t2180589999_0_0_0 = { 1, GenInst_IEnumerable_1_t2180589999_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t1121341796_0_0_0_Types[] = { (&IList_1_t1121341796_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t1121341796_0_0_0 = { 1, GenInst_IList_1_t1121341796_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t403550_0_0_0_Types[] = { (&ICollection_1_t403550_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t403550_0_0_0 = { 1, GenInst_ICollection_1_t403550_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t3151800736_0_0_0_Types[] = { (&IEnumerable_1_t3151800736_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t3151800736_0_0_0 = { 1, GenInst_IEnumerable_1_t3151800736_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t2238066568_0_0_0_Types[] = { (&IList_1_t2238066568_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t2238066568_0_0_0 = { 1, GenInst_IList_1_t2238066568_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t1117128322_0_0_0_Types[] = { (&ICollection_1_t1117128322_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t1117128322_0_0_0 = { 1, GenInst_ICollection_1_t1117128322_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t4268525508_0_0_0_Types[] = { (&IEnumerable_1_t4268525508_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t4268525508_0_0_0 = { 1, GenInst_IEnumerable_1_t4268525508_0_0_0_Types };
static const RuntimeType* GenInst_ILTokenInfo_t3857000042_0_0_0_Types[] = { (&ILTokenInfo_t3857000042_0_0_0) };
extern const Il2CppGenericInst GenInst_ILTokenInfo_t3857000042_0_0_0 = { 1, GenInst_ILTokenInfo_t3857000042_0_0_0_Types };
static const RuntimeType* GenInst_LabelData_t2222154365_0_0_0_Types[] = { (&LabelData_t2222154365_0_0_0) };
extern const Il2CppGenericInst GenInst_LabelData_t2222154365_0_0_0 = { 1, GenInst_LabelData_t2222154365_0_0_0_Types };
static const RuntimeType* GenInst_LabelFixup_t426630335_0_0_0_Types[] = { (&LabelFixup_t426630335_0_0_0) };
extern const Il2CppGenericInst GenInst_LabelFixup_t426630335_0_0_0 = { 1, GenInst_LabelFixup_t426630335_0_0_0_Types };
static const RuntimeType* GenInst_GenericTypeParameterBuilder_t1019212843_0_0_0_Types[] = { (&GenericTypeParameterBuilder_t1019212843_0_0_0) };
extern const Il2CppGenericInst GenInst_GenericTypeParameterBuilder_t1019212843_0_0_0 = { 1, GenInst_GenericTypeParameterBuilder_t1019212843_0_0_0_Types };
static const RuntimeType* GenInst_TypeBuilder_t3350860216_0_0_0_Types[] = { (&TypeBuilder_t3350860216_0_0_0) };
extern const Il2CppGenericInst GenInst_TypeBuilder_t3350860216_0_0_0 = { 1, GenInst_TypeBuilder_t3350860216_0_0_0_Types };
static const RuntimeType* GenInst__TypeBuilder_t47360046_0_0_0_Types[] = { (&_TypeBuilder_t47360046_0_0_0) };
extern const Il2CppGenericInst GenInst__TypeBuilder_t47360046_0_0_0 = { 1, GenInst__TypeBuilder_t47360046_0_0_0_Types };
static const RuntimeType* GenInst_MethodBuilder_t434851514_0_0_0_Types[] = { (&MethodBuilder_t434851514_0_0_0) };
extern const Il2CppGenericInst GenInst_MethodBuilder_t434851514_0_0_0 = { 1, GenInst_MethodBuilder_t434851514_0_0_0_Types };
static const RuntimeType* GenInst__MethodBuilder_t1063350594_0_0_0_Types[] = { (&_MethodBuilder_t1063350594_0_0_0) };
extern const Il2CppGenericInst GenInst__MethodBuilder_t1063350594_0_0_0 = { 1, GenInst__MethodBuilder_t1063350594_0_0_0_Types };
static const RuntimeType* GenInst_ConstructorBuilder_t1269217984_0_0_0_Types[] = { (&ConstructorBuilder_t1269217984_0_0_0) };
extern const Il2CppGenericInst GenInst_ConstructorBuilder_t1269217984_0_0_0 = { 1, GenInst_ConstructorBuilder_t1269217984_0_0_0_Types };
static const RuntimeType* GenInst__ConstructorBuilder_t2590771407_0_0_0_Types[] = { (&_ConstructorBuilder_t2590771407_0_0_0) };
extern const Il2CppGenericInst GenInst__ConstructorBuilder_t2590771407_0_0_0 = { 1, GenInst__ConstructorBuilder_t2590771407_0_0_0_Types };
static const RuntimeType* GenInst_FieldBuilder_t2373739222_0_0_0_Types[] = { (&FieldBuilder_t2373739222_0_0_0) };
extern const Il2CppGenericInst GenInst_FieldBuilder_t2373739222_0_0_0 = { 1, GenInst_FieldBuilder_t2373739222_0_0_0_Types };
static const RuntimeType* GenInst__FieldBuilder_t3411354663_0_0_0_Types[] = { (&_FieldBuilder_t3411354663_0_0_0) };
extern const Il2CppGenericInst GenInst__FieldBuilder_t3411354663_0_0_0 = { 1, GenInst__FieldBuilder_t3411354663_0_0_0_Types };
static const RuntimeType* GenInst_PropertyInfo_t_0_0_0_Types[] = { (&PropertyInfo_t_0_0_0) };
extern const Il2CppGenericInst GenInst_PropertyInfo_t_0_0_0 = { 1, GenInst_PropertyInfo_t_0_0_0_Types };
static const RuntimeType* GenInst__PropertyInfo_t4067770872_0_0_0_Types[] = { (&_PropertyInfo_t4067770872_0_0_0) };
extern const Il2CppGenericInst GenInst__PropertyInfo_t4067770872_0_0_0 = { 1, GenInst__PropertyInfo_t4067770872_0_0_0_Types };
static const RuntimeType* GenInst_CustomAttributeTypedArgument_t2066493570_0_0_0_Types[] = { (&CustomAttributeTypedArgument_t2066493570_0_0_0) };
extern const Il2CppGenericInst GenInst_CustomAttributeTypedArgument_t2066493570_0_0_0 = { 1, GenInst_CustomAttributeTypedArgument_t2066493570_0_0_0_Types };
static const RuntimeType* GenInst_CustomAttributeNamedArgument_t3456585787_0_0_0_Types[] = { (&CustomAttributeNamedArgument_t3456585787_0_0_0) };
extern const Il2CppGenericInst GenInst_CustomAttributeNamedArgument_t3456585787_0_0_0 = { 1, GenInst_CustomAttributeNamedArgument_t3456585787_0_0_0_Types };
static const RuntimeType* GenInst_CustomAttributeData_t73279812_0_0_0_Types[] = { (&CustomAttributeData_t73279812_0_0_0) };
extern const Il2CppGenericInst GenInst_CustomAttributeData_t73279812_0_0_0 = { 1, GenInst_CustomAttributeData_t73279812_0_0_0_Types };
static const RuntimeType* GenInst_ResourceInfo_t1067968749_0_0_0_Types[] = { (&ResourceInfo_t1067968749_0_0_0) };
extern const Il2CppGenericInst GenInst_ResourceInfo_t1067968749_0_0_0 = { 1, GenInst_ResourceInfo_t1067968749_0_0_0_Types };
static const RuntimeType* GenInst_ResourceCacheItem_t2576962992_0_0_0_Types[] = { (&ResourceCacheItem_t2576962992_0_0_0) };
extern const Il2CppGenericInst GenInst_ResourceCacheItem_t2576962992_0_0_0 = { 1, GenInst_ResourceCacheItem_t2576962992_0_0_0_Types };
static const RuntimeType* GenInst_IContextProperty_t406597577_0_0_0_Types[] = { (&IContextProperty_t406597577_0_0_0) };
extern const Il2CppGenericInst GenInst_IContextProperty_t406597577_0_0_0 = { 1, GenInst_IContextProperty_t406597577_0_0_0_Types };
static const RuntimeType* GenInst_Header_t867743215_0_0_0_Types[] = { (&Header_t867743215_0_0_0) };
extern const Il2CppGenericInst GenInst_Header_t867743215_0_0_0 = { 1, GenInst_Header_t867743215_0_0_0_Types };
static const RuntimeType* GenInst_ITrackingHandler_t974392511_0_0_0_Types[] = { (&ITrackingHandler_t974392511_0_0_0) };
extern const Il2CppGenericInst GenInst_ITrackingHandler_t974392511_0_0_0 = { 1, GenInst_ITrackingHandler_t974392511_0_0_0_Types };
static const RuntimeType* GenInst_IContextAttribute_t831350911_0_0_0_Types[] = { (&IContextAttribute_t831350911_0_0_0) };
extern const Il2CppGenericInst GenInst_IContextAttribute_t831350911_0_0_0 = { 1, GenInst_IContextAttribute_t831350911_0_0_0_Types };
static const RuntimeType* GenInst_DateTime_t3836236387_0_0_0_Types[] = { (&DateTime_t3836236387_0_0_0) };
extern const Il2CppGenericInst GenInst_DateTime_t3836236387_0_0_0 = { 1, GenInst_DateTime_t3836236387_0_0_0_Types };
static const RuntimeType* GenInst_TimeSpan_t4182925364_0_0_0_Types[] = { (&TimeSpan_t4182925364_0_0_0) };
extern const Il2CppGenericInst GenInst_TimeSpan_t4182925364_0_0_0 = { 1, GenInst_TimeSpan_t4182925364_0_0_0_Types };
static const RuntimeType* GenInst_TypeTag_t1823465210_0_0_0_Types[] = { (&TypeTag_t1823465210_0_0_0) };
extern const Il2CppGenericInst GenInst_TypeTag_t1823465210_0_0_0 = { 1, GenInst_TypeTag_t1823465210_0_0_0_Types };
static const RuntimeType* GenInst_MonoType_t_0_0_0_Types[] = { (&MonoType_t_0_0_0) };
extern const Il2CppGenericInst GenInst_MonoType_t_0_0_0 = { 1, GenInst_MonoType_t_0_0_0_Types };
static const RuntimeType* GenInst_StrongName_t2472190370_0_0_0_Types[] = { (&StrongName_t2472190370_0_0_0) };
extern const Il2CppGenericInst GenInst_StrongName_t2472190370_0_0_0 = { 1, GenInst_StrongName_t2472190370_0_0_0_Types };
static const RuntimeType* GenInst_IBuiltInEvidence_t2042430021_0_0_0_Types[] = { (&IBuiltInEvidence_t2042430021_0_0_0) };
extern const Il2CppGenericInst GenInst_IBuiltInEvidence_t2042430021_0_0_0 = { 1, GenInst_IBuiltInEvidence_t2042430021_0_0_0_Types };
static const RuntimeType* GenInst_IIdentityPermissionFactory_t3494792867_0_0_0_Types[] = { (&IIdentityPermissionFactory_t3494792867_0_0_0) };
extern const Il2CppGenericInst GenInst_IIdentityPermissionFactory_t3494792867_0_0_0 = { 1, GenInst_IIdentityPermissionFactory_t3494792867_0_0_0_Types };
static const RuntimeType* GenInst_DateTimeOffset_t3036919142_0_0_0_Types[] = { (&DateTimeOffset_t3036919142_0_0_0) };
extern const Il2CppGenericInst GenInst_DateTimeOffset_t3036919142_0_0_0 = { 1, GenInst_DateTimeOffset_t3036919142_0_0_0_Types };
static const RuntimeType* GenInst_Guid_t_0_0_0_Types[] = { (&Guid_t_0_0_0) };
extern const Il2CppGenericInst GenInst_Guid_t_0_0_0 = { 1, GenInst_Guid_t_0_0_0_Types };
static const RuntimeType* GenInst_Version_t3942069453_0_0_0_Types[] = { (&Version_t3942069453_0_0_0) };
extern const Il2CppGenericInst GenInst_Version_t3942069453_0_0_0 = { 1, GenInst_Version_t3942069453_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0_Types[] = { (&String_t_0_0_0), (&Boolean_t402932760_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0 = { 2, GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Boolean_t402932760_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0 = { 2, GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3674847205_0_0_0_Types[] = { (&KeyValuePair_2_t3674847205_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3674847205_0_0_0 = { 1, GenInst_KeyValuePair_2_t3674847205_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0_DictionaryEntry_t578375704_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Boolean_t402932760_0_0_0), (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0_DictionaryEntry_t578375704_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0_KeyValuePair_2_t3674847205_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Boolean_t402932760_0_0_0), (&KeyValuePair_2_t3674847205_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0_KeyValuePair_2_t3674847205_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0_KeyValuePair_2_t3674847205_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0_DictionaryEntry_t578375704_0_0_0_Types[] = { (&String_t_0_0_0), (&Boolean_t402932760_0_0_0), (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0_DictionaryEntry_t578375704_0_0_0 = { 3, GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0_KeyValuePair_2_t1166309443_0_0_0_Types[] = { (&String_t_0_0_0), (&Boolean_t402932760_0_0_0), (&KeyValuePair_2_t1166309443_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0_KeyValuePair_2_t1166309443_0_0_0 = { 3, GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0_KeyValuePair_2_t1166309443_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t1166309443_0_0_0_Types[] = { (&KeyValuePair_2_t1166309443_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t1166309443_0_0_0 = { 1, GenInst_KeyValuePair_2_t1166309443_0_0_0_Types };
static const RuntimeType* GenInst_X509Certificate_t4268988265_0_0_0_Types[] = { (&X509Certificate_t4268988265_0_0_0) };
extern const Il2CppGenericInst GenInst_X509Certificate_t4268988265_0_0_0 = { 1, GenInst_X509Certificate_t4268988265_0_0_0_Types };
static const RuntimeType* GenInst_IDeserializationCallback_t706750576_0_0_0_Types[] = { (&IDeserializationCallback_t706750576_0_0_0) };
extern const Il2CppGenericInst GenInst_IDeserializationCallback_t706750576_0_0_0 = { 1, GenInst_IDeserializationCallback_t706750576_0_0_0_Types };
static const RuntimeType* GenInst_X509ChainStatus_t2329993372_0_0_0_Types[] = { (&X509ChainStatus_t2329993372_0_0_0) };
extern const Il2CppGenericInst GenInst_X509ChainStatus_t2329993372_0_0_0 = { 1, GenInst_X509ChainStatus_t2329993372_0_0_0_Types };
static const RuntimeType* GenInst_Capture_t1091228552_0_0_0_Types[] = { (&Capture_t1091228552_0_0_0) };
extern const Il2CppGenericInst GenInst_Capture_t1091228552_0_0_0 = { 1, GenInst_Capture_t1091228552_0_0_0_Types };
static const RuntimeType* GenInst_Group_t2387438183_0_0_0_Types[] = { (&Group_t2387438183_0_0_0) };
extern const Il2CppGenericInst GenInst_Group_t2387438183_0_0_0 = { 1, GenInst_Group_t2387438183_0_0_0_Types };
static const RuntimeType* GenInst_Mark_t3306160088_0_0_0_Types[] = { (&Mark_t3306160088_0_0_0) };
extern const Il2CppGenericInst GenInst_Mark_t3306160088_0_0_0 = { 1, GenInst_Mark_t3306160088_0_0_0_Types };
static const RuntimeType* GenInst_UriScheme_t2520867868_0_0_0_Types[] = { (&UriScheme_t2520867868_0_0_0) };
extern const Il2CppGenericInst GenInst_UriScheme_t2520867868_0_0_0 = { 1, GenInst_UriScheme_t2520867868_0_0_0_Types };
static const RuntimeType* GenInst_BigInteger_t964697201_0_0_0_Types[] = { (&BigInteger_t964697201_0_0_0) };
extern const Il2CppGenericInst GenInst_BigInteger_t964697201_0_0_0 = { 1, GenInst_BigInteger_t964697201_0_0_0_Types };
static const RuntimeType* GenInst_ByteU5BU5D_t3003616614_0_0_0_Types[] = { (&ByteU5BU5D_t3003616614_0_0_0) };
extern const Il2CppGenericInst GenInst_ByteU5BU5D_t3003616614_0_0_0 = { 1, GenInst_ByteU5BU5D_t3003616614_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t3835064308_0_0_0_Types[] = { (&IList_1_t3835064308_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t3835064308_0_0_0 = { 1, GenInst_IList_1_t3835064308_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t2714126062_0_0_0_Types[] = { (&ICollection_1_t2714126062_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t2714126062_0_0_0 = { 1, GenInst_ICollection_1_t2714126062_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t1570555952_0_0_0_Types[] = { (&IEnumerable_1_t1570555952_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t1570555952_0_0_0 = { 1, GenInst_IEnumerable_1_t1570555952_0_0_0_Types };
static const RuntimeType* GenInst_ClientCertificateType_t2095209863_0_0_0_Types[] = { (&ClientCertificateType_t2095209863_0_0_0) };
extern const Il2CppGenericInst GenInst_ClientCertificateType_t2095209863_0_0_0 = { 1, GenInst_ClientCertificateType_t2095209863_0_0_0_Types };
static const RuntimeType* GenInst_Object_t3267094820_0_0_0_Types[] = { (&Object_t3267094820_0_0_0) };
extern const Il2CppGenericInst GenInst_Object_t3267094820_0_0_0 = { 1, GenInst_Object_t3267094820_0_0_0_Types };
static const RuntimeType* GenInst_Camera_t142011664_0_0_0_Types[] = { (&Camera_t142011664_0_0_0) };
extern const Il2CppGenericInst GenInst_Camera_t142011664_0_0_0 = { 1, GenInst_Camera_t142011664_0_0_0_Types };
static const RuntimeType* GenInst_Behaviour_t2953351352_0_0_0_Types[] = { (&Behaviour_t2953351352_0_0_0) };
extern const Il2CppGenericInst GenInst_Behaviour_t2953351352_0_0_0 = { 1, GenInst_Behaviour_t2953351352_0_0_0_Types };
static const RuntimeType* GenInst_Component_t21088299_0_0_0_Types[] = { (&Component_t21088299_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_t21088299_0_0_0 = { 1, GenInst_Component_t21088299_0_0_0_Types };
static const RuntimeType* GenInst_Display_t289224223_0_0_0_Types[] = { (&Display_t289224223_0_0_0) };
extern const Il2CppGenericInst GenInst_Display_t289224223_0_0_0 = { 1, GenInst_Display_t289224223_0_0_0_Types };
static const RuntimeType* GenInst_Keyframe_t1047575712_0_0_0_Types[] = { (&Keyframe_t1047575712_0_0_0) };
extern const Il2CppGenericInst GenInst_Keyframe_t1047575712_0_0_0 = { 1, GenInst_Keyframe_t1047575712_0_0_0_Types };
static const RuntimeType* GenInst_Playable_t3436777522_0_0_0_Types[] = { (&Playable_t3436777522_0_0_0) };
extern const Il2CppGenericInst GenInst_Playable_t3436777522_0_0_0 = { 1, GenInst_Playable_t3436777522_0_0_0_Types };
static const RuntimeType* GenInst_PlayableOutput_t758663699_0_0_0_Types[] = { (&PlayableOutput_t758663699_0_0_0) };
extern const Il2CppGenericInst GenInst_PlayableOutput_t758663699_0_0_0 = { 1, GenInst_PlayableOutput_t758663699_0_0_0_Types };
static const RuntimeType* GenInst_Scene_t2009218140_0_0_0_LoadSceneMode_t136971723_0_0_0_Types[] = { (&Scene_t2009218140_0_0_0), (&LoadSceneMode_t136971723_0_0_0) };
extern const Il2CppGenericInst GenInst_Scene_t2009218140_0_0_0_LoadSceneMode_t136971723_0_0_0 = { 2, GenInst_Scene_t2009218140_0_0_0_LoadSceneMode_t136971723_0_0_0_Types };
static const RuntimeType* GenInst_Scene_t2009218140_0_0_0_Types[] = { (&Scene_t2009218140_0_0_0) };
extern const Il2CppGenericInst GenInst_Scene_t2009218140_0_0_0 = { 1, GenInst_Scene_t2009218140_0_0_0_Types };
static const RuntimeType* GenInst_Scene_t2009218140_0_0_0_Scene_t2009218140_0_0_0_Types[] = { (&Scene_t2009218140_0_0_0), (&Scene_t2009218140_0_0_0) };
extern const Il2CppGenericInst GenInst_Scene_t2009218140_0_0_0_Scene_t2009218140_0_0_0 = { 2, GenInst_Scene_t2009218140_0_0_0_Scene_t2009218140_0_0_0_Types };
static const RuntimeType* GenInst_SpriteAtlas_t2914147186_0_0_0_Types[] = { (&SpriteAtlas_t2914147186_0_0_0) };
extern const Il2CppGenericInst GenInst_SpriteAtlas_t2914147186_0_0_0 = { 1, GenInst_SpriteAtlas_t2914147186_0_0_0_Types };
static const RuntimeType* GenInst_ContactPoint_t3765348581_0_0_0_Types[] = { (&ContactPoint_t3765348581_0_0_0) };
extern const Il2CppGenericInst GenInst_ContactPoint_t3765348581_0_0_0 = { 1, GenInst_ContactPoint_t3765348581_0_0_0_Types };
static const RuntimeType* GenInst_RaycastHit_t2786726017_0_0_0_Types[] = { (&RaycastHit_t2786726017_0_0_0) };
extern const Il2CppGenericInst GenInst_RaycastHit_t2786726017_0_0_0 = { 1, GenInst_RaycastHit_t2786726017_0_0_0_Types };
static const RuntimeType* GenInst_AudioClipPlayable_t3295732336_0_0_0_Types[] = { (&AudioClipPlayable_t3295732336_0_0_0) };
extern const Il2CppGenericInst GenInst_AudioClipPlayable_t3295732336_0_0_0 = { 1, GenInst_AudioClipPlayable_t3295732336_0_0_0_Types };
static const RuntimeType* GenInst_AudioMixerPlayable_t3345238233_0_0_0_Types[] = { (&AudioMixerPlayable_t3345238233_0_0_0) };
extern const Il2CppGenericInst GenInst_AudioMixerPlayable_t3345238233_0_0_0 = { 1, GenInst_AudioMixerPlayable_t3345238233_0_0_0_Types };
static const RuntimeType* GenInst_Font_t208834271_0_0_0_Types[] = { (&Font_t208834271_0_0_0) };
extern const Il2CppGenericInst GenInst_Font_t208834271_0_0_0 = { 1, GenInst_Font_t208834271_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_RuntimeObject_0_0_0_Types[] = { (&String_t_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_String_t_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t861395070_0_0_0_Types[] = { (&KeyValuePair_2_t861395070_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t861395070_0_0_0 = { 1, GenInst_KeyValuePair_2_t861395070_0_0_0_Types };
static const RuntimeType* GenInst_DisallowMultipleComponent_t1571297057_0_0_0_Types[] = { (&DisallowMultipleComponent_t1571297057_0_0_0) };
extern const Il2CppGenericInst GenInst_DisallowMultipleComponent_t1571297057_0_0_0 = { 1, GenInst_DisallowMultipleComponent_t1571297057_0_0_0_Types };
static const RuntimeType* GenInst_Attribute_t1821863933_0_0_0_Types[] = { (&Attribute_t1821863933_0_0_0) };
extern const Il2CppGenericInst GenInst_Attribute_t1821863933_0_0_0 = { 1, GenInst_Attribute_t1821863933_0_0_0_Types };
static const RuntimeType* GenInst__Attribute_t1412570690_0_0_0_Types[] = { (&_Attribute_t1412570690_0_0_0) };
extern const Il2CppGenericInst GenInst__Attribute_t1412570690_0_0_0 = { 1, GenInst__Attribute_t1412570690_0_0_0_Types };
static const RuntimeType* GenInst_ExecuteInEditMode_t2292583052_0_0_0_Types[] = { (&ExecuteInEditMode_t2292583052_0_0_0) };
extern const Il2CppGenericInst GenInst_ExecuteInEditMode_t2292583052_0_0_0 = { 1, GenInst_ExecuteInEditMode_t2292583052_0_0_0_Types };
static const RuntimeType* GenInst_RequireComponent_t2231837482_0_0_0_Types[] = { (&RequireComponent_t2231837482_0_0_0) };
extern const Il2CppGenericInst GenInst_RequireComponent_t2231837482_0_0_0 = { 1, GenInst_RequireComponent_t2231837482_0_0_0_Types };
static const RuntimeType* GenInst_HitInfo_t2681867412_0_0_0_Types[] = { (&HitInfo_t2681867412_0_0_0) };
extern const Il2CppGenericInst GenInst_HitInfo_t2681867412_0_0_0 = { 1, GenInst_HitInfo_t2681867412_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0 = { 4, GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_PersistentCall_t183227066_0_0_0_Types[] = { (&PersistentCall_t183227066_0_0_0) };
extern const Il2CppGenericInst GenInst_PersistentCall_t183227066_0_0_0 = { 1, GenInst_PersistentCall_t183227066_0_0_0_Types };
static const RuntimeType* GenInst_BaseInvokableCall_t2607094378_0_0_0_Types[] = { (&BaseInvokableCall_t2607094378_0_0_0) };
extern const Il2CppGenericInst GenInst_BaseInvokableCall_t2607094378_0_0_0 = { 1, GenInst_BaseInvokableCall_t2607094378_0_0_0_Types };
static const RuntimeType* GenInst_WorkRequest_t3203378897_0_0_0_Types[] = { (&WorkRequest_t3203378897_0_0_0) };
extern const Il2CppGenericInst GenInst_WorkRequest_t3203378897_0_0_0 = { 1, GenInst_WorkRequest_t3203378897_0_0_0_Types };
static const RuntimeType* GenInst_PlayableBinding_t2470704133_0_0_0_Types[] = { (&PlayableBinding_t2470704133_0_0_0) };
extern const Il2CppGenericInst GenInst_PlayableBinding_t2470704133_0_0_0 = { 1, GenInst_PlayableBinding_t2470704133_0_0_0_Types };
static const RuntimeType* GenInst_MessageTypeSubscribers_t4164304980_0_0_0_Types[] = { (&MessageTypeSubscribers_t4164304980_0_0_0) };
extern const Il2CppGenericInst GenInst_MessageTypeSubscribers_t4164304980_0_0_0 = { 1, GenInst_MessageTypeSubscribers_t4164304980_0_0_0_Types };
static const RuntimeType* GenInst_MessageTypeSubscribers_t4164304980_0_0_0_Boolean_t402932760_0_0_0_Types[] = { (&MessageTypeSubscribers_t4164304980_0_0_0), (&Boolean_t402932760_0_0_0) };
extern const Il2CppGenericInst GenInst_MessageTypeSubscribers_t4164304980_0_0_0_Boolean_t402932760_0_0_0 = { 2, GenInst_MessageTypeSubscribers_t4164304980_0_0_0_Boolean_t402932760_0_0_0_Types };
static const RuntimeType* GenInst_MessageEventArgs_t1276058715_0_0_0_Types[] = { (&MessageEventArgs_t1276058715_0_0_0) };
extern const Il2CppGenericInst GenInst_MessageEventArgs_t1276058715_0_0_0 = { 1, GenInst_MessageEventArgs_t1276058715_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&WeakReference_t2646405993_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0 = { 2, GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2173232590_0_0_0_Types[] = { (&KeyValuePair_2_t2173232590_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2173232590_0_0_0 = { 1, GenInst_KeyValuePair_2_t2173232590_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&RuntimeObject_0_0_0), (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0 = { 3, GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t2173232590_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&RuntimeObject_0_0_0), (&KeyValuePair_2_t2173232590_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t2173232590_0_0_0 = { 3, GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t2173232590_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0_DictionaryEntry_t578375704_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&WeakReference_t2646405993_0_0_0), (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0_DictionaryEntry_t578375704_0_0_0 = { 3, GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0_KeyValuePair_2_t426652900_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&WeakReference_t2646405993_0_0_0), (&KeyValuePair_2_t426652900_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0_KeyValuePair_2_t426652900_0_0_0 = { 3, GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0_KeyValuePair_2_t426652900_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t426652900_0_0_0_Types[] = { (&KeyValuePair_2_t426652900_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t426652900_0_0_0 = { 1, GenInst_KeyValuePair_2_t426652900_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0_Types[] = { (&String_t_0_0_0), (&RuntimeObject_0_0_0), (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0 = { 3, GenInst_String_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t861395070_0_0_0_Types[] = { (&String_t_0_0_0), (&RuntimeObject_0_0_0), (&KeyValuePair_2_t861395070_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t861395070_0_0_0 = { 3, GenInst_String_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t861395070_0_0_0_Types };
static const RuntimeType* GenInst_FieldWithTarget_t2257325677_0_0_0_Types[] = { (&FieldWithTarget_t2257325677_0_0_0) };
extern const Il2CppGenericInst GenInst_FieldWithTarget_t2257325677_0_0_0 = { 1, GenInst_FieldWithTarget_t2257325677_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t1022578892_gp_0_0_0_0_Types[] = { (&IEnumerable_1_t1022578892_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t1022578892_gp_0_0_0_0 = { 1, GenInst_IEnumerable_1_t1022578892_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_InternalArray__IEnumerable_GetEnumerator_m1669952694_gp_0_0_0_0_Types[] = { (&Array_InternalArray__IEnumerable_GetEnumerator_m1669952694_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_InternalArray__IEnumerable_GetEnumerator_m1669952694_gp_0_0_0_0 = { 1, GenInst_Array_InternalArray__IEnumerable_GetEnumerator_m1669952694_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m1072890388_gp_0_0_0_0_Array_Sort_m1072890388_gp_0_0_0_0_Types[] = { (&Array_Sort_m1072890388_gp_0_0_0_0), (&Array_Sort_m1072890388_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m1072890388_gp_0_0_0_0_Array_Sort_m1072890388_gp_0_0_0_0 = { 2, GenInst_Array_Sort_m1072890388_gp_0_0_0_0_Array_Sort_m1072890388_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2260390429_gp_0_0_0_0_Array_Sort_m2260390429_gp_1_0_0_0_Types[] = { (&Array_Sort_m2260390429_gp_0_0_0_0), (&Array_Sort_m2260390429_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2260390429_gp_0_0_0_0_Array_Sort_m2260390429_gp_1_0_0_0 = { 2, GenInst_Array_Sort_m2260390429_gp_0_0_0_0_Array_Sort_m2260390429_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2466936610_gp_0_0_0_0_Types[] = { (&Array_Sort_m2466936610_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2466936610_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m2466936610_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2466936610_gp_0_0_0_0_Array_Sort_m2466936610_gp_0_0_0_0_Types[] = { (&Array_Sort_m2466936610_gp_0_0_0_0), (&Array_Sort_m2466936610_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2466936610_gp_0_0_0_0_Array_Sort_m2466936610_gp_0_0_0_0 = { 2, GenInst_Array_Sort_m2466936610_gp_0_0_0_0_Array_Sort_m2466936610_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m1673438336_gp_0_0_0_0_Types[] = { (&Array_Sort_m1673438336_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m1673438336_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m1673438336_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m1673438336_gp_0_0_0_0_Array_Sort_m1673438336_gp_1_0_0_0_Types[] = { (&Array_Sort_m1673438336_gp_0_0_0_0), (&Array_Sort_m1673438336_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m1673438336_gp_0_0_0_0_Array_Sort_m1673438336_gp_1_0_0_0 = { 2, GenInst_Array_Sort_m1673438336_gp_0_0_0_0_Array_Sort_m1673438336_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m4275090730_gp_0_0_0_0_Array_Sort_m4275090730_gp_0_0_0_0_Types[] = { (&Array_Sort_m4275090730_gp_0_0_0_0), (&Array_Sort_m4275090730_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m4275090730_gp_0_0_0_0_Array_Sort_m4275090730_gp_0_0_0_0 = { 2, GenInst_Array_Sort_m4275090730_gp_0_0_0_0_Array_Sort_m4275090730_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2213423065_gp_0_0_0_0_Array_Sort_m2213423065_gp_1_0_0_0_Types[] = { (&Array_Sort_m2213423065_gp_0_0_0_0), (&Array_Sort_m2213423065_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2213423065_gp_0_0_0_0_Array_Sort_m2213423065_gp_1_0_0_0 = { 2, GenInst_Array_Sort_m2213423065_gp_0_0_0_0_Array_Sort_m2213423065_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m3813128040_gp_0_0_0_0_Types[] = { (&Array_Sort_m3813128040_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m3813128040_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m3813128040_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m3813128040_gp_0_0_0_0_Array_Sort_m3813128040_gp_0_0_0_0_Types[] = { (&Array_Sort_m3813128040_gp_0_0_0_0), (&Array_Sort_m3813128040_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m3813128040_gp_0_0_0_0_Array_Sort_m3813128040_gp_0_0_0_0 = { 2, GenInst_Array_Sort_m3813128040_gp_0_0_0_0_Array_Sort_m3813128040_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2658527309_gp_0_0_0_0_Types[] = { (&Array_Sort_m2658527309_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2658527309_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m2658527309_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2658527309_gp_1_0_0_0_Types[] = { (&Array_Sort_m2658527309_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2658527309_gp_1_0_0_0 = { 1, GenInst_Array_Sort_m2658527309_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2658527309_gp_0_0_0_0_Array_Sort_m2658527309_gp_1_0_0_0_Types[] = { (&Array_Sort_m2658527309_gp_0_0_0_0), (&Array_Sort_m2658527309_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2658527309_gp_0_0_0_0_Array_Sort_m2658527309_gp_1_0_0_0 = { 2, GenInst_Array_Sort_m2658527309_gp_0_0_0_0_Array_Sort_m2658527309_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m972389192_gp_0_0_0_0_Types[] = { (&Array_Sort_m972389192_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m972389192_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m972389192_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m649440607_gp_0_0_0_0_Types[] = { (&Array_Sort_m649440607_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m649440607_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m649440607_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_qsort_m209006070_gp_0_0_0_0_Types[] = { (&Array_qsort_m209006070_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_qsort_m209006070_gp_0_0_0_0 = { 1, GenInst_Array_qsort_m209006070_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_qsort_m209006070_gp_0_0_0_0_Array_qsort_m209006070_gp_1_0_0_0_Types[] = { (&Array_qsort_m209006070_gp_0_0_0_0), (&Array_qsort_m209006070_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_qsort_m209006070_gp_0_0_0_0_Array_qsort_m209006070_gp_1_0_0_0 = { 2, GenInst_Array_qsort_m209006070_gp_0_0_0_0_Array_qsort_m209006070_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_compare_m4182503070_gp_0_0_0_0_Types[] = { (&Array_compare_m4182503070_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_compare_m4182503070_gp_0_0_0_0 = { 1, GenInst_Array_compare_m4182503070_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_qsort_m2221164107_gp_0_0_0_0_Types[] = { (&Array_qsort_m2221164107_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_qsort_m2221164107_gp_0_0_0_0 = { 1, GenInst_Array_qsort_m2221164107_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Resize_m2100239636_gp_0_0_0_0_Types[] = { (&Array_Resize_m2100239636_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Resize_m2100239636_gp_0_0_0_0 = { 1, GenInst_Array_Resize_m2100239636_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_TrueForAll_m3027858380_gp_0_0_0_0_Types[] = { (&Array_TrueForAll_m3027858380_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_TrueForAll_m3027858380_gp_0_0_0_0 = { 1, GenInst_Array_TrueForAll_m3027858380_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_ForEach_m3706321912_gp_0_0_0_0_Types[] = { (&Array_ForEach_m3706321912_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_ForEach_m3706321912_gp_0_0_0_0 = { 1, GenInst_Array_ForEach_m3706321912_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_ConvertAll_m3519299715_gp_0_0_0_0_Array_ConvertAll_m3519299715_gp_1_0_0_0_Types[] = { (&Array_ConvertAll_m3519299715_gp_0_0_0_0), (&Array_ConvertAll_m3519299715_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_ConvertAll_m3519299715_gp_0_0_0_0_Array_ConvertAll_m3519299715_gp_1_0_0_0 = { 2, GenInst_Array_ConvertAll_m3519299715_gp_0_0_0_0_Array_ConvertAll_m3519299715_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindLastIndex_m2214885193_gp_0_0_0_0_Types[] = { (&Array_FindLastIndex_m2214885193_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindLastIndex_m2214885193_gp_0_0_0_0 = { 1, GenInst_Array_FindLastIndex_m2214885193_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindLastIndex_m860191247_gp_0_0_0_0_Types[] = { (&Array_FindLastIndex_m860191247_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindLastIndex_m860191247_gp_0_0_0_0 = { 1, GenInst_Array_FindLastIndex_m860191247_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindLastIndex_m1827158888_gp_0_0_0_0_Types[] = { (&Array_FindLastIndex_m1827158888_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindLastIndex_m1827158888_gp_0_0_0_0 = { 1, GenInst_Array_FindLastIndex_m1827158888_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindIndex_m2875137143_gp_0_0_0_0_Types[] = { (&Array_FindIndex_m2875137143_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindIndex_m2875137143_gp_0_0_0_0 = { 1, GenInst_Array_FindIndex_m2875137143_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindIndex_m2010363940_gp_0_0_0_0_Types[] = { (&Array_FindIndex_m2010363940_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindIndex_m2010363940_gp_0_0_0_0 = { 1, GenInst_Array_FindIndex_m2010363940_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindIndex_m3203021108_gp_0_0_0_0_Types[] = { (&Array_FindIndex_m3203021108_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindIndex_m3203021108_gp_0_0_0_0 = { 1, GenInst_Array_FindIndex_m3203021108_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_BinarySearch_m265843292_gp_0_0_0_0_Types[] = { (&Array_BinarySearch_m265843292_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_BinarySearch_m265843292_gp_0_0_0_0 = { 1, GenInst_Array_BinarySearch_m265843292_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_BinarySearch_m2054507326_gp_0_0_0_0_Types[] = { (&Array_BinarySearch_m2054507326_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_BinarySearch_m2054507326_gp_0_0_0_0 = { 1, GenInst_Array_BinarySearch_m2054507326_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_BinarySearch_m2165578130_gp_0_0_0_0_Types[] = { (&Array_BinarySearch_m2165578130_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_BinarySearch_m2165578130_gp_0_0_0_0 = { 1, GenInst_Array_BinarySearch_m2165578130_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_BinarySearch_m1225743805_gp_0_0_0_0_Types[] = { (&Array_BinarySearch_m1225743805_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_BinarySearch_m1225743805_gp_0_0_0_0 = { 1, GenInst_Array_BinarySearch_m1225743805_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_IndexOf_m326784914_gp_0_0_0_0_Types[] = { (&Array_IndexOf_m326784914_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_IndexOf_m326784914_gp_0_0_0_0 = { 1, GenInst_Array_IndexOf_m326784914_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_IndexOf_m4162377550_gp_0_0_0_0_Types[] = { (&Array_IndexOf_m4162377550_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_IndexOf_m4162377550_gp_0_0_0_0 = { 1, GenInst_Array_IndexOf_m4162377550_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_IndexOf_m1433803741_gp_0_0_0_0_Types[] = { (&Array_IndexOf_m1433803741_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_IndexOf_m1433803741_gp_0_0_0_0 = { 1, GenInst_Array_IndexOf_m1433803741_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_LastIndexOf_m1870232505_gp_0_0_0_0_Types[] = { (&Array_LastIndexOf_m1870232505_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_LastIndexOf_m1870232505_gp_0_0_0_0 = { 1, GenInst_Array_LastIndexOf_m1870232505_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_LastIndexOf_m1925872913_gp_0_0_0_0_Types[] = { (&Array_LastIndexOf_m1925872913_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_LastIndexOf_m1925872913_gp_0_0_0_0 = { 1, GenInst_Array_LastIndexOf_m1925872913_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_LastIndexOf_m1095612650_gp_0_0_0_0_Types[] = { (&Array_LastIndexOf_m1095612650_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_LastIndexOf_m1095612650_gp_0_0_0_0 = { 1, GenInst_Array_LastIndexOf_m1095612650_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindAll_m4056086111_gp_0_0_0_0_Types[] = { (&Array_FindAll_m4056086111_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindAll_m4056086111_gp_0_0_0_0 = { 1, GenInst_Array_FindAll_m4056086111_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Exists_m3820198506_gp_0_0_0_0_Types[] = { (&Array_Exists_m3820198506_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Exists_m3820198506_gp_0_0_0_0 = { 1, GenInst_Array_Exists_m3820198506_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_AsReadOnly_m2538139719_gp_0_0_0_0_Types[] = { (&Array_AsReadOnly_m2538139719_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_AsReadOnly_m2538139719_gp_0_0_0_0 = { 1, GenInst_Array_AsReadOnly_m2538139719_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Find_m2107862747_gp_0_0_0_0_Types[] = { (&Array_Find_m2107862747_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Find_m2107862747_gp_0_0_0_0 = { 1, GenInst_Array_Find_m2107862747_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindLast_m1630072226_gp_0_0_0_0_Types[] = { (&Array_FindLast_m1630072226_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindLast_m1630072226_gp_0_0_0_0 = { 1, GenInst_Array_FindLast_m1630072226_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_InternalEnumerator_1_t511305203_gp_0_0_0_0_Types[] = { (&InternalEnumerator_1_t511305203_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_InternalEnumerator_1_t511305203_gp_0_0_0_0 = { 1, GenInst_InternalEnumerator_1_t511305203_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ArrayReadOnlyList_1_t1478687212_gp_0_0_0_0_Types[] = { (&ArrayReadOnlyList_1_t1478687212_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ArrayReadOnlyList_1_t1478687212_gp_0_0_0_0 = { 1, GenInst_ArrayReadOnlyList_1_t1478687212_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_U3CGetEnumeratorU3Ec__Iterator0_t3090871926_gp_0_0_0_0_Types[] = { (&U3CGetEnumeratorU3Ec__Iterator0_t3090871926_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_U3CGetEnumeratorU3Ec__Iterator0_t3090871926_gp_0_0_0_0 = { 1, GenInst_U3CGetEnumeratorU3Ec__Iterator0_t3090871926_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t822657584_gp_0_0_0_0_Types[] = { (&IList_1_t822657584_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t822657584_gp_0_0_0_0 = { 1, GenInst_IList_1_t822657584_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t299879354_gp_0_0_0_0_Types[] = { (&ICollection_1_t299879354_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t299879354_gp_0_0_0_0 = { 1, GenInst_ICollection_1_t299879354_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Nullable_1_t3171292327_gp_0_0_0_0_Types[] = { (&Nullable_1_t3171292327_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Nullable_1_t3171292327_gp_0_0_0_0 = { 1, GenInst_Nullable_1_t3171292327_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Comparer_1_t612255760_gp_0_0_0_0_Types[] = { (&Comparer_1_t612255760_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Comparer_1_t612255760_gp_0_0_0_0 = { 1, GenInst_Comparer_1_t612255760_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_DefaultComparer_t4070014030_gp_0_0_0_0_Types[] = { (&DefaultComparer_t4070014030_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_DefaultComparer_t4070014030_gp_0_0_0_0 = { 1, GenInst_DefaultComparer_t4070014030_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_GenericComparer_1_t1749919386_gp_0_0_0_0_Types[] = { (&GenericComparer_1_t1749919386_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_GenericComparer_1_t1749919386_gp_0_0_0_0 = { 1, GenInst_GenericComparer_1_t1749919386_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Types[] = { (&Dictionary_2_t1155016036_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t1155016036_gp_0_0_0_0 = { 1, GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_Types[] = { (&Dictionary_2_t1155016036_gp_0_0_0_0), (&Dictionary_2_t1155016036_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0 = { 2, GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t249753073_0_0_0_Types[] = { (&KeyValuePair_2_t249753073_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t249753073_0_0_0 = { 1, GenInst_KeyValuePair_2_t249753073_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_Dictionary_2_Do_CopyTo_m2742623902_gp_0_0_0_0_Types[] = { (&Dictionary_2_t1155016036_gp_0_0_0_0), (&Dictionary_2_t1155016036_gp_1_0_0_0), (&Dictionary_2_Do_CopyTo_m2742623902_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_Dictionary_2_Do_CopyTo_m2742623902_gp_0_0_0_0 = { 3, GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_Dictionary_2_Do_CopyTo_m2742623902_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0_Types[] = { (&Dictionary_2_t1155016036_gp_0_0_0_0), (&Dictionary_2_t1155016036_gp_1_0_0_0), (&Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0 = { 3, GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0_RuntimeObject_0_0_0_Types[] = { (&Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_DictionaryEntry_t578375704_0_0_0_Types[] = { (&Dictionary_2_t1155016036_gp_0_0_0_0), (&Dictionary_2_t1155016036_gp_1_0_0_0), (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_DictionaryEntry_t578375704_0_0_0 = { 3, GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_ShimEnumerator_t2146408712_gp_0_0_0_0_ShimEnumerator_t2146408712_gp_1_0_0_0_Types[] = { (&ShimEnumerator_t2146408712_gp_0_0_0_0), (&ShimEnumerator_t2146408712_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_ShimEnumerator_t2146408712_gp_0_0_0_0_ShimEnumerator_t2146408712_gp_1_0_0_0 = { 2, GenInst_ShimEnumerator_t2146408712_gp_0_0_0_0_ShimEnumerator_t2146408712_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t1186497974_gp_0_0_0_0_Enumerator_t1186497974_gp_1_0_0_0_Types[] = { (&Enumerator_t1186497974_gp_0_0_0_0), (&Enumerator_t1186497974_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t1186497974_gp_0_0_0_0_Enumerator_t1186497974_gp_1_0_0_0 = { 2, GenInst_Enumerator_t1186497974_gp_0_0_0_0_Enumerator_t1186497974_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2965215337_0_0_0_Types[] = { (&KeyValuePair_2_t2965215337_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2965215337_0_0_0 = { 1, GenInst_KeyValuePair_2_t2965215337_0_0_0_Types };
static const RuntimeType* GenInst_DictionaryEntry_t578375704_0_0_0_DictionaryEntry_t578375704_0_0_0_Types[] = { (&DictionaryEntry_t578375704_0_0_0), (&DictionaryEntry_t578375704_0_0_0) };
extern const Il2CppGenericInst GenInst_DictionaryEntry_t578375704_0_0_0_DictionaryEntry_t578375704_0_0_0 = { 2, GenInst_DictionaryEntry_t578375704_0_0_0_DictionaryEntry_t578375704_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_KeyValuePair_2_t249753073_0_0_0_Types[] = { (&Dictionary_2_t1155016036_gp_0_0_0_0), (&Dictionary_2_t1155016036_gp_1_0_0_0), (&KeyValuePair_2_t249753073_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_KeyValuePair_2_t249753073_0_0_0 = { 3, GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_KeyValuePair_2_t249753073_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t249753073_0_0_0_KeyValuePair_2_t249753073_0_0_0_Types[] = { (&KeyValuePair_2_t249753073_0_0_0), (&KeyValuePair_2_t249753073_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t249753073_0_0_0_KeyValuePair_2_t249753073_0_0_0 = { 2, GenInst_KeyValuePair_2_t249753073_0_0_0_KeyValuePair_2_t249753073_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t1155016036_gp_1_0_0_0_Types[] = { (&Dictionary_2_t1155016036_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t1155016036_gp_1_0_0_0 = { 1, GenInst_Dictionary_2_t1155016036_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_EqualityComparer_1_t3917655132_gp_0_0_0_0_Types[] = { (&EqualityComparer_1_t3917655132_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_EqualityComparer_1_t3917655132_gp_0_0_0_0 = { 1, GenInst_EqualityComparer_1_t3917655132_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_DefaultComparer_t2413763153_gp_0_0_0_0_Types[] = { (&DefaultComparer_t2413763153_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_DefaultComparer_t2413763153_gp_0_0_0_0 = { 1, GenInst_DefaultComparer_t2413763153_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_GenericEqualityComparer_1_t2616639575_gp_0_0_0_0_Types[] = { (&GenericEqualityComparer_1_t2616639575_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_GenericEqualityComparer_1_t2616639575_gp_0_0_0_0 = { 1, GenInst_GenericEqualityComparer_1_t2616639575_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2310743657_0_0_0_Types[] = { (&KeyValuePair_2_t2310743657_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2310743657_0_0_0 = { 1, GenInst_KeyValuePair_2_t2310743657_0_0_0_Types };
static const RuntimeType* GenInst_IDictionary_2_t332250678_gp_0_0_0_0_IDictionary_2_t332250678_gp_1_0_0_0_Types[] = { (&IDictionary_2_t332250678_gp_0_0_0_0), (&IDictionary_2_t332250678_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_IDictionary_2_t332250678_gp_0_0_0_0_IDictionary_2_t332250678_gp_1_0_0_0 = { 2, GenInst_IDictionary_2_t332250678_gp_0_0_0_0_IDictionary_2_t332250678_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3396090807_gp_0_0_0_0_KeyValuePair_2_t3396090807_gp_1_0_0_0_Types[] = { (&KeyValuePair_2_t3396090807_gp_0_0_0_0), (&KeyValuePair_2_t3396090807_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3396090807_gp_0_0_0_0_KeyValuePair_2_t3396090807_gp_1_0_0_0 = { 2, GenInst_KeyValuePair_2_t3396090807_gp_0_0_0_0_KeyValuePair_2_t3396090807_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t2059616371_gp_0_0_0_0_Types[] = { (&List_1_t2059616371_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t2059616371_gp_0_0_0_0 = { 1, GenInst_List_1_t2059616371_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t548538204_gp_0_0_0_0_Types[] = { (&Enumerator_t548538204_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t548538204_gp_0_0_0_0 = { 1, GenInst_Enumerator_t548538204_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Collection_1_t2882572264_gp_0_0_0_0_Types[] = { (&Collection_1_t2882572264_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Collection_1_t2882572264_gp_0_0_0_0 = { 1, GenInst_Collection_1_t2882572264_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ReadOnlyCollection_1_t2481933861_gp_0_0_0_0_Types[] = { (&ReadOnlyCollection_1_t2481933861_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ReadOnlyCollection_1_t2481933861_gp_0_0_0_0 = { 1, GenInst_ReadOnlyCollection_1_t2481933861_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_MonoProperty_GetterAdapterFrame_m1385778246_gp_0_0_0_0_MonoProperty_GetterAdapterFrame_m1385778246_gp_1_0_0_0_Types[] = { (&MonoProperty_GetterAdapterFrame_m1385778246_gp_0_0_0_0), (&MonoProperty_GetterAdapterFrame_m1385778246_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_MonoProperty_GetterAdapterFrame_m1385778246_gp_0_0_0_0_MonoProperty_GetterAdapterFrame_m1385778246_gp_1_0_0_0 = { 2, GenInst_MonoProperty_GetterAdapterFrame_m1385778246_gp_0_0_0_0_MonoProperty_GetterAdapterFrame_m1385778246_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_MonoProperty_StaticGetterAdapterFrame_m917416377_gp_0_0_0_0_Types[] = { (&MonoProperty_StaticGetterAdapterFrame_m917416377_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_MonoProperty_StaticGetterAdapterFrame_m917416377_gp_0_0_0_0 = { 1, GenInst_MonoProperty_StaticGetterAdapterFrame_m917416377_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Queue_1_t3027544886_gp_0_0_0_0_Types[] = { (&Queue_1_t3027544886_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Queue_1_t3027544886_gp_0_0_0_0 = { 1, GenInst_Queue_1_t3027544886_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t1097944946_gp_0_0_0_0_Types[] = { (&Enumerator_t1097944946_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t1097944946_gp_0_0_0_0 = { 1, GenInst_Enumerator_t1097944946_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Stack_1_t4283693321_gp_0_0_0_0_Types[] = { (&Stack_1_t4283693321_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Stack_1_t4283693321_gp_0_0_0_0 = { 1, GenInst_Stack_1_t4283693321_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t3903841341_gp_0_0_0_0_Types[] = { (&Enumerator_t3903841341_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t3903841341_gp_0_0_0_0 = { 1, GenInst_Enumerator_t3903841341_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerable_Any_m437989361_gp_0_0_0_0_Types[] = { (&Enumerable_Any_m437989361_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerable_Any_m437989361_gp_0_0_0_0 = { 1, GenInst_Enumerable_Any_m437989361_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerable_Where_m311029895_gp_0_0_0_0_Types[] = { (&Enumerable_Where_m311029895_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerable_Where_m311029895_gp_0_0_0_0 = { 1, GenInst_Enumerable_Where_m311029895_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerable_Where_m311029895_gp_0_0_0_0_Boolean_t402932760_0_0_0_Types[] = { (&Enumerable_Where_m311029895_gp_0_0_0_0), (&Boolean_t402932760_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerable_Where_m311029895_gp_0_0_0_0_Boolean_t402932760_0_0_0 = { 2, GenInst_Enumerable_Where_m311029895_gp_0_0_0_0_Boolean_t402932760_0_0_0_Types };
static const RuntimeType* GenInst_Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0_Types[] = { (&Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0 = { 1, GenInst_Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0_Boolean_t402932760_0_0_0_Types[] = { (&Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0), (&Boolean_t402932760_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0_Boolean_t402932760_0_0_0 = { 2, GenInst_Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0_Boolean_t402932760_0_0_0_Types };
static const RuntimeType* GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0_Types[] = { (&U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0 = { 1, GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0_Boolean_t402932760_0_0_0_Types[] = { (&U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0), (&Boolean_t402932760_0_0_0) };
extern const Il2CppGenericInst GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0_Boolean_t402932760_0_0_0 = { 2, GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0_Boolean_t402932760_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentInChildren_m2013229797_gp_0_0_0_0_Types[] = { (&Component_GetComponentInChildren_m2013229797_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentInChildren_m2013229797_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentInChildren_m2013229797_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentsInChildren_m3349813871_gp_0_0_0_0_Types[] = { (&Component_GetComponentsInChildren_m3349813871_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentsInChildren_m3349813871_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentsInChildren_m3349813871_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentsInChildren_m3768785598_gp_0_0_0_0_Types[] = { (&Component_GetComponentsInChildren_m3768785598_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentsInChildren_m3768785598_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentsInChildren_m3768785598_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentsInChildren_m1145032281_gp_0_0_0_0_Types[] = { (&Component_GetComponentsInChildren_m1145032281_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentsInChildren_m1145032281_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentsInChildren_m1145032281_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentsInChildren_m4128002223_gp_0_0_0_0_Types[] = { (&Component_GetComponentsInChildren_m4128002223_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentsInChildren_m4128002223_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentsInChildren_m4128002223_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentsInParent_m1346221865_gp_0_0_0_0_Types[] = { (&Component_GetComponentsInParent_m1346221865_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentsInParent_m1346221865_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentsInParent_m1346221865_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentsInParent_m4108781761_gp_0_0_0_0_Types[] = { (&Component_GetComponentsInParent_m4108781761_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentsInParent_m4108781761_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentsInParent_m4108781761_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentsInParent_m704351154_gp_0_0_0_0_Types[] = { (&Component_GetComponentsInParent_m704351154_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentsInParent_m704351154_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentsInParent_m704351154_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponents_m3735850386_gp_0_0_0_0_Types[] = { (&Component_GetComponents_m3735850386_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponents_m3735850386_gp_0_0_0_0 = { 1, GenInst_Component_GetComponents_m3735850386_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponents_m2761802573_gp_0_0_0_0_Types[] = { (&Component_GetComponents_m2761802573_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponents_m2761802573_gp_0_0_0_0 = { 1, GenInst_Component_GetComponents_m2761802573_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_GameObject_GetComponentsInChildren_m3043092117_gp_0_0_0_0_Types[] = { (&GameObject_GetComponentsInChildren_m3043092117_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_GameObject_GetComponentsInChildren_m3043092117_gp_0_0_0_0 = { 1, GenInst_GameObject_GetComponentsInChildren_m3043092117_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_GameObject_GetComponentsInParent_m2509003192_gp_0_0_0_0_Types[] = { (&GameObject_GetComponentsInParent_m2509003192_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_GameObject_GetComponentsInParent_m2509003192_gp_0_0_0_0 = { 1, GenInst_GameObject_GetComponentsInParent_m2509003192_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Object_Instantiate_m620518311_gp_0_0_0_0_Types[] = { (&Object_Instantiate_m620518311_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Object_Instantiate_m620518311_gp_0_0_0_0 = { 1, GenInst_Object_Instantiate_m620518311_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Object_FindObjectsOfType_m2502297032_gp_0_0_0_0_Types[] = { (&Object_FindObjectsOfType_m2502297032_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Object_FindObjectsOfType_m2502297032_gp_0_0_0_0 = { 1, GenInst_Object_FindObjectsOfType_m2502297032_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Playable_IsPlayableOfType_m3325280013_gp_0_0_0_0_Types[] = { (&Playable_IsPlayableOfType_m3325280013_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Playable_IsPlayableOfType_m3325280013_gp_0_0_0_0 = { 1, GenInst_Playable_IsPlayableOfType_m3325280013_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_PlayableOutput_IsPlayableOutputOfType_m3768091146_gp_0_0_0_0_Types[] = { (&PlayableOutput_IsPlayableOutputOfType_m3768091146_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_PlayableOutput_IsPlayableOutputOfType_m3768091146_gp_0_0_0_0 = { 1, GenInst_PlayableOutput_IsPlayableOutputOfType_m3768091146_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_1_t3068523820_gp_0_0_0_0_Types[] = { (&InvokableCall_1_t3068523820_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_1_t3068523820_gp_0_0_0_0 = { 1, GenInst_InvokableCall_1_t3068523820_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_UnityAction_1_t575283959_0_0_0_Types[] = { (&UnityAction_1_t575283959_0_0_0) };
extern const Il2CppGenericInst GenInst_UnityAction_1_t575283959_0_0_0 = { 1, GenInst_UnityAction_1_t575283959_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_2_t4124072994_gp_0_0_0_0_InvokableCall_2_t4124072994_gp_1_0_0_0_Types[] = { (&InvokableCall_2_t4124072994_gp_0_0_0_0), (&InvokableCall_2_t4124072994_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_2_t4124072994_gp_0_0_0_0_InvokableCall_2_t4124072994_gp_1_0_0_0 = { 2, GenInst_InvokableCall_2_t4124072994_gp_0_0_0_0_InvokableCall_2_t4124072994_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_2_t4124072994_gp_0_0_0_0_Types[] = { (&InvokableCall_2_t4124072994_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_2_t4124072994_gp_0_0_0_0 = { 1, GenInst_InvokableCall_2_t4124072994_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_2_t4124072994_gp_1_0_0_0_Types[] = { (&InvokableCall_2_t4124072994_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_2_t4124072994_gp_1_0_0_0 = { 1, GenInst_InvokableCall_2_t4124072994_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_3_t442739363_gp_0_0_0_0_InvokableCall_3_t442739363_gp_1_0_0_0_InvokableCall_3_t442739363_gp_2_0_0_0_Types[] = { (&InvokableCall_3_t442739363_gp_0_0_0_0), (&InvokableCall_3_t442739363_gp_1_0_0_0), (&InvokableCall_3_t442739363_gp_2_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_3_t442739363_gp_0_0_0_0_InvokableCall_3_t442739363_gp_1_0_0_0_InvokableCall_3_t442739363_gp_2_0_0_0 = { 3, GenInst_InvokableCall_3_t442739363_gp_0_0_0_0_InvokableCall_3_t442739363_gp_1_0_0_0_InvokableCall_3_t442739363_gp_2_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_3_t442739363_gp_0_0_0_0_Types[] = { (&InvokableCall_3_t442739363_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_3_t442739363_gp_0_0_0_0 = { 1, GenInst_InvokableCall_3_t442739363_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_3_t442739363_gp_1_0_0_0_Types[] = { (&InvokableCall_3_t442739363_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_3_t442739363_gp_1_0_0_0 = { 1, GenInst_InvokableCall_3_t442739363_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_3_t442739363_gp_2_0_0_0_Types[] = { (&InvokableCall_3_t442739363_gp_2_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_3_t442739363_gp_2_0_0_0 = { 1, GenInst_InvokableCall_3_t442739363_gp_2_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_4_t3127597954_gp_0_0_0_0_InvokableCall_4_t3127597954_gp_1_0_0_0_InvokableCall_4_t3127597954_gp_2_0_0_0_InvokableCall_4_t3127597954_gp_3_0_0_0_Types[] = { (&InvokableCall_4_t3127597954_gp_0_0_0_0), (&InvokableCall_4_t3127597954_gp_1_0_0_0), (&InvokableCall_4_t3127597954_gp_2_0_0_0), (&InvokableCall_4_t3127597954_gp_3_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_4_t3127597954_gp_0_0_0_0_InvokableCall_4_t3127597954_gp_1_0_0_0_InvokableCall_4_t3127597954_gp_2_0_0_0_InvokableCall_4_t3127597954_gp_3_0_0_0 = { 4, GenInst_InvokableCall_4_t3127597954_gp_0_0_0_0_InvokableCall_4_t3127597954_gp_1_0_0_0_InvokableCall_4_t3127597954_gp_2_0_0_0_InvokableCall_4_t3127597954_gp_3_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_4_t3127597954_gp_0_0_0_0_Types[] = { (&InvokableCall_4_t3127597954_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_4_t3127597954_gp_0_0_0_0 = { 1, GenInst_InvokableCall_4_t3127597954_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_4_t3127597954_gp_1_0_0_0_Types[] = { (&InvokableCall_4_t3127597954_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_4_t3127597954_gp_1_0_0_0 = { 1, GenInst_InvokableCall_4_t3127597954_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_4_t3127597954_gp_2_0_0_0_Types[] = { (&InvokableCall_4_t3127597954_gp_2_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_4_t3127597954_gp_2_0_0_0 = { 1, GenInst_InvokableCall_4_t3127597954_gp_2_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_4_t3127597954_gp_3_0_0_0_Types[] = { (&InvokableCall_4_t3127597954_gp_3_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_4_t3127597954_gp_3_0_0_0 = { 1, GenInst_InvokableCall_4_t3127597954_gp_3_0_0_0_Types };
static const RuntimeType* GenInst_CachedInvokableCall_1_t2741087613_gp_0_0_0_0_Types[] = { (&CachedInvokableCall_1_t2741087613_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_CachedInvokableCall_1_t2741087613_gp_0_0_0_0 = { 1, GenInst_CachedInvokableCall_1_t2741087613_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_UnityEvent_1_t664801528_gp_0_0_0_0_Types[] = { (&UnityEvent_1_t664801528_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_UnityEvent_1_t664801528_gp_0_0_0_0 = { 1, GenInst_UnityEvent_1_t664801528_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_UnityEvent_2_t3195527707_gp_0_0_0_0_UnityEvent_2_t3195527707_gp_1_0_0_0_Types[] = { (&UnityEvent_2_t3195527707_gp_0_0_0_0), (&UnityEvent_2_t3195527707_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_UnityEvent_2_t3195527707_gp_0_0_0_0_UnityEvent_2_t3195527707_gp_1_0_0_0 = { 2, GenInst_UnityEvent_2_t3195527707_gp_0_0_0_0_UnityEvent_2_t3195527707_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_UnityEvent_3_t180400136_gp_0_0_0_0_UnityEvent_3_t180400136_gp_1_0_0_0_UnityEvent_3_t180400136_gp_2_0_0_0_Types[] = { (&UnityEvent_3_t180400136_gp_0_0_0_0), (&UnityEvent_3_t180400136_gp_1_0_0_0), (&UnityEvent_3_t180400136_gp_2_0_0_0) };
extern const Il2CppGenericInst GenInst_UnityEvent_3_t180400136_gp_0_0_0_0_UnityEvent_3_t180400136_gp_1_0_0_0_UnityEvent_3_t180400136_gp_2_0_0_0 = { 3, GenInst_UnityEvent_3_t180400136_gp_0_0_0_0_UnityEvent_3_t180400136_gp_1_0_0_0_UnityEvent_3_t180400136_gp_2_0_0_0_Types };
static const RuntimeType* GenInst_UnityEvent_4_t316486966_gp_0_0_0_0_UnityEvent_4_t316486966_gp_1_0_0_0_UnityEvent_4_t316486966_gp_2_0_0_0_UnityEvent_4_t316486966_gp_3_0_0_0_Types[] = { (&UnityEvent_4_t316486966_gp_0_0_0_0), (&UnityEvent_4_t316486966_gp_1_0_0_0), (&UnityEvent_4_t316486966_gp_2_0_0_0), (&UnityEvent_4_t316486966_gp_3_0_0_0) };
extern const Il2CppGenericInst GenInst_UnityEvent_4_t316486966_gp_0_0_0_0_UnityEvent_4_t316486966_gp_1_0_0_0_UnityEvent_4_t316486966_gp_2_0_0_0_UnityEvent_4_t316486966_gp_3_0_0_0 = { 4, GenInst_UnityEvent_4_t316486966_gp_0_0_0_0_UnityEvent_4_t316486966_gp_1_0_0_0_UnityEvent_4_t316486966_gp_2_0_0_0_UnityEvent_4_t316486966_gp_3_0_0_0_Types };
static const RuntimeType* GenInst_DefaultExecutionOrder_t1687762308_0_0_0_Types[] = { (&DefaultExecutionOrder_t1687762308_0_0_0) };
extern const Il2CppGenericInst GenInst_DefaultExecutionOrder_t1687762308_0_0_0 = { 1, GenInst_DefaultExecutionOrder_t1687762308_0_0_0_Types };
static const RuntimeType* GenInst_AudioPlayableOutput_t2616039667_0_0_0_Types[] = { (&AudioPlayableOutput_t2616039667_0_0_0) };
extern const Il2CppGenericInst GenInst_AudioPlayableOutput_t2616039667_0_0_0 = { 1, GenInst_AudioPlayableOutput_t2616039667_0_0_0_Types };
static const RuntimeType* GenInst_PlayerConnection_t1218065583_0_0_0_Types[] = { (&PlayerConnection_t1218065583_0_0_0) };
extern const Il2CppGenericInst GenInst_PlayerConnection_t1218065583_0_0_0 = { 1, GenInst_PlayerConnection_t1218065583_0_0_0_Types };
static const RuntimeType* GenInst_ScriptPlayableOutput_t2716968363_0_0_0_Types[] = { (&ScriptPlayableOutput_t2716968363_0_0_0) };
extern const Il2CppGenericInst GenInst_ScriptPlayableOutput_t2716968363_0_0_0 = { 1, GenInst_ScriptPlayableOutput_t2716968363_0_0_0_Types };
static const RuntimeType* GenInst_GUILayer_t3734926407_0_0_0_Types[] = { (&GUILayer_t3734926407_0_0_0) };
extern const Il2CppGenericInst GenInst_GUILayer_t3734926407_0_0_0 = { 1, GenInst_GUILayer_t3734926407_0_0_0_Types };
static const RuntimeType* GenInst_Rigidbody_t3670484383_0_0_0_Types[] = { (&Rigidbody_t3670484383_0_0_0) };
extern const Il2CppGenericInst GenInst_Rigidbody_t3670484383_0_0_0 = { 1, GenInst_Rigidbody_t3670484383_0_0_0_Types };
static const RuntimeType* GenInst_CharacterController_t2965295687_0_0_0_Types[] = { (&CharacterController_t2965295687_0_0_0) };
extern const Il2CppGenericInst GenInst_CharacterController_t2965295687_0_0_0 = { 1, GenInst_CharacterController_t2965295687_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2173232590_0_0_0_KeyValuePair_2_t2173232590_0_0_0_Types[] = { (&KeyValuePair_2_t2173232590_0_0_0), (&KeyValuePair_2_t2173232590_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2173232590_0_0_0_KeyValuePair_2_t2173232590_0_0_0 = { 2, GenInst_KeyValuePair_2_t2173232590_0_0_0_KeyValuePair_2_t2173232590_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2173232590_0_0_0_RuntimeObject_0_0_0_Types[] = { (&KeyValuePair_2_t2173232590_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2173232590_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_KeyValuePair_2_t2173232590_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3674847205_0_0_0_KeyValuePair_2_t3674847205_0_0_0_Types[] = { (&KeyValuePair_2_t3674847205_0_0_0), (&KeyValuePair_2_t3674847205_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3674847205_0_0_0_KeyValuePair_2_t3674847205_0_0_0 = { 2, GenInst_KeyValuePair_2_t3674847205_0_0_0_KeyValuePair_2_t3674847205_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3674847205_0_0_0_RuntimeObject_0_0_0_Types[] = { (&KeyValuePair_2_t3674847205_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3674847205_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_KeyValuePair_2_t3674847205_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3710135120_0_0_0_KeyValuePair_2_t3710135120_0_0_0_Types[] = { (&KeyValuePair_2_t3710135120_0_0_0), (&KeyValuePair_2_t3710135120_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3710135120_0_0_0_KeyValuePair_2_t3710135120_0_0_0 = { 2, GenInst_KeyValuePair_2_t3710135120_0_0_0_KeyValuePair_2_t3710135120_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3710135120_0_0_0_RuntimeObject_0_0_0_Types[] = { (&KeyValuePair_2_t3710135120_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3710135120_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_KeyValuePair_2_t3710135120_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3369932832_0_0_0_KeyValuePair_2_t3369932832_0_0_0_Types[] = { (&KeyValuePair_2_t3369932832_0_0_0), (&KeyValuePair_2_t3369932832_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3369932832_0_0_0_KeyValuePair_2_t3369932832_0_0_0 = { 2, GenInst_KeyValuePair_2_t3369932832_0_0_0_KeyValuePair_2_t3369932832_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3369932832_0_0_0_RuntimeObject_0_0_0_Types[] = { (&KeyValuePair_2_t3369932832_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3369932832_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_KeyValuePair_2_t3369932832_0_0_0_RuntimeObject_0_0_0_Types };
extern const Il2CppGenericInst* const g_Il2CppGenericInstTable[337] = 
{
	&GenInst_RuntimeObject_0_0_0,
	&GenInst_Int32_t438220675_0_0_0,
	&GenInst_Char_t4217985068_0_0_0,
	&GenInst_Int64_t3733094498_0_0_0,
	&GenInst_UInt32_t1752406861_0_0_0,
	&GenInst_UInt64_t1261996727_0_0_0,
	&GenInst_Byte_t1695016127_0_0_0,
	&GenInst_SByte_t1526744772_0_0_0,
	&GenInst_Int16_t674212087_0_0_0,
	&GenInst_UInt16_t2530548644_0_0_0,
	&GenInst_String_t_0_0_0,
	&GenInst_IConvertible_t893085710_0_0_0,
	&GenInst_IComparable_t242364074_0_0_0,
	&GenInst_IEnumerable_t1561071510_0_0_0,
	&GenInst_ICloneable_t3275016770_0_0_0,
	&GenInst_IComparable_1_t1512452349_0_0_0,
	&GenInst_IEquatable_1_t3218538922_0_0_0,
	&GenInst_Type_t_0_0_0,
	&GenInst_IReflect_t3760602010_0_0_0,
	&GenInst__Type_t3776473474_0_0_0,
	&GenInst_MemberInfo_t_0_0_0,
	&GenInst_ICustomAttributeProvider_t2305050174_0_0_0,
	&GenInst__MemberInfo_t3276260911_0_0_0,
	&GenInst_Single_t3678960876_0_0_0,
	&GenInst_Double_t3420139759_0_0_0,
	&GenInst_Decimal_t2382302464_0_0_0,
	&GenInst_Boolean_t402932760_0_0_0,
	&GenInst_Delegate_t2990640460_0_0_0,
	&GenInst_ISerializable_t3453043479_0_0_0,
	&GenInst_ParameterInfo_t3793757615_0_0_0,
	&GenInst__ParameterInfo_t1133799119_0_0_0,
	&GenInst_ParameterModifier_t1406754278_0_0_0,
	&GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0,
	&GenInst_FieldInfo_t_0_0_0,
	&GenInst__FieldInfo_t616591751_0_0_0,
	&GenInst_MethodInfo_t_0_0_0,
	&GenInst__MethodInfo_t187796706_0_0_0,
	&GenInst_MethodBase_t2010470530_0_0_0,
	&GenInst__MethodBase_t1718158610_0_0_0,
	&GenInst_ConstructorInfo_t2050809311_0_0_0,
	&GenInst__ConstructorInfo_t3612455801_0_0_0,
	&GenInst_IntPtr_t_0_0_0,
	&GenInst_TableRange_t2080199027_0_0_0,
	&GenInst_TailoringInfo_t3419808840_0_0_0,
	&GenInst_String_t_0_0_0_Int32_t438220675_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0,
	&GenInst_KeyValuePair_2_t3710135120_0_0_0,
	&GenInst_Link_t808767725_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0_DictionaryEntry_t578375704_0_0_0,
	&GenInst_DictionaryEntry_t578375704_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Int32_t438220675_0_0_0_KeyValuePair_2_t3710135120_0_0_0,
	&GenInst_String_t_0_0_0_Int32_t438220675_0_0_0_DictionaryEntry_t578375704_0_0_0,
	&GenInst_String_t_0_0_0_Int32_t438220675_0_0_0_KeyValuePair_2_t1201597358_0_0_0,
	&GenInst_KeyValuePair_2_t1201597358_0_0_0,
	&GenInst_Contraction_t3155759031_0_0_0,
	&GenInst_Level2Map_t2835147305_0_0_0,
	&GenInst_BigInteger_t964697200_0_0_0,
	&GenInst_KeySizes_t45689487_0_0_0,
	&GenInst_KeyValuePair_2_t3369932832_0_0_0,
	&GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0,
	&GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t3369932832_0_0_0,
	&GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0,
	&GenInst_Slot_t2703514113_0_0_0,
	&GenInst_Slot_t2810825829_0_0_0,
	&GenInst_StackFrame_t1838224435_0_0_0,
	&GenInst_Calendar_t4269329426_0_0_0,
	&GenInst_ModuleBuilder_t3159331943_0_0_0,
	&GenInst__ModuleBuilder_t234448247_0_0_0,
	&GenInst_Module_t3479515451_0_0_0,
	&GenInst__Module_t107875809_0_0_0,
	&GenInst_ParameterBuilder_t3753085247_0_0_0,
	&GenInst__ParameterBuilder_t1036287219_0_0_0,
	&GenInst_TypeU5BU5D_t1722708557_0_0_0,
	&GenInst_RuntimeArray_0_0_0,
	&GenInst_ICollection_t2613627688_0_0_0,
	&GenInst_IList_t480837924_0_0_0,
	&GenInst_IList_1_t90195417_0_0_0,
	&GenInst_ICollection_1_t3264224467_0_0_0,
	&GenInst_IEnumerable_1_t2120654357_0_0_0,
	&GenInst_IList_1_t1605682895_0_0_0,
	&GenInst_ICollection_1_t484744649_0_0_0,
	&GenInst_IEnumerable_1_t3636141835_0_0_0,
	&GenInst_IList_1_t1621554359_0_0_0,
	&GenInst_ICollection_1_t500616113_0_0_0,
	&GenInst_IEnumerable_1_t3652013299_0_0_0,
	&GenInst_IList_1_t2289122548_0_0_0,
	&GenInst_ICollection_1_t1168184302_0_0_0,
	&GenInst_IEnumerable_1_t24614192_0_0_0,
	&GenInst_IList_1_t150131059_0_0_0,
	&GenInst_ICollection_1_t3324160109_0_0_0,
	&GenInst_IEnumerable_1_t2180589999_0_0_0,
	&GenInst_IList_1_t1121341796_0_0_0,
	&GenInst_ICollection_1_t403550_0_0_0,
	&GenInst_IEnumerable_1_t3151800736_0_0_0,
	&GenInst_IList_1_t2238066568_0_0_0,
	&GenInst_ICollection_1_t1117128322_0_0_0,
	&GenInst_IEnumerable_1_t4268525508_0_0_0,
	&GenInst_ILTokenInfo_t3857000042_0_0_0,
	&GenInst_LabelData_t2222154365_0_0_0,
	&GenInst_LabelFixup_t426630335_0_0_0,
	&GenInst_GenericTypeParameterBuilder_t1019212843_0_0_0,
	&GenInst_TypeBuilder_t3350860216_0_0_0,
	&GenInst__TypeBuilder_t47360046_0_0_0,
	&GenInst_MethodBuilder_t434851514_0_0_0,
	&GenInst__MethodBuilder_t1063350594_0_0_0,
	&GenInst_ConstructorBuilder_t1269217984_0_0_0,
	&GenInst__ConstructorBuilder_t2590771407_0_0_0,
	&GenInst_FieldBuilder_t2373739222_0_0_0,
	&GenInst__FieldBuilder_t3411354663_0_0_0,
	&GenInst_PropertyInfo_t_0_0_0,
	&GenInst__PropertyInfo_t4067770872_0_0_0,
	&GenInst_CustomAttributeTypedArgument_t2066493570_0_0_0,
	&GenInst_CustomAttributeNamedArgument_t3456585787_0_0_0,
	&GenInst_CustomAttributeData_t73279812_0_0_0,
	&GenInst_ResourceInfo_t1067968749_0_0_0,
	&GenInst_ResourceCacheItem_t2576962992_0_0_0,
	&GenInst_IContextProperty_t406597577_0_0_0,
	&GenInst_Header_t867743215_0_0_0,
	&GenInst_ITrackingHandler_t974392511_0_0_0,
	&GenInst_IContextAttribute_t831350911_0_0_0,
	&GenInst_DateTime_t3836236387_0_0_0,
	&GenInst_TimeSpan_t4182925364_0_0_0,
	&GenInst_TypeTag_t1823465210_0_0_0,
	&GenInst_MonoType_t_0_0_0,
	&GenInst_StrongName_t2472190370_0_0_0,
	&GenInst_IBuiltInEvidence_t2042430021_0_0_0,
	&GenInst_IIdentityPermissionFactory_t3494792867_0_0_0,
	&GenInst_DateTimeOffset_t3036919142_0_0_0,
	&GenInst_Guid_t_0_0_0,
	&GenInst_Version_t3942069453_0_0_0,
	&GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0,
	&GenInst_KeyValuePair_2_t3674847205_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0_DictionaryEntry_t578375704_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Boolean_t402932760_0_0_0_KeyValuePair_2_t3674847205_0_0_0,
	&GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0_DictionaryEntry_t578375704_0_0_0,
	&GenInst_String_t_0_0_0_Boolean_t402932760_0_0_0_KeyValuePair_2_t1166309443_0_0_0,
	&GenInst_KeyValuePair_2_t1166309443_0_0_0,
	&GenInst_X509Certificate_t4268988265_0_0_0,
	&GenInst_IDeserializationCallback_t706750576_0_0_0,
	&GenInst_X509ChainStatus_t2329993372_0_0_0,
	&GenInst_Capture_t1091228552_0_0_0,
	&GenInst_Group_t2387438183_0_0_0,
	&GenInst_Mark_t3306160088_0_0_0,
	&GenInst_UriScheme_t2520867868_0_0_0,
	&GenInst_BigInteger_t964697201_0_0_0,
	&GenInst_ByteU5BU5D_t3003616614_0_0_0,
	&GenInst_IList_1_t3835064308_0_0_0,
	&GenInst_ICollection_1_t2714126062_0_0_0,
	&GenInst_IEnumerable_1_t1570555952_0_0_0,
	&GenInst_ClientCertificateType_t2095209863_0_0_0,
	&GenInst_Object_t3267094820_0_0_0,
	&GenInst_Camera_t142011664_0_0_0,
	&GenInst_Behaviour_t2953351352_0_0_0,
	&GenInst_Component_t21088299_0_0_0,
	&GenInst_Display_t289224223_0_0_0,
	&GenInst_Keyframe_t1047575712_0_0_0,
	&GenInst_Playable_t3436777522_0_0_0,
	&GenInst_PlayableOutput_t758663699_0_0_0,
	&GenInst_Scene_t2009218140_0_0_0_LoadSceneMode_t136971723_0_0_0,
	&GenInst_Scene_t2009218140_0_0_0,
	&GenInst_Scene_t2009218140_0_0_0_Scene_t2009218140_0_0_0,
	&GenInst_SpriteAtlas_t2914147186_0_0_0,
	&GenInst_ContactPoint_t3765348581_0_0_0,
	&GenInst_RaycastHit_t2786726017_0_0_0,
	&GenInst_AudioClipPlayable_t3295732336_0_0_0,
	&GenInst_AudioMixerPlayable_t3345238233_0_0_0,
	&GenInst_Font_t208834271_0_0_0,
	&GenInst_String_t_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t861395070_0_0_0,
	&GenInst_DisallowMultipleComponent_t1571297057_0_0_0,
	&GenInst_Attribute_t1821863933_0_0_0,
	&GenInst__Attribute_t1412570690_0_0_0,
	&GenInst_ExecuteInEditMode_t2292583052_0_0_0,
	&GenInst_RequireComponent_t2231837482_0_0_0,
	&GenInst_HitInfo_t2681867412_0_0_0,
	&GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0,
	&GenInst_PersistentCall_t183227066_0_0_0,
	&GenInst_BaseInvokableCall_t2607094378_0_0_0,
	&GenInst_WorkRequest_t3203378897_0_0_0,
	&GenInst_PlayableBinding_t2470704133_0_0_0,
	&GenInst_MessageTypeSubscribers_t4164304980_0_0_0,
	&GenInst_MessageTypeSubscribers_t4164304980_0_0_0_Boolean_t402932760_0_0_0,
	&GenInst_MessageEventArgs_t1276058715_0_0_0,
	&GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0,
	&GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t2173232590_0_0_0,
	&GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0,
	&GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t2173232590_0_0_0,
	&GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0_DictionaryEntry_t578375704_0_0_0,
	&GenInst_IntPtr_t_0_0_0_WeakReference_t2646405993_0_0_0_KeyValuePair_2_t426652900_0_0_0,
	&GenInst_KeyValuePair_2_t426652900_0_0_0,
	&GenInst_String_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t578375704_0_0_0,
	&GenInst_String_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t861395070_0_0_0,
	&GenInst_FieldWithTarget_t2257325677_0_0_0,
	&GenInst_IEnumerable_1_t1022578892_gp_0_0_0_0,
	&GenInst_Array_InternalArray__IEnumerable_GetEnumerator_m1669952694_gp_0_0_0_0,
	&GenInst_Array_Sort_m1072890388_gp_0_0_0_0_Array_Sort_m1072890388_gp_0_0_0_0,
	&GenInst_Array_Sort_m2260390429_gp_0_0_0_0_Array_Sort_m2260390429_gp_1_0_0_0,
	&GenInst_Array_Sort_m2466936610_gp_0_0_0_0,
	&GenInst_Array_Sort_m2466936610_gp_0_0_0_0_Array_Sort_m2466936610_gp_0_0_0_0,
	&GenInst_Array_Sort_m1673438336_gp_0_0_0_0,
	&GenInst_Array_Sort_m1673438336_gp_0_0_0_0_Array_Sort_m1673438336_gp_1_0_0_0,
	&GenInst_Array_Sort_m4275090730_gp_0_0_0_0_Array_Sort_m4275090730_gp_0_0_0_0,
	&GenInst_Array_Sort_m2213423065_gp_0_0_0_0_Array_Sort_m2213423065_gp_1_0_0_0,
	&GenInst_Array_Sort_m3813128040_gp_0_0_0_0,
	&GenInst_Array_Sort_m3813128040_gp_0_0_0_0_Array_Sort_m3813128040_gp_0_0_0_0,
	&GenInst_Array_Sort_m2658527309_gp_0_0_0_0,
	&GenInst_Array_Sort_m2658527309_gp_1_0_0_0,
	&GenInst_Array_Sort_m2658527309_gp_0_0_0_0_Array_Sort_m2658527309_gp_1_0_0_0,
	&GenInst_Array_Sort_m972389192_gp_0_0_0_0,
	&GenInst_Array_Sort_m649440607_gp_0_0_0_0,
	&GenInst_Array_qsort_m209006070_gp_0_0_0_0,
	&GenInst_Array_qsort_m209006070_gp_0_0_0_0_Array_qsort_m209006070_gp_1_0_0_0,
	&GenInst_Array_compare_m4182503070_gp_0_0_0_0,
	&GenInst_Array_qsort_m2221164107_gp_0_0_0_0,
	&GenInst_Array_Resize_m2100239636_gp_0_0_0_0,
	&GenInst_Array_TrueForAll_m3027858380_gp_0_0_0_0,
	&GenInst_Array_ForEach_m3706321912_gp_0_0_0_0,
	&GenInst_Array_ConvertAll_m3519299715_gp_0_0_0_0_Array_ConvertAll_m3519299715_gp_1_0_0_0,
	&GenInst_Array_FindLastIndex_m2214885193_gp_0_0_0_0,
	&GenInst_Array_FindLastIndex_m860191247_gp_0_0_0_0,
	&GenInst_Array_FindLastIndex_m1827158888_gp_0_0_0_0,
	&GenInst_Array_FindIndex_m2875137143_gp_0_0_0_0,
	&GenInst_Array_FindIndex_m2010363940_gp_0_0_0_0,
	&GenInst_Array_FindIndex_m3203021108_gp_0_0_0_0,
	&GenInst_Array_BinarySearch_m265843292_gp_0_0_0_0,
	&GenInst_Array_BinarySearch_m2054507326_gp_0_0_0_0,
	&GenInst_Array_BinarySearch_m2165578130_gp_0_0_0_0,
	&GenInst_Array_BinarySearch_m1225743805_gp_0_0_0_0,
	&GenInst_Array_IndexOf_m326784914_gp_0_0_0_0,
	&GenInst_Array_IndexOf_m4162377550_gp_0_0_0_0,
	&GenInst_Array_IndexOf_m1433803741_gp_0_0_0_0,
	&GenInst_Array_LastIndexOf_m1870232505_gp_0_0_0_0,
	&GenInst_Array_LastIndexOf_m1925872913_gp_0_0_0_0,
	&GenInst_Array_LastIndexOf_m1095612650_gp_0_0_0_0,
	&GenInst_Array_FindAll_m4056086111_gp_0_0_0_0,
	&GenInst_Array_Exists_m3820198506_gp_0_0_0_0,
	&GenInst_Array_AsReadOnly_m2538139719_gp_0_0_0_0,
	&GenInst_Array_Find_m2107862747_gp_0_0_0_0,
	&GenInst_Array_FindLast_m1630072226_gp_0_0_0_0,
	&GenInst_InternalEnumerator_1_t511305203_gp_0_0_0_0,
	&GenInst_ArrayReadOnlyList_1_t1478687212_gp_0_0_0_0,
	&GenInst_U3CGetEnumeratorU3Ec__Iterator0_t3090871926_gp_0_0_0_0,
	&GenInst_IList_1_t822657584_gp_0_0_0_0,
	&GenInst_ICollection_1_t299879354_gp_0_0_0_0,
	&GenInst_Nullable_1_t3171292327_gp_0_0_0_0,
	&GenInst_Comparer_1_t612255760_gp_0_0_0_0,
	&GenInst_DefaultComparer_t4070014030_gp_0_0_0_0,
	&GenInst_GenericComparer_1_t1749919386_gp_0_0_0_0,
	&GenInst_Dictionary_2_t1155016036_gp_0_0_0_0,
	&GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0,
	&GenInst_KeyValuePair_2_t249753073_0_0_0,
	&GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_Dictionary_2_Do_CopyTo_m2742623902_gp_0_0_0_0,
	&GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0,
	&GenInst_Dictionary_2_Do_ICollectionCopyTo_m382925975_gp_0_0_0_0_RuntimeObject_0_0_0,
	&GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_DictionaryEntry_t578375704_0_0_0,
	&GenInst_ShimEnumerator_t2146408712_gp_0_0_0_0_ShimEnumerator_t2146408712_gp_1_0_0_0,
	&GenInst_Enumerator_t1186497974_gp_0_0_0_0_Enumerator_t1186497974_gp_1_0_0_0,
	&GenInst_KeyValuePair_2_t2965215337_0_0_0,
	&GenInst_DictionaryEntry_t578375704_0_0_0_DictionaryEntry_t578375704_0_0_0,
	&GenInst_Dictionary_2_t1155016036_gp_0_0_0_0_Dictionary_2_t1155016036_gp_1_0_0_0_KeyValuePair_2_t249753073_0_0_0,
	&GenInst_KeyValuePair_2_t249753073_0_0_0_KeyValuePair_2_t249753073_0_0_0,
	&GenInst_Dictionary_2_t1155016036_gp_1_0_0_0,
	&GenInst_EqualityComparer_1_t3917655132_gp_0_0_0_0,
	&GenInst_DefaultComparer_t2413763153_gp_0_0_0_0,
	&GenInst_GenericEqualityComparer_1_t2616639575_gp_0_0_0_0,
	&GenInst_KeyValuePair_2_t2310743657_0_0_0,
	&GenInst_IDictionary_2_t332250678_gp_0_0_0_0_IDictionary_2_t332250678_gp_1_0_0_0,
	&GenInst_KeyValuePair_2_t3396090807_gp_0_0_0_0_KeyValuePair_2_t3396090807_gp_1_0_0_0,
	&GenInst_List_1_t2059616371_gp_0_0_0_0,
	&GenInst_Enumerator_t548538204_gp_0_0_0_0,
	&GenInst_Collection_1_t2882572264_gp_0_0_0_0,
	&GenInst_ReadOnlyCollection_1_t2481933861_gp_0_0_0_0,
	&GenInst_MonoProperty_GetterAdapterFrame_m1385778246_gp_0_0_0_0_MonoProperty_GetterAdapterFrame_m1385778246_gp_1_0_0_0,
	&GenInst_MonoProperty_StaticGetterAdapterFrame_m917416377_gp_0_0_0_0,
	&GenInst_Queue_1_t3027544886_gp_0_0_0_0,
	&GenInst_Enumerator_t1097944946_gp_0_0_0_0,
	&GenInst_Stack_1_t4283693321_gp_0_0_0_0,
	&GenInst_Enumerator_t3903841341_gp_0_0_0_0,
	&GenInst_Enumerable_Any_m437989361_gp_0_0_0_0,
	&GenInst_Enumerable_Where_m311029895_gp_0_0_0_0,
	&GenInst_Enumerable_Where_m311029895_gp_0_0_0_0_Boolean_t402932760_0_0_0,
	&GenInst_Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0,
	&GenInst_Enumerable_CreateWhereIterator_m2574702225_gp_0_0_0_0_Boolean_t402932760_0_0_0,
	&GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0,
	&GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t1582284265_gp_0_0_0_0_Boolean_t402932760_0_0_0,
	&GenInst_Component_GetComponentInChildren_m2013229797_gp_0_0_0_0,
	&GenInst_Component_GetComponentsInChildren_m3349813871_gp_0_0_0_0,
	&GenInst_Component_GetComponentsInChildren_m3768785598_gp_0_0_0_0,
	&GenInst_Component_GetComponentsInChildren_m1145032281_gp_0_0_0_0,
	&GenInst_Component_GetComponentsInChildren_m4128002223_gp_0_0_0_0,
	&GenInst_Component_GetComponentsInParent_m1346221865_gp_0_0_0_0,
	&GenInst_Component_GetComponentsInParent_m4108781761_gp_0_0_0_0,
	&GenInst_Component_GetComponentsInParent_m704351154_gp_0_0_0_0,
	&GenInst_Component_GetComponents_m3735850386_gp_0_0_0_0,
	&GenInst_Component_GetComponents_m2761802573_gp_0_0_0_0,
	&GenInst_GameObject_GetComponentsInChildren_m3043092117_gp_0_0_0_0,
	&GenInst_GameObject_GetComponentsInParent_m2509003192_gp_0_0_0_0,
	&GenInst_Object_Instantiate_m620518311_gp_0_0_0_0,
	&GenInst_Object_FindObjectsOfType_m2502297032_gp_0_0_0_0,
	&GenInst_Playable_IsPlayableOfType_m3325280013_gp_0_0_0_0,
	&GenInst_PlayableOutput_IsPlayableOutputOfType_m3768091146_gp_0_0_0_0,
	&GenInst_InvokableCall_1_t3068523820_gp_0_0_0_0,
	&GenInst_UnityAction_1_t575283959_0_0_0,
	&GenInst_InvokableCall_2_t4124072994_gp_0_0_0_0_InvokableCall_2_t4124072994_gp_1_0_0_0,
	&GenInst_InvokableCall_2_t4124072994_gp_0_0_0_0,
	&GenInst_InvokableCall_2_t4124072994_gp_1_0_0_0,
	&GenInst_InvokableCall_3_t442739363_gp_0_0_0_0_InvokableCall_3_t442739363_gp_1_0_0_0_InvokableCall_3_t442739363_gp_2_0_0_0,
	&GenInst_InvokableCall_3_t442739363_gp_0_0_0_0,
	&GenInst_InvokableCall_3_t442739363_gp_1_0_0_0,
	&GenInst_InvokableCall_3_t442739363_gp_2_0_0_0,
	&GenInst_InvokableCall_4_t3127597954_gp_0_0_0_0_InvokableCall_4_t3127597954_gp_1_0_0_0_InvokableCall_4_t3127597954_gp_2_0_0_0_InvokableCall_4_t3127597954_gp_3_0_0_0,
	&GenInst_InvokableCall_4_t3127597954_gp_0_0_0_0,
	&GenInst_InvokableCall_4_t3127597954_gp_1_0_0_0,
	&GenInst_InvokableCall_4_t3127597954_gp_2_0_0_0,
	&GenInst_InvokableCall_4_t3127597954_gp_3_0_0_0,
	&GenInst_CachedInvokableCall_1_t2741087613_gp_0_0_0_0,
	&GenInst_UnityEvent_1_t664801528_gp_0_0_0_0,
	&GenInst_UnityEvent_2_t3195527707_gp_0_0_0_0_UnityEvent_2_t3195527707_gp_1_0_0_0,
	&GenInst_UnityEvent_3_t180400136_gp_0_0_0_0_UnityEvent_3_t180400136_gp_1_0_0_0_UnityEvent_3_t180400136_gp_2_0_0_0,
	&GenInst_UnityEvent_4_t316486966_gp_0_0_0_0_UnityEvent_4_t316486966_gp_1_0_0_0_UnityEvent_4_t316486966_gp_2_0_0_0_UnityEvent_4_t316486966_gp_3_0_0_0,
	&GenInst_DefaultExecutionOrder_t1687762308_0_0_0,
	&GenInst_AudioPlayableOutput_t2616039667_0_0_0,
	&GenInst_PlayerConnection_t1218065583_0_0_0,
	&GenInst_ScriptPlayableOutput_t2716968363_0_0_0,
	&GenInst_GUILayer_t3734926407_0_0_0,
	&GenInst_Rigidbody_t3670484383_0_0_0,
	&GenInst_CharacterController_t2965295687_0_0_0,
	&GenInst_KeyValuePair_2_t2173232590_0_0_0_KeyValuePair_2_t2173232590_0_0_0,
	&GenInst_KeyValuePair_2_t2173232590_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t3674847205_0_0_0_KeyValuePair_2_t3674847205_0_0_0,
	&GenInst_KeyValuePair_2_t3674847205_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t3710135120_0_0_0_KeyValuePair_2_t3710135120_0_0_0,
	&GenInst_KeyValuePair_2_t3710135120_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t3369932832_0_0_0_KeyValuePair_2_t3369932832_0_0_0,
	&GenInst_KeyValuePair_2_t3369932832_0_0_0_RuntimeObject_0_0_0,
};
