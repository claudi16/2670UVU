﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "object-internals.h"

// System.Object[]
struct ObjectU5BU5D_t42211586;
// System.Exception
struct Exception_t2443218823;
// System.String
struct String_t;
// System.MulticastDelegate
struct MulticastDelegate_t608486974;
// Mono.Globalization.Unicode.Contraction[]
struct ContractionU5BU5D_t572014478;
// Mono.Globalization.Unicode.Contraction
struct Contraction_t3155759031;
// Mono.Globalization.Unicode.Level2Map[]
struct Level2MapU5BU5D_t3298050836;
// Mono.Globalization.Unicode.Level2Map
struct Level2Map_t2835147305;
// Mono.Globalization.Unicode.CodePointIndexer
struct CodePointIndexer_t1787520931;
// System.Byte[]
struct ByteU5BU5D_t3003616614;
// System.Reflection.MethodBase
struct MethodBase_t2010470530;
// System.Reflection.Module
struct Module_t3479515451;
// System.Runtime.Serialization.ISurrogateSelector
struct ISurrogateSelector_t1458111122;
// System.Runtime.Remoting.Messaging.Header[]
struct HeaderU5BU5D_t4052410742;
// System.Runtime.Remoting.Messaging.Header
struct Header_t867743215;
// System.Runtime.Serialization.SerializationInfo
struct SerializationInfo_t623100739;
// System.Text.StringBuilder
struct StringBuilder_t718897314;
// System.Text.EncoderFallbackBuffer
struct EncoderFallbackBuffer_t1850839809;
// System.Char[]
struct CharU5BU5D_t2816624037;
// System.Text.DecoderFallbackBuffer
struct DecoderFallbackBuffer_t3917683653;
// System.Int64[]
struct Int64U5BU5D_t110483415;
// System.String[]
struct StringU5BU5D_t1828641120;
// System.Collections.Specialized.ListDictionary/DictionaryNode
struct DictionaryNode_t4268507831;
// System.Net.IPAddress
struct IPAddress_t3056411848;
// System.Net.IPv6Address
struct IPv6Address_t2462431949;
// System.UriFormatException
struct UriFormatException_t2885938561;
// System.Int32[]
struct Int32U5BU5D_t1381360402;
// System.Reflection.CustomAttributeNamedArgument[]
struct CustomAttributeNamedArgumentU5BU5D_t2930047098;
// System.Reflection.CustomAttributeTypedArgument[]
struct CustomAttributeTypedArgumentU5BU5D_t3967009591;
// Mono.Globalization.Unicode.CodePointIndexer/TableRange[]
struct TableRangeU5BU5D_t2106422114;
// System.IntPtr[]
struct IntPtrU5BU5D_t3140478640;
// System.Collections.IDictionary
struct IDictionary_t702710298;
// System.UInt16[]
struct UInt16U5BU5D_t3522456909;
// System.Collections.Hashtable
struct Hashtable_t1665082780;
// System.Collections.ArrayList
struct ArrayList_t3384568281;
// System.Runtime.Serialization.IFormatterConverter
struct IFormatterConverter_t2745970127;
// System.Type
struct Type_t;
// System.MonoEnumInfo/SByteComparer
struct SByteComparer_t2237130840;
// System.MonoEnumInfo/ShortComparer
struct ShortComparer_t2447776917;
// System.MonoEnumInfo/IntComparer
struct IntComparer_t882780267;
// System.MonoEnumInfo/LongComparer
struct LongComparer_t3667784522;
// UnityEngine.GameObject
struct GameObject_t2602266141;
// UnityEngine.Camera
struct Camera_t142011664;
// System.Security.Cryptography.RandomNumberGenerator
struct RandomNumberGenerator_t4006679883;
// System.Collections.Generic.Stack`1<System.Object>
struct Stack_1_t1024921593;
// System.Collections.Generic.Queue`1<System.Object>
struct Queue_1_t1177328798;
// System.Collections.Generic.Queue`1<UnityEngine.UnitySynchronizationContext/WorkRequest>
struct Queue_1_t4282689308;
// System.Collections.Generic.List`1<System.Int32>
struct List_1_t1487969539;
// System.Boolean[]
struct BooleanU5BU5D_t1580036233;
// System.Reflection.MemberInfo
struct MemberInfo_t;
// System.Threading.SendOrPostCallback
struct SendOrPostCallback_t1512258509;
// System.Collections.Generic.List`1<System.Object>
struct List_1_t1147767251;
// System.Byte
struct Byte_t1695016127;
// System.Double
struct Double_t3420139759;
// System.UInt16
struct UInt16_t2530548644;
// System.Void
struct Void_t1421048318;
// System.Collections.Generic.Dictionary`2<System.Object,System.Object>
struct Dictionary_2_t3607226823;
// UnityEngine.Collider
struct Collider_t3066580567;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.DelegateData
struct DelegateData_t2320928782;
// System.Collections.Generic.List`1<System.Reflection.CustomAttributeTypedArgument>
struct List_1_t3116242434;
// System.Collections.Generic.Dictionary`2<System.Object,System.Int32>
struct Dictionary_2_t3947429111;
// System.Collections.Generic.Dictionary`2<System.Object,System.Boolean>
struct Dictionary_2_t3912141196;
// System.Reflection.TypeFilter
struct TypeFilter_t3805304870;
// System.Reflection.Assembly
struct Assembly_t3774988722;
// System.Reflection.MethodInfo[]
struct MethodInfoU5BU5D_t2800860053;
// System.Collections.Generic.List`1<System.Reflection.CustomAttributeNamedArgument>
struct List_1_t211367355;
// UnityEngine.Playables.PlayableBinding[]
struct PlayableBindingU5BU5D_t3564038728;
// UnityEngine.Object
struct Object_t3267094820;
// System.Collections.Generic.Dictionary`2<System.IntPtr,System.Object>
struct Dictionary_2_t2410526581;

struct Object_t3267094820_marshaled_com;

struct ObjectU5BU5D_t42211586;
struct ContractionU5BU5D_t572014478;
struct Level2MapU5BU5D_t3298050836;
struct ByteU5BU5D_t3003616614;
struct HeaderU5BU5D_t4052410742;
struct CharU5BU5D_t2816624037;
struct Int64U5BU5D_t110483415;
struct StringU5BU5D_t1828641120;
struct Int32U5BU5D_t1381360402;
struct CustomAttributeNamedArgumentU5BU5D_t2930047098;
struct CustomAttributeTypedArgumentU5BU5D_t3967009591;


#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef CODEPOINTINDEXER_T1787520931_H
#define CODEPOINTINDEXER_T1787520931_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Globalization.Unicode.CodePointIndexer
struct  CodePointIndexer_t1787520931  : public RuntimeObject
{
public:
	// Mono.Globalization.Unicode.CodePointIndexer/TableRange[] Mono.Globalization.Unicode.CodePointIndexer::ranges
	TableRangeU5BU5D_t2106422114* ___ranges_0;
	// System.Int32 Mono.Globalization.Unicode.CodePointIndexer::TotalCount
	int32_t ___TotalCount_1;
	// System.Int32 Mono.Globalization.Unicode.CodePointIndexer::defaultIndex
	int32_t ___defaultIndex_2;
	// System.Int32 Mono.Globalization.Unicode.CodePointIndexer::defaultCP
	int32_t ___defaultCP_3;

public:
	inline static int32_t get_offset_of_ranges_0() { return static_cast<int32_t>(offsetof(CodePointIndexer_t1787520931, ___ranges_0)); }
	inline TableRangeU5BU5D_t2106422114* get_ranges_0() const { return ___ranges_0; }
	inline TableRangeU5BU5D_t2106422114** get_address_of_ranges_0() { return &___ranges_0; }
	inline void set_ranges_0(TableRangeU5BU5D_t2106422114* value)
	{
		___ranges_0 = value;
		Il2CppCodeGenWriteBarrier((&___ranges_0), value);
	}

	inline static int32_t get_offset_of_TotalCount_1() { return static_cast<int32_t>(offsetof(CodePointIndexer_t1787520931, ___TotalCount_1)); }
	inline int32_t get_TotalCount_1() const { return ___TotalCount_1; }
	inline int32_t* get_address_of_TotalCount_1() { return &___TotalCount_1; }
	inline void set_TotalCount_1(int32_t value)
	{
		___TotalCount_1 = value;
	}

	inline static int32_t get_offset_of_defaultIndex_2() { return static_cast<int32_t>(offsetof(CodePointIndexer_t1787520931, ___defaultIndex_2)); }
	inline int32_t get_defaultIndex_2() const { return ___defaultIndex_2; }
	inline int32_t* get_address_of_defaultIndex_2() { return &___defaultIndex_2; }
	inline void set_defaultIndex_2(int32_t value)
	{
		___defaultIndex_2 = value;
	}

	inline static int32_t get_offset_of_defaultCP_3() { return static_cast<int32_t>(offsetof(CodePointIndexer_t1787520931, ___defaultCP_3)); }
	inline int32_t get_defaultCP_3() const { return ___defaultCP_3; }
	inline int32_t* get_address_of_defaultCP_3() { return &___defaultCP_3; }
	inline void set_defaultCP_3(int32_t value)
	{
		___defaultCP_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CODEPOINTINDEXER_T1787520931_H
#ifndef STRING_T_H
#define STRING_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::length
	int32_t ___length_0;
	// System.Char System.String::start_char
	Il2CppChar ___start_char_1;

public:
	inline static int32_t get_offset_of_length_0() { return static_cast<int32_t>(offsetof(String_t, ___length_0)); }
	inline int32_t get_length_0() const { return ___length_0; }
	inline int32_t* get_address_of_length_0() { return &___length_0; }
	inline void set_length_0(int32_t value)
	{
		___length_0 = value;
	}

	inline static int32_t get_offset_of_start_char_1() { return static_cast<int32_t>(offsetof(String_t, ___start_char_1)); }
	inline Il2CppChar get_start_char_1() const { return ___start_char_1; }
	inline Il2CppChar* get_address_of_start_char_1() { return &___start_char_1; }
	inline void set_start_char_1(Il2CppChar value)
	{
		___start_char_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_2;
	// System.Char[] System.String::WhiteChars
	CharU5BU5D_t2816624037* ___WhiteChars_3;

public:
	inline static int32_t get_offset_of_Empty_2() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_2)); }
	inline String_t* get_Empty_2() const { return ___Empty_2; }
	inline String_t** get_address_of_Empty_2() { return &___Empty_2; }
	inline void set_Empty_2(String_t* value)
	{
		___Empty_2 = value;
		Il2CppCodeGenWriteBarrier((&___Empty_2), value);
	}

	inline static int32_t get_offset_of_WhiteChars_3() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___WhiteChars_3)); }
	inline CharU5BU5D_t2816624037* get_WhiteChars_3() const { return ___WhiteChars_3; }
	inline CharU5BU5D_t2816624037** get_address_of_WhiteChars_3() { return &___WhiteChars_3; }
	inline void set_WhiteChars_3(CharU5BU5D_t2816624037* value)
	{
		___WhiteChars_3 = value;
		Il2CppCodeGenWriteBarrier((&___WhiteChars_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRING_T_H
#ifndef EXCEPTION_T2443218823_H
#define EXCEPTION_T2443218823_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Exception
struct  Exception_t2443218823  : public RuntimeObject
{
public:
	// System.IntPtr[] System.Exception::trace_ips
	IntPtrU5BU5D_t3140478640* ___trace_ips_0;
	// System.Exception System.Exception::inner_exception
	Exception_t2443218823 * ___inner_exception_1;
	// System.String System.Exception::message
	String_t* ___message_2;
	// System.String System.Exception::help_link
	String_t* ___help_link_3;
	// System.String System.Exception::class_name
	String_t* ___class_name_4;
	// System.String System.Exception::stack_trace
	String_t* ___stack_trace_5;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_6;
	// System.Int32 System.Exception::remote_stack_index
	int32_t ___remote_stack_index_7;
	// System.Int32 System.Exception::hresult
	int32_t ___hresult_8;
	// System.String System.Exception::source
	String_t* ___source_9;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_10;

public:
	inline static int32_t get_offset_of_trace_ips_0() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ___trace_ips_0)); }
	inline IntPtrU5BU5D_t3140478640* get_trace_ips_0() const { return ___trace_ips_0; }
	inline IntPtrU5BU5D_t3140478640** get_address_of_trace_ips_0() { return &___trace_ips_0; }
	inline void set_trace_ips_0(IntPtrU5BU5D_t3140478640* value)
	{
		___trace_ips_0 = value;
		Il2CppCodeGenWriteBarrier((&___trace_ips_0), value);
	}

	inline static int32_t get_offset_of_inner_exception_1() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ___inner_exception_1)); }
	inline Exception_t2443218823 * get_inner_exception_1() const { return ___inner_exception_1; }
	inline Exception_t2443218823 ** get_address_of_inner_exception_1() { return &___inner_exception_1; }
	inline void set_inner_exception_1(Exception_t2443218823 * value)
	{
		___inner_exception_1 = value;
		Il2CppCodeGenWriteBarrier((&___inner_exception_1), value);
	}

	inline static int32_t get_offset_of_message_2() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ___message_2)); }
	inline String_t* get_message_2() const { return ___message_2; }
	inline String_t** get_address_of_message_2() { return &___message_2; }
	inline void set_message_2(String_t* value)
	{
		___message_2 = value;
		Il2CppCodeGenWriteBarrier((&___message_2), value);
	}

	inline static int32_t get_offset_of_help_link_3() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ___help_link_3)); }
	inline String_t* get_help_link_3() const { return ___help_link_3; }
	inline String_t** get_address_of_help_link_3() { return &___help_link_3; }
	inline void set_help_link_3(String_t* value)
	{
		___help_link_3 = value;
		Il2CppCodeGenWriteBarrier((&___help_link_3), value);
	}

	inline static int32_t get_offset_of_class_name_4() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ___class_name_4)); }
	inline String_t* get_class_name_4() const { return ___class_name_4; }
	inline String_t** get_address_of_class_name_4() { return &___class_name_4; }
	inline void set_class_name_4(String_t* value)
	{
		___class_name_4 = value;
		Il2CppCodeGenWriteBarrier((&___class_name_4), value);
	}

	inline static int32_t get_offset_of_stack_trace_5() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ___stack_trace_5)); }
	inline String_t* get_stack_trace_5() const { return ___stack_trace_5; }
	inline String_t** get_address_of_stack_trace_5() { return &___stack_trace_5; }
	inline void set_stack_trace_5(String_t* value)
	{
		___stack_trace_5 = value;
		Il2CppCodeGenWriteBarrier((&___stack_trace_5), value);
	}

	inline static int32_t get_offset_of__remoteStackTraceString_6() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ____remoteStackTraceString_6)); }
	inline String_t* get__remoteStackTraceString_6() const { return ____remoteStackTraceString_6; }
	inline String_t** get_address_of__remoteStackTraceString_6() { return &____remoteStackTraceString_6; }
	inline void set__remoteStackTraceString_6(String_t* value)
	{
		____remoteStackTraceString_6 = value;
		Il2CppCodeGenWriteBarrier((&____remoteStackTraceString_6), value);
	}

	inline static int32_t get_offset_of_remote_stack_index_7() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ___remote_stack_index_7)); }
	inline int32_t get_remote_stack_index_7() const { return ___remote_stack_index_7; }
	inline int32_t* get_address_of_remote_stack_index_7() { return &___remote_stack_index_7; }
	inline void set_remote_stack_index_7(int32_t value)
	{
		___remote_stack_index_7 = value;
	}

	inline static int32_t get_offset_of_hresult_8() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ___hresult_8)); }
	inline int32_t get_hresult_8() const { return ___hresult_8; }
	inline int32_t* get_address_of_hresult_8() { return &___hresult_8; }
	inline void set_hresult_8(int32_t value)
	{
		___hresult_8 = value;
	}

	inline static int32_t get_offset_of_source_9() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ___source_9)); }
	inline String_t* get_source_9() const { return ___source_9; }
	inline String_t** get_address_of_source_9() { return &___source_9; }
	inline void set_source_9(String_t* value)
	{
		___source_9 = value;
		Il2CppCodeGenWriteBarrier((&___source_9), value);
	}

	inline static int32_t get_offset_of__data_10() { return static_cast<int32_t>(offsetof(Exception_t2443218823, ____data_10)); }
	inline RuntimeObject* get__data_10() const { return ____data_10; }
	inline RuntimeObject** get_address_of__data_10() { return &____data_10; }
	inline void set__data_10(RuntimeObject* value)
	{
		____data_10 = value;
		Il2CppCodeGenWriteBarrier((&____data_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXCEPTION_T2443218823_H
#ifndef LEVEL2MAP_T2835147305_H
#define LEVEL2MAP_T2835147305_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Globalization.Unicode.Level2Map
struct  Level2Map_t2835147305  : public RuntimeObject
{
public:
	// System.Byte Mono.Globalization.Unicode.Level2Map::Source
	uint8_t ___Source_0;
	// System.Byte Mono.Globalization.Unicode.Level2Map::Replace
	uint8_t ___Replace_1;

public:
	inline static int32_t get_offset_of_Source_0() { return static_cast<int32_t>(offsetof(Level2Map_t2835147305, ___Source_0)); }
	inline uint8_t get_Source_0() const { return ___Source_0; }
	inline uint8_t* get_address_of_Source_0() { return &___Source_0; }
	inline void set_Source_0(uint8_t value)
	{
		___Source_0 = value;
	}

	inline static int32_t get_offset_of_Replace_1() { return static_cast<int32_t>(offsetof(Level2Map_t2835147305, ___Replace_1)); }
	inline uint8_t get_Replace_1() const { return ___Replace_1; }
	inline uint8_t* get_address_of_Replace_1() { return &___Replace_1; }
	inline void set_Replace_1(uint8_t value)
	{
		___Replace_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LEVEL2MAP_T2835147305_H
#ifndef IPV6ADDRESS_T2462431949_H
#define IPV6ADDRESS_T2462431949_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Net.IPv6Address
struct  IPv6Address_t2462431949  : public RuntimeObject
{
public:
	// System.UInt16[] System.Net.IPv6Address::address
	UInt16U5BU5D_t3522456909* ___address_0;
	// System.Int32 System.Net.IPv6Address::prefixLength
	int32_t ___prefixLength_1;
	// System.Int64 System.Net.IPv6Address::scopeId
	int64_t ___scopeId_2;

public:
	inline static int32_t get_offset_of_address_0() { return static_cast<int32_t>(offsetof(IPv6Address_t2462431949, ___address_0)); }
	inline UInt16U5BU5D_t3522456909* get_address_0() const { return ___address_0; }
	inline UInt16U5BU5D_t3522456909** get_address_of_address_0() { return &___address_0; }
	inline void set_address_0(UInt16U5BU5D_t3522456909* value)
	{
		___address_0 = value;
		Il2CppCodeGenWriteBarrier((&___address_0), value);
	}

	inline static int32_t get_offset_of_prefixLength_1() { return static_cast<int32_t>(offsetof(IPv6Address_t2462431949, ___prefixLength_1)); }
	inline int32_t get_prefixLength_1() const { return ___prefixLength_1; }
	inline int32_t* get_address_of_prefixLength_1() { return &___prefixLength_1; }
	inline void set_prefixLength_1(int32_t value)
	{
		___prefixLength_1 = value;
	}

	inline static int32_t get_offset_of_scopeId_2() { return static_cast<int32_t>(offsetof(IPv6Address_t2462431949, ___scopeId_2)); }
	inline int64_t get_scopeId_2() const { return ___scopeId_2; }
	inline int64_t* get_address_of_scopeId_2() { return &___scopeId_2; }
	inline void set_scopeId_2(int64_t value)
	{
		___scopeId_2 = value;
	}
};

struct IPv6Address_t2462431949_StaticFields
{
public:
	// System.Net.IPv6Address System.Net.IPv6Address::Loopback
	IPv6Address_t2462431949 * ___Loopback_3;
	// System.Net.IPv6Address System.Net.IPv6Address::Unspecified
	IPv6Address_t2462431949 * ___Unspecified_4;

public:
	inline static int32_t get_offset_of_Loopback_3() { return static_cast<int32_t>(offsetof(IPv6Address_t2462431949_StaticFields, ___Loopback_3)); }
	inline IPv6Address_t2462431949 * get_Loopback_3() const { return ___Loopback_3; }
	inline IPv6Address_t2462431949 ** get_address_of_Loopback_3() { return &___Loopback_3; }
	inline void set_Loopback_3(IPv6Address_t2462431949 * value)
	{
		___Loopback_3 = value;
		Il2CppCodeGenWriteBarrier((&___Loopback_3), value);
	}

	inline static int32_t get_offset_of_Unspecified_4() { return static_cast<int32_t>(offsetof(IPv6Address_t2462431949_StaticFields, ___Unspecified_4)); }
	inline IPv6Address_t2462431949 * get_Unspecified_4() const { return ___Unspecified_4; }
	inline IPv6Address_t2462431949 ** get_address_of_Unspecified_4() { return &___Unspecified_4; }
	inline void set_Unspecified_4(IPv6Address_t2462431949 * value)
	{
		___Unspecified_4 = value;
		Il2CppCodeGenWriteBarrier((&___Unspecified_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // IPV6ADDRESS_T2462431949_H
#ifndef DICTIONARYNODE_T4268507831_H
#define DICTIONARYNODE_T4268507831_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Specialized.ListDictionary/DictionaryNode
struct  DictionaryNode_t4268507831  : public RuntimeObject
{
public:
	// System.Object System.Collections.Specialized.ListDictionary/DictionaryNode::key
	RuntimeObject * ___key_0;
	// System.Object System.Collections.Specialized.ListDictionary/DictionaryNode::value
	RuntimeObject * ___value_1;
	// System.Collections.Specialized.ListDictionary/DictionaryNode System.Collections.Specialized.ListDictionary/DictionaryNode::next
	DictionaryNode_t4268507831 * ___next_2;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(DictionaryNode_t4268507831, ___key_0)); }
	inline RuntimeObject * get_key_0() const { return ___key_0; }
	inline RuntimeObject ** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(RuntimeObject * value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((&___key_0), value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(DictionaryNode_t4268507831, ___value_1)); }
	inline RuntimeObject * get_value_1() const { return ___value_1; }
	inline RuntimeObject ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(RuntimeObject * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}

	inline static int32_t get_offset_of_next_2() { return static_cast<int32_t>(offsetof(DictionaryNode_t4268507831, ___next_2)); }
	inline DictionaryNode_t4268507831 * get_next_2() const { return ___next_2; }
	inline DictionaryNode_t4268507831 ** get_address_of_next_2() { return &___next_2; }
	inline void set_next_2(DictionaryNode_t4268507831 * value)
	{
		___next_2 = value;
		Il2CppCodeGenWriteBarrier((&___next_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARYNODE_T4268507831_H
#ifndef DECODERFALLBACKBUFFER_T3917683653_H
#define DECODERFALLBACKBUFFER_T3917683653_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.DecoderFallbackBuffer
struct  DecoderFallbackBuffer_t3917683653  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DECODERFALLBACKBUFFER_T3917683653_H
#ifndef CONTRACTION_T3155759031_H
#define CONTRACTION_T3155759031_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Globalization.Unicode.Contraction
struct  Contraction_t3155759031  : public RuntimeObject
{
public:
	// System.Char[] Mono.Globalization.Unicode.Contraction::Source
	CharU5BU5D_t2816624037* ___Source_0;
	// System.String Mono.Globalization.Unicode.Contraction::Replacement
	String_t* ___Replacement_1;
	// System.Byte[] Mono.Globalization.Unicode.Contraction::SortKey
	ByteU5BU5D_t3003616614* ___SortKey_2;

public:
	inline static int32_t get_offset_of_Source_0() { return static_cast<int32_t>(offsetof(Contraction_t3155759031, ___Source_0)); }
	inline CharU5BU5D_t2816624037* get_Source_0() const { return ___Source_0; }
	inline CharU5BU5D_t2816624037** get_address_of_Source_0() { return &___Source_0; }
	inline void set_Source_0(CharU5BU5D_t2816624037* value)
	{
		___Source_0 = value;
		Il2CppCodeGenWriteBarrier((&___Source_0), value);
	}

	inline static int32_t get_offset_of_Replacement_1() { return static_cast<int32_t>(offsetof(Contraction_t3155759031, ___Replacement_1)); }
	inline String_t* get_Replacement_1() const { return ___Replacement_1; }
	inline String_t** get_address_of_Replacement_1() { return &___Replacement_1; }
	inline void set_Replacement_1(String_t* value)
	{
		___Replacement_1 = value;
		Il2CppCodeGenWriteBarrier((&___Replacement_1), value);
	}

	inline static int32_t get_offset_of_SortKey_2() { return static_cast<int32_t>(offsetof(Contraction_t3155759031, ___SortKey_2)); }
	inline ByteU5BU5D_t3003616614* get_SortKey_2() const { return ___SortKey_2; }
	inline ByteU5BU5D_t3003616614** get_address_of_SortKey_2() { return &___SortKey_2; }
	inline void set_SortKey_2(ByteU5BU5D_t3003616614* value)
	{
		___SortKey_2 = value;
		Il2CppCodeGenWriteBarrier((&___SortKey_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONTRACTION_T3155759031_H
#ifndef HEADER_T867743215_H
#define HEADER_T867743215_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.Messaging.Header
struct  Header_t867743215  : public RuntimeObject
{
public:
	// System.String System.Runtime.Remoting.Messaging.Header::HeaderNamespace
	String_t* ___HeaderNamespace_0;
	// System.Boolean System.Runtime.Remoting.Messaging.Header::MustUnderstand
	bool ___MustUnderstand_1;
	// System.String System.Runtime.Remoting.Messaging.Header::Name
	String_t* ___Name_2;
	// System.Object System.Runtime.Remoting.Messaging.Header::Value
	RuntimeObject * ___Value_3;

public:
	inline static int32_t get_offset_of_HeaderNamespace_0() { return static_cast<int32_t>(offsetof(Header_t867743215, ___HeaderNamespace_0)); }
	inline String_t* get_HeaderNamespace_0() const { return ___HeaderNamespace_0; }
	inline String_t** get_address_of_HeaderNamespace_0() { return &___HeaderNamespace_0; }
	inline void set_HeaderNamespace_0(String_t* value)
	{
		___HeaderNamespace_0 = value;
		Il2CppCodeGenWriteBarrier((&___HeaderNamespace_0), value);
	}

	inline static int32_t get_offset_of_MustUnderstand_1() { return static_cast<int32_t>(offsetof(Header_t867743215, ___MustUnderstand_1)); }
	inline bool get_MustUnderstand_1() const { return ___MustUnderstand_1; }
	inline bool* get_address_of_MustUnderstand_1() { return &___MustUnderstand_1; }
	inline void set_MustUnderstand_1(bool value)
	{
		___MustUnderstand_1 = value;
	}

	inline static int32_t get_offset_of_Name_2() { return static_cast<int32_t>(offsetof(Header_t867743215, ___Name_2)); }
	inline String_t* get_Name_2() const { return ___Name_2; }
	inline String_t** get_address_of_Name_2() { return &___Name_2; }
	inline void set_Name_2(String_t* value)
	{
		___Name_2 = value;
		Il2CppCodeGenWriteBarrier((&___Name_2), value);
	}

	inline static int32_t get_offset_of_Value_3() { return static_cast<int32_t>(offsetof(Header_t867743215, ___Value_3)); }
	inline RuntimeObject * get_Value_3() const { return ___Value_3; }
	inline RuntimeObject ** get_address_of_Value_3() { return &___Value_3; }
	inline void set_Value_3(RuntimeObject * value)
	{
		___Value_3 = value;
		Il2CppCodeGenWriteBarrier((&___Value_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HEADER_T867743215_H
#ifndef STRINGBUILDER_T718897314_H
#define STRINGBUILDER_T718897314_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.StringBuilder
struct  StringBuilder_t718897314  : public RuntimeObject
{
public:
	// System.Int32 System.Text.StringBuilder::_length
	int32_t ____length_1;
	// System.String System.Text.StringBuilder::_str
	String_t* ____str_2;
	// System.String System.Text.StringBuilder::_cached_str
	String_t* ____cached_str_3;
	// System.Int32 System.Text.StringBuilder::_maxCapacity
	int32_t ____maxCapacity_4;

public:
	inline static int32_t get_offset_of__length_1() { return static_cast<int32_t>(offsetof(StringBuilder_t718897314, ____length_1)); }
	inline int32_t get__length_1() const { return ____length_1; }
	inline int32_t* get_address_of__length_1() { return &____length_1; }
	inline void set__length_1(int32_t value)
	{
		____length_1 = value;
	}

	inline static int32_t get_offset_of__str_2() { return static_cast<int32_t>(offsetof(StringBuilder_t718897314, ____str_2)); }
	inline String_t* get__str_2() const { return ____str_2; }
	inline String_t** get_address_of__str_2() { return &____str_2; }
	inline void set__str_2(String_t* value)
	{
		____str_2 = value;
		Il2CppCodeGenWriteBarrier((&____str_2), value);
	}

	inline static int32_t get_offset_of__cached_str_3() { return static_cast<int32_t>(offsetof(StringBuilder_t718897314, ____cached_str_3)); }
	inline String_t* get__cached_str_3() const { return ____cached_str_3; }
	inline String_t** get_address_of__cached_str_3() { return &____cached_str_3; }
	inline void set__cached_str_3(String_t* value)
	{
		____cached_str_3 = value;
		Il2CppCodeGenWriteBarrier((&____cached_str_3), value);
	}

	inline static int32_t get_offset_of__maxCapacity_4() { return static_cast<int32_t>(offsetof(StringBuilder_t718897314, ____maxCapacity_4)); }
	inline int32_t get__maxCapacity_4() const { return ____maxCapacity_4; }
	inline int32_t* get_address_of__maxCapacity_4() { return &____maxCapacity_4; }
	inline void set__maxCapacity_4(int32_t value)
	{
		____maxCapacity_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRINGBUILDER_T718897314_H
#ifndef VALUETYPE_T3348802692_H
#define VALUETYPE_T3348802692_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t3348802692  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t3348802692_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t3348802692_marshaled_com
{
};
#endif // VALUETYPE_T3348802692_H
#ifndef SERIALIZATIONINFO_T623100739_H
#define SERIALIZATIONINFO_T623100739_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Serialization.SerializationInfo
struct  SerializationInfo_t623100739  : public RuntimeObject
{
public:
	// System.Collections.Hashtable System.Runtime.Serialization.SerializationInfo::serialized
	Hashtable_t1665082780 * ___serialized_0;
	// System.Collections.ArrayList System.Runtime.Serialization.SerializationInfo::values
	ArrayList_t3384568281 * ___values_1;
	// System.String System.Runtime.Serialization.SerializationInfo::assemblyName
	String_t* ___assemblyName_2;
	// System.String System.Runtime.Serialization.SerializationInfo::fullTypeName
	String_t* ___fullTypeName_3;
	// System.Runtime.Serialization.IFormatterConverter System.Runtime.Serialization.SerializationInfo::converter
	RuntimeObject* ___converter_4;

public:
	inline static int32_t get_offset_of_serialized_0() { return static_cast<int32_t>(offsetof(SerializationInfo_t623100739, ___serialized_0)); }
	inline Hashtable_t1665082780 * get_serialized_0() const { return ___serialized_0; }
	inline Hashtable_t1665082780 ** get_address_of_serialized_0() { return &___serialized_0; }
	inline void set_serialized_0(Hashtable_t1665082780 * value)
	{
		___serialized_0 = value;
		Il2CppCodeGenWriteBarrier((&___serialized_0), value);
	}

	inline static int32_t get_offset_of_values_1() { return static_cast<int32_t>(offsetof(SerializationInfo_t623100739, ___values_1)); }
	inline ArrayList_t3384568281 * get_values_1() const { return ___values_1; }
	inline ArrayList_t3384568281 ** get_address_of_values_1() { return &___values_1; }
	inline void set_values_1(ArrayList_t3384568281 * value)
	{
		___values_1 = value;
		Il2CppCodeGenWriteBarrier((&___values_1), value);
	}

	inline static int32_t get_offset_of_assemblyName_2() { return static_cast<int32_t>(offsetof(SerializationInfo_t623100739, ___assemblyName_2)); }
	inline String_t* get_assemblyName_2() const { return ___assemblyName_2; }
	inline String_t** get_address_of_assemblyName_2() { return &___assemblyName_2; }
	inline void set_assemblyName_2(String_t* value)
	{
		___assemblyName_2 = value;
		Il2CppCodeGenWriteBarrier((&___assemblyName_2), value);
	}

	inline static int32_t get_offset_of_fullTypeName_3() { return static_cast<int32_t>(offsetof(SerializationInfo_t623100739, ___fullTypeName_3)); }
	inline String_t* get_fullTypeName_3() const { return ___fullTypeName_3; }
	inline String_t** get_address_of_fullTypeName_3() { return &___fullTypeName_3; }
	inline void set_fullTypeName_3(String_t* value)
	{
		___fullTypeName_3 = value;
		Il2CppCodeGenWriteBarrier((&___fullTypeName_3), value);
	}

	inline static int32_t get_offset_of_converter_4() { return static_cast<int32_t>(offsetof(SerializationInfo_t623100739, ___converter_4)); }
	inline RuntimeObject* get_converter_4() const { return ___converter_4; }
	inline RuntimeObject** get_address_of_converter_4() { return &___converter_4; }
	inline void set_converter_4(RuntimeObject* value)
	{
		___converter_4 = value;
		Il2CppCodeGenWriteBarrier((&___converter_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SERIALIZATIONINFO_T623100739_H
#ifndef ENCODERFALLBACKBUFFER_T1850839809_H
#define ENCODERFALLBACKBUFFER_T1850839809_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.EncoderFallbackBuffer
struct  EncoderFallbackBuffer_t1850839809  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENCODERFALLBACKBUFFER_T1850839809_H
#ifndef MEMBERINFO_T_H
#define MEMBERINFO_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.MemberInfo
struct  MemberInfo_t  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEMBERINFO_T_H
#ifndef MONOENUMINFO_T2659694797_H
#define MONOENUMINFO_T2659694797_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MonoEnumInfo
struct  MonoEnumInfo_t2659694797 
{
public:
	// System.Type System.MonoEnumInfo::utype
	Type_t * ___utype_0;
	// System.Array System.MonoEnumInfo::values
	RuntimeArray * ___values_1;
	// System.String[] System.MonoEnumInfo::names
	StringU5BU5D_t1828641120* ___names_2;
	// System.Collections.Hashtable System.MonoEnumInfo::name_hash
	Hashtable_t1665082780 * ___name_hash_3;

public:
	inline static int32_t get_offset_of_utype_0() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797, ___utype_0)); }
	inline Type_t * get_utype_0() const { return ___utype_0; }
	inline Type_t ** get_address_of_utype_0() { return &___utype_0; }
	inline void set_utype_0(Type_t * value)
	{
		___utype_0 = value;
		Il2CppCodeGenWriteBarrier((&___utype_0), value);
	}

	inline static int32_t get_offset_of_values_1() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797, ___values_1)); }
	inline RuntimeArray * get_values_1() const { return ___values_1; }
	inline RuntimeArray ** get_address_of_values_1() { return &___values_1; }
	inline void set_values_1(RuntimeArray * value)
	{
		___values_1 = value;
		Il2CppCodeGenWriteBarrier((&___values_1), value);
	}

	inline static int32_t get_offset_of_names_2() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797, ___names_2)); }
	inline StringU5BU5D_t1828641120* get_names_2() const { return ___names_2; }
	inline StringU5BU5D_t1828641120** get_address_of_names_2() { return &___names_2; }
	inline void set_names_2(StringU5BU5D_t1828641120* value)
	{
		___names_2 = value;
		Il2CppCodeGenWriteBarrier((&___names_2), value);
	}

	inline static int32_t get_offset_of_name_hash_3() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797, ___name_hash_3)); }
	inline Hashtable_t1665082780 * get_name_hash_3() const { return ___name_hash_3; }
	inline Hashtable_t1665082780 ** get_address_of_name_hash_3() { return &___name_hash_3; }
	inline void set_name_hash_3(Hashtable_t1665082780 * value)
	{
		___name_hash_3 = value;
		Il2CppCodeGenWriteBarrier((&___name_hash_3), value);
	}
};

struct MonoEnumInfo_t2659694797_StaticFields
{
public:
	// System.Collections.Hashtable System.MonoEnumInfo::global_cache
	Hashtable_t1665082780 * ___global_cache_5;
	// System.Object System.MonoEnumInfo::global_cache_monitor
	RuntimeObject * ___global_cache_monitor_6;
	// System.MonoEnumInfo/SByteComparer System.MonoEnumInfo::sbyte_comparer
	SByteComparer_t2237130840 * ___sbyte_comparer_7;
	// System.MonoEnumInfo/ShortComparer System.MonoEnumInfo::short_comparer
	ShortComparer_t2447776917 * ___short_comparer_8;
	// System.MonoEnumInfo/IntComparer System.MonoEnumInfo::int_comparer
	IntComparer_t882780267 * ___int_comparer_9;
	// System.MonoEnumInfo/LongComparer System.MonoEnumInfo::long_comparer
	LongComparer_t3667784522 * ___long_comparer_10;

public:
	inline static int32_t get_offset_of_global_cache_5() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797_StaticFields, ___global_cache_5)); }
	inline Hashtable_t1665082780 * get_global_cache_5() const { return ___global_cache_5; }
	inline Hashtable_t1665082780 ** get_address_of_global_cache_5() { return &___global_cache_5; }
	inline void set_global_cache_5(Hashtable_t1665082780 * value)
	{
		___global_cache_5 = value;
		Il2CppCodeGenWriteBarrier((&___global_cache_5), value);
	}

	inline static int32_t get_offset_of_global_cache_monitor_6() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797_StaticFields, ___global_cache_monitor_6)); }
	inline RuntimeObject * get_global_cache_monitor_6() const { return ___global_cache_monitor_6; }
	inline RuntimeObject ** get_address_of_global_cache_monitor_6() { return &___global_cache_monitor_6; }
	inline void set_global_cache_monitor_6(RuntimeObject * value)
	{
		___global_cache_monitor_6 = value;
		Il2CppCodeGenWriteBarrier((&___global_cache_monitor_6), value);
	}

	inline static int32_t get_offset_of_sbyte_comparer_7() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797_StaticFields, ___sbyte_comparer_7)); }
	inline SByteComparer_t2237130840 * get_sbyte_comparer_7() const { return ___sbyte_comparer_7; }
	inline SByteComparer_t2237130840 ** get_address_of_sbyte_comparer_7() { return &___sbyte_comparer_7; }
	inline void set_sbyte_comparer_7(SByteComparer_t2237130840 * value)
	{
		___sbyte_comparer_7 = value;
		Il2CppCodeGenWriteBarrier((&___sbyte_comparer_7), value);
	}

	inline static int32_t get_offset_of_short_comparer_8() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797_StaticFields, ___short_comparer_8)); }
	inline ShortComparer_t2447776917 * get_short_comparer_8() const { return ___short_comparer_8; }
	inline ShortComparer_t2447776917 ** get_address_of_short_comparer_8() { return &___short_comparer_8; }
	inline void set_short_comparer_8(ShortComparer_t2447776917 * value)
	{
		___short_comparer_8 = value;
		Il2CppCodeGenWriteBarrier((&___short_comparer_8), value);
	}

	inline static int32_t get_offset_of_int_comparer_9() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797_StaticFields, ___int_comparer_9)); }
	inline IntComparer_t882780267 * get_int_comparer_9() const { return ___int_comparer_9; }
	inline IntComparer_t882780267 ** get_address_of_int_comparer_9() { return &___int_comparer_9; }
	inline void set_int_comparer_9(IntComparer_t882780267 * value)
	{
		___int_comparer_9 = value;
		Il2CppCodeGenWriteBarrier((&___int_comparer_9), value);
	}

	inline static int32_t get_offset_of_long_comparer_10() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797_StaticFields, ___long_comparer_10)); }
	inline LongComparer_t3667784522 * get_long_comparer_10() const { return ___long_comparer_10; }
	inline LongComparer_t3667784522 ** get_address_of_long_comparer_10() { return &___long_comparer_10; }
	inline void set_long_comparer_10(LongComparer_t3667784522 * value)
	{
		___long_comparer_10 = value;
		Il2CppCodeGenWriteBarrier((&___long_comparer_10), value);
	}
};

struct MonoEnumInfo_t2659694797_ThreadStaticFields
{
public:
	// System.Collections.Hashtable System.MonoEnumInfo::cache
	Hashtable_t1665082780 * ___cache_4;

public:
	inline static int32_t get_offset_of_cache_4() { return static_cast<int32_t>(offsetof(MonoEnumInfo_t2659694797_ThreadStaticFields, ___cache_4)); }
	inline Hashtable_t1665082780 * get_cache_4() const { return ___cache_4; }
	inline Hashtable_t1665082780 ** get_address_of_cache_4() { return &___cache_4; }
	inline void set_cache_4(Hashtable_t1665082780 * value)
	{
		___cache_4 = value;
		Il2CppCodeGenWriteBarrier((&___cache_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.MonoEnumInfo
struct MonoEnumInfo_t2659694797_marshaled_pinvoke
{
	Type_t * ___utype_0;
	RuntimeArray * ___values_1;
	char** ___names_2;
	Hashtable_t1665082780 * ___name_hash_3;
};
// Native definition for COM marshalling of System.MonoEnumInfo
struct MonoEnumInfo_t2659694797_marshaled_com
{
	Type_t * ___utype_0;
	RuntimeArray * ___values_1;
	Il2CppChar** ___names_2;
	Hashtable_t1665082780 * ___name_hash_3;
};
#endif // MONOENUMINFO_T2659694797_H
#ifndef KEYVALUEPAIR_2_T3369932832_H
#define KEYVALUEPAIR_2_T3369932832_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.KeyValuePair`2<System.Object,System.Object>
struct  KeyValuePair_2_t3369932832 
{
public:
	// TKey System.Collections.Generic.KeyValuePair`2::key
	RuntimeObject * ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	RuntimeObject * ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t3369932832, ___key_0)); }
	inline RuntimeObject * get_key_0() const { return ___key_0; }
	inline RuntimeObject ** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(RuntimeObject * value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((&___key_0), value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t3369932832, ___value_1)); }
	inline RuntimeObject * get_value_1() const { return ___value_1; }
	inline RuntimeObject ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(RuntimeObject * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYVALUEPAIR_2_T3369932832_H
#ifndef CSSSIZE_T478721537_H
#define CSSSIZE_T478721537_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CSSLayout.CSSSize
struct  CSSSize_t478721537 
{
public:
	// System.Single UnityEngine.CSSLayout.CSSSize::width
	float ___width_0;
	// System.Single UnityEngine.CSSLayout.CSSSize::height
	float ___height_1;

public:
	inline static int32_t get_offset_of_width_0() { return static_cast<int32_t>(offsetof(CSSSize_t478721537, ___width_0)); }
	inline float get_width_0() const { return ___width_0; }
	inline float* get_address_of_width_0() { return &___width_0; }
	inline void set_width_0(float value)
	{
		___width_0 = value;
	}

	inline static int32_t get_offset_of_height_1() { return static_cast<int32_t>(offsetof(CSSSize_t478721537, ___height_1)); }
	inline float get_height_1() const { return ___height_1; }
	inline float* get_address_of_height_1() { return &___height_1; }
	inline void set_height_1(float value)
	{
		___height_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CSSSIZE_T478721537_H
#ifndef HITINFO_T2681867412_H
#define HITINFO_T2681867412_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.SendMouseEvents/HitInfo
struct  HitInfo_t2681867412 
{
public:
	// UnityEngine.GameObject UnityEngine.SendMouseEvents/HitInfo::target
	GameObject_t2602266141 * ___target_0;
	// UnityEngine.Camera UnityEngine.SendMouseEvents/HitInfo::camera
	Camera_t142011664 * ___camera_1;

public:
	inline static int32_t get_offset_of_target_0() { return static_cast<int32_t>(offsetof(HitInfo_t2681867412, ___target_0)); }
	inline GameObject_t2602266141 * get_target_0() const { return ___target_0; }
	inline GameObject_t2602266141 ** get_address_of_target_0() { return &___target_0; }
	inline void set_target_0(GameObject_t2602266141 * value)
	{
		___target_0 = value;
		Il2CppCodeGenWriteBarrier((&___target_0), value);
	}

	inline static int32_t get_offset_of_camera_1() { return static_cast<int32_t>(offsetof(HitInfo_t2681867412, ___camera_1)); }
	inline Camera_t142011664 * get_camera_1() const { return ___camera_1; }
	inline Camera_t142011664 ** get_address_of_camera_1() { return &___camera_1; }
	inline void set_camera_1(Camera_t142011664 * value)
	{
		___camera_1 = value;
		Il2CppCodeGenWriteBarrier((&___camera_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.SendMouseEvents/HitInfo
struct HitInfo_t2681867412_marshaled_pinvoke
{
	GameObject_t2602266141 * ___target_0;
	Camera_t142011664 * ___camera_1;
};
// Native definition for COM marshalling of UnityEngine.SendMouseEvents/HitInfo
struct HitInfo_t2681867412_marshaled_com
{
	GameObject_t2602266141 * ___target_0;
	Camera_t142011664 * ___camera_1;
};
#endif // HITINFO_T2681867412_H
#ifndef SCENE_T2009218140_H
#define SCENE_T2009218140_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.SceneManagement.Scene
struct  Scene_t2009218140 
{
public:
	// System.Int32 UnityEngine.SceneManagement.Scene::m_Handle
	int32_t ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(Scene_t2009218140, ___m_Handle_0)); }
	inline int32_t get_m_Handle_0() const { return ___m_Handle_0; }
	inline int32_t* get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(int32_t value)
	{
		___m_Handle_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCENE_T2009218140_H
#ifndef CULLINGGROUPEVENT_T3626597461_H
#define CULLINGGROUPEVENT_T3626597461_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CullingGroupEvent
struct  CullingGroupEvent_t3626597461 
{
public:
	// System.Int32 UnityEngine.CullingGroupEvent::m_Index
	int32_t ___m_Index_0;
	// System.Byte UnityEngine.CullingGroupEvent::m_PrevState
	uint8_t ___m_PrevState_1;
	// System.Byte UnityEngine.CullingGroupEvent::m_ThisState
	uint8_t ___m_ThisState_2;

public:
	inline static int32_t get_offset_of_m_Index_0() { return static_cast<int32_t>(offsetof(CullingGroupEvent_t3626597461, ___m_Index_0)); }
	inline int32_t get_m_Index_0() const { return ___m_Index_0; }
	inline int32_t* get_address_of_m_Index_0() { return &___m_Index_0; }
	inline void set_m_Index_0(int32_t value)
	{
		___m_Index_0 = value;
	}

	inline static int32_t get_offset_of_m_PrevState_1() { return static_cast<int32_t>(offsetof(CullingGroupEvent_t3626597461, ___m_PrevState_1)); }
	inline uint8_t get_m_PrevState_1() const { return ___m_PrevState_1; }
	inline uint8_t* get_address_of_m_PrevState_1() { return &___m_PrevState_1; }
	inline void set_m_PrevState_1(uint8_t value)
	{
		___m_PrevState_1 = value;
	}

	inline static int32_t get_offset_of_m_ThisState_2() { return static_cast<int32_t>(offsetof(CullingGroupEvent_t3626597461, ___m_ThisState_2)); }
	inline uint8_t get_m_ThisState_2() const { return ___m_ThisState_2; }
	inline uint8_t* get_address_of_m_ThisState_2() { return &___m_ThisState_2; }
	inline void set_m_ThisState_2(uint8_t value)
	{
		___m_ThisState_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CULLINGGROUPEVENT_T3626597461_H
#ifndef VECTOR3_T2987449647_H
#define VECTOR3_T2987449647_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector3
struct  Vector3_t2987449647 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_1;
	// System.Single UnityEngine.Vector3::y
	float ___y_2;
	// System.Single UnityEngine.Vector3::z
	float ___z_3;

public:
	inline static int32_t get_offset_of_x_1() { return static_cast<int32_t>(offsetof(Vector3_t2987449647, ___x_1)); }
	inline float get_x_1() const { return ___x_1; }
	inline float* get_address_of_x_1() { return &___x_1; }
	inline void set_x_1(float value)
	{
		___x_1 = value;
	}

	inline static int32_t get_offset_of_y_2() { return static_cast<int32_t>(offsetof(Vector3_t2987449647, ___y_2)); }
	inline float get_y_2() const { return ___y_2; }
	inline float* get_address_of_y_2() { return &___y_2; }
	inline void set_y_2(float value)
	{
		___y_2 = value;
	}

	inline static int32_t get_offset_of_z_3() { return static_cast<int32_t>(offsetof(Vector3_t2987449647, ___z_3)); }
	inline float get_z_3() const { return ___z_3; }
	inline float* get_address_of_z_3() { return &___z_3; }
	inline void set_z_3(float value)
	{
		___z_3 = value;
	}
};

struct Vector3_t2987449647_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t2987449647  ___zeroVector_4;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t2987449647  ___oneVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t2987449647  ___upVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t2987449647  ___downVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t2987449647  ___leftVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t2987449647  ___rightVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t2987449647  ___forwardVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t2987449647  ___backVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t2987449647  ___positiveInfinityVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t2987449647  ___negativeInfinityVector_13;

public:
	inline static int32_t get_offset_of_zeroVector_4() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___zeroVector_4)); }
	inline Vector3_t2987449647  get_zeroVector_4() const { return ___zeroVector_4; }
	inline Vector3_t2987449647 * get_address_of_zeroVector_4() { return &___zeroVector_4; }
	inline void set_zeroVector_4(Vector3_t2987449647  value)
	{
		___zeroVector_4 = value;
	}

	inline static int32_t get_offset_of_oneVector_5() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___oneVector_5)); }
	inline Vector3_t2987449647  get_oneVector_5() const { return ___oneVector_5; }
	inline Vector3_t2987449647 * get_address_of_oneVector_5() { return &___oneVector_5; }
	inline void set_oneVector_5(Vector3_t2987449647  value)
	{
		___oneVector_5 = value;
	}

	inline static int32_t get_offset_of_upVector_6() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___upVector_6)); }
	inline Vector3_t2987449647  get_upVector_6() const { return ___upVector_6; }
	inline Vector3_t2987449647 * get_address_of_upVector_6() { return &___upVector_6; }
	inline void set_upVector_6(Vector3_t2987449647  value)
	{
		___upVector_6 = value;
	}

	inline static int32_t get_offset_of_downVector_7() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___downVector_7)); }
	inline Vector3_t2987449647  get_downVector_7() const { return ___downVector_7; }
	inline Vector3_t2987449647 * get_address_of_downVector_7() { return &___downVector_7; }
	inline void set_downVector_7(Vector3_t2987449647  value)
	{
		___downVector_7 = value;
	}

	inline static int32_t get_offset_of_leftVector_8() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___leftVector_8)); }
	inline Vector3_t2987449647  get_leftVector_8() const { return ___leftVector_8; }
	inline Vector3_t2987449647 * get_address_of_leftVector_8() { return &___leftVector_8; }
	inline void set_leftVector_8(Vector3_t2987449647  value)
	{
		___leftVector_8 = value;
	}

	inline static int32_t get_offset_of_rightVector_9() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___rightVector_9)); }
	inline Vector3_t2987449647  get_rightVector_9() const { return ___rightVector_9; }
	inline Vector3_t2987449647 * get_address_of_rightVector_9() { return &___rightVector_9; }
	inline void set_rightVector_9(Vector3_t2987449647  value)
	{
		___rightVector_9 = value;
	}

	inline static int32_t get_offset_of_forwardVector_10() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___forwardVector_10)); }
	inline Vector3_t2987449647  get_forwardVector_10() const { return ___forwardVector_10; }
	inline Vector3_t2987449647 * get_address_of_forwardVector_10() { return &___forwardVector_10; }
	inline void set_forwardVector_10(Vector3_t2987449647  value)
	{
		___forwardVector_10 = value;
	}

	inline static int32_t get_offset_of_backVector_11() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___backVector_11)); }
	inline Vector3_t2987449647  get_backVector_11() const { return ___backVector_11; }
	inline Vector3_t2987449647 * get_address_of_backVector_11() { return &___backVector_11; }
	inline void set_backVector_11(Vector3_t2987449647  value)
	{
		___backVector_11 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_12() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___positiveInfinityVector_12)); }
	inline Vector3_t2987449647  get_positiveInfinityVector_12() const { return ___positiveInfinityVector_12; }
	inline Vector3_t2987449647 * get_address_of_positiveInfinityVector_12() { return &___positiveInfinityVector_12; }
	inline void set_positiveInfinityVector_12(Vector3_t2987449647  value)
	{
		___positiveInfinityVector_12 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_t2987449647_StaticFields, ___negativeInfinityVector_13)); }
	inline Vector3_t2987449647  get_negativeInfinityVector_13() const { return ___negativeInfinityVector_13; }
	inline Vector3_t2987449647 * get_address_of_negativeInfinityVector_13() { return &___negativeInfinityVector_13; }
	inline void set_negativeInfinityVector_13(Vector3_t2987449647  value)
	{
		___negativeInfinityVector_13 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR3_T2987449647_H
#ifndef RECT_T1940963286_H
#define RECT_T1940963286_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rect
struct  Rect_t1940963286 
{
public:
	// System.Single UnityEngine.Rect::m_XMin
	float ___m_XMin_0;
	// System.Single UnityEngine.Rect::m_YMin
	float ___m_YMin_1;
	// System.Single UnityEngine.Rect::m_Width
	float ___m_Width_2;
	// System.Single UnityEngine.Rect::m_Height
	float ___m_Height_3;

public:
	inline static int32_t get_offset_of_m_XMin_0() { return static_cast<int32_t>(offsetof(Rect_t1940963286, ___m_XMin_0)); }
	inline float get_m_XMin_0() const { return ___m_XMin_0; }
	inline float* get_address_of_m_XMin_0() { return &___m_XMin_0; }
	inline void set_m_XMin_0(float value)
	{
		___m_XMin_0 = value;
	}

	inline static int32_t get_offset_of_m_YMin_1() { return static_cast<int32_t>(offsetof(Rect_t1940963286, ___m_YMin_1)); }
	inline float get_m_YMin_1() const { return ___m_YMin_1; }
	inline float* get_address_of_m_YMin_1() { return &___m_YMin_1; }
	inline void set_m_YMin_1(float value)
	{
		___m_YMin_1 = value;
	}

	inline static int32_t get_offset_of_m_Width_2() { return static_cast<int32_t>(offsetof(Rect_t1940963286, ___m_Width_2)); }
	inline float get_m_Width_2() const { return ___m_Width_2; }
	inline float* get_address_of_m_Width_2() { return &___m_Width_2; }
	inline void set_m_Width_2(float value)
	{
		___m_Width_2 = value;
	}

	inline static int32_t get_offset_of_m_Height_3() { return static_cast<int32_t>(offsetof(Rect_t1940963286, ___m_Height_3)); }
	inline float get_m_Height_3() const { return ___m_Height_3; }
	inline float* get_address_of_m_Height_3() { return &___m_Height_3; }
	inline void set_m_Height_3(float value)
	{
		___m_Height_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RECT_T1940963286_H
#ifndef SERIALIZATIONENTRY_T2018126969_H
#define SERIALIZATIONENTRY_T2018126969_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Serialization.SerializationEntry
struct  SerializationEntry_t2018126969 
{
public:
	// System.String System.Runtime.Serialization.SerializationEntry::name
	String_t* ___name_0;
	// System.Type System.Runtime.Serialization.SerializationEntry::objectType
	Type_t * ___objectType_1;
	// System.Object System.Runtime.Serialization.SerializationEntry::value
	RuntimeObject * ___value_2;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(SerializationEntry_t2018126969, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}

	inline static int32_t get_offset_of_objectType_1() { return static_cast<int32_t>(offsetof(SerializationEntry_t2018126969, ___objectType_1)); }
	inline Type_t * get_objectType_1() const { return ___objectType_1; }
	inline Type_t ** get_address_of_objectType_1() { return &___objectType_1; }
	inline void set_objectType_1(Type_t * value)
	{
		___objectType_1 = value;
		Il2CppCodeGenWriteBarrier((&___objectType_1), value);
	}

	inline static int32_t get_offset_of_value_2() { return static_cast<int32_t>(offsetof(SerializationEntry_t2018126969, ___value_2)); }
	inline RuntimeObject * get_value_2() const { return ___value_2; }
	inline RuntimeObject ** get_address_of_value_2() { return &___value_2; }
	inline void set_value_2(RuntimeObject * value)
	{
		___value_2 = value;
		Il2CppCodeGenWriteBarrier((&___value_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Runtime.Serialization.SerializationEntry
struct SerializationEntry_t2018126969_marshaled_pinvoke
{
	char* ___name_0;
	Type_t * ___objectType_1;
	Il2CppIUnknown* ___value_2;
};
// Native definition for COM marshalling of System.Runtime.Serialization.SerializationEntry
struct SerializationEntry_t2018126969_marshaled_com
{
	Il2CppChar* ___name_0;
	Type_t * ___objectType_1;
	Il2CppIUnknown* ___value_2;
};
#endif // SERIALIZATIONENTRY_T2018126969_H
#ifndef GUID_T_H
#define GUID_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Guid
struct  Guid_t 
{
public:
	// System.Int32 System.Guid::_a
	int32_t ____a_0;
	// System.Int16 System.Guid::_b
	int16_t ____b_1;
	// System.Int16 System.Guid::_c
	int16_t ____c_2;
	// System.Byte System.Guid::_d
	uint8_t ____d_3;
	// System.Byte System.Guid::_e
	uint8_t ____e_4;
	// System.Byte System.Guid::_f
	uint8_t ____f_5;
	// System.Byte System.Guid::_g
	uint8_t ____g_6;
	// System.Byte System.Guid::_h
	uint8_t ____h_7;
	// System.Byte System.Guid::_i
	uint8_t ____i_8;
	// System.Byte System.Guid::_j
	uint8_t ____j_9;
	// System.Byte System.Guid::_k
	uint8_t ____k_10;

public:
	inline static int32_t get_offset_of__a_0() { return static_cast<int32_t>(offsetof(Guid_t, ____a_0)); }
	inline int32_t get__a_0() const { return ____a_0; }
	inline int32_t* get_address_of__a_0() { return &____a_0; }
	inline void set__a_0(int32_t value)
	{
		____a_0 = value;
	}

	inline static int32_t get_offset_of__b_1() { return static_cast<int32_t>(offsetof(Guid_t, ____b_1)); }
	inline int16_t get__b_1() const { return ____b_1; }
	inline int16_t* get_address_of__b_1() { return &____b_1; }
	inline void set__b_1(int16_t value)
	{
		____b_1 = value;
	}

	inline static int32_t get_offset_of__c_2() { return static_cast<int32_t>(offsetof(Guid_t, ____c_2)); }
	inline int16_t get__c_2() const { return ____c_2; }
	inline int16_t* get_address_of__c_2() { return &____c_2; }
	inline void set__c_2(int16_t value)
	{
		____c_2 = value;
	}

	inline static int32_t get_offset_of__d_3() { return static_cast<int32_t>(offsetof(Guid_t, ____d_3)); }
	inline uint8_t get__d_3() const { return ____d_3; }
	inline uint8_t* get_address_of__d_3() { return &____d_3; }
	inline void set__d_3(uint8_t value)
	{
		____d_3 = value;
	}

	inline static int32_t get_offset_of__e_4() { return static_cast<int32_t>(offsetof(Guid_t, ____e_4)); }
	inline uint8_t get__e_4() const { return ____e_4; }
	inline uint8_t* get_address_of__e_4() { return &____e_4; }
	inline void set__e_4(uint8_t value)
	{
		____e_4 = value;
	}

	inline static int32_t get_offset_of__f_5() { return static_cast<int32_t>(offsetof(Guid_t, ____f_5)); }
	inline uint8_t get__f_5() const { return ____f_5; }
	inline uint8_t* get_address_of__f_5() { return &____f_5; }
	inline void set__f_5(uint8_t value)
	{
		____f_5 = value;
	}

	inline static int32_t get_offset_of__g_6() { return static_cast<int32_t>(offsetof(Guid_t, ____g_6)); }
	inline uint8_t get__g_6() const { return ____g_6; }
	inline uint8_t* get_address_of__g_6() { return &____g_6; }
	inline void set__g_6(uint8_t value)
	{
		____g_6 = value;
	}

	inline static int32_t get_offset_of__h_7() { return static_cast<int32_t>(offsetof(Guid_t, ____h_7)); }
	inline uint8_t get__h_7() const { return ____h_7; }
	inline uint8_t* get_address_of__h_7() { return &____h_7; }
	inline void set__h_7(uint8_t value)
	{
		____h_7 = value;
	}

	inline static int32_t get_offset_of__i_8() { return static_cast<int32_t>(offsetof(Guid_t, ____i_8)); }
	inline uint8_t get__i_8() const { return ____i_8; }
	inline uint8_t* get_address_of__i_8() { return &____i_8; }
	inline void set__i_8(uint8_t value)
	{
		____i_8 = value;
	}

	inline static int32_t get_offset_of__j_9() { return static_cast<int32_t>(offsetof(Guid_t, ____j_9)); }
	inline uint8_t get__j_9() const { return ____j_9; }
	inline uint8_t* get_address_of__j_9() { return &____j_9; }
	inline void set__j_9(uint8_t value)
	{
		____j_9 = value;
	}

	inline static int32_t get_offset_of__k_10() { return static_cast<int32_t>(offsetof(Guid_t, ____k_10)); }
	inline uint8_t get__k_10() const { return ____k_10; }
	inline uint8_t* get_address_of__k_10() { return &____k_10; }
	inline void set__k_10(uint8_t value)
	{
		____k_10 = value;
	}
};

struct Guid_t_StaticFields
{
public:
	// System.Guid System.Guid::Empty
	Guid_t  ___Empty_11;
	// System.Object System.Guid::_rngAccess
	RuntimeObject * ____rngAccess_12;
	// System.Security.Cryptography.RandomNumberGenerator System.Guid::_rng
	RandomNumberGenerator_t4006679883 * ____rng_13;

public:
	inline static int32_t get_offset_of_Empty_11() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ___Empty_11)); }
	inline Guid_t  get_Empty_11() const { return ___Empty_11; }
	inline Guid_t * get_address_of_Empty_11() { return &___Empty_11; }
	inline void set_Empty_11(Guid_t  value)
	{
		___Empty_11 = value;
	}

	inline static int32_t get_offset_of__rngAccess_12() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____rngAccess_12)); }
	inline RuntimeObject * get__rngAccess_12() const { return ____rngAccess_12; }
	inline RuntimeObject ** get_address_of__rngAccess_12() { return &____rngAccess_12; }
	inline void set__rngAccess_12(RuntimeObject * value)
	{
		____rngAccess_12 = value;
		Il2CppCodeGenWriteBarrier((&____rngAccess_12), value);
	}

	inline static int32_t get_offset_of__rng_13() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____rng_13)); }
	inline RandomNumberGenerator_t4006679883 * get__rng_13() const { return ____rng_13; }
	inline RandomNumberGenerator_t4006679883 ** get_address_of__rng_13() { return &____rng_13; }
	inline void set__rng_13(RandomNumberGenerator_t4006679883 * value)
	{
		____rng_13 = value;
		Il2CppCodeGenWriteBarrier((&____rng_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GUID_T_H
#ifndef QUATERNION_T895809378_H
#define QUATERNION_T895809378_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Quaternion
struct  Quaternion_t895809378 
{
public:
	// System.Single UnityEngine.Quaternion::x
	float ___x_0;
	// System.Single UnityEngine.Quaternion::y
	float ___y_1;
	// System.Single UnityEngine.Quaternion::z
	float ___z_2;
	// System.Single UnityEngine.Quaternion::w
	float ___w_3;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Quaternion_t895809378, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Quaternion_t895809378, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(Quaternion_t895809378, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}

	inline static int32_t get_offset_of_w_3() { return static_cast<int32_t>(offsetof(Quaternion_t895809378, ___w_3)); }
	inline float get_w_3() const { return ___w_3; }
	inline float* get_address_of_w_3() { return &___w_3; }
	inline void set_w_3(float value)
	{
		___w_3 = value;
	}
};

struct Quaternion_t895809378_StaticFields
{
public:
	// UnityEngine.Quaternion UnityEngine.Quaternion::identityQuaternion
	Quaternion_t895809378  ___identityQuaternion_4;

public:
	inline static int32_t get_offset_of_identityQuaternion_4() { return static_cast<int32_t>(offsetof(Quaternion_t895809378_StaticFields, ___identityQuaternion_4)); }
	inline Quaternion_t895809378  get_identityQuaternion_4() const { return ___identityQuaternion_4; }
	inline Quaternion_t895809378 * get_address_of_identityQuaternion_4() { return &___identityQuaternion_4; }
	inline void set_identityQuaternion_4(Quaternion_t895809378  value)
	{
		___identityQuaternion_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // QUATERNION_T895809378_H
#ifndef INTERVAL_T176111467_H
#define INTERVAL_T176111467_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.RegularExpressions.Interval
struct  Interval_t176111467 
{
public:
	// System.Int32 System.Text.RegularExpressions.Interval::low
	int32_t ___low_0;
	// System.Int32 System.Text.RegularExpressions.Interval::high
	int32_t ___high_1;
	// System.Boolean System.Text.RegularExpressions.Interval::contiguous
	bool ___contiguous_2;

public:
	inline static int32_t get_offset_of_low_0() { return static_cast<int32_t>(offsetof(Interval_t176111467, ___low_0)); }
	inline int32_t get_low_0() const { return ___low_0; }
	inline int32_t* get_address_of_low_0() { return &___low_0; }
	inline void set_low_0(int32_t value)
	{
		___low_0 = value;
	}

	inline static int32_t get_offset_of_high_1() { return static_cast<int32_t>(offsetof(Interval_t176111467, ___high_1)); }
	inline int32_t get_high_1() const { return ___high_1; }
	inline int32_t* get_address_of_high_1() { return &___high_1; }
	inline void set_high_1(int32_t value)
	{
		___high_1 = value;
	}

	inline static int32_t get_offset_of_contiguous_2() { return static_cast<int32_t>(offsetof(Interval_t176111467, ___contiguous_2)); }
	inline bool get_contiguous_2() const { return ___contiguous_2; }
	inline bool* get_address_of_contiguous_2() { return &___contiguous_2; }
	inline void set_contiguous_2(bool value)
	{
		___contiguous_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Text.RegularExpressions.Interval
struct Interval_t176111467_marshaled_pinvoke
{
	int32_t ___low_0;
	int32_t ___high_1;
	int32_t ___contiguous_2;
};
// Native definition for COM marshalling of System.Text.RegularExpressions.Interval
struct Interval_t176111467_marshaled_com
{
	int32_t ___low_0;
	int32_t ___high_1;
	int32_t ___contiguous_2;
};
#endif // INTERVAL_T176111467_H
#ifndef ENUMERATOR_T2206974221_H
#define ENUMERATOR_T2206974221_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Stack`1/Enumerator<System.Object>
struct  Enumerator_t2206974221 
{
public:
	// System.Collections.Generic.Stack`1<T> System.Collections.Generic.Stack`1/Enumerator::parent
	Stack_1_t1024921593 * ___parent_0;
	// System.Int32 System.Collections.Generic.Stack`1/Enumerator::idx
	int32_t ___idx_1;
	// System.Int32 System.Collections.Generic.Stack`1/Enumerator::_version
	int32_t ____version_2;

public:
	inline static int32_t get_offset_of_parent_0() { return static_cast<int32_t>(offsetof(Enumerator_t2206974221, ___parent_0)); }
	inline Stack_1_t1024921593 * get_parent_0() const { return ___parent_0; }
	inline Stack_1_t1024921593 ** get_address_of_parent_0() { return &___parent_0; }
	inline void set_parent_0(Stack_1_t1024921593 * value)
	{
		___parent_0 = value;
		Il2CppCodeGenWriteBarrier((&___parent_0), value);
	}

	inline static int32_t get_offset_of_idx_1() { return static_cast<int32_t>(offsetof(Enumerator_t2206974221, ___idx_1)); }
	inline int32_t get_idx_1() const { return ___idx_1; }
	inline int32_t* get_address_of_idx_1() { return &___idx_1; }
	inline void set_idx_1(int32_t value)
	{
		___idx_1 = value;
	}

	inline static int32_t get_offset_of__version_2() { return static_cast<int32_t>(offsetof(Enumerator_t2206974221, ____version_2)); }
	inline int32_t get__version_2() const { return ____version_2; }
	inline int32_t* get_address_of__version_2() { return &____version_2; }
	inline void set__version_2(int32_t value)
	{
		____version_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T2206974221_H
#ifndef ENUMERATOR_T4263500154_H
#define ENUMERATOR_T4263500154_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Queue`1/Enumerator<System.Object>
struct  Enumerator_t4263500154 
{
public:
	// System.Collections.Generic.Queue`1<T> System.Collections.Generic.Queue`1/Enumerator::q
	Queue_1_t1177328798 * ___q_0;
	// System.Int32 System.Collections.Generic.Queue`1/Enumerator::idx
	int32_t ___idx_1;
	// System.Int32 System.Collections.Generic.Queue`1/Enumerator::ver
	int32_t ___ver_2;

public:
	inline static int32_t get_offset_of_q_0() { return static_cast<int32_t>(offsetof(Enumerator_t4263500154, ___q_0)); }
	inline Queue_1_t1177328798 * get_q_0() const { return ___q_0; }
	inline Queue_1_t1177328798 ** get_address_of_q_0() { return &___q_0; }
	inline void set_q_0(Queue_1_t1177328798 * value)
	{
		___q_0 = value;
		Il2CppCodeGenWriteBarrier((&___q_0), value);
	}

	inline static int32_t get_offset_of_idx_1() { return static_cast<int32_t>(offsetof(Enumerator_t4263500154, ___idx_1)); }
	inline int32_t get_idx_1() const { return ___idx_1; }
	inline int32_t* get_address_of_idx_1() { return &___idx_1; }
	inline void set_idx_1(int32_t value)
	{
		___idx_1 = value;
	}

	inline static int32_t get_offset_of_ver_2() { return static_cast<int32_t>(offsetof(Enumerator_t4263500154, ___ver_2)); }
	inline int32_t get_ver_2() const { return ___ver_2; }
	inline int32_t* get_address_of_ver_2() { return &___ver_2; }
	inline void set_ver_2(int32_t value)
	{
		___ver_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T4263500154_H
#ifndef VECTOR2_T218349997_H
#define VECTOR2_T218349997_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector2
struct  Vector2_t218349997 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_t218349997, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_t218349997, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_t218349997_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_t218349997  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_t218349997  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_t218349997  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_t218349997  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_t218349997  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_t218349997  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_t218349997  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_t218349997  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_t218349997_StaticFields, ___zeroVector_2)); }
	inline Vector2_t218349997  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_t218349997 * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_t218349997  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_t218349997_StaticFields, ___oneVector_3)); }
	inline Vector2_t218349997  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_t218349997 * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_t218349997  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_t218349997_StaticFields, ___upVector_4)); }
	inline Vector2_t218349997  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_t218349997 * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_t218349997  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_t218349997_StaticFields, ___downVector_5)); }
	inline Vector2_t218349997  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_t218349997 * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_t218349997  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_t218349997_StaticFields, ___leftVector_6)); }
	inline Vector2_t218349997  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_t218349997 * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_t218349997  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_t218349997_StaticFields, ___rightVector_7)); }
	inline Vector2_t218349997  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_t218349997 * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_t218349997  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_t218349997_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_t218349997  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_t218349997 * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_t218349997  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_t218349997_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_t218349997  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_t218349997 * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_t218349997  value)
	{
		___negativeInfinityVector_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR2_T218349997_H
#ifndef ENUM_T4088700107_H
#define ENUM_T4088700107_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t4088700107  : public ValueType_t3348802692
{
public:

public:
};

struct Enum_t4088700107_StaticFields
{
public:
	// System.Char[] System.Enum::split_char
	CharU5BU5D_t2816624037* ___split_char_0;

public:
	inline static int32_t get_offset_of_split_char_0() { return static_cast<int32_t>(offsetof(Enum_t4088700107_StaticFields, ___split_char_0)); }
	inline CharU5BU5D_t2816624037* get_split_char_0() const { return ___split_char_0; }
	inline CharU5BU5D_t2816624037** get_address_of_split_char_0() { return &___split_char_0; }
	inline void set_split_char_0(CharU5BU5D_t2816624037* value)
	{
		___split_char_0 = value;
		Il2CppCodeGenWriteBarrier((&___split_char_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t4088700107_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t4088700107_marshaled_com
{
};
#endif // ENUM_T4088700107_H
#ifndef ENUMERATOR_T3073893368_H
#define ENUMERATOR_T3073893368_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Queue`1/Enumerator<UnityEngine.UnitySynchronizationContext/WorkRequest>
struct  Enumerator_t3073893368 
{
public:
	// System.Collections.Generic.Queue`1<T> System.Collections.Generic.Queue`1/Enumerator::q
	Queue_1_t4282689308 * ___q_0;
	// System.Int32 System.Collections.Generic.Queue`1/Enumerator::idx
	int32_t ___idx_1;
	// System.Int32 System.Collections.Generic.Queue`1/Enumerator::ver
	int32_t ___ver_2;

public:
	inline static int32_t get_offset_of_q_0() { return static_cast<int32_t>(offsetof(Enumerator_t3073893368, ___q_0)); }
	inline Queue_1_t4282689308 * get_q_0() const { return ___q_0; }
	inline Queue_1_t4282689308 ** get_address_of_q_0() { return &___q_0; }
	inline void set_q_0(Queue_1_t4282689308 * value)
	{
		___q_0 = value;
		Il2CppCodeGenWriteBarrier((&___q_0), value);
	}

	inline static int32_t get_offset_of_idx_1() { return static_cast<int32_t>(offsetof(Enumerator_t3073893368, ___idx_1)); }
	inline int32_t get_idx_1() const { return ___idx_1; }
	inline int32_t* get_address_of_idx_1() { return &___idx_1; }
	inline void set_idx_1(int32_t value)
	{
		___idx_1 = value;
	}

	inline static int32_t get_offset_of_ver_2() { return static_cast<int32_t>(offsetof(Enumerator_t3073893368, ___ver_2)); }
	inline int32_t get_ver_2() const { return ___ver_2; }
	inline int32_t* get_address_of_ver_2() { return &___ver_2; }
	inline void set_ver_2(int32_t value)
	{
		___ver_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T3073893368_H
#ifndef ENUMERATOR_T2760704772_H
#define ENUMERATOR_T2760704772_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1/Enumerator<System.Int32>
struct  Enumerator_t2760704772 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::l
	List_1_t1487969539 * ___l_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::ver
	int32_t ___ver_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	int32_t ___current_3;

public:
	inline static int32_t get_offset_of_l_0() { return static_cast<int32_t>(offsetof(Enumerator_t2760704772, ___l_0)); }
	inline List_1_t1487969539 * get_l_0() const { return ___l_0; }
	inline List_1_t1487969539 ** get_address_of_l_0() { return &___l_0; }
	inline void set_l_0(List_1_t1487969539 * value)
	{
		___l_0 = value;
		Il2CppCodeGenWriteBarrier((&___l_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t2760704772, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_ver_2() { return static_cast<int32_t>(offsetof(Enumerator_t2760704772, ___ver_2)); }
	inline int32_t get_ver_2() const { return ___ver_2; }
	inline int32_t* get_address_of_ver_2() { return &___ver_2; }
	inline void set_ver_2(int32_t value)
	{
		___ver_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t2760704772, ___current_3)); }
	inline int32_t get_current_3() const { return ___current_3; }
	inline int32_t* get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(int32_t value)
	{
		___current_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T2760704772_H
#ifndef KEYFRAME_T1047575712_H
#define KEYFRAME_T1047575712_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Keyframe
struct  Keyframe_t1047575712 
{
public:
	// System.Single UnityEngine.Keyframe::m_Time
	float ___m_Time_0;
	// System.Single UnityEngine.Keyframe::m_Value
	float ___m_Value_1;
	// System.Single UnityEngine.Keyframe::m_InTangent
	float ___m_InTangent_2;
	// System.Single UnityEngine.Keyframe::m_OutTangent
	float ___m_OutTangent_3;

public:
	inline static int32_t get_offset_of_m_Time_0() { return static_cast<int32_t>(offsetof(Keyframe_t1047575712, ___m_Time_0)); }
	inline float get_m_Time_0() const { return ___m_Time_0; }
	inline float* get_address_of_m_Time_0() { return &___m_Time_0; }
	inline void set_m_Time_0(float value)
	{
		___m_Time_0 = value;
	}

	inline static int32_t get_offset_of_m_Value_1() { return static_cast<int32_t>(offsetof(Keyframe_t1047575712, ___m_Value_1)); }
	inline float get_m_Value_1() const { return ___m_Value_1; }
	inline float* get_address_of_m_Value_1() { return &___m_Value_1; }
	inline void set_m_Value_1(float value)
	{
		___m_Value_1 = value;
	}

	inline static int32_t get_offset_of_m_InTangent_2() { return static_cast<int32_t>(offsetof(Keyframe_t1047575712, ___m_InTangent_2)); }
	inline float get_m_InTangent_2() const { return ___m_InTangent_2; }
	inline float* get_address_of_m_InTangent_2() { return &___m_InTangent_2; }
	inline void set_m_InTangent_2(float value)
	{
		___m_InTangent_2 = value;
	}

	inline static int32_t get_offset_of_m_OutTangent_3() { return static_cast<int32_t>(offsetof(Keyframe_t1047575712, ___m_OutTangent_3)); }
	inline float get_m_OutTangent_3() const { return ___m_OutTangent_3; }
	inline float* get_address_of_m_OutTangent_3() { return &___m_OutTangent_3; }
	inline void set_m_OutTangent_3(float value)
	{
		___m_OutTangent_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYFRAME_T1047575712_H
#ifndef URISCHEME_T2520867868_H
#define URISCHEME_T2520867868_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Uri/UriScheme
struct  UriScheme_t2520867868 
{
public:
	// System.String System.Uri/UriScheme::scheme
	String_t* ___scheme_0;
	// System.String System.Uri/UriScheme::delimiter
	String_t* ___delimiter_1;
	// System.Int32 System.Uri/UriScheme::defaultPort
	int32_t ___defaultPort_2;

public:
	inline static int32_t get_offset_of_scheme_0() { return static_cast<int32_t>(offsetof(UriScheme_t2520867868, ___scheme_0)); }
	inline String_t* get_scheme_0() const { return ___scheme_0; }
	inline String_t** get_address_of_scheme_0() { return &___scheme_0; }
	inline void set_scheme_0(String_t* value)
	{
		___scheme_0 = value;
		Il2CppCodeGenWriteBarrier((&___scheme_0), value);
	}

	inline static int32_t get_offset_of_delimiter_1() { return static_cast<int32_t>(offsetof(UriScheme_t2520867868, ___delimiter_1)); }
	inline String_t* get_delimiter_1() const { return ___delimiter_1; }
	inline String_t** get_address_of_delimiter_1() { return &___delimiter_1; }
	inline void set_delimiter_1(String_t* value)
	{
		___delimiter_1 = value;
		Il2CppCodeGenWriteBarrier((&___delimiter_1), value);
	}

	inline static int32_t get_offset_of_defaultPort_2() { return static_cast<int32_t>(offsetof(UriScheme_t2520867868, ___defaultPort_2)); }
	inline int32_t get_defaultPort_2() const { return ___defaultPort_2; }
	inline int32_t* get_address_of_defaultPort_2() { return &___defaultPort_2; }
	inline void set_defaultPort_2(int32_t value)
	{
		___defaultPort_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Uri/UriScheme
struct UriScheme_t2520867868_marshaled_pinvoke
{
	char* ___scheme_0;
	char* ___delimiter_1;
	int32_t ___defaultPort_2;
};
// Native definition for COM marshalling of System.Uri/UriScheme
struct UriScheme_t2520867868_marshaled_com
{
	Il2CppChar* ___scheme_0;
	Il2CppChar* ___delimiter_1;
	int32_t ___defaultPort_2;
};
#endif // URISCHEME_T2520867868_H
#ifndef MARK_T3306160088_H
#define MARK_T3306160088_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.RegularExpressions.Mark
struct  Mark_t3306160088 
{
public:
	// System.Int32 System.Text.RegularExpressions.Mark::Start
	int32_t ___Start_0;
	// System.Int32 System.Text.RegularExpressions.Mark::End
	int32_t ___End_1;
	// System.Int32 System.Text.RegularExpressions.Mark::Previous
	int32_t ___Previous_2;

public:
	inline static int32_t get_offset_of_Start_0() { return static_cast<int32_t>(offsetof(Mark_t3306160088, ___Start_0)); }
	inline int32_t get_Start_0() const { return ___Start_0; }
	inline int32_t* get_address_of_Start_0() { return &___Start_0; }
	inline void set_Start_0(int32_t value)
	{
		___Start_0 = value;
	}

	inline static int32_t get_offset_of_End_1() { return static_cast<int32_t>(offsetof(Mark_t3306160088, ___End_1)); }
	inline int32_t get_End_1() const { return ___End_1; }
	inline int32_t* get_address_of_End_1() { return &___End_1; }
	inline void set_End_1(int32_t value)
	{
		___End_1 = value;
	}

	inline static int32_t get_offset_of_Previous_2() { return static_cast<int32_t>(offsetof(Mark_t3306160088, ___Previous_2)); }
	inline int32_t get_Previous_2() const { return ___Previous_2; }
	inline int32_t* get_address_of_Previous_2() { return &___Previous_2; }
	inline void set_Previous_2(int32_t value)
	{
		___Previous_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MARK_T3306160088_H
#ifndef RESOURCECACHEITEM_T2576962992_H
#define RESOURCECACHEITEM_T2576962992_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Resources.ResourceReader/ResourceCacheItem
struct  ResourceCacheItem_t2576962992 
{
public:
	// System.String System.Resources.ResourceReader/ResourceCacheItem::ResourceName
	String_t* ___ResourceName_0;
	// System.Object System.Resources.ResourceReader/ResourceCacheItem::ResourceValue
	RuntimeObject * ___ResourceValue_1;

public:
	inline static int32_t get_offset_of_ResourceName_0() { return static_cast<int32_t>(offsetof(ResourceCacheItem_t2576962992, ___ResourceName_0)); }
	inline String_t* get_ResourceName_0() const { return ___ResourceName_0; }
	inline String_t** get_address_of_ResourceName_0() { return &___ResourceName_0; }
	inline void set_ResourceName_0(String_t* value)
	{
		___ResourceName_0 = value;
		Il2CppCodeGenWriteBarrier((&___ResourceName_0), value);
	}

	inline static int32_t get_offset_of_ResourceValue_1() { return static_cast<int32_t>(offsetof(ResourceCacheItem_t2576962992, ___ResourceValue_1)); }
	inline RuntimeObject * get_ResourceValue_1() const { return ___ResourceValue_1; }
	inline RuntimeObject ** get_address_of_ResourceValue_1() { return &___ResourceValue_1; }
	inline void set_ResourceValue_1(RuntimeObject * value)
	{
		___ResourceValue_1 = value;
		Il2CppCodeGenWriteBarrier((&___ResourceValue_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Resources.ResourceReader/ResourceCacheItem
struct ResourceCacheItem_t2576962992_marshaled_pinvoke
{
	char* ___ResourceName_0;
	Il2CppIUnknown* ___ResourceValue_1;
};
// Native definition for COM marshalling of System.Resources.ResourceReader/ResourceCacheItem
struct ResourceCacheItem_t2576962992_marshaled_com
{
	Il2CppChar* ___ResourceName_0;
	Il2CppIUnknown* ___ResourceValue_1;
};
#endif // RESOURCECACHEITEM_T2576962992_H
#ifndef PARAMETERMODIFIER_T1406754278_H
#define PARAMETERMODIFIER_T1406754278_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.ParameterModifier
struct  ParameterModifier_t1406754278 
{
public:
	// System.Boolean[] System.Reflection.ParameterModifier::_byref
	BooleanU5BU5D_t1580036233* ____byref_0;

public:
	inline static int32_t get_offset_of__byref_0() { return static_cast<int32_t>(offsetof(ParameterModifier_t1406754278, ____byref_0)); }
	inline BooleanU5BU5D_t1580036233* get__byref_0() const { return ____byref_0; }
	inline BooleanU5BU5D_t1580036233** get_address_of__byref_0() { return &____byref_0; }
	inline void set__byref_0(BooleanU5BU5D_t1580036233* value)
	{
		____byref_0 = value;
		Il2CppCodeGenWriteBarrier((&____byref_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Reflection.ParameterModifier
struct ParameterModifier_t1406754278_marshaled_pinvoke
{
	int32_t* ____byref_0;
};
// Native definition for COM marshalling of System.Reflection.ParameterModifier
struct ParameterModifier_t1406754278_marshaled_com
{
	int32_t* ____byref_0;
};
#endif // PARAMETERMODIFIER_T1406754278_H
#ifndef ILTOKENINFO_T3857000042_H
#define ILTOKENINFO_T3857000042_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.Emit.ILTokenInfo
struct  ILTokenInfo_t3857000042 
{
public:
	// System.Reflection.MemberInfo System.Reflection.Emit.ILTokenInfo::member
	MemberInfo_t * ___member_0;
	// System.Int32 System.Reflection.Emit.ILTokenInfo::code_pos
	int32_t ___code_pos_1;

public:
	inline static int32_t get_offset_of_member_0() { return static_cast<int32_t>(offsetof(ILTokenInfo_t3857000042, ___member_0)); }
	inline MemberInfo_t * get_member_0() const { return ___member_0; }
	inline MemberInfo_t ** get_address_of_member_0() { return &___member_0; }
	inline void set_member_0(MemberInfo_t * value)
	{
		___member_0 = value;
		Il2CppCodeGenWriteBarrier((&___member_0), value);
	}

	inline static int32_t get_offset_of_code_pos_1() { return static_cast<int32_t>(offsetof(ILTokenInfo_t3857000042, ___code_pos_1)); }
	inline int32_t get_code_pos_1() const { return ___code_pos_1; }
	inline int32_t* get_address_of_code_pos_1() { return &___code_pos_1; }
	inline void set_code_pos_1(int32_t value)
	{
		___code_pos_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Reflection.Emit.ILTokenInfo
struct ILTokenInfo_t3857000042_marshaled_pinvoke
{
	MemberInfo_t * ___member_0;
	int32_t ___code_pos_1;
};
// Native definition for COM marshalling of System.Reflection.Emit.ILTokenInfo
struct ILTokenInfo_t3857000042_marshaled_com
{
	MemberInfo_t * ___member_0;
	int32_t ___code_pos_1;
};
#endif // ILTOKENINFO_T3857000042_H
#ifndef LABELFIXUP_T426630335_H
#define LABELFIXUP_T426630335_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.Emit.ILGenerator/LabelFixup
struct  LabelFixup_t426630335 
{
public:
	// System.Int32 System.Reflection.Emit.ILGenerator/LabelFixup::offset
	int32_t ___offset_0;
	// System.Int32 System.Reflection.Emit.ILGenerator/LabelFixup::pos
	int32_t ___pos_1;
	// System.Int32 System.Reflection.Emit.ILGenerator/LabelFixup::label_idx
	int32_t ___label_idx_2;

public:
	inline static int32_t get_offset_of_offset_0() { return static_cast<int32_t>(offsetof(LabelFixup_t426630335, ___offset_0)); }
	inline int32_t get_offset_0() const { return ___offset_0; }
	inline int32_t* get_address_of_offset_0() { return &___offset_0; }
	inline void set_offset_0(int32_t value)
	{
		___offset_0 = value;
	}

	inline static int32_t get_offset_of_pos_1() { return static_cast<int32_t>(offsetof(LabelFixup_t426630335, ___pos_1)); }
	inline int32_t get_pos_1() const { return ___pos_1; }
	inline int32_t* get_address_of_pos_1() { return &___pos_1; }
	inline void set_pos_1(int32_t value)
	{
		___pos_1 = value;
	}

	inline static int32_t get_offset_of_label_idx_2() { return static_cast<int32_t>(offsetof(LabelFixup_t426630335, ___label_idx_2)); }
	inline int32_t get_label_idx_2() const { return ___label_idx_2; }
	inline int32_t* get_address_of_label_idx_2() { return &___label_idx_2; }
	inline void set_label_idx_2(int32_t value)
	{
		___label_idx_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LABELFIXUP_T426630335_H
#ifndef LABELDATA_T2222154365_H
#define LABELDATA_T2222154365_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.Emit.ILGenerator/LabelData
struct  LabelData_t2222154365 
{
public:
	// System.Int32 System.Reflection.Emit.ILGenerator/LabelData::addr
	int32_t ___addr_0;
	// System.Int32 System.Reflection.Emit.ILGenerator/LabelData::maxStack
	int32_t ___maxStack_1;

public:
	inline static int32_t get_offset_of_addr_0() { return static_cast<int32_t>(offsetof(LabelData_t2222154365, ___addr_0)); }
	inline int32_t get_addr_0() const { return ___addr_0; }
	inline int32_t* get_address_of_addr_0() { return &___addr_0; }
	inline void set_addr_0(int32_t value)
	{
		___addr_0 = value;
	}

	inline static int32_t get_offset_of_maxStack_1() { return static_cast<int32_t>(offsetof(LabelData_t2222154365, ___maxStack_1)); }
	inline int32_t get_maxStack_1() const { return ___maxStack_1; }
	inline int32_t* get_address_of_maxStack_1() { return &___maxStack_1; }
	inline void set_maxStack_1(int32_t value)
	{
		___maxStack_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LABELDATA_T2222154365_H
#ifndef CUSTOMATTRIBUTETYPEDARGUMENT_T2066493570_H
#define CUSTOMATTRIBUTETYPEDARGUMENT_T2066493570_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.CustomAttributeTypedArgument
struct  CustomAttributeTypedArgument_t2066493570 
{
public:
	// System.Type System.Reflection.CustomAttributeTypedArgument::argumentType
	Type_t * ___argumentType_0;
	// System.Object System.Reflection.CustomAttributeTypedArgument::value
	RuntimeObject * ___value_1;

public:
	inline static int32_t get_offset_of_argumentType_0() { return static_cast<int32_t>(offsetof(CustomAttributeTypedArgument_t2066493570, ___argumentType_0)); }
	inline Type_t * get_argumentType_0() const { return ___argumentType_0; }
	inline Type_t ** get_address_of_argumentType_0() { return &___argumentType_0; }
	inline void set_argumentType_0(Type_t * value)
	{
		___argumentType_0 = value;
		Il2CppCodeGenWriteBarrier((&___argumentType_0), value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(CustomAttributeTypedArgument_t2066493570, ___value_1)); }
	inline RuntimeObject * get_value_1() const { return ___value_1; }
	inline RuntimeObject ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(RuntimeObject * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Reflection.CustomAttributeTypedArgument
struct CustomAttributeTypedArgument_t2066493570_marshaled_pinvoke
{
	Type_t * ___argumentType_0;
	Il2CppIUnknown* ___value_1;
};
// Native definition for COM marshalling of System.Reflection.CustomAttributeTypedArgument
struct CustomAttributeTypedArgument_t2066493570_marshaled_com
{
	Type_t * ___argumentType_0;
	Il2CppIUnknown* ___value_1;
};
#endif // CUSTOMATTRIBUTETYPEDARGUMENT_T2066493570_H
#ifndef SLOT_T2810825829_H
#define SLOT_T2810825829_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.SortedList/Slot
struct  Slot_t2810825829 
{
public:
	// System.Object System.Collections.SortedList/Slot::key
	RuntimeObject * ___key_0;
	// System.Object System.Collections.SortedList/Slot::value
	RuntimeObject * ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(Slot_t2810825829, ___key_0)); }
	inline RuntimeObject * get_key_0() const { return ___key_0; }
	inline RuntimeObject ** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(RuntimeObject * value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((&___key_0), value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(Slot_t2810825829, ___value_1)); }
	inline RuntimeObject * get_value_1() const { return ___value_1; }
	inline RuntimeObject ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(RuntimeObject * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Collections.SortedList/Slot
struct Slot_t2810825829_marshaled_pinvoke
{
	Il2CppIUnknown* ___key_0;
	Il2CppIUnknown* ___value_1;
};
// Native definition for COM marshalling of System.Collections.SortedList/Slot
struct Slot_t2810825829_marshaled_com
{
	Il2CppIUnknown* ___key_0;
	Il2CppIUnknown* ___value_1;
};
#endif // SLOT_T2810825829_H
#ifndef SLOT_T2703514113_H
#define SLOT_T2703514113_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Hashtable/Slot
struct  Slot_t2703514113 
{
public:
	// System.Object System.Collections.Hashtable/Slot::key
	RuntimeObject * ___key_0;
	// System.Object System.Collections.Hashtable/Slot::value
	RuntimeObject * ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(Slot_t2703514113, ___key_0)); }
	inline RuntimeObject * get_key_0() const { return ___key_0; }
	inline RuntimeObject ** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(RuntimeObject * value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((&___key_0), value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(Slot_t2703514113, ___value_1)); }
	inline RuntimeObject * get_value_1() const { return ___value_1; }
	inline RuntimeObject ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(RuntimeObject * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Collections.Hashtable/Slot
struct Slot_t2703514113_marshaled_pinvoke
{
	Il2CppIUnknown* ___key_0;
	Il2CppIUnknown* ___value_1;
};
// Native definition for COM marshalling of System.Collections.Hashtable/Slot
struct Slot_t2703514113_marshaled_com
{
	Il2CppIUnknown* ___key_0;
	Il2CppIUnknown* ___value_1;
};
#endif // SLOT_T2703514113_H
#ifndef LINK_T808767725_H
#define LINK_T808767725_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Link
struct  Link_t808767725 
{
public:
	// System.Int32 System.Collections.Generic.Link::HashCode
	int32_t ___HashCode_0;
	// System.Int32 System.Collections.Generic.Link::Next
	int32_t ___Next_1;

public:
	inline static int32_t get_offset_of_HashCode_0() { return static_cast<int32_t>(offsetof(Link_t808767725, ___HashCode_0)); }
	inline int32_t get_HashCode_0() const { return ___HashCode_0; }
	inline int32_t* get_address_of_HashCode_0() { return &___HashCode_0; }
	inline void set_HashCode_0(int32_t value)
	{
		___HashCode_0 = value;
	}

	inline static int32_t get_offset_of_Next_1() { return static_cast<int32_t>(offsetof(Link_t808767725, ___Next_1)); }
	inline int32_t get_Next_1() const { return ___Next_1; }
	inline int32_t* get_address_of_Next_1() { return &___Next_1; }
	inline void set_Next_1(int32_t value)
	{
		___Next_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LINK_T808767725_H
#ifndef KEYVALUEPAIR_2_T3710135120_H
#define KEYVALUEPAIR_2_T3710135120_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.KeyValuePair`2<System.Object,System.Int32>
struct  KeyValuePair_2_t3710135120 
{
public:
	// TKey System.Collections.Generic.KeyValuePair`2::key
	RuntimeObject * ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t3710135120, ___key_0)); }
	inline RuntimeObject * get_key_0() const { return ___key_0; }
	inline RuntimeObject ** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(RuntimeObject * value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((&___key_0), value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t3710135120, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYVALUEPAIR_2_T3710135120_H
#ifndef KEYVALUEPAIR_2_T3674847205_H
#define KEYVALUEPAIR_2_T3674847205_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.KeyValuePair`2<System.Object,System.Boolean>
struct  KeyValuePair_2_t3674847205 
{
public:
	// TKey System.Collections.Generic.KeyValuePair`2::key
	RuntimeObject * ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	bool ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t3674847205, ___key_0)); }
	inline RuntimeObject * get_key_0() const { return ___key_0; }
	inline RuntimeObject ** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(RuntimeObject * value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((&___key_0), value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t3674847205, ___value_1)); }
	inline bool get_value_1() const { return ___value_1; }
	inline bool* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(bool value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYVALUEPAIR_2_T3674847205_H
#ifndef TABLERANGE_T2080199027_H
#define TABLERANGE_T2080199027_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Globalization.Unicode.CodePointIndexer/TableRange
struct  TableRange_t2080199027 
{
public:
	// System.Int32 Mono.Globalization.Unicode.CodePointIndexer/TableRange::Start
	int32_t ___Start_0;
	// System.Int32 Mono.Globalization.Unicode.CodePointIndexer/TableRange::End
	int32_t ___End_1;
	// System.Int32 Mono.Globalization.Unicode.CodePointIndexer/TableRange::Count
	int32_t ___Count_2;
	// System.Int32 Mono.Globalization.Unicode.CodePointIndexer/TableRange::IndexStart
	int32_t ___IndexStart_3;
	// System.Int32 Mono.Globalization.Unicode.CodePointIndexer/TableRange::IndexEnd
	int32_t ___IndexEnd_4;

public:
	inline static int32_t get_offset_of_Start_0() { return static_cast<int32_t>(offsetof(TableRange_t2080199027, ___Start_0)); }
	inline int32_t get_Start_0() const { return ___Start_0; }
	inline int32_t* get_address_of_Start_0() { return &___Start_0; }
	inline void set_Start_0(int32_t value)
	{
		___Start_0 = value;
	}

	inline static int32_t get_offset_of_End_1() { return static_cast<int32_t>(offsetof(TableRange_t2080199027, ___End_1)); }
	inline int32_t get_End_1() const { return ___End_1; }
	inline int32_t* get_address_of_End_1() { return &___End_1; }
	inline void set_End_1(int32_t value)
	{
		___End_1 = value;
	}

	inline static int32_t get_offset_of_Count_2() { return static_cast<int32_t>(offsetof(TableRange_t2080199027, ___Count_2)); }
	inline int32_t get_Count_2() const { return ___Count_2; }
	inline int32_t* get_address_of_Count_2() { return &___Count_2; }
	inline void set_Count_2(int32_t value)
	{
		___Count_2 = value;
	}

	inline static int32_t get_offset_of_IndexStart_3() { return static_cast<int32_t>(offsetof(TableRange_t2080199027, ___IndexStart_3)); }
	inline int32_t get_IndexStart_3() const { return ___IndexStart_3; }
	inline int32_t* get_address_of_IndexStart_3() { return &___IndexStart_3; }
	inline void set_IndexStart_3(int32_t value)
	{
		___IndexStart_3 = value;
	}

	inline static int32_t get_offset_of_IndexEnd_4() { return static_cast<int32_t>(offsetof(TableRange_t2080199027, ___IndexEnd_4)); }
	inline int32_t get_IndexEnd_4() const { return ___IndexEnd_4; }
	inline int32_t* get_address_of_IndexEnd_4() { return &___IndexEnd_4; }
	inline void set_IndexEnd_4(int32_t value)
	{
		___IndexEnd_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TABLERANGE_T2080199027_H
#ifndef WORKREQUEST_T3203378897_H
#define WORKREQUEST_T3203378897_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UnitySynchronizationContext/WorkRequest
struct  WorkRequest_t3203378897 
{
public:
	// System.Threading.SendOrPostCallback UnityEngine.UnitySynchronizationContext/WorkRequest::m_DelagateCallback
	SendOrPostCallback_t1512258509 * ___m_DelagateCallback_0;
	// System.Object UnityEngine.UnitySynchronizationContext/WorkRequest::m_DelagateState
	RuntimeObject * ___m_DelagateState_1;

public:
	inline static int32_t get_offset_of_m_DelagateCallback_0() { return static_cast<int32_t>(offsetof(WorkRequest_t3203378897, ___m_DelagateCallback_0)); }
	inline SendOrPostCallback_t1512258509 * get_m_DelagateCallback_0() const { return ___m_DelagateCallback_0; }
	inline SendOrPostCallback_t1512258509 ** get_address_of_m_DelagateCallback_0() { return &___m_DelagateCallback_0; }
	inline void set_m_DelagateCallback_0(SendOrPostCallback_t1512258509 * value)
	{
		___m_DelagateCallback_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_DelagateCallback_0), value);
	}

	inline static int32_t get_offset_of_m_DelagateState_1() { return static_cast<int32_t>(offsetof(WorkRequest_t3203378897, ___m_DelagateState_1)); }
	inline RuntimeObject * get_m_DelagateState_1() const { return ___m_DelagateState_1; }
	inline RuntimeObject ** get_address_of_m_DelagateState_1() { return &___m_DelagateState_1; }
	inline void set_m_DelagateState_1(RuntimeObject * value)
	{
		___m_DelagateState_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_DelagateState_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.UnitySynchronizationContext/WorkRequest
struct WorkRequest_t3203378897_marshaled_pinvoke
{
	Il2CppMethodPointer ___m_DelagateCallback_0;
	Il2CppIUnknown* ___m_DelagateState_1;
};
// Native definition for COM marshalling of UnityEngine.UnitySynchronizationContext/WorkRequest
struct WorkRequest_t3203378897_marshaled_com
{
	Il2CppMethodPointer ___m_DelagateCallback_0;
	Il2CppIUnknown* ___m_DelagateState_1;
};
#endif // WORKREQUEST_T3203378897_H
#ifndef GCHANDLE_T2291726809_H
#define GCHANDLE_T2291726809_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.GCHandle
struct  GCHandle_t2291726809 
{
public:
	// System.Int32 System.Runtime.InteropServices.GCHandle::handle
	int32_t ___handle_0;

public:
	inline static int32_t get_offset_of_handle_0() { return static_cast<int32_t>(offsetof(GCHandle_t2291726809, ___handle_0)); }
	inline int32_t get_handle_0() const { return ___handle_0; }
	inline int32_t* get_address_of_handle_0() { return &___handle_0; }
	inline void set_handle_0(int32_t value)
	{
		___handle_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GCHANDLE_T2291726809_H
#ifndef ENUMERATOR_T2420502484_H
#define ENUMERATOR_T2420502484_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1/Enumerator<System.Object>
struct  Enumerator_t2420502484 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::l
	List_1_t1147767251 * ___l_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::ver
	int32_t ___ver_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	RuntimeObject * ___current_3;

public:
	inline static int32_t get_offset_of_l_0() { return static_cast<int32_t>(offsetof(Enumerator_t2420502484, ___l_0)); }
	inline List_1_t1147767251 * get_l_0() const { return ___l_0; }
	inline List_1_t1147767251 ** get_address_of_l_0() { return &___l_0; }
	inline void set_l_0(List_1_t1147767251 * value)
	{
		___l_0 = value;
		Il2CppCodeGenWriteBarrier((&___l_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t2420502484, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_ver_2() { return static_cast<int32_t>(offsetof(Enumerator_t2420502484, ___ver_2)); }
	inline int32_t get_ver_2() const { return ___ver_2; }
	inline int32_t* get_address_of_ver_2() { return &___ver_2; }
	inline void set_ver_2(int32_t value)
	{
		___ver_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t2420502484, ___current_3)); }
	inline RuntimeObject * get_current_3() const { return ___current_3; }
	inline RuntimeObject ** get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(RuntimeObject * value)
	{
		___current_3 = value;
		Il2CppCodeGenWriteBarrier((&___current_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T2420502484_H
#ifndef RESOURCEINFO_T1067968749_H
#define RESOURCEINFO_T1067968749_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Resources.ResourceReader/ResourceInfo
struct  ResourceInfo_t1067968749 
{
public:
	// System.Int64 System.Resources.ResourceReader/ResourceInfo::ValuePosition
	int64_t ___ValuePosition_0;
	// System.String System.Resources.ResourceReader/ResourceInfo::ResourceName
	String_t* ___ResourceName_1;
	// System.Int32 System.Resources.ResourceReader/ResourceInfo::TypeIndex
	int32_t ___TypeIndex_2;

public:
	inline static int32_t get_offset_of_ValuePosition_0() { return static_cast<int32_t>(offsetof(ResourceInfo_t1067968749, ___ValuePosition_0)); }
	inline int64_t get_ValuePosition_0() const { return ___ValuePosition_0; }
	inline int64_t* get_address_of_ValuePosition_0() { return &___ValuePosition_0; }
	inline void set_ValuePosition_0(int64_t value)
	{
		___ValuePosition_0 = value;
	}

	inline static int32_t get_offset_of_ResourceName_1() { return static_cast<int32_t>(offsetof(ResourceInfo_t1067968749, ___ResourceName_1)); }
	inline String_t* get_ResourceName_1() const { return ___ResourceName_1; }
	inline String_t** get_address_of_ResourceName_1() { return &___ResourceName_1; }
	inline void set_ResourceName_1(String_t* value)
	{
		___ResourceName_1 = value;
		Il2CppCodeGenWriteBarrier((&___ResourceName_1), value);
	}

	inline static int32_t get_offset_of_TypeIndex_2() { return static_cast<int32_t>(offsetof(ResourceInfo_t1067968749, ___TypeIndex_2)); }
	inline int32_t get_TypeIndex_2() const { return ___TypeIndex_2; }
	inline int32_t* get_address_of_TypeIndex_2() { return &___TypeIndex_2; }
	inline void set_TypeIndex_2(int32_t value)
	{
		___TypeIndex_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Resources.ResourceReader/ResourceInfo
struct ResourceInfo_t1067968749_marshaled_pinvoke
{
	int64_t ___ValuePosition_0;
	char* ___ResourceName_1;
	int32_t ___TypeIndex_2;
};
// Native definition for COM marshalling of System.Resources.ResourceReader/ResourceInfo
struct ResourceInfo_t1067968749_marshaled_com
{
	int64_t ___ValuePosition_0;
	Il2CppChar* ___ResourceName_1;
	int32_t ___TypeIndex_2;
};
#endif // RESOURCEINFO_T1067968749_H
#ifndef SYSTEMEXCEPTION_T2605480680_H
#define SYSTEMEXCEPTION_T2605480680_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.SystemException
struct  SystemException_t2605480680  : public Exception_t2443218823
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYSTEMEXCEPTION_T2605480680_H
#ifndef SBYTE_T1526744772_H
#define SBYTE_T1526744772_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.SByte
struct  SByte_t1526744772 
{
public:
	// System.SByte System.SByte::m_value
	int8_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(SByte_t1526744772, ___m_value_0)); }
	inline int8_t get_m_value_0() const { return ___m_value_0; }
	inline int8_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int8_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SBYTE_T1526744772_H
#ifndef INT64_T3733094498_H
#define INT64_T3733094498_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int64
struct  Int64_t3733094498 
{
public:
	// System.Int64 System.Int64::m_value
	int64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int64_t3733094498, ___m_value_0)); }
	inline int64_t get_m_value_0() const { return ___m_value_0; }
	inline int64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int64_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT64_T3733094498_H
#ifndef INT16_T674212087_H
#define INT16_T674212087_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int16
struct  Int16_t674212087 
{
public:
	// System.Int16 System.Int16::m_value
	int16_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int16_t674212087, ___m_value_0)); }
	inline int16_t get_m_value_0() const { return ___m_value_0; }
	inline int16_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int16_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT16_T674212087_H
#ifndef DOUBLE_T3420139759_H
#define DOUBLE_T3420139759_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Double
struct  Double_t3420139759 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_13;

public:
	inline static int32_t get_offset_of_m_value_13() { return static_cast<int32_t>(offsetof(Double_t3420139759, ___m_value_13)); }
	inline double get_m_value_13() const { return ___m_value_13; }
	inline double* get_address_of_m_value_13() { return &___m_value_13; }
	inline void set_m_value_13(double value)
	{
		___m_value_13 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DOUBLE_T3420139759_H
#ifndef DECIMAL_T2382302464_H
#define DECIMAL_T2382302464_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Decimal
struct  Decimal_t2382302464 
{
public:
	// System.UInt32 System.Decimal::flags
	uint32_t ___flags_5;
	// System.UInt32 System.Decimal::hi
	uint32_t ___hi_6;
	// System.UInt32 System.Decimal::lo
	uint32_t ___lo_7;
	// System.UInt32 System.Decimal::mid
	uint32_t ___mid_8;

public:
	inline static int32_t get_offset_of_flags_5() { return static_cast<int32_t>(offsetof(Decimal_t2382302464, ___flags_5)); }
	inline uint32_t get_flags_5() const { return ___flags_5; }
	inline uint32_t* get_address_of_flags_5() { return &___flags_5; }
	inline void set_flags_5(uint32_t value)
	{
		___flags_5 = value;
	}

	inline static int32_t get_offset_of_hi_6() { return static_cast<int32_t>(offsetof(Decimal_t2382302464, ___hi_6)); }
	inline uint32_t get_hi_6() const { return ___hi_6; }
	inline uint32_t* get_address_of_hi_6() { return &___hi_6; }
	inline void set_hi_6(uint32_t value)
	{
		___hi_6 = value;
	}

	inline static int32_t get_offset_of_lo_7() { return static_cast<int32_t>(offsetof(Decimal_t2382302464, ___lo_7)); }
	inline uint32_t get_lo_7() const { return ___lo_7; }
	inline uint32_t* get_address_of_lo_7() { return &___lo_7; }
	inline void set_lo_7(uint32_t value)
	{
		___lo_7 = value;
	}

	inline static int32_t get_offset_of_mid_8() { return static_cast<int32_t>(offsetof(Decimal_t2382302464, ___mid_8)); }
	inline uint32_t get_mid_8() const { return ___mid_8; }
	inline uint32_t* get_address_of_mid_8() { return &___mid_8; }
	inline void set_mid_8(uint32_t value)
	{
		___mid_8 = value;
	}
};

struct Decimal_t2382302464_StaticFields
{
public:
	// System.Decimal System.Decimal::MinValue
	Decimal_t2382302464  ___MinValue_0;
	// System.Decimal System.Decimal::MaxValue
	Decimal_t2382302464  ___MaxValue_1;
	// System.Decimal System.Decimal::MinusOne
	Decimal_t2382302464  ___MinusOne_2;
	// System.Decimal System.Decimal::One
	Decimal_t2382302464  ___One_3;
	// System.Decimal System.Decimal::MaxValueDiv10
	Decimal_t2382302464  ___MaxValueDiv10_4;

public:
	inline static int32_t get_offset_of_MinValue_0() { return static_cast<int32_t>(offsetof(Decimal_t2382302464_StaticFields, ___MinValue_0)); }
	inline Decimal_t2382302464  get_MinValue_0() const { return ___MinValue_0; }
	inline Decimal_t2382302464 * get_address_of_MinValue_0() { return &___MinValue_0; }
	inline void set_MinValue_0(Decimal_t2382302464  value)
	{
		___MinValue_0 = value;
	}

	inline static int32_t get_offset_of_MaxValue_1() { return static_cast<int32_t>(offsetof(Decimal_t2382302464_StaticFields, ___MaxValue_1)); }
	inline Decimal_t2382302464  get_MaxValue_1() const { return ___MaxValue_1; }
	inline Decimal_t2382302464 * get_address_of_MaxValue_1() { return &___MaxValue_1; }
	inline void set_MaxValue_1(Decimal_t2382302464  value)
	{
		___MaxValue_1 = value;
	}

	inline static int32_t get_offset_of_MinusOne_2() { return static_cast<int32_t>(offsetof(Decimal_t2382302464_StaticFields, ___MinusOne_2)); }
	inline Decimal_t2382302464  get_MinusOne_2() const { return ___MinusOne_2; }
	inline Decimal_t2382302464 * get_address_of_MinusOne_2() { return &___MinusOne_2; }
	inline void set_MinusOne_2(Decimal_t2382302464  value)
	{
		___MinusOne_2 = value;
	}

	inline static int32_t get_offset_of_One_3() { return static_cast<int32_t>(offsetof(Decimal_t2382302464_StaticFields, ___One_3)); }
	inline Decimal_t2382302464  get_One_3() const { return ___One_3; }
	inline Decimal_t2382302464 * get_address_of_One_3() { return &___One_3; }
	inline void set_One_3(Decimal_t2382302464  value)
	{
		___One_3 = value;
	}

	inline static int32_t get_offset_of_MaxValueDiv10_4() { return static_cast<int32_t>(offsetof(Decimal_t2382302464_StaticFields, ___MaxValueDiv10_4)); }
	inline Decimal_t2382302464  get_MaxValueDiv10_4() const { return ___MaxValueDiv10_4; }
	inline Decimal_t2382302464 * get_address_of_MaxValueDiv10_4() { return &___MaxValueDiv10_4; }
	inline void set_MaxValueDiv10_4(Decimal_t2382302464  value)
	{
		___MaxValueDiv10_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DECIMAL_T2382302464_H
#ifndef UINT32_T1752406861_H
#define UINT32_T1752406861_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UInt32
struct  UInt32_t1752406861 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt32_t1752406861, ___m_value_0)); }
	inline uint32_t get_m_value_0() const { return ___m_value_0; }
	inline uint32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint32_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINT32_T1752406861_H
#ifndef UINT64_T1261996727_H
#define UINT64_T1261996727_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UInt64
struct  UInt64_t1261996727 
{
public:
	// System.UInt64 System.UInt64::m_value
	uint64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt64_t1261996727, ___m_value_0)); }
	inline uint64_t get_m_value_0() const { return ___m_value_0; }
	inline uint64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint64_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINT64_T1261996727_H
#ifndef METHODBASE_T2010470530_H
#define METHODBASE_T2010470530_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.MethodBase
struct  MethodBase_t2010470530  : public MemberInfo_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // METHODBASE_T2010470530_H
#ifndef TIMESPAN_T4182925364_H
#define TIMESPAN_T4182925364_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.TimeSpan
struct  TimeSpan_t4182925364 
{
public:
	// System.Int64 System.TimeSpan::_ticks
	int64_t ____ticks_3;

public:
	inline static int32_t get_offset_of__ticks_3() { return static_cast<int32_t>(offsetof(TimeSpan_t4182925364, ____ticks_3)); }
	inline int64_t get__ticks_3() const { return ____ticks_3; }
	inline int64_t* get_address_of__ticks_3() { return &____ticks_3; }
	inline void set__ticks_3(int64_t value)
	{
		____ticks_3 = value;
	}
};

struct TimeSpan_t4182925364_StaticFields
{
public:
	// System.TimeSpan System.TimeSpan::MaxValue
	TimeSpan_t4182925364  ___MaxValue_0;
	// System.TimeSpan System.TimeSpan::MinValue
	TimeSpan_t4182925364  ___MinValue_1;
	// System.TimeSpan System.TimeSpan::Zero
	TimeSpan_t4182925364  ___Zero_2;

public:
	inline static int32_t get_offset_of_MaxValue_0() { return static_cast<int32_t>(offsetof(TimeSpan_t4182925364_StaticFields, ___MaxValue_0)); }
	inline TimeSpan_t4182925364  get_MaxValue_0() const { return ___MaxValue_0; }
	inline TimeSpan_t4182925364 * get_address_of_MaxValue_0() { return &___MaxValue_0; }
	inline void set_MaxValue_0(TimeSpan_t4182925364  value)
	{
		___MaxValue_0 = value;
	}

	inline static int32_t get_offset_of_MinValue_1() { return static_cast<int32_t>(offsetof(TimeSpan_t4182925364_StaticFields, ___MinValue_1)); }
	inline TimeSpan_t4182925364  get_MinValue_1() const { return ___MinValue_1; }
	inline TimeSpan_t4182925364 * get_address_of_MinValue_1() { return &___MinValue_1; }
	inline void set_MinValue_1(TimeSpan_t4182925364  value)
	{
		___MinValue_1 = value;
	}

	inline static int32_t get_offset_of_Zero_2() { return static_cast<int32_t>(offsetof(TimeSpan_t4182925364_StaticFields, ___Zero_2)); }
	inline TimeSpan_t4182925364  get_Zero_2() const { return ___Zero_2; }
	inline TimeSpan_t4182925364 * get_address_of_Zero_2() { return &___Zero_2; }
	inline void set_Zero_2(TimeSpan_t4182925364  value)
	{
		___Zero_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TIMESPAN_T4182925364_H
#ifndef CHAR_T4217985068_H
#define CHAR_T4217985068_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Char
struct  Char_t4217985068 
{
public:
	// System.Char System.Char::m_value
	Il2CppChar ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Char_t4217985068, ___m_value_2)); }
	inline Il2CppChar get_m_value_2() const { return ___m_value_2; }
	inline Il2CppChar* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(Il2CppChar value)
	{
		___m_value_2 = value;
	}
};

struct Char_t4217985068_StaticFields
{
public:
	// System.Byte* System.Char::category_data
	uint8_t* ___category_data_3;
	// System.Byte* System.Char::numeric_data
	uint8_t* ___numeric_data_4;
	// System.Double* System.Char::numeric_data_values
	double* ___numeric_data_values_5;
	// System.UInt16* System.Char::to_lower_data_low
	uint16_t* ___to_lower_data_low_6;
	// System.UInt16* System.Char::to_lower_data_high
	uint16_t* ___to_lower_data_high_7;
	// System.UInt16* System.Char::to_upper_data_low
	uint16_t* ___to_upper_data_low_8;
	// System.UInt16* System.Char::to_upper_data_high
	uint16_t* ___to_upper_data_high_9;

public:
	inline static int32_t get_offset_of_category_data_3() { return static_cast<int32_t>(offsetof(Char_t4217985068_StaticFields, ___category_data_3)); }
	inline uint8_t* get_category_data_3() const { return ___category_data_3; }
	inline uint8_t** get_address_of_category_data_3() { return &___category_data_3; }
	inline void set_category_data_3(uint8_t* value)
	{
		___category_data_3 = value;
	}

	inline static int32_t get_offset_of_numeric_data_4() { return static_cast<int32_t>(offsetof(Char_t4217985068_StaticFields, ___numeric_data_4)); }
	inline uint8_t* get_numeric_data_4() const { return ___numeric_data_4; }
	inline uint8_t** get_address_of_numeric_data_4() { return &___numeric_data_4; }
	inline void set_numeric_data_4(uint8_t* value)
	{
		___numeric_data_4 = value;
	}

	inline static int32_t get_offset_of_numeric_data_values_5() { return static_cast<int32_t>(offsetof(Char_t4217985068_StaticFields, ___numeric_data_values_5)); }
	inline double* get_numeric_data_values_5() const { return ___numeric_data_values_5; }
	inline double** get_address_of_numeric_data_values_5() { return &___numeric_data_values_5; }
	inline void set_numeric_data_values_5(double* value)
	{
		___numeric_data_values_5 = value;
	}

	inline static int32_t get_offset_of_to_lower_data_low_6() { return static_cast<int32_t>(offsetof(Char_t4217985068_StaticFields, ___to_lower_data_low_6)); }
	inline uint16_t* get_to_lower_data_low_6() const { return ___to_lower_data_low_6; }
	inline uint16_t** get_address_of_to_lower_data_low_6() { return &___to_lower_data_low_6; }
	inline void set_to_lower_data_low_6(uint16_t* value)
	{
		___to_lower_data_low_6 = value;
	}

	inline static int32_t get_offset_of_to_lower_data_high_7() { return static_cast<int32_t>(offsetof(Char_t4217985068_StaticFields, ___to_lower_data_high_7)); }
	inline uint16_t* get_to_lower_data_high_7() const { return ___to_lower_data_high_7; }
	inline uint16_t** get_address_of_to_lower_data_high_7() { return &___to_lower_data_high_7; }
	inline void set_to_lower_data_high_7(uint16_t* value)
	{
		___to_lower_data_high_7 = value;
	}

	inline static int32_t get_offset_of_to_upper_data_low_8() { return static_cast<int32_t>(offsetof(Char_t4217985068_StaticFields, ___to_upper_data_low_8)); }
	inline uint16_t* get_to_upper_data_low_8() const { return ___to_upper_data_low_8; }
	inline uint16_t** get_address_of_to_upper_data_low_8() { return &___to_upper_data_low_8; }
	inline void set_to_upper_data_low_8(uint16_t* value)
	{
		___to_upper_data_low_8 = value;
	}

	inline static int32_t get_offset_of_to_upper_data_high_9() { return static_cast<int32_t>(offsetof(Char_t4217985068_StaticFields, ___to_upper_data_high_9)); }
	inline uint16_t* get_to_upper_data_high_9() const { return ___to_upper_data_high_9; }
	inline uint16_t** get_address_of_to_upper_data_high_9() { return &___to_upper_data_high_9; }
	inline void set_to_upper_data_high_9(uint16_t* value)
	{
		___to_upper_data_high_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHAR_T4217985068_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	IntPtr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline IntPtr_t get_Zero_1() const { return ___Zero_1; }
	inline IntPtr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(IntPtr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef BYTE_T1695016127_H
#define BYTE_T1695016127_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Byte
struct  Byte_t1695016127 
{
public:
	// System.Byte System.Byte::m_value
	uint8_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Byte_t1695016127, ___m_value_2)); }
	inline uint8_t get_m_value_2() const { return ___m_value_2; }
	inline uint8_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(uint8_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BYTE_T1695016127_H
#ifndef SINGLE_T3678960876_H
#define SINGLE_T3678960876_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Single
struct  Single_t3678960876 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_7;

public:
	inline static int32_t get_offset_of_m_value_7() { return static_cast<int32_t>(offsetof(Single_t3678960876, ___m_value_7)); }
	inline float get_m_value_7() const { return ___m_value_7; }
	inline float* get_address_of_m_value_7() { return &___m_value_7; }
	inline void set_m_value_7(float value)
	{
		___m_value_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SINGLE_T3678960876_H
#ifndef UINT16_T2530548644_H
#define UINT16_T2530548644_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UInt16
struct  UInt16_t2530548644 
{
public:
	// System.UInt16 System.UInt16::m_value
	uint16_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(UInt16_t2530548644, ___m_value_2)); }
	inline uint16_t get_m_value_2() const { return ___m_value_2; }
	inline uint16_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(uint16_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINT16_T2530548644_H
#ifndef INT32_T438220675_H
#define INT32_T438220675_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int32
struct  Int32_t438220675 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Int32_t438220675, ___m_value_2)); }
	inline int32_t get_m_value_2() const { return ___m_value_2; }
	inline int32_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(int32_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT32_T438220675_H
#ifndef UINTPTR_T_H
#define UINTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UIntPtr
struct  UIntPtr_t 
{
public:
	// System.Void* System.UIntPtr::_pointer
	void* ____pointer_1;

public:
	inline static int32_t get_offset_of__pointer_1() { return static_cast<int32_t>(offsetof(UIntPtr_t, ____pointer_1)); }
	inline void* get__pointer_1() const { return ____pointer_1; }
	inline void** get_address_of__pointer_1() { return &____pointer_1; }
	inline void set__pointer_1(void* value)
	{
		____pointer_1 = value;
	}
};

struct UIntPtr_t_StaticFields
{
public:
	// System.UIntPtr System.UIntPtr::Zero
	UIntPtr_t  ___Zero_0;

public:
	inline static int32_t get_offset_of_Zero_0() { return static_cast<int32_t>(offsetof(UIntPtr_t_StaticFields, ___Zero_0)); }
	inline UIntPtr_t  get_Zero_0() const { return ___Zero_0; }
	inline UIntPtr_t * get_address_of_Zero_0() { return &___Zero_0; }
	inline void set_Zero_0(UIntPtr_t  value)
	{
		___Zero_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINTPTR_T_H
#ifndef OPCODE_T1117422012_H
#define OPCODE_T1117422012_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.Emit.OpCode
struct  OpCode_t1117422012 
{
public:
	// System.Byte System.Reflection.Emit.OpCode::op1
	uint8_t ___op1_0;
	// System.Byte System.Reflection.Emit.OpCode::op2
	uint8_t ___op2_1;
	// System.Byte System.Reflection.Emit.OpCode::push
	uint8_t ___push_2;
	// System.Byte System.Reflection.Emit.OpCode::pop
	uint8_t ___pop_3;
	// System.Byte System.Reflection.Emit.OpCode::size
	uint8_t ___size_4;
	// System.Byte System.Reflection.Emit.OpCode::type
	uint8_t ___type_5;
	// System.Byte System.Reflection.Emit.OpCode::args
	uint8_t ___args_6;
	// System.Byte System.Reflection.Emit.OpCode::flow
	uint8_t ___flow_7;

public:
	inline static int32_t get_offset_of_op1_0() { return static_cast<int32_t>(offsetof(OpCode_t1117422012, ___op1_0)); }
	inline uint8_t get_op1_0() const { return ___op1_0; }
	inline uint8_t* get_address_of_op1_0() { return &___op1_0; }
	inline void set_op1_0(uint8_t value)
	{
		___op1_0 = value;
	}

	inline static int32_t get_offset_of_op2_1() { return static_cast<int32_t>(offsetof(OpCode_t1117422012, ___op2_1)); }
	inline uint8_t get_op2_1() const { return ___op2_1; }
	inline uint8_t* get_address_of_op2_1() { return &___op2_1; }
	inline void set_op2_1(uint8_t value)
	{
		___op2_1 = value;
	}

	inline static int32_t get_offset_of_push_2() { return static_cast<int32_t>(offsetof(OpCode_t1117422012, ___push_2)); }
	inline uint8_t get_push_2() const { return ___push_2; }
	inline uint8_t* get_address_of_push_2() { return &___push_2; }
	inline void set_push_2(uint8_t value)
	{
		___push_2 = value;
	}

	inline static int32_t get_offset_of_pop_3() { return static_cast<int32_t>(offsetof(OpCode_t1117422012, ___pop_3)); }
	inline uint8_t get_pop_3() const { return ___pop_3; }
	inline uint8_t* get_address_of_pop_3() { return &___pop_3; }
	inline void set_pop_3(uint8_t value)
	{
		___pop_3 = value;
	}

	inline static int32_t get_offset_of_size_4() { return static_cast<int32_t>(offsetof(OpCode_t1117422012, ___size_4)); }
	inline uint8_t get_size_4() const { return ___size_4; }
	inline uint8_t* get_address_of_size_4() { return &___size_4; }
	inline void set_size_4(uint8_t value)
	{
		___size_4 = value;
	}

	inline static int32_t get_offset_of_type_5() { return static_cast<int32_t>(offsetof(OpCode_t1117422012, ___type_5)); }
	inline uint8_t get_type_5() const { return ___type_5; }
	inline uint8_t* get_address_of_type_5() { return &___type_5; }
	inline void set_type_5(uint8_t value)
	{
		___type_5 = value;
	}

	inline static int32_t get_offset_of_args_6() { return static_cast<int32_t>(offsetof(OpCode_t1117422012, ___args_6)); }
	inline uint8_t get_args_6() const { return ___args_6; }
	inline uint8_t* get_address_of_args_6() { return &___args_6; }
	inline void set_args_6(uint8_t value)
	{
		___args_6 = value;
	}

	inline static int32_t get_offset_of_flow_7() { return static_cast<int32_t>(offsetof(OpCode_t1117422012, ___flow_7)); }
	inline uint8_t get_flow_7() const { return ___flow_7; }
	inline uint8_t* get_address_of_flow_7() { return &___flow_7; }
	inline void set_flow_7(uint8_t value)
	{
		___flow_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OPCODE_T1117422012_H
#ifndef BOOLEAN_T402932760_H
#define BOOLEAN_T402932760_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Boolean
struct  Boolean_t402932760 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Boolean_t402932760, ___m_value_2)); }
	inline bool get_m_value_2() const { return ___m_value_2; }
	inline bool* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(bool value)
	{
		___m_value_2 = value;
	}
};

struct Boolean_t402932760_StaticFields
{
public:
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_0;
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_1;

public:
	inline static int32_t get_offset_of_FalseString_0() { return static_cast<int32_t>(offsetof(Boolean_t402932760_StaticFields, ___FalseString_0)); }
	inline String_t* get_FalseString_0() const { return ___FalseString_0; }
	inline String_t** get_address_of_FalseString_0() { return &___FalseString_0; }
	inline void set_FalseString_0(String_t* value)
	{
		___FalseString_0 = value;
		Il2CppCodeGenWriteBarrier((&___FalseString_0), value);
	}

	inline static int32_t get_offset_of_TrueString_1() { return static_cast<int32_t>(offsetof(Boolean_t402932760_StaticFields, ___TrueString_1)); }
	inline String_t* get_TrueString_1() const { return ___TrueString_1; }
	inline String_t** get_address_of_TrueString_1() { return &___TrueString_1; }
	inline void set_TrueString_1(String_t* value)
	{
		___TrueString_1 = value;
		Il2CppCodeGenWriteBarrier((&___TrueString_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOOLEAN_T402932760_H
#ifndef DSAPARAMETERS_T4013484323_H
#define DSAPARAMETERS_T4013484323_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.DSAParameters
struct  DSAParameters_t4013484323 
{
public:
	// System.Int32 System.Security.Cryptography.DSAParameters::Counter
	int32_t ___Counter_0;
	// System.Byte[] System.Security.Cryptography.DSAParameters::G
	ByteU5BU5D_t3003616614* ___G_1;
	// System.Byte[] System.Security.Cryptography.DSAParameters::J
	ByteU5BU5D_t3003616614* ___J_2;
	// System.Byte[] System.Security.Cryptography.DSAParameters::P
	ByteU5BU5D_t3003616614* ___P_3;
	// System.Byte[] System.Security.Cryptography.DSAParameters::Q
	ByteU5BU5D_t3003616614* ___Q_4;
	// System.Byte[] System.Security.Cryptography.DSAParameters::Seed
	ByteU5BU5D_t3003616614* ___Seed_5;
	// System.Byte[] System.Security.Cryptography.DSAParameters::X
	ByteU5BU5D_t3003616614* ___X_6;
	// System.Byte[] System.Security.Cryptography.DSAParameters::Y
	ByteU5BU5D_t3003616614* ___Y_7;

public:
	inline static int32_t get_offset_of_Counter_0() { return static_cast<int32_t>(offsetof(DSAParameters_t4013484323, ___Counter_0)); }
	inline int32_t get_Counter_0() const { return ___Counter_0; }
	inline int32_t* get_address_of_Counter_0() { return &___Counter_0; }
	inline void set_Counter_0(int32_t value)
	{
		___Counter_0 = value;
	}

	inline static int32_t get_offset_of_G_1() { return static_cast<int32_t>(offsetof(DSAParameters_t4013484323, ___G_1)); }
	inline ByteU5BU5D_t3003616614* get_G_1() const { return ___G_1; }
	inline ByteU5BU5D_t3003616614** get_address_of_G_1() { return &___G_1; }
	inline void set_G_1(ByteU5BU5D_t3003616614* value)
	{
		___G_1 = value;
		Il2CppCodeGenWriteBarrier((&___G_1), value);
	}

	inline static int32_t get_offset_of_J_2() { return static_cast<int32_t>(offsetof(DSAParameters_t4013484323, ___J_2)); }
	inline ByteU5BU5D_t3003616614* get_J_2() const { return ___J_2; }
	inline ByteU5BU5D_t3003616614** get_address_of_J_2() { return &___J_2; }
	inline void set_J_2(ByteU5BU5D_t3003616614* value)
	{
		___J_2 = value;
		Il2CppCodeGenWriteBarrier((&___J_2), value);
	}

	inline static int32_t get_offset_of_P_3() { return static_cast<int32_t>(offsetof(DSAParameters_t4013484323, ___P_3)); }
	inline ByteU5BU5D_t3003616614* get_P_3() const { return ___P_3; }
	inline ByteU5BU5D_t3003616614** get_address_of_P_3() { return &___P_3; }
	inline void set_P_3(ByteU5BU5D_t3003616614* value)
	{
		___P_3 = value;
		Il2CppCodeGenWriteBarrier((&___P_3), value);
	}

	inline static int32_t get_offset_of_Q_4() { return static_cast<int32_t>(offsetof(DSAParameters_t4013484323, ___Q_4)); }
	inline ByteU5BU5D_t3003616614* get_Q_4() const { return ___Q_4; }
	inline ByteU5BU5D_t3003616614** get_address_of_Q_4() { return &___Q_4; }
	inline void set_Q_4(ByteU5BU5D_t3003616614* value)
	{
		___Q_4 = value;
		Il2CppCodeGenWriteBarrier((&___Q_4), value);
	}

	inline static int32_t get_offset_of_Seed_5() { return static_cast<int32_t>(offsetof(DSAParameters_t4013484323, ___Seed_5)); }
	inline ByteU5BU5D_t3003616614* get_Seed_5() const { return ___Seed_5; }
	inline ByteU5BU5D_t3003616614** get_address_of_Seed_5() { return &___Seed_5; }
	inline void set_Seed_5(ByteU5BU5D_t3003616614* value)
	{
		___Seed_5 = value;
		Il2CppCodeGenWriteBarrier((&___Seed_5), value);
	}

	inline static int32_t get_offset_of_X_6() { return static_cast<int32_t>(offsetof(DSAParameters_t4013484323, ___X_6)); }
	inline ByteU5BU5D_t3003616614* get_X_6() const { return ___X_6; }
	inline ByteU5BU5D_t3003616614** get_address_of_X_6() { return &___X_6; }
	inline void set_X_6(ByteU5BU5D_t3003616614* value)
	{
		___X_6 = value;
		Il2CppCodeGenWriteBarrier((&___X_6), value);
	}

	inline static int32_t get_offset_of_Y_7() { return static_cast<int32_t>(offsetof(DSAParameters_t4013484323, ___Y_7)); }
	inline ByteU5BU5D_t3003616614* get_Y_7() const { return ___Y_7; }
	inline ByteU5BU5D_t3003616614** get_address_of_Y_7() { return &___Y_7; }
	inline void set_Y_7(ByteU5BU5D_t3003616614* value)
	{
		___Y_7 = value;
		Il2CppCodeGenWriteBarrier((&___Y_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Security.Cryptography.DSAParameters
struct DSAParameters_t4013484323_marshaled_pinvoke
{
	int32_t ___Counter_0;
	uint8_t* ___G_1;
	uint8_t* ___J_2;
	uint8_t* ___P_3;
	uint8_t* ___Q_4;
	uint8_t* ___Seed_5;
	uint8_t* ___X_6;
	uint8_t* ___Y_7;
};
// Native definition for COM marshalling of System.Security.Cryptography.DSAParameters
struct DSAParameters_t4013484323_marshaled_com
{
	int32_t ___Counter_0;
	uint8_t* ___G_1;
	uint8_t* ___J_2;
	uint8_t* ___P_3;
	uint8_t* ___Q_4;
	uint8_t* ___Seed_5;
	uint8_t* ___X_6;
	uint8_t* ___Y_7;
};
#endif // DSAPARAMETERS_T4013484323_H
#ifndef VOID_T1421048318_H
#define VOID_T1421048318_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Void
struct  Void_t1421048318 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VOID_T1421048318_H
#ifndef RSAPARAMETERS_T3314567386_H
#define RSAPARAMETERS_T3314567386_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.RSAParameters
struct  RSAParameters_t3314567386 
{
public:
	// System.Byte[] System.Security.Cryptography.RSAParameters::P
	ByteU5BU5D_t3003616614* ___P_0;
	// System.Byte[] System.Security.Cryptography.RSAParameters::Q
	ByteU5BU5D_t3003616614* ___Q_1;
	// System.Byte[] System.Security.Cryptography.RSAParameters::D
	ByteU5BU5D_t3003616614* ___D_2;
	// System.Byte[] System.Security.Cryptography.RSAParameters::DP
	ByteU5BU5D_t3003616614* ___DP_3;
	// System.Byte[] System.Security.Cryptography.RSAParameters::DQ
	ByteU5BU5D_t3003616614* ___DQ_4;
	// System.Byte[] System.Security.Cryptography.RSAParameters::InverseQ
	ByteU5BU5D_t3003616614* ___InverseQ_5;
	// System.Byte[] System.Security.Cryptography.RSAParameters::Modulus
	ByteU5BU5D_t3003616614* ___Modulus_6;
	// System.Byte[] System.Security.Cryptography.RSAParameters::Exponent
	ByteU5BU5D_t3003616614* ___Exponent_7;

public:
	inline static int32_t get_offset_of_P_0() { return static_cast<int32_t>(offsetof(RSAParameters_t3314567386, ___P_0)); }
	inline ByteU5BU5D_t3003616614* get_P_0() const { return ___P_0; }
	inline ByteU5BU5D_t3003616614** get_address_of_P_0() { return &___P_0; }
	inline void set_P_0(ByteU5BU5D_t3003616614* value)
	{
		___P_0 = value;
		Il2CppCodeGenWriteBarrier((&___P_0), value);
	}

	inline static int32_t get_offset_of_Q_1() { return static_cast<int32_t>(offsetof(RSAParameters_t3314567386, ___Q_1)); }
	inline ByteU5BU5D_t3003616614* get_Q_1() const { return ___Q_1; }
	inline ByteU5BU5D_t3003616614** get_address_of_Q_1() { return &___Q_1; }
	inline void set_Q_1(ByteU5BU5D_t3003616614* value)
	{
		___Q_1 = value;
		Il2CppCodeGenWriteBarrier((&___Q_1), value);
	}

	inline static int32_t get_offset_of_D_2() { return static_cast<int32_t>(offsetof(RSAParameters_t3314567386, ___D_2)); }
	inline ByteU5BU5D_t3003616614* get_D_2() const { return ___D_2; }
	inline ByteU5BU5D_t3003616614** get_address_of_D_2() { return &___D_2; }
	inline void set_D_2(ByteU5BU5D_t3003616614* value)
	{
		___D_2 = value;
		Il2CppCodeGenWriteBarrier((&___D_2), value);
	}

	inline static int32_t get_offset_of_DP_3() { return static_cast<int32_t>(offsetof(RSAParameters_t3314567386, ___DP_3)); }
	inline ByteU5BU5D_t3003616614* get_DP_3() const { return ___DP_3; }
	inline ByteU5BU5D_t3003616614** get_address_of_DP_3() { return &___DP_3; }
	inline void set_DP_3(ByteU5BU5D_t3003616614* value)
	{
		___DP_3 = value;
		Il2CppCodeGenWriteBarrier((&___DP_3), value);
	}

	inline static int32_t get_offset_of_DQ_4() { return static_cast<int32_t>(offsetof(RSAParameters_t3314567386, ___DQ_4)); }
	inline ByteU5BU5D_t3003616614* get_DQ_4() const { return ___DQ_4; }
	inline ByteU5BU5D_t3003616614** get_address_of_DQ_4() { return &___DQ_4; }
	inline void set_DQ_4(ByteU5BU5D_t3003616614* value)
	{
		___DQ_4 = value;
		Il2CppCodeGenWriteBarrier((&___DQ_4), value);
	}

	inline static int32_t get_offset_of_InverseQ_5() { return static_cast<int32_t>(offsetof(RSAParameters_t3314567386, ___InverseQ_5)); }
	inline ByteU5BU5D_t3003616614* get_InverseQ_5() const { return ___InverseQ_5; }
	inline ByteU5BU5D_t3003616614** get_address_of_InverseQ_5() { return &___InverseQ_5; }
	inline void set_InverseQ_5(ByteU5BU5D_t3003616614* value)
	{
		___InverseQ_5 = value;
		Il2CppCodeGenWriteBarrier((&___InverseQ_5), value);
	}

	inline static int32_t get_offset_of_Modulus_6() { return static_cast<int32_t>(offsetof(RSAParameters_t3314567386, ___Modulus_6)); }
	inline ByteU5BU5D_t3003616614* get_Modulus_6() const { return ___Modulus_6; }
	inline ByteU5BU5D_t3003616614** get_address_of_Modulus_6() { return &___Modulus_6; }
	inline void set_Modulus_6(ByteU5BU5D_t3003616614* value)
	{
		___Modulus_6 = value;
		Il2CppCodeGenWriteBarrier((&___Modulus_6), value);
	}

	inline static int32_t get_offset_of_Exponent_7() { return static_cast<int32_t>(offsetof(RSAParameters_t3314567386, ___Exponent_7)); }
	inline ByteU5BU5D_t3003616614* get_Exponent_7() const { return ___Exponent_7; }
	inline ByteU5BU5D_t3003616614** get_address_of_Exponent_7() { return &___Exponent_7; }
	inline void set_Exponent_7(ByteU5BU5D_t3003616614* value)
	{
		___Exponent_7 = value;
		Il2CppCodeGenWriteBarrier((&___Exponent_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Security.Cryptography.RSAParameters
struct RSAParameters_t3314567386_marshaled_pinvoke
{
	uint8_t* ___P_0;
	uint8_t* ___Q_1;
	uint8_t* ___D_2;
	uint8_t* ___DP_3;
	uint8_t* ___DQ_4;
	uint8_t* ___InverseQ_5;
	uint8_t* ___Modulus_6;
	uint8_t* ___Exponent_7;
};
// Native definition for COM marshalling of System.Security.Cryptography.RSAParameters
struct RSAParameters_t3314567386_marshaled_com
{
	uint8_t* ___P_0;
	uint8_t* ___Q_1;
	uint8_t* ___D_2;
	uint8_t* ___DP_3;
	uint8_t* ___DQ_4;
	uint8_t* ___InverseQ_5;
	uint8_t* ___Modulus_6;
	uint8_t* ___Exponent_7;
};
#endif // RSAPARAMETERS_T3314567386_H
#ifndef DICTIONARYENTRY_T578375704_H
#define DICTIONARYENTRY_T578375704_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.DictionaryEntry
struct  DictionaryEntry_t578375704 
{
public:
	// System.Object System.Collections.DictionaryEntry::_key
	RuntimeObject * ____key_0;
	// System.Object System.Collections.DictionaryEntry::_value
	RuntimeObject * ____value_1;

public:
	inline static int32_t get_offset_of__key_0() { return static_cast<int32_t>(offsetof(DictionaryEntry_t578375704, ____key_0)); }
	inline RuntimeObject * get__key_0() const { return ____key_0; }
	inline RuntimeObject ** get_address_of__key_0() { return &____key_0; }
	inline void set__key_0(RuntimeObject * value)
	{
		____key_0 = value;
		Il2CppCodeGenWriteBarrier((&____key_0), value);
	}

	inline static int32_t get_offset_of__value_1() { return static_cast<int32_t>(offsetof(DictionaryEntry_t578375704, ____value_1)); }
	inline RuntimeObject * get__value_1() const { return ____value_1; }
	inline RuntimeObject ** get_address_of__value_1() { return &____value_1; }
	inline void set__value_1(RuntimeObject * value)
	{
		____value_1 = value;
		Il2CppCodeGenWriteBarrier((&____value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Collections.DictionaryEntry
struct DictionaryEntry_t578375704_marshaled_pinvoke
{
	Il2CppIUnknown* ____key_0;
	Il2CppIUnknown* ____value_1;
};
// Native definition for COM marshalling of System.Collections.DictionaryEntry
struct DictionaryEntry_t578375704_marshaled_com
{
	Il2CppIUnknown* ____key_0;
	Il2CppIUnknown* ____value_1;
};
#endif // DICTIONARYENTRY_T578375704_H
#ifndef METHODTOKEN_T1418749877_H
#define METHODTOKEN_T1418749877_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.Emit.MethodToken
struct  MethodToken_t1418749877 
{
public:
	// System.Int32 System.Reflection.Emit.MethodToken::tokValue
	int32_t ___tokValue_0;

public:
	inline static int32_t get_offset_of_tokValue_0() { return static_cast<int32_t>(offsetof(MethodToken_t1418749877, ___tokValue_0)); }
	inline int32_t get_tokValue_0() const { return ___tokValue_0; }
	inline int32_t* get_address_of_tokValue_0() { return &___tokValue_0; }
	inline void set_tokValue_0(int32_t value)
	{
		___tokValue_0 = value;
	}
};

struct MethodToken_t1418749877_StaticFields
{
public:
	// System.Reflection.Emit.MethodToken System.Reflection.Emit.MethodToken::Empty
	MethodToken_t1418749877  ___Empty_1;

public:
	inline static int32_t get_offset_of_Empty_1() { return static_cast<int32_t>(offsetof(MethodToken_t1418749877_StaticFields, ___Empty_1)); }
	inline MethodToken_t1418749877  get_Empty_1() const { return ___Empty_1; }
	inline MethodToken_t1418749877 * get_address_of_Empty_1() { return &___Empty_1; }
	inline void set_Empty_1(MethodToken_t1418749877  value)
	{
		___Empty_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // METHODTOKEN_T1418749877_H
#ifndef LOGTYPE_T310145821_H
#define LOGTYPE_T310145821_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.LogType
struct  LogType_t310145821 
{
public:
	// System.Int32 UnityEngine.LogType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(LogType_t310145821, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOGTYPE_T310145821_H
#ifndef PERSISTENTLISTENERMODE_T2357711828_H
#define PERSISTENTLISTENERMODE_T2357711828_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Events.PersistentListenerMode
struct  PersistentListenerMode_t2357711828 
{
public:
	// System.Int32 UnityEngine.Events.PersistentListenerMode::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(PersistentListenerMode_t2357711828, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PERSISTENTLISTENERMODE_T2357711828_H
#ifndef SCRIPTABLERENDERCONTEXT_T3163458046_H
#define SCRIPTABLERENDERCONTEXT_T3163458046_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Rendering.ScriptableRenderContext
struct  ScriptableRenderContext_t3163458046 
{
public:
	// System.IntPtr UnityEngine.Experimental.Rendering.ScriptableRenderContext::m_Ptr
	IntPtr_t ___m_Ptr_0;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(ScriptableRenderContext_t3163458046, ___m_Ptr_0)); }
	inline IntPtr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline IntPtr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(IntPtr_t value)
	{
		___m_Ptr_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCRIPTABLERENDERCONTEXT_T3163458046_H
#ifndef EXTENDERTYPE_T2570490418_H
#define EXTENDERTYPE_T2570490418_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Globalization.Unicode.SimpleCollator/ExtenderType
struct  ExtenderType_t2570490418 
{
public:
	// System.Int32 Mono.Globalization.Unicode.SimpleCollator/ExtenderType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ExtenderType_t2570490418, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXTENDERTYPE_T2570490418_H
#ifndef ASSEMBLYNAMEFLAGS_T1966831008_H
#define ASSEMBLYNAMEFLAGS_T1966831008_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.AssemblyNameFlags
struct  AssemblyNameFlags_t1966831008 
{
public:
	// System.Int32 System.Reflection.AssemblyNameFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AssemblyNameFlags_t1966831008, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASSEMBLYNAMEFLAGS_T1966831008_H
#ifndef COLLISIONFLAGS_T2921713114_H
#define COLLISIONFLAGS_T2921713114_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CollisionFlags
struct  CollisionFlags_t2921713114 
{
public:
	// System.Int32 UnityEngine.CollisionFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CollisionFlags_t2921713114, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLLISIONFLAGS_T2921713114_H
#ifndef ANALYTICSRESULT_T1733525867_H
#define ANALYTICSRESULT_T1733525867_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Analytics.AnalyticsResult
struct  AnalyticsResult_t1733525867 
{
public:
	// System.Int32 UnityEngine.Analytics.AnalyticsResult::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AnalyticsResult_t1733525867, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ANALYTICSRESULT_T1733525867_H
#ifndef ENUMERATOR_T2659973885_H
#define ENUMERATOR_T2659973885_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2/Enumerator<System.Object,System.Object>
struct  Enumerator_t2659973885 
{
public:
	// System.Collections.Generic.Dictionary`2<TKey,TValue> System.Collections.Generic.Dictionary`2/Enumerator::dictionary
	Dictionary_2_t3607226823 * ___dictionary_0;
	// System.Int32 System.Collections.Generic.Dictionary`2/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.Dictionary`2/Enumerator::stamp
	int32_t ___stamp_2;
	// System.Collections.Generic.KeyValuePair`2<TKey,TValue> System.Collections.Generic.Dictionary`2/Enumerator::current
	KeyValuePair_2_t3369932832  ___current_3;

public:
	inline static int32_t get_offset_of_dictionary_0() { return static_cast<int32_t>(offsetof(Enumerator_t2659973885, ___dictionary_0)); }
	inline Dictionary_2_t3607226823 * get_dictionary_0() const { return ___dictionary_0; }
	inline Dictionary_2_t3607226823 ** get_address_of_dictionary_0() { return &___dictionary_0; }
	inline void set_dictionary_0(Dictionary_2_t3607226823 * value)
	{
		___dictionary_0 = value;
		Il2CppCodeGenWriteBarrier((&___dictionary_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t2659973885, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_stamp_2() { return static_cast<int32_t>(offsetof(Enumerator_t2659973885, ___stamp_2)); }
	inline int32_t get_stamp_2() const { return ___stamp_2; }
	inline int32_t* get_address_of_stamp_2() { return &___stamp_2; }
	inline void set_stamp_2(int32_t value)
	{
		___stamp_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t2659973885, ___current_3)); }
	inline KeyValuePair_2_t3369932832  get_current_3() const { return ___current_3; }
	inline KeyValuePair_2_t3369932832 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(KeyValuePair_2_t3369932832  value)
	{
		___current_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T2659973885_H
#ifndef BOUNDS_T1424290876_H
#define BOUNDS_T1424290876_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Bounds
struct  Bounds_t1424290876 
{
public:
	// UnityEngine.Vector3 UnityEngine.Bounds::m_Center
	Vector3_t2987449647  ___m_Center_0;
	// UnityEngine.Vector3 UnityEngine.Bounds::m_Extents
	Vector3_t2987449647  ___m_Extents_1;

public:
	inline static int32_t get_offset_of_m_Center_0() { return static_cast<int32_t>(offsetof(Bounds_t1424290876, ___m_Center_0)); }
	inline Vector3_t2987449647  get_m_Center_0() const { return ___m_Center_0; }
	inline Vector3_t2987449647 * get_address_of_m_Center_0() { return &___m_Center_0; }
	inline void set_m_Center_0(Vector3_t2987449647  value)
	{
		___m_Center_0 = value;
	}

	inline static int32_t get_offset_of_m_Extents_1() { return static_cast<int32_t>(offsetof(Bounds_t1424290876, ___m_Extents_1)); }
	inline Vector3_t2987449647  get_m_Extents_1() const { return ___m_Extents_1; }
	inline Vector3_t2987449647 * get_address_of_m_Extents_1() { return &___m_Extents_1; }
	inline void set_m_Extents_1(Vector3_t2987449647  value)
	{
		___m_Extents_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOUNDS_T1424290876_H
#ifndef RAYCASTHIT_T2786726017_H
#define RAYCASTHIT_T2786726017_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RaycastHit
struct  RaycastHit_t2786726017 
{
public:
	// UnityEngine.Vector3 UnityEngine.RaycastHit::m_Point
	Vector3_t2987449647  ___m_Point_0;
	// UnityEngine.Vector3 UnityEngine.RaycastHit::m_Normal
	Vector3_t2987449647  ___m_Normal_1;
	// System.Int32 UnityEngine.RaycastHit::m_FaceID
	int32_t ___m_FaceID_2;
	// System.Single UnityEngine.RaycastHit::m_Distance
	float ___m_Distance_3;
	// UnityEngine.Vector2 UnityEngine.RaycastHit::m_UV
	Vector2_t218349997  ___m_UV_4;
	// UnityEngine.Collider UnityEngine.RaycastHit::m_Collider
	Collider_t3066580567 * ___m_Collider_5;

public:
	inline static int32_t get_offset_of_m_Point_0() { return static_cast<int32_t>(offsetof(RaycastHit_t2786726017, ___m_Point_0)); }
	inline Vector3_t2987449647  get_m_Point_0() const { return ___m_Point_0; }
	inline Vector3_t2987449647 * get_address_of_m_Point_0() { return &___m_Point_0; }
	inline void set_m_Point_0(Vector3_t2987449647  value)
	{
		___m_Point_0 = value;
	}

	inline static int32_t get_offset_of_m_Normal_1() { return static_cast<int32_t>(offsetof(RaycastHit_t2786726017, ___m_Normal_1)); }
	inline Vector3_t2987449647  get_m_Normal_1() const { return ___m_Normal_1; }
	inline Vector3_t2987449647 * get_address_of_m_Normal_1() { return &___m_Normal_1; }
	inline void set_m_Normal_1(Vector3_t2987449647  value)
	{
		___m_Normal_1 = value;
	}

	inline static int32_t get_offset_of_m_FaceID_2() { return static_cast<int32_t>(offsetof(RaycastHit_t2786726017, ___m_FaceID_2)); }
	inline int32_t get_m_FaceID_2() const { return ___m_FaceID_2; }
	inline int32_t* get_address_of_m_FaceID_2() { return &___m_FaceID_2; }
	inline void set_m_FaceID_2(int32_t value)
	{
		___m_FaceID_2 = value;
	}

	inline static int32_t get_offset_of_m_Distance_3() { return static_cast<int32_t>(offsetof(RaycastHit_t2786726017, ___m_Distance_3)); }
	inline float get_m_Distance_3() const { return ___m_Distance_3; }
	inline float* get_address_of_m_Distance_3() { return &___m_Distance_3; }
	inline void set_m_Distance_3(float value)
	{
		___m_Distance_3 = value;
	}

	inline static int32_t get_offset_of_m_UV_4() { return static_cast<int32_t>(offsetof(RaycastHit_t2786726017, ___m_UV_4)); }
	inline Vector2_t218349997  get_m_UV_4() const { return ___m_UV_4; }
	inline Vector2_t218349997 * get_address_of_m_UV_4() { return &___m_UV_4; }
	inline void set_m_UV_4(Vector2_t218349997  value)
	{
		___m_UV_4 = value;
	}

	inline static int32_t get_offset_of_m_Collider_5() { return static_cast<int32_t>(offsetof(RaycastHit_t2786726017, ___m_Collider_5)); }
	inline Collider_t3066580567 * get_m_Collider_5() const { return ___m_Collider_5; }
	inline Collider_t3066580567 ** get_address_of_m_Collider_5() { return &___m_Collider_5; }
	inline void set_m_Collider_5(Collider_t3066580567 * value)
	{
		___m_Collider_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_Collider_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.RaycastHit
struct RaycastHit_t2786726017_marshaled_pinvoke
{
	Vector3_t2987449647  ___m_Point_0;
	Vector3_t2987449647  ___m_Normal_1;
	int32_t ___m_FaceID_2;
	float ___m_Distance_3;
	Vector2_t218349997  ___m_UV_4;
	Collider_t3066580567 * ___m_Collider_5;
};
// Native definition for COM marshalling of UnityEngine.RaycastHit
struct RaycastHit_t2786726017_marshaled_com
{
	Vector3_t2987449647  ___m_Point_0;
	Vector3_t2987449647  ___m_Normal_1;
	int32_t ___m_FaceID_2;
	float ___m_Distance_3;
	Vector2_t218349997  ___m_UV_4;
	Collider_t3066580567 * ___m_Collider_5;
};
#endif // RAYCASTHIT_T2786726017_H
#ifndef SIGN_T170185131_H
#define SIGN_T170185131_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Math.BigInteger/Sign
struct  Sign_t170185131 
{
public:
	// System.Int32 Mono.Math.BigInteger/Sign::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(Sign_t170185131, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SIGN_T170185131_H
#ifndef PLAYABLEOUTPUTHANDLE_T4210482917_H
#define PLAYABLEOUTPUTHANDLE_T4210482917_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.PlayableOutputHandle
struct  PlayableOutputHandle_t4210482917 
{
public:
	// System.IntPtr UnityEngine.Playables.PlayableOutputHandle::m_Handle
	IntPtr_t ___m_Handle_0;
	// System.Int32 UnityEngine.Playables.PlayableOutputHandle::m_Version
	int32_t ___m_Version_1;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(PlayableOutputHandle_t4210482917, ___m_Handle_0)); }
	inline IntPtr_t get_m_Handle_0() const { return ___m_Handle_0; }
	inline IntPtr_t* get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(IntPtr_t value)
	{
		___m_Handle_0 = value;
	}

	inline static int32_t get_offset_of_m_Version_1() { return static_cast<int32_t>(offsetof(PlayableOutputHandle_t4210482917, ___m_Version_1)); }
	inline int32_t get_m_Version_1() const { return ___m_Version_1; }
	inline int32_t* get_address_of_m_Version_1() { return &___m_Version_1; }
	inline void set_m_Version_1(int32_t value)
	{
		___m_Version_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYABLEOUTPUTHANDLE_T4210482917_H
#ifndef PLAYABLEGRAPH_T4192197450_H
#define PLAYABLEGRAPH_T4192197450_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.PlayableGraph
struct  PlayableGraph_t4192197450 
{
public:
	// System.IntPtr UnityEngine.Playables.PlayableGraph::m_Handle
	IntPtr_t ___m_Handle_0;
	// System.Int32 UnityEngine.Playables.PlayableGraph::m_Version
	int32_t ___m_Version_1;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(PlayableGraph_t4192197450, ___m_Handle_0)); }
	inline IntPtr_t get_m_Handle_0() const { return ___m_Handle_0; }
	inline IntPtr_t* get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(IntPtr_t value)
	{
		___m_Handle_0 = value;
	}

	inline static int32_t get_offset_of_m_Version_1() { return static_cast<int32_t>(offsetof(PlayableGraph_t4192197450, ___m_Version_1)); }
	inline int32_t get_m_Version_1() const { return ___m_Version_1; }
	inline int32_t* get_address_of_m_Version_1() { return &___m_Version_1; }
	inline void set_m_Version_1(int32_t value)
	{
		___m_Version_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYABLEGRAPH_T4192197450_H
#ifndef PLAYABLEHANDLE_T2910061178_H
#define PLAYABLEHANDLE_T2910061178_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.PlayableHandle
struct  PlayableHandle_t2910061178 
{
public:
	// System.IntPtr UnityEngine.Playables.PlayableHandle::m_Handle
	IntPtr_t ___m_Handle_0;
	// System.Int32 UnityEngine.Playables.PlayableHandle::m_Version
	int32_t ___m_Version_1;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(PlayableHandle_t2910061178, ___m_Handle_0)); }
	inline IntPtr_t get_m_Handle_0() const { return ___m_Handle_0; }
	inline IntPtr_t* get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(IntPtr_t value)
	{
		___m_Handle_0 = value;
	}

	inline static int32_t get_offset_of_m_Version_1() { return static_cast<int32_t>(offsetof(PlayableHandle_t2910061178, ___m_Version_1)); }
	inline int32_t get_m_Version_1() const { return ___m_Version_1; }
	inline int32_t* get_address_of_m_Version_1() { return &___m_Version_1; }
	inline void set_m_Version_1(int32_t value)
	{
		___m_Version_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYABLEHANDLE_T2910061178_H
#ifndef HIDEFLAGS_T1270484704_H
#define HIDEFLAGS_T1270484704_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.HideFlags
struct  HideFlags_t1270484704 
{
public:
	// System.Int32 UnityEngine.HideFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(HideFlags_t1270484704, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HIDEFLAGS_T1270484704_H
#ifndef CONFIDENCEFACTOR_T1730967935_H
#define CONFIDENCEFACTOR_T1730967935_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Math.Prime.ConfidenceFactor
struct  ConfidenceFactor_t1730967935 
{
public:
	// System.Int32 Mono.Math.Prime.ConfidenceFactor::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ConfidenceFactor_t1730967935, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONFIDENCEFACTOR_T1730967935_H
#ifndef RUNTIMEFIELDHANDLE_T2492430303_H
#define RUNTIMEFIELDHANDLE_T2492430303_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.RuntimeFieldHandle
struct  RuntimeFieldHandle_t2492430303 
{
public:
	// System.IntPtr System.RuntimeFieldHandle::value
	IntPtr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeFieldHandle_t2492430303, ___value_0)); }
	inline IntPtr_t get_value_0() const { return ___value_0; }
	inline IntPtr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(IntPtr_t value)
	{
		___value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEFIELDHANDLE_T2492430303_H
#ifndef CUSTOMATTRIBUTENAMEDARGUMENT_T3456585787_H
#define CUSTOMATTRIBUTENAMEDARGUMENT_T3456585787_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.CustomAttributeNamedArgument
struct  CustomAttributeNamedArgument_t3456585787 
{
public:
	// System.Reflection.CustomAttributeTypedArgument System.Reflection.CustomAttributeNamedArgument::typedArgument
	CustomAttributeTypedArgument_t2066493570  ___typedArgument_0;
	// System.Reflection.MemberInfo System.Reflection.CustomAttributeNamedArgument::memberInfo
	MemberInfo_t * ___memberInfo_1;

public:
	inline static int32_t get_offset_of_typedArgument_0() { return static_cast<int32_t>(offsetof(CustomAttributeNamedArgument_t3456585787, ___typedArgument_0)); }
	inline CustomAttributeTypedArgument_t2066493570  get_typedArgument_0() const { return ___typedArgument_0; }
	inline CustomAttributeTypedArgument_t2066493570 * get_address_of_typedArgument_0() { return &___typedArgument_0; }
	inline void set_typedArgument_0(CustomAttributeTypedArgument_t2066493570  value)
	{
		___typedArgument_0 = value;
	}

	inline static int32_t get_offset_of_memberInfo_1() { return static_cast<int32_t>(offsetof(CustomAttributeNamedArgument_t3456585787, ___memberInfo_1)); }
	inline MemberInfo_t * get_memberInfo_1() const { return ___memberInfo_1; }
	inline MemberInfo_t ** get_address_of_memberInfo_1() { return &___memberInfo_1; }
	inline void set_memberInfo_1(MemberInfo_t * value)
	{
		___memberInfo_1 = value;
		Il2CppCodeGenWriteBarrier((&___memberInfo_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Reflection.CustomAttributeNamedArgument
struct CustomAttributeNamedArgument_t3456585787_marshaled_pinvoke
{
	CustomAttributeTypedArgument_t2066493570_marshaled_pinvoke ___typedArgument_0;
	MemberInfo_t * ___memberInfo_1;
};
// Native definition for COM marshalling of System.Reflection.CustomAttributeNamedArgument
struct CustomAttributeNamedArgument_t3456585787_marshaled_com
{
	CustomAttributeTypedArgument_t2066493570_marshaled_com ___typedArgument_0;
	MemberInfo_t * ___memberInfo_1;
};
#endif // CUSTOMATTRIBUTENAMEDARGUMENT_T3456585787_H
#ifndef MEMBERTYPES_T1145889401_H
#define MEMBERTYPES_T1145889401_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.MemberTypes
struct  MemberTypes_t1145889401 
{
public:
	// System.Int32 System.Reflection.MemberTypes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(MemberTypes_t1145889401, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEMBERTYPES_T1145889401_H
#ifndef DATASTREAMTYPE_T2750545491_H
#define DATASTREAMTYPE_T2750545491_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.DataStreamType
struct  DataStreamType_t2750545491 
{
public:
	// System.Int32 UnityEngine.Playables.DataStreamType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(DataStreamType_t2750545491, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATASTREAMTYPE_T2750545491_H
#ifndef FLAGS_T704280897_H
#define FLAGS_T704280897_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.FrameData/Flags
struct  Flags_t704280897 
{
public:
	// System.Int32 UnityEngine.Playables.FrameData/Flags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(Flags_t704280897, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FLAGS_T704280897_H
#ifndef FORMATEXCEPTION_T2016869209_H
#define FORMATEXCEPTION_T2016869209_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.FormatException
struct  FormatException_t2016869209  : public SystemException_t2605480680
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FORMATEXCEPTION_T2016869209_H
#ifndef METHODIMPLATTRIBUTES_T2411131545_H
#define METHODIMPLATTRIBUTES_T2411131545_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.MethodImplAttributes
struct  MethodImplAttributes_t2411131545 
{
public:
	// System.Int32 System.Reflection.MethodImplAttributes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(MethodImplAttributes_t2411131545, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // METHODIMPLATTRIBUTES_T2411131545_H
#ifndef BINDINGFLAGS_T2634920058_H
#define BINDINGFLAGS_T2634920058_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.BindingFlags
struct  BindingFlags_t2634920058 
{
public:
	// System.Int32 System.Reflection.BindingFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(BindingFlags_t2634920058, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BINDINGFLAGS_T2634920058_H
#ifndef COMPAREOPTIONS_T2067543004_H
#define COMPAREOPTIONS_T2067543004_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Globalization.CompareOptions
struct  CompareOptions_t2067543004 
{
public:
	// System.Int32 System.Globalization.CompareOptions::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CompareOptions_t2067543004, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPAREOPTIONS_T2067543004_H
#ifndef DELEGATE_T2990640460_H
#define DELEGATE_T2990640460_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t2990640460  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	IntPtr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	IntPtr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	IntPtr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::method_code
	IntPtr_t ___method_code_5;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_6;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_7;
	// System.DelegateData System.Delegate::data
	DelegateData_t2320928782 * ___data_8;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___invoke_impl_1)); }
	inline IntPtr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline IntPtr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(IntPtr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___method_3)); }
	inline IntPtr_t get_method_3() const { return ___method_3; }
	inline IntPtr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(IntPtr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___delegate_trampoline_4)); }
	inline IntPtr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline IntPtr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(IntPtr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_method_code_5() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___method_code_5)); }
	inline IntPtr_t get_method_code_5() const { return ___method_code_5; }
	inline IntPtr_t* get_address_of_method_code_5() { return &___method_code_5; }
	inline void set_method_code_5(IntPtr_t value)
	{
		___method_code_5 = value;
	}

	inline static int32_t get_offset_of_method_info_6() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___method_info_6)); }
	inline MethodInfo_t * get_method_info_6() const { return ___method_info_6; }
	inline MethodInfo_t ** get_address_of_method_info_6() { return &___method_info_6; }
	inline void set_method_info_6(MethodInfo_t * value)
	{
		___method_info_6 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_6), value);
	}

	inline static int32_t get_offset_of_original_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___original_method_info_7)); }
	inline MethodInfo_t * get_original_method_info_7() const { return ___original_method_info_7; }
	inline MethodInfo_t ** get_address_of_original_method_info_7() { return &___original_method_info_7; }
	inline void set_original_method_info_7(MethodInfo_t * value)
	{
		___original_method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_7), value);
	}

	inline static int32_t get_offset_of_data_8() { return static_cast<int32_t>(offsetof(Delegate_t2990640460, ___data_8)); }
	inline DelegateData_t2320928782 * get_data_8() const { return ___data_8; }
	inline DelegateData_t2320928782 ** get_address_of_data_8() { return &___data_8; }
	inline void set_data_8(DelegateData_t2320928782 * value)
	{
		___data_8 = value;
		Il2CppCodeGenWriteBarrier((&___data_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DELEGATE_T2990640460_H
#ifndef ENUMERATOR_T94010371_H
#define ENUMERATOR_T94010371_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1/Enumerator<System.Reflection.CustomAttributeTypedArgument>
struct  Enumerator_t94010371 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::l
	List_1_t3116242434 * ___l_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::ver
	int32_t ___ver_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	CustomAttributeTypedArgument_t2066493570  ___current_3;

public:
	inline static int32_t get_offset_of_l_0() { return static_cast<int32_t>(offsetof(Enumerator_t94010371, ___l_0)); }
	inline List_1_t3116242434 * get_l_0() const { return ___l_0; }
	inline List_1_t3116242434 ** get_address_of_l_0() { return &___l_0; }
	inline void set_l_0(List_1_t3116242434 * value)
	{
		___l_0 = value;
		Il2CppCodeGenWriteBarrier((&___l_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t94010371, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_ver_2() { return static_cast<int32_t>(offsetof(Enumerator_t94010371, ___ver_2)); }
	inline int32_t get_ver_2() const { return ___ver_2; }
	inline int32_t* get_address_of_ver_2() { return &___ver_2; }
	inline void set_ver_2(int32_t value)
	{
		___ver_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t94010371, ___current_3)); }
	inline CustomAttributeTypedArgument_t2066493570  get_current_3() const { return ___current_3; }
	inline CustomAttributeTypedArgument_t2066493570 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(CustomAttributeTypedArgument_t2066493570  value)
	{
		___current_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T94010371_H
#ifndef ENUMERATOR_T3000176173_H
#define ENUMERATOR_T3000176173_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2/Enumerator<System.Object,System.Int32>
struct  Enumerator_t3000176173 
{
public:
	// System.Collections.Generic.Dictionary`2<TKey,TValue> System.Collections.Generic.Dictionary`2/Enumerator::dictionary
	Dictionary_2_t3947429111 * ___dictionary_0;
	// System.Int32 System.Collections.Generic.Dictionary`2/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.Dictionary`2/Enumerator::stamp
	int32_t ___stamp_2;
	// System.Collections.Generic.KeyValuePair`2<TKey,TValue> System.Collections.Generic.Dictionary`2/Enumerator::current
	KeyValuePair_2_t3710135120  ___current_3;

public:
	inline static int32_t get_offset_of_dictionary_0() { return static_cast<int32_t>(offsetof(Enumerator_t3000176173, ___dictionary_0)); }
	inline Dictionary_2_t3947429111 * get_dictionary_0() const { return ___dictionary_0; }
	inline Dictionary_2_t3947429111 ** get_address_of_dictionary_0() { return &___dictionary_0; }
	inline void set_dictionary_0(Dictionary_2_t3947429111 * value)
	{
		___dictionary_0 = value;
		Il2CppCodeGenWriteBarrier((&___dictionary_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t3000176173, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_stamp_2() { return static_cast<int32_t>(offsetof(Enumerator_t3000176173, ___stamp_2)); }
	inline int32_t get_stamp_2() const { return ___stamp_2; }
	inline int32_t* get_address_of_stamp_2() { return &___stamp_2; }
	inline void set_stamp_2(int32_t value)
	{
		___stamp_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t3000176173, ___current_3)); }
	inline KeyValuePair_2_t3710135120  get_current_3() const { return ___current_3; }
	inline KeyValuePair_2_t3710135120 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(KeyValuePair_2_t3710135120  value)
	{
		___current_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T3000176173_H
#ifndef ENUMERATOR_T2964888258_H
#define ENUMERATOR_T2964888258_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2/Enumerator<System.Object,System.Boolean>
struct  Enumerator_t2964888258 
{
public:
	// System.Collections.Generic.Dictionary`2<TKey,TValue> System.Collections.Generic.Dictionary`2/Enumerator::dictionary
	Dictionary_2_t3912141196 * ___dictionary_0;
	// System.Int32 System.Collections.Generic.Dictionary`2/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.Dictionary`2/Enumerator::stamp
	int32_t ___stamp_2;
	// System.Collections.Generic.KeyValuePair`2<TKey,TValue> System.Collections.Generic.Dictionary`2/Enumerator::current
	KeyValuePair_2_t3674847205  ___current_3;

public:
	inline static int32_t get_offset_of_dictionary_0() { return static_cast<int32_t>(offsetof(Enumerator_t2964888258, ___dictionary_0)); }
	inline Dictionary_2_t3912141196 * get_dictionary_0() const { return ___dictionary_0; }
	inline Dictionary_2_t3912141196 ** get_address_of_dictionary_0() { return &___dictionary_0; }
	inline void set_dictionary_0(Dictionary_2_t3912141196 * value)
	{
		___dictionary_0 = value;
		Il2CppCodeGenWriteBarrier((&___dictionary_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t2964888258, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_stamp_2() { return static_cast<int32_t>(offsetof(Enumerator_t2964888258, ___stamp_2)); }
	inline int32_t get_stamp_2() const { return ___stamp_2; }
	inline int32_t* get_address_of_stamp_2() { return &___stamp_2; }
	inline void set_stamp_2(int32_t value)
	{
		___stamp_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t2964888258, ___current_3)); }
	inline KeyValuePair_2_t3674847205  get_current_3() const { return ___current_3; }
	inline KeyValuePair_2_t3674847205 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(KeyValuePair_2_t3674847205  value)
	{
		___current_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T2964888258_H
#ifndef TYPETAG_T1823465210_H
#define TYPETAG_T1823465210_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Serialization.Formatters.Binary.TypeTag
struct  TypeTag_t1823465210 
{
public:
	// System.Byte System.Runtime.Serialization.Formatters.Binary.TypeTag::value__
	uint8_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TypeTag_t1823465210, ___value___1)); }
	inline uint8_t get_value___1() const { return ___value___1; }
	inline uint8_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(uint8_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPETAG_T1823465210_H
#ifndef CLIENTCERTIFICATETYPE_T2095209863_H
#define CLIENTCERTIFICATETYPE_T2095209863_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.Handshake.ClientCertificateType
struct  ClientCertificateType_t2095209863 
{
public:
	// System.Int32 Mono.Security.Protocol.Tls.Handshake.ClientCertificateType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ClientCertificateType_t2095209863, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CLIENTCERTIFICATETYPE_T2095209863_H
#ifndef CONTACTPOINT_T3765348581_H
#define CONTACTPOINT_T3765348581_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.ContactPoint
struct  ContactPoint_t3765348581 
{
public:
	// UnityEngine.Vector3 UnityEngine.ContactPoint::m_Point
	Vector3_t2987449647  ___m_Point_0;
	// UnityEngine.Vector3 UnityEngine.ContactPoint::m_Normal
	Vector3_t2987449647  ___m_Normal_1;
	// System.Int32 UnityEngine.ContactPoint::m_ThisColliderInstanceID
	int32_t ___m_ThisColliderInstanceID_2;
	// System.Int32 UnityEngine.ContactPoint::m_OtherColliderInstanceID
	int32_t ___m_OtherColliderInstanceID_3;
	// System.Single UnityEngine.ContactPoint::m_Separation
	float ___m_Separation_4;

public:
	inline static int32_t get_offset_of_m_Point_0() { return static_cast<int32_t>(offsetof(ContactPoint_t3765348581, ___m_Point_0)); }
	inline Vector3_t2987449647  get_m_Point_0() const { return ___m_Point_0; }
	inline Vector3_t2987449647 * get_address_of_m_Point_0() { return &___m_Point_0; }
	inline void set_m_Point_0(Vector3_t2987449647  value)
	{
		___m_Point_0 = value;
	}

	inline static int32_t get_offset_of_m_Normal_1() { return static_cast<int32_t>(offsetof(ContactPoint_t3765348581, ___m_Normal_1)); }
	inline Vector3_t2987449647  get_m_Normal_1() const { return ___m_Normal_1; }
	inline Vector3_t2987449647 * get_address_of_m_Normal_1() { return &___m_Normal_1; }
	inline void set_m_Normal_1(Vector3_t2987449647  value)
	{
		___m_Normal_1 = value;
	}

	inline static int32_t get_offset_of_m_ThisColliderInstanceID_2() { return static_cast<int32_t>(offsetof(ContactPoint_t3765348581, ___m_ThisColliderInstanceID_2)); }
	inline int32_t get_m_ThisColliderInstanceID_2() const { return ___m_ThisColliderInstanceID_2; }
	inline int32_t* get_address_of_m_ThisColliderInstanceID_2() { return &___m_ThisColliderInstanceID_2; }
	inline void set_m_ThisColliderInstanceID_2(int32_t value)
	{
		___m_ThisColliderInstanceID_2 = value;
	}

	inline static int32_t get_offset_of_m_OtherColliderInstanceID_3() { return static_cast<int32_t>(offsetof(ContactPoint_t3765348581, ___m_OtherColliderInstanceID_3)); }
	inline int32_t get_m_OtherColliderInstanceID_3() const { return ___m_OtherColliderInstanceID_3; }
	inline int32_t* get_address_of_m_OtherColliderInstanceID_3() { return &___m_OtherColliderInstanceID_3; }
	inline void set_m_OtherColliderInstanceID_3(int32_t value)
	{
		___m_OtherColliderInstanceID_3 = value;
	}

	inline static int32_t get_offset_of_m_Separation_4() { return static_cast<int32_t>(offsetof(ContactPoint_t3765348581, ___m_Separation_4)); }
	inline float get_m_Separation_4() const { return ___m_Separation_4; }
	inline float* get_address_of_m_Separation_4() { return &___m_Separation_4; }
	inline void set_m_Separation_4(float value)
	{
		___m_Separation_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONTACTPOINT_T3765348581_H
#ifndef UNICODECATEGORY_T47276028_H
#define UNICODECATEGORY_T47276028_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Globalization.UnicodeCategory
struct  UnicodeCategory_t47276028 
{
public:
	// System.Int32 System.Globalization.UnicodeCategory::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(UnicodeCategory_t47276028, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNICODECATEGORY_T47276028_H
#ifndef KEYVALUEPAIR_2_T2173232590_H
#define KEYVALUEPAIR_2_T2173232590_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.KeyValuePair`2<System.IntPtr,System.Object>
struct  KeyValuePair_2_t2173232590 
{
public:
	// TKey System.Collections.Generic.KeyValuePair`2::key
	IntPtr_t ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	RuntimeObject * ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t2173232590, ___key_0)); }
	inline IntPtr_t get_key_0() const { return ___key_0; }
	inline IntPtr_t* get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(IntPtr_t value)
	{
		___key_0 = value;
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t2173232590, ___value_1)); }
	inline RuntimeObject * get_value_1() const { return ___value_1; }
	inline RuntimeObject ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(RuntimeObject * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYVALUEPAIR_2_T2173232590_H
#ifndef TYPECODE_T842513060_H
#define TYPECODE_T842513060_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.TypeCode
struct  TypeCode_t842513060 
{
public:
	// System.Int32 System.TypeCode::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TypeCode_t842513060, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPECODE_T842513060_H
#ifndef TYPEATTRIBUTES_T1669384266_H
#define TYPEATTRIBUTES_T1669384266_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.TypeAttributes
struct  TypeAttributes_t1669384266 
{
public:
	// System.Int32 System.Reflection.TypeAttributes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TypeAttributes_t1669384266, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPEATTRIBUTES_T1669384266_H
#ifndef RUNTIMETYPEHANDLE_T1361003276_H
#define RUNTIMETYPEHANDLE_T1361003276_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.RuntimeTypeHandle
struct  RuntimeTypeHandle_t1361003276 
{
public:
	// System.IntPtr System.RuntimeTypeHandle::value
	IntPtr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeTypeHandle_t1361003276, ___value_0)); }
	inline IntPtr_t get_value_0() const { return ___value_0; }
	inline IntPtr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(IntPtr_t value)
	{
		___value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMETYPEHANDLE_T1361003276_H
#ifndef RAY_T3298836202_H
#define RAY_T3298836202_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Ray
struct  Ray_t3298836202 
{
public:
	// UnityEngine.Vector3 UnityEngine.Ray::m_Origin
	Vector3_t2987449647  ___m_Origin_0;
	// UnityEngine.Vector3 UnityEngine.Ray::m_Direction
	Vector3_t2987449647  ___m_Direction_1;

public:
	inline static int32_t get_offset_of_m_Origin_0() { return static_cast<int32_t>(offsetof(Ray_t3298836202, ___m_Origin_0)); }
	inline Vector3_t2987449647  get_m_Origin_0() const { return ___m_Origin_0; }
	inline Vector3_t2987449647 * get_address_of_m_Origin_0() { return &___m_Origin_0; }
	inline void set_m_Origin_0(Vector3_t2987449647  value)
	{
		___m_Origin_0 = value;
	}

	inline static int32_t get_offset_of_m_Direction_1() { return static_cast<int32_t>(offsetof(Ray_t3298836202, ___m_Direction_1)); }
	inline Vector3_t2987449647  get_m_Direction_1() const { return ___m_Direction_1; }
	inline Vector3_t2987449647 * get_address_of_m_Direction_1() { return &___m_Direction_1; }
	inline void set_m_Direction_1(Vector3_t2987449647  value)
	{
		___m_Direction_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAY_T3298836202_H
#ifndef PLAYSTATE_T540826789_H
#define PLAYSTATE_T540826789_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.PlayState
struct  PlayState_t540826789 
{
public:
	// System.Int32 UnityEngine.Playables.PlayState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(PlayState_t540826789, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYSTATE_T540826789_H
#ifndef CONTENTTYPE_T2215461912_H
#define CONTENTTYPE_T2215461912_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.ContentType
struct  ContentType_t2215461912 
{
public:
	// System.Byte Mono.Security.Protocol.Tls.ContentType::value__
	uint8_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ContentType_t2215461912, ___value___1)); }
	inline uint8_t get_value___1() const { return ___value___1; }
	inline uint8_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(uint8_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONTENTTYPE_T2215461912_H
#ifndef X509REVOCATIONFLAG_T3862259269_H
#define X509REVOCATIONFLAG_T3862259269_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.X509Certificates.X509RevocationFlag
struct  X509RevocationFlag_t3862259269 
{
public:
	// System.Int32 System.Security.Cryptography.X509Certificates.X509RevocationFlag::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(X509RevocationFlag_t3862259269, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // X509REVOCATIONFLAG_T3862259269_H
#ifndef X509CHAINSTATUSFLAGS_T3387568385_H
#define X509CHAINSTATUSFLAGS_T3387568385_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.X509Certificates.X509ChainStatusFlags
struct  X509ChainStatusFlags_t3387568385 
{
public:
	// System.Int32 System.Security.Cryptography.X509Certificates.X509ChainStatusFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(X509ChainStatusFlags_t3387568385, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // X509CHAINSTATUSFLAGS_T3387568385_H
#ifndef ASNDECODESTATUS_T361668025_H
#define ASNDECODESTATUS_T361668025_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.AsnDecodeStatus
struct  AsnDecodeStatus_t361668025 
{
public:
	// System.Int32 System.Security.Cryptography.AsnDecodeStatus::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AsnDecodeStatus_t361668025, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASNDECODESTATUS_T361668025_H
#ifndef CAMERACLEARFLAGS_T1620199384_H
#define CAMERACLEARFLAGS_T1620199384_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CameraClearFlags
struct  CameraClearFlags_t1620199384 
{
public:
	// System.Int32 UnityEngine.CameraClearFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CameraClearFlags_t1620199384, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CAMERACLEARFLAGS_T1620199384_H
#ifndef SECURITYPROTOCOLTYPE_T2871506216_H
#define SECURITYPROTOCOLTYPE_T2871506216_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Net.SecurityProtocolType
struct  SecurityProtocolType_t2871506216 
{
public:
	// System.Int32 System.Net.SecurityProtocolType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(SecurityProtocolType_t2871506216, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SECURITYPROTOCOLTYPE_T2871506216_H
#ifndef ADDRESSFAMILY_T450096203_H
#define ADDRESSFAMILY_T450096203_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Net.Sockets.AddressFamily
struct  AddressFamily_t450096203 
{
public:
	// System.Int32 System.Net.Sockets.AddressFamily::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AddressFamily_t450096203, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ADDRESSFAMILY_T450096203_H
#ifndef EDITORBROWSABLESTATE_T2901581142_H
#define EDITORBROWSABLESTATE_T2901581142_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ComponentModel.EditorBrowsableState
struct  EditorBrowsableState_t2901581142 
{
public:
	// System.Int32 System.ComponentModel.EditorBrowsableState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(EditorBrowsableState_t2901581142, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EDITORBROWSABLESTATE_T2901581142_H
#ifndef MONOIOERROR_T2148272570_H
#define MONOIOERROR_T2148272570_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IO.MonoIOError
struct  MonoIOError_t2148272570 
{
public:
	// System.Int32 System.IO.MonoIOError::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(MonoIOError_t2148272570, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOIOERROR_T2148272570_H
#ifndef FILEATTRIBUTES_T4239897840_H
#define FILEATTRIBUTES_T4239897840_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IO.FileAttributes
struct  FileAttributes_t4239897840 
{
public:
	// System.Int32 System.IO.FileAttributes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(FileAttributes_t4239897840, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FILEATTRIBUTES_T4239897840_H
#ifndef PLATFORMID_T1036322677_H
#define PLATFORMID_T1036322677_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.PlatformID
struct  PlatformID_t1036322677 
{
public:
	// System.Int32 System.PlatformID::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(PlatformID_t1036322677, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLATFORMID_T1036322677_H
#ifndef MONOFILETYPE_T2806097864_H
#define MONOFILETYPE_T2806097864_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IO.MonoFileType
struct  MonoFileType_t2806097864 
{
public:
	// System.Int32 System.IO.MonoFileType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(MonoFileType_t2806097864, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOFILETYPE_T2806097864_H
#ifndef NULLABLE_1_T534706120_H
#define NULLABLE_1_T534706120_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Nullable`1<System.TimeSpan>
struct  Nullable_1_t534706120 
{
public:
	// T System.Nullable`1::value
	TimeSpan_t4182925364  ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_t534706120, ___value_0)); }
	inline TimeSpan_t4182925364  get_value_0() const { return ___value_0; }
	inline TimeSpan_t4182925364 * get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(TimeSpan_t4182925364  value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_t534706120, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NULLABLE_1_T534706120_H
#ifndef DATETIMEKIND_T588365666_H
#define DATETIMEKIND_T588365666_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.DateTimeKind
struct  DateTimeKind_t588365666 
{
public:
	// System.Int32 System.DateTimeKind::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(DateTimeKind_t588365666, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATETIMEKIND_T588365666_H
#ifndef CALLINGCONVENTIONS_T369066136_H
#define CALLINGCONVENTIONS_T369066136_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.CallingConventions
struct  CallingConventions_t369066136 
{
public:
	// System.Int32 System.Reflection.CallingConventions::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CallingConventions_t369066136, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLINGCONVENTIONS_T369066136_H
#ifndef RUNTIMEMETHODHANDLE_T4063774698_H
#define RUNTIMEMETHODHANDLE_T4063774698_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.RuntimeMethodHandle
struct  RuntimeMethodHandle_t4063774698 
{
public:
	// System.IntPtr System.RuntimeMethodHandle::value
	IntPtr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeMethodHandle_t4063774698, ___value_0)); }
	inline IntPtr_t get_value_0() const { return ___value_0; }
	inline IntPtr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(IntPtr_t value)
	{
		___value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEMETHODHANDLE_T4063774698_H
#ifndef PADDINGMODE_T927572615_H
#define PADDINGMODE_T927572615_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.PaddingMode
struct  PaddingMode_t927572615 
{
public:
	// System.Int32 System.Security.Cryptography.PaddingMode::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(PaddingMode_t927572615, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PADDINGMODE_T927572615_H
#ifndef CIPHERMODE_T1510653764_H
#define CIPHERMODE_T1510653764_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.CipherMode
struct  CipherMode_t1510653764 
{
public:
	// System.Int32 System.Security.Cryptography.CipherMode::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CipherMode_t1510653764, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CIPHERMODE_T1510653764_H
#ifndef CSPPROVIDERFLAGS_T613247746_H
#define CSPPROVIDERFLAGS_T613247746_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.CspProviderFlags
struct  CspProviderFlags_t613247746 
{
public:
	// System.Int32 System.Security.Cryptography.CspProviderFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CspProviderFlags_t613247746, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CSPPROVIDERFLAGS_T613247746_H
#ifndef STREAMINGCONTEXTSTATES_T317203920_H
#define STREAMINGCONTEXTSTATES_T317203920_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Serialization.StreamingContextStates
struct  StreamingContextStates_t317203920 
{
public:
	// System.Int32 System.Runtime.Serialization.StreamingContextStates::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(StreamingContextStates_t317203920, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STREAMINGCONTEXTSTATES_T317203920_H
#ifndef METHODATTRIBUTES_T1488178787_H
#define METHODATTRIBUTES_T1488178787_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.MethodAttributes
struct  MethodAttributes_t1488178787 
{
public:
	// System.Int32 System.Reflection.MethodAttributes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(MethodAttributes_t1488178787, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // METHODATTRIBUTES_T1488178787_H
#ifndef FIELDATTRIBUTES_T1558435749_H
#define FIELDATTRIBUTES_T1558435749_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.FieldAttributes
struct  FieldAttributes_t1558435749 
{
public:
	// System.Int32 System.Reflection.FieldAttributes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(FieldAttributes_t1558435749, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FIELDATTRIBUTES_T1558435749_H
#ifndef TYPEFILTERLEVEL_T1430716943_H
#define TYPEFILTERLEVEL_T1430716943_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Serialization.Formatters.TypeFilterLevel
struct  TypeFilterLevel_t1430716943 
{
public:
	// System.Int32 System.Runtime.Serialization.Formatters.TypeFilterLevel::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TypeFilterLevel_t1430716943, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TYPEFILTERLEVEL_T1430716943_H
#ifndef WELLKNOWNOBJECTMODE_T653959841_H
#define WELLKNOWNOBJECTMODE_T653959841_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Remoting.WellKnownObjectMode
struct  WellKnownObjectMode_t653959841 
{
public:
	// System.Int32 System.Runtime.Remoting.WellKnownObjectMode::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(WellKnownObjectMode_t653959841, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WELLKNOWNOBJECTMODE_T653959841_H
#ifndef STACKBEHAVIOUR_T2397757739_H
#define STACKBEHAVIOUR_T2397757739_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.Emit.StackBehaviour
struct  StackBehaviour_t2397757739 
{
public:
	// System.Int32 System.Reflection.Emit.StackBehaviour::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(StackBehaviour_t2397757739, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STACKBEHAVIOUR_T2397757739_H
#ifndef PARAMETERATTRIBUTES_T2464461462_H
#define PARAMETERATTRIBUTES_T2464461462_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.ParameterAttributes
struct  ParameterAttributes_t2464461462 
{
public:
	// System.Int32 System.Reflection.ParameterAttributes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ParameterAttributes_t2464461462, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETERATTRIBUTES_T2464461462_H
#ifndef PROPERTYATTRIBUTES_T974795916_H
#define PROPERTYATTRIBUTES_T974795916_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.PropertyAttributes
struct  PropertyAttributes_t974795916 
{
public:
	// System.Int32 System.Reflection.PropertyAttributes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(PropertyAttributes_t974795916, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PROPERTYATTRIBUTES_T974795916_H
#ifndef EVENTATTRIBUTES_T1919574847_H
#define EVENTATTRIBUTES_T1919574847_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.EventAttributes
struct  EventAttributes_t1919574847 
{
public:
	// System.Int32 System.Reflection.EventAttributes::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(EventAttributes_t1919574847, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EVENTATTRIBUTES_T1919574847_H
#ifndef X509REVOCATIONMODE_T1666302436_H
#define X509REVOCATIONMODE_T1666302436_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.X509Certificates.X509RevocationMode
struct  X509RevocationMode_t1666302436 
{
public:
	// System.Int32 System.Security.Cryptography.X509Certificates.X509RevocationMode::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(X509RevocationMode_t1666302436, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // X509REVOCATIONMODE_T1666302436_H
#ifndef X509VERIFICATIONFLAGS_T2857382038_H
#define X509VERIFICATIONFLAGS_T2857382038_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.X509Certificates.X509VerificationFlags
struct  X509VerificationFlags_t2857382038 
{
public:
	// System.Int32 System.Security.Cryptography.X509Certificates.X509VerificationFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(X509VerificationFlags_t2857382038, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // X509VERIFICATIONFLAGS_T2857382038_H
#ifndef CATEGORY_T326181340_H
#define CATEGORY_T326181340_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.RegularExpressions.Category
struct  Category_t326181340 
{
public:
	// System.UInt16 System.Text.RegularExpressions.Category::value__
	uint16_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(Category_t326181340, ___value___1)); }
	inline uint16_t get_value___1() const { return ___value___1; }
	inline uint16_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(uint16_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CATEGORY_T326181340_H
#ifndef REGEXOPTIONS_T1904484159_H
#define REGEXOPTIONS_T1904484159_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.RegularExpressions.RegexOptions
struct  RegexOptions_t1904484159 
{
public:
	// System.Int32 System.Text.RegularExpressions.RegexOptions::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(RegexOptions_t1904484159, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REGEXOPTIONS_T1904484159_H
#ifndef X509CHAINSTATUSFLAGS_T2964126077_H
#define X509CHAINSTATUSFLAGS_T2964126077_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.X509.X509ChainStatusFlags
struct  X509ChainStatusFlags_t2964126077 
{
public:
	// System.Int32 Mono.Security.X509.X509ChainStatusFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(X509ChainStatusFlags_t2964126077, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // X509CHAINSTATUSFLAGS_T2964126077_H
#ifndef CIPHERALGORITHMTYPE_T976551082_H
#define CIPHERALGORITHMTYPE_T976551082_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.CipherAlgorithmType
struct  CipherAlgorithmType_t976551082 
{
public:
	// System.Int32 Mono.Security.Protocol.Tls.CipherAlgorithmType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(CipherAlgorithmType_t976551082, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CIPHERALGORITHMTYPE_T976551082_H
#ifndef X509KEYUSAGEFLAGS_T2405450781_H
#define X509KEYUSAGEFLAGS_T2405450781_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.X509Certificates.X509KeyUsageFlags
struct  X509KeyUsageFlags_t2405450781 
{
public:
	// System.Int32 System.Security.Cryptography.X509Certificates.X509KeyUsageFlags::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(X509KeyUsageFlags_t2405450781, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // X509KEYUSAGEFLAGS_T2405450781_H
#ifndef HASHALGORITHMTYPE_T1587630734_H
#define HASHALGORITHMTYPE_T1587630734_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.HashAlgorithmType
struct  HashAlgorithmType_t1587630734 
{
public:
	// System.Int32 Mono.Security.Protocol.Tls.HashAlgorithmType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(HashAlgorithmType_t1587630734, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HASHALGORITHMTYPE_T1587630734_H
#ifndef EXCHANGEALGORITHMTYPE_T3448911736_H
#define EXCHANGEALGORITHMTYPE_T3448911736_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.ExchangeAlgorithmType
struct  ExchangeAlgorithmType_t3448911736 
{
public:
	// System.Int32 Mono.Security.Protocol.Tls.ExchangeAlgorithmType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ExchangeAlgorithmType_t3448911736, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXCHANGEALGORITHMTYPE_T3448911736_H
#ifndef SECURITYPROTOCOLTYPE_T1676794907_H
#define SECURITYPROTOCOLTYPE_T1676794907_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.SecurityProtocolType
struct  SecurityProtocolType_t1676794907 
{
public:
	// System.Int32 Mono.Security.Protocol.Tls.SecurityProtocolType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(SecurityProtocolType_t1676794907, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SECURITYPROTOCOLTYPE_T1676794907_H
#ifndef CONFIDENCEFACTOR_T1730967936_H
#define CONFIDENCEFACTOR_T1730967936_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Math.Prime.ConfidenceFactor
struct  ConfidenceFactor_t1730967936 
{
public:
	// System.Int32 Mono.Math.Prime.ConfidenceFactor::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ConfidenceFactor_t1730967936, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONFIDENCEFACTOR_T1730967936_H
#ifndef ALERTLEVEL_T393210211_H
#define ALERTLEVEL_T393210211_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.AlertLevel
struct  AlertLevel_t393210211 
{
public:
	// System.Byte Mono.Security.Protocol.Tls.AlertLevel::value__
	uint8_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AlertLevel_t393210211, ___value___1)); }
	inline uint8_t get_value___1() const { return ___value___1; }
	inline uint8_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(uint8_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ALERTLEVEL_T393210211_H
#ifndef SECURITYCOMPRESSIONTYPE_T3510785785_H
#define SECURITYCOMPRESSIONTYPE_T3510785785_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.SecurityCompressionType
struct  SecurityCompressionType_t3510785785 
{
public:
	// System.Int32 Mono.Security.Protocol.Tls.SecurityCompressionType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(SecurityCompressionType_t3510785785, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SECURITYCOMPRESSIONTYPE_T3510785785_H
#ifndef SIGN_T170185132_H
#define SIGN_T170185132_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Math.BigInteger/Sign
struct  Sign_t170185132 
{
public:
	// System.Int32 Mono.Math.BigInteger/Sign::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(Sign_t170185132, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SIGN_T170185132_H
#ifndef URIHOSTNAMETYPE_T1012973887_H
#define URIHOSTNAMETYPE_T1012973887_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UriHostNameType
struct  UriHostNameType_t1012973887 
{
public:
	// System.Int32 System.UriHostNameType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(UriHostNameType_t1012973887, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // URIHOSTNAMETYPE_T1012973887_H
#ifndef POSITION_T731461718_H
#define POSITION_T731461718_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.RegularExpressions.Position
struct  Position_t731461718 
{
public:
	// System.UInt16 System.Text.RegularExpressions.Position::value__
	uint16_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(Position_t731461718, ___value___1)); }
	inline uint16_t get_value___1() const { return ___value___1; }
	inline uint16_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(uint16_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSITION_T731461718_H
#ifndef DAYOFWEEK_T1380878247_H
#define DAYOFWEEK_T1380878247_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.DayOfWeek
struct  DayOfWeek_t1380878247 
{
public:
	// System.Int32 System.DayOfWeek::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(DayOfWeek_t1380878247, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DAYOFWEEK_T1380878247_H
#ifndef OPFLAGS_T871130963_H
#define OPFLAGS_T871130963_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.RegularExpressions.OpFlags
struct  OpFlags_t871130963 
{
public:
	// System.UInt16 System.Text.RegularExpressions.OpFlags::value__
	uint16_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(OpFlags_t871130963, ___value___1)); }
	inline uint16_t get_value___1() const { return ___value___1; }
	inline uint16_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(uint16_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OPFLAGS_T871130963_H
#ifndef HANDSHAKESTATE_T386269849_H
#define HANDSHAKESTATE_T386269849_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.HandshakeState
struct  HandshakeState_t386269849 
{
public:
	// System.Int32 Mono.Security.Protocol.Tls.HandshakeState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(HandshakeState_t386269849, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HANDSHAKESTATE_T386269849_H
#ifndef OBJECT_T3267094820_H
#define OBJECT_T3267094820_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_t3267094820  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	IntPtr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_t3267094820, ___m_CachedPtr_0)); }
	inline IntPtr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline IntPtr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(IntPtr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_t3267094820_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_t3267094820_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_t3267094820_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_t3267094820_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_T3267094820_H
#ifndef HANDSHAKETYPE_T1042630806_H
#define HANDSHAKETYPE_T1042630806_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.Handshake.HandshakeType
struct  HandshakeType_t1042630806 
{
public:
	// System.Byte Mono.Security.Protocol.Tls.Handshake.HandshakeType::value__
	uint8_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(HandshakeType_t1042630806, ___value___1)); }
	inline uint8_t get_value___1() const { return ___value___1; }
	inline uint8_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(uint8_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HANDSHAKETYPE_T1042630806_H
#ifndef ALERTDESCRIPTION_T1388230643_H
#define ALERTDESCRIPTION_T1388230643_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Security.Protocol.Tls.AlertDescription
struct  AlertDescription_t1388230643 
{
public:
	// System.Byte Mono.Security.Protocol.Tls.AlertDescription::value__
	uint8_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(AlertDescription_t1388230643, ___value___1)); }
	inline uint8_t get_value___1() const { return ___value___1; }
	inline uint8_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(uint8_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ALERTDESCRIPTION_T1388230643_H
#ifndef MONOPROPERTYINFO_T301114984_H
#define MONOPROPERTYINFO_T301114984_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.MonoPropertyInfo
struct  MonoPropertyInfo_t301114984 
{
public:
	// System.Type System.Reflection.MonoPropertyInfo::parent
	Type_t * ___parent_0;
	// System.String System.Reflection.MonoPropertyInfo::name
	String_t* ___name_1;
	// System.Reflection.MethodInfo System.Reflection.MonoPropertyInfo::get_method
	MethodInfo_t * ___get_method_2;
	// System.Reflection.MethodInfo System.Reflection.MonoPropertyInfo::set_method
	MethodInfo_t * ___set_method_3;
	// System.Reflection.PropertyAttributes System.Reflection.MonoPropertyInfo::attrs
	int32_t ___attrs_4;

public:
	inline static int32_t get_offset_of_parent_0() { return static_cast<int32_t>(offsetof(MonoPropertyInfo_t301114984, ___parent_0)); }
	inline Type_t * get_parent_0() const { return ___parent_0; }
	inline Type_t ** get_address_of_parent_0() { return &___parent_0; }
	inline void set_parent_0(Type_t * value)
	{
		___parent_0 = value;
		Il2CppCodeGenWriteBarrier((&___parent_0), value);
	}

	inline static int32_t get_offset_of_name_1() { return static_cast<int32_t>(offsetof(MonoPropertyInfo_t301114984, ___name_1)); }
	inline String_t* get_name_1() const { return ___name_1; }
	inline String_t** get_address_of_name_1() { return &___name_1; }
	inline void set_name_1(String_t* value)
	{
		___name_1 = value;
		Il2CppCodeGenWriteBarrier((&___name_1), value);
	}

	inline static int32_t get_offset_of_get_method_2() { return static_cast<int32_t>(offsetof(MonoPropertyInfo_t301114984, ___get_method_2)); }
	inline MethodInfo_t * get_get_method_2() const { return ___get_method_2; }
	inline MethodInfo_t ** get_address_of_get_method_2() { return &___get_method_2; }
	inline void set_get_method_2(MethodInfo_t * value)
	{
		___get_method_2 = value;
		Il2CppCodeGenWriteBarrier((&___get_method_2), value);
	}

	inline static int32_t get_offset_of_set_method_3() { return static_cast<int32_t>(offsetof(MonoPropertyInfo_t301114984, ___set_method_3)); }
	inline MethodInfo_t * get_set_method_3() const { return ___set_method_3; }
	inline MethodInfo_t ** get_address_of_set_method_3() { return &___set_method_3; }
	inline void set_set_method_3(MethodInfo_t * value)
	{
		___set_method_3 = value;
		Il2CppCodeGenWriteBarrier((&___set_method_3), value);
	}

	inline static int32_t get_offset_of_attrs_4() { return static_cast<int32_t>(offsetof(MonoPropertyInfo_t301114984, ___attrs_4)); }
	inline int32_t get_attrs_4() const { return ___attrs_4; }
	inline int32_t* get_address_of_attrs_4() { return &___attrs_4; }
	inline void set_attrs_4(int32_t value)
	{
		___attrs_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Reflection.MonoPropertyInfo
struct MonoPropertyInfo_t301114984_marshaled_pinvoke
{
	Type_t * ___parent_0;
	char* ___name_1;
	MethodInfo_t * ___get_method_2;
	MethodInfo_t * ___set_method_3;
	int32_t ___attrs_4;
};
// Native definition for COM marshalling of System.Reflection.MonoPropertyInfo
struct MonoPropertyInfo_t301114984_marshaled_com
{
	Type_t * ___parent_0;
	Il2CppChar* ___name_1;
	MethodInfo_t * ___get_method_2;
	MethodInfo_t * ___set_method_3;
	int32_t ___attrs_4;
};
#endif // MONOPROPERTYINFO_T301114984_H
#ifndef MONOMETHODINFO_T2273945901_H
#define MONOMETHODINFO_T2273945901_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.MonoMethodInfo
struct  MonoMethodInfo_t2273945901 
{
public:
	// System.Type System.Reflection.MonoMethodInfo::parent
	Type_t * ___parent_0;
	// System.Type System.Reflection.MonoMethodInfo::ret
	Type_t * ___ret_1;
	// System.Reflection.MethodAttributes System.Reflection.MonoMethodInfo::attrs
	int32_t ___attrs_2;
	// System.Reflection.MethodImplAttributes System.Reflection.MonoMethodInfo::iattrs
	int32_t ___iattrs_3;
	// System.Reflection.CallingConventions System.Reflection.MonoMethodInfo::callconv
	int32_t ___callconv_4;

public:
	inline static int32_t get_offset_of_parent_0() { return static_cast<int32_t>(offsetof(MonoMethodInfo_t2273945901, ___parent_0)); }
	inline Type_t * get_parent_0() const { return ___parent_0; }
	inline Type_t ** get_address_of_parent_0() { return &___parent_0; }
	inline void set_parent_0(Type_t * value)
	{
		___parent_0 = value;
		Il2CppCodeGenWriteBarrier((&___parent_0), value);
	}

	inline static int32_t get_offset_of_ret_1() { return static_cast<int32_t>(offsetof(MonoMethodInfo_t2273945901, ___ret_1)); }
	inline Type_t * get_ret_1() const { return ___ret_1; }
	inline Type_t ** get_address_of_ret_1() { return &___ret_1; }
	inline void set_ret_1(Type_t * value)
	{
		___ret_1 = value;
		Il2CppCodeGenWriteBarrier((&___ret_1), value);
	}

	inline static int32_t get_offset_of_attrs_2() { return static_cast<int32_t>(offsetof(MonoMethodInfo_t2273945901, ___attrs_2)); }
	inline int32_t get_attrs_2() const { return ___attrs_2; }
	inline int32_t* get_address_of_attrs_2() { return &___attrs_2; }
	inline void set_attrs_2(int32_t value)
	{
		___attrs_2 = value;
	}

	inline static int32_t get_offset_of_iattrs_3() { return static_cast<int32_t>(offsetof(MonoMethodInfo_t2273945901, ___iattrs_3)); }
	inline int32_t get_iattrs_3() const { return ___iattrs_3; }
	inline int32_t* get_address_of_iattrs_3() { return &___iattrs_3; }
	inline void set_iattrs_3(int32_t value)
	{
		___iattrs_3 = value;
	}

	inline static int32_t get_offset_of_callconv_4() { return static_cast<int32_t>(offsetof(MonoMethodInfo_t2273945901, ___callconv_4)); }
	inline int32_t get_callconv_4() const { return ___callconv_4; }
	inline int32_t* get_address_of_callconv_4() { return &___callconv_4; }
	inline void set_callconv_4(int32_t value)
	{
		___callconv_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Reflection.MonoMethodInfo
struct MonoMethodInfo_t2273945901_marshaled_pinvoke
{
	Type_t * ___parent_0;
	Type_t * ___ret_1;
	int32_t ___attrs_2;
	int32_t ___iattrs_3;
	int32_t ___callconv_4;
};
// Native definition for COM marshalling of System.Reflection.MonoMethodInfo
struct MonoMethodInfo_t2273945901_marshaled_com
{
	Type_t * ___parent_0;
	Type_t * ___ret_1;
	int32_t ___attrs_2;
	int32_t ___iattrs_3;
	int32_t ___callconv_4;
};
#endif // MONOMETHODINFO_T2273945901_H
#ifndef MODULE_T3479515451_H
#define MODULE_T3479515451_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.Module
struct  Module_t3479515451  : public RuntimeObject
{
public:
	// System.IntPtr System.Reflection.Module::_impl
	IntPtr_t ____impl_3;
	// System.Reflection.Assembly System.Reflection.Module::assembly
	Assembly_t3774988722 * ___assembly_4;
	// System.String System.Reflection.Module::fqname
	String_t* ___fqname_5;
	// System.String System.Reflection.Module::name
	String_t* ___name_6;
	// System.String System.Reflection.Module::scopename
	String_t* ___scopename_7;
	// System.Boolean System.Reflection.Module::is_resource
	bool ___is_resource_8;
	// System.Int32 System.Reflection.Module::token
	int32_t ___token_9;

public:
	inline static int32_t get_offset_of__impl_3() { return static_cast<int32_t>(offsetof(Module_t3479515451, ____impl_3)); }
	inline IntPtr_t get__impl_3() const { return ____impl_3; }
	inline IntPtr_t* get_address_of__impl_3() { return &____impl_3; }
	inline void set__impl_3(IntPtr_t value)
	{
		____impl_3 = value;
	}

	inline static int32_t get_offset_of_assembly_4() { return static_cast<int32_t>(offsetof(Module_t3479515451, ___assembly_4)); }
	inline Assembly_t3774988722 * get_assembly_4() const { return ___assembly_4; }
	inline Assembly_t3774988722 ** get_address_of_assembly_4() { return &___assembly_4; }
	inline void set_assembly_4(Assembly_t3774988722 * value)
	{
		___assembly_4 = value;
		Il2CppCodeGenWriteBarrier((&___assembly_4), value);
	}

	inline static int32_t get_offset_of_fqname_5() { return static_cast<int32_t>(offsetof(Module_t3479515451, ___fqname_5)); }
	inline String_t* get_fqname_5() const { return ___fqname_5; }
	inline String_t** get_address_of_fqname_5() { return &___fqname_5; }
	inline void set_fqname_5(String_t* value)
	{
		___fqname_5 = value;
		Il2CppCodeGenWriteBarrier((&___fqname_5), value);
	}

	inline static int32_t get_offset_of_name_6() { return static_cast<int32_t>(offsetof(Module_t3479515451, ___name_6)); }
	inline String_t* get_name_6() const { return ___name_6; }
	inline String_t** get_address_of_name_6() { return &___name_6; }
	inline void set_name_6(String_t* value)
	{
		___name_6 = value;
		Il2CppCodeGenWriteBarrier((&___name_6), value);
	}

	inline static int32_t get_offset_of_scopename_7() { return static_cast<int32_t>(offsetof(Module_t3479515451, ___scopename_7)); }
	inline String_t* get_scopename_7() const { return ___scopename_7; }
	inline String_t** get_address_of_scopename_7() { return &___scopename_7; }
	inline void set_scopename_7(String_t* value)
	{
		___scopename_7 = value;
		Il2CppCodeGenWriteBarrier((&___scopename_7), value);
	}

	inline static int32_t get_offset_of_is_resource_8() { return static_cast<int32_t>(offsetof(Module_t3479515451, ___is_resource_8)); }
	inline bool get_is_resource_8() const { return ___is_resource_8; }
	inline bool* get_address_of_is_resource_8() { return &___is_resource_8; }
	inline void set_is_resource_8(bool value)
	{
		___is_resource_8 = value;
	}

	inline static int32_t get_offset_of_token_9() { return static_cast<int32_t>(offsetof(Module_t3479515451, ___token_9)); }
	inline int32_t get_token_9() const { return ___token_9; }
	inline int32_t* get_address_of_token_9() { return &___token_9; }
	inline void set_token_9(int32_t value)
	{
		___token_9 = value;
	}
};

struct Module_t3479515451_StaticFields
{
public:
	// System.Reflection.TypeFilter System.Reflection.Module::FilterTypeName
	TypeFilter_t3805304870 * ___FilterTypeName_1;
	// System.Reflection.TypeFilter System.Reflection.Module::FilterTypeNameIgnoreCase
	TypeFilter_t3805304870 * ___FilterTypeNameIgnoreCase_2;

public:
	inline static int32_t get_offset_of_FilterTypeName_1() { return static_cast<int32_t>(offsetof(Module_t3479515451_StaticFields, ___FilterTypeName_1)); }
	inline TypeFilter_t3805304870 * get_FilterTypeName_1() const { return ___FilterTypeName_1; }
	inline TypeFilter_t3805304870 ** get_address_of_FilterTypeName_1() { return &___FilterTypeName_1; }
	inline void set_FilterTypeName_1(TypeFilter_t3805304870 * value)
	{
		___FilterTypeName_1 = value;
		Il2CppCodeGenWriteBarrier((&___FilterTypeName_1), value);
	}

	inline static int32_t get_offset_of_FilterTypeNameIgnoreCase_2() { return static_cast<int32_t>(offsetof(Module_t3479515451_StaticFields, ___FilterTypeNameIgnoreCase_2)); }
	inline TypeFilter_t3805304870 * get_FilterTypeNameIgnoreCase_2() const { return ___FilterTypeNameIgnoreCase_2; }
	inline TypeFilter_t3805304870 ** get_address_of_FilterTypeNameIgnoreCase_2() { return &___FilterTypeNameIgnoreCase_2; }
	inline void set_FilterTypeNameIgnoreCase_2(TypeFilter_t3805304870 * value)
	{
		___FilterTypeNameIgnoreCase_2 = value;
		Il2CppCodeGenWriteBarrier((&___FilterTypeNameIgnoreCase_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MODULE_T3479515451_H
#ifndef PLAYABLE_T3436777522_H
#define PLAYABLE_T3436777522_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.Playable
struct  Playable_t3436777522 
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.Playable::m_Handle
	PlayableHandle_t2910061178  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(Playable_t3436777522, ___m_Handle_0)); }
	inline PlayableHandle_t2910061178  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableHandle_t2910061178 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableHandle_t2910061178  value)
	{
		___m_Handle_0 = value;
	}
};

struct Playable_t3436777522_StaticFields
{
public:
	// UnityEngine.Playables.Playable UnityEngine.Playables.Playable::m_NullPlayable
	Playable_t3436777522  ___m_NullPlayable_1;

public:
	inline static int32_t get_offset_of_m_NullPlayable_1() { return static_cast<int32_t>(offsetof(Playable_t3436777522_StaticFields, ___m_NullPlayable_1)); }
	inline Playable_t3436777522  get_m_NullPlayable_1() const { return ___m_NullPlayable_1; }
	inline Playable_t3436777522 * get_address_of_m_NullPlayable_1() { return &___m_NullPlayable_1; }
	inline void set_m_NullPlayable_1(Playable_t3436777522  value)
	{
		___m_NullPlayable_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYABLE_T3436777522_H
#ifndef MONOEVENTINFO_T2799518403_H
#define MONOEVENTINFO_T2799518403_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Reflection.MonoEventInfo
struct  MonoEventInfo_t2799518403 
{
public:
	// System.Type System.Reflection.MonoEventInfo::declaring_type
	Type_t * ___declaring_type_0;
	// System.Type System.Reflection.MonoEventInfo::reflected_type
	Type_t * ___reflected_type_1;
	// System.String System.Reflection.MonoEventInfo::name
	String_t* ___name_2;
	// System.Reflection.MethodInfo System.Reflection.MonoEventInfo::add_method
	MethodInfo_t * ___add_method_3;
	// System.Reflection.MethodInfo System.Reflection.MonoEventInfo::remove_method
	MethodInfo_t * ___remove_method_4;
	// System.Reflection.MethodInfo System.Reflection.MonoEventInfo::raise_method
	MethodInfo_t * ___raise_method_5;
	// System.Reflection.EventAttributes System.Reflection.MonoEventInfo::attrs
	int32_t ___attrs_6;
	// System.Reflection.MethodInfo[] System.Reflection.MonoEventInfo::other_methods
	MethodInfoU5BU5D_t2800860053* ___other_methods_7;

public:
	inline static int32_t get_offset_of_declaring_type_0() { return static_cast<int32_t>(offsetof(MonoEventInfo_t2799518403, ___declaring_type_0)); }
	inline Type_t * get_declaring_type_0() const { return ___declaring_type_0; }
	inline Type_t ** get_address_of_declaring_type_0() { return &___declaring_type_0; }
	inline void set_declaring_type_0(Type_t * value)
	{
		___declaring_type_0 = value;
		Il2CppCodeGenWriteBarrier((&___declaring_type_0), value);
	}

	inline static int32_t get_offset_of_reflected_type_1() { return static_cast<int32_t>(offsetof(MonoEventInfo_t2799518403, ___reflected_type_1)); }
	inline Type_t * get_reflected_type_1() const { return ___reflected_type_1; }
	inline Type_t ** get_address_of_reflected_type_1() { return &___reflected_type_1; }
	inline void set_reflected_type_1(Type_t * value)
	{
		___reflected_type_1 = value;
		Il2CppCodeGenWriteBarrier((&___reflected_type_1), value);
	}

	inline static int32_t get_offset_of_name_2() { return static_cast<int32_t>(offsetof(MonoEventInfo_t2799518403, ___name_2)); }
	inline String_t* get_name_2() const { return ___name_2; }
	inline String_t** get_address_of_name_2() { return &___name_2; }
	inline void set_name_2(String_t* value)
	{
		___name_2 = value;
		Il2CppCodeGenWriteBarrier((&___name_2), value);
	}

	inline static int32_t get_offset_of_add_method_3() { return static_cast<int32_t>(offsetof(MonoEventInfo_t2799518403, ___add_method_3)); }
	inline MethodInfo_t * get_add_method_3() const { return ___add_method_3; }
	inline MethodInfo_t ** get_address_of_add_method_3() { return &___add_method_3; }
	inline void set_add_method_3(MethodInfo_t * value)
	{
		___add_method_3 = value;
		Il2CppCodeGenWriteBarrier((&___add_method_3), value);
	}

	inline static int32_t get_offset_of_remove_method_4() { return static_cast<int32_t>(offsetof(MonoEventInfo_t2799518403, ___remove_method_4)); }
	inline MethodInfo_t * get_remove_method_4() const { return ___remove_method_4; }
	inline MethodInfo_t ** get_address_of_remove_method_4() { return &___remove_method_4; }
	inline void set_remove_method_4(MethodInfo_t * value)
	{
		___remove_method_4 = value;
		Il2CppCodeGenWriteBarrier((&___remove_method_4), value);
	}

	inline static int32_t get_offset_of_raise_method_5() { return static_cast<int32_t>(offsetof(MonoEventInfo_t2799518403, ___raise_method_5)); }
	inline MethodInfo_t * get_raise_method_5() const { return ___raise_method_5; }
	inline MethodInfo_t ** get_address_of_raise_method_5() { return &___raise_method_5; }
	inline void set_raise_method_5(MethodInfo_t * value)
	{
		___raise_method_5 = value;
		Il2CppCodeGenWriteBarrier((&___raise_method_5), value);
	}

	inline static int32_t get_offset_of_attrs_6() { return static_cast<int32_t>(offsetof(MonoEventInfo_t2799518403, ___attrs_6)); }
	inline int32_t get_attrs_6() const { return ___attrs_6; }
	inline int32_t* get_address_of_attrs_6() { return &___attrs_6; }
	inline void set_attrs_6(int32_t value)
	{
		___attrs_6 = value;
	}

	inline static int32_t get_offset_of_other_methods_7() { return static_cast<int32_t>(offsetof(MonoEventInfo_t2799518403, ___other_methods_7)); }
	inline MethodInfoU5BU5D_t2800860053* get_other_methods_7() const { return ___other_methods_7; }
	inline MethodInfoU5BU5D_t2800860053** get_address_of_other_methods_7() { return &___other_methods_7; }
	inline void set_other_methods_7(MethodInfoU5BU5D_t2800860053* value)
	{
		___other_methods_7 = value;
		Il2CppCodeGenWriteBarrier((&___other_methods_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Reflection.MonoEventInfo
struct MonoEventInfo_t2799518403_marshaled_pinvoke
{
	Type_t * ___declaring_type_0;
	Type_t * ___reflected_type_1;
	char* ___name_2;
	MethodInfo_t * ___add_method_3;
	MethodInfo_t * ___remove_method_4;
	MethodInfo_t * ___raise_method_5;
	int32_t ___attrs_6;
	MethodInfoU5BU5D_t2800860053* ___other_methods_7;
};
// Native definition for COM marshalling of System.Reflection.MonoEventInfo
struct MonoEventInfo_t2799518403_marshaled_com
{
	Type_t * ___declaring_type_0;
	Type_t * ___reflected_type_1;
	Il2CppChar* ___name_2;
	MethodInfo_t * ___add_method_3;
	MethodInfo_t * ___remove_method_4;
	MethodInfo_t * ___raise_method_5;
	int32_t ___attrs_6;
	MethodInfoU5BU5D_t2800860053* ___other_methods_7;
};
#endif // MONOEVENTINFO_T2799518403_H
#ifndef PLAYABLEOUTPUT_T758663699_H
#define PLAYABLEOUTPUT_T758663699_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.PlayableOutput
struct  PlayableOutput_t758663699 
{
public:
	// UnityEngine.Playables.PlayableOutputHandle UnityEngine.Playables.PlayableOutput::m_Handle
	PlayableOutputHandle_t4210482917  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(PlayableOutput_t758663699, ___m_Handle_0)); }
	inline PlayableOutputHandle_t4210482917  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableOutputHandle_t4210482917 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableOutputHandle_t4210482917  value)
	{
		___m_Handle_0 = value;
	}
};

struct PlayableOutput_t758663699_StaticFields
{
public:
	// UnityEngine.Playables.PlayableOutput UnityEngine.Playables.PlayableOutput::m_NullPlayableOutput
	PlayableOutput_t758663699  ___m_NullPlayableOutput_1;

public:
	inline static int32_t get_offset_of_m_NullPlayableOutput_1() { return static_cast<int32_t>(offsetof(PlayableOutput_t758663699_StaticFields, ___m_NullPlayableOutput_1)); }
	inline PlayableOutput_t758663699  get_m_NullPlayableOutput_1() const { return ___m_NullPlayableOutput_1; }
	inline PlayableOutput_t758663699 * get_address_of_m_NullPlayableOutput_1() { return &___m_NullPlayableOutput_1; }
	inline void set_m_NullPlayableOutput_1(PlayableOutput_t758663699  value)
	{
		___m_NullPlayableOutput_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYABLEOUTPUT_T758663699_H
#ifndef ENUMERATOR_T1484102588_H
#define ENUMERATOR_T1484102588_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1/Enumerator<System.Reflection.CustomAttributeNamedArgument>
struct  Enumerator_t1484102588 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::l
	List_1_t211367355 * ___l_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::ver
	int32_t ___ver_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	CustomAttributeNamedArgument_t3456585787  ___current_3;

public:
	inline static int32_t get_offset_of_l_0() { return static_cast<int32_t>(offsetof(Enumerator_t1484102588, ___l_0)); }
	inline List_1_t211367355 * get_l_0() const { return ___l_0; }
	inline List_1_t211367355 ** get_address_of_l_0() { return &___l_0; }
	inline void set_l_0(List_1_t211367355 * value)
	{
		___l_0 = value;
		Il2CppCodeGenWriteBarrier((&___l_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t1484102588, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_ver_2() { return static_cast<int32_t>(offsetof(Enumerator_t1484102588, ___ver_2)); }
	inline int32_t get_ver_2() const { return ___ver_2; }
	inline int32_t* get_address_of_ver_2() { return &___ver_2; }
	inline void set_ver_2(int32_t value)
	{
		___ver_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t1484102588, ___current_3)); }
	inline CustomAttributeNamedArgument_t3456585787  get_current_3() const { return ___current_3; }
	inline CustomAttributeNamedArgument_t3456585787 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(CustomAttributeNamedArgument_t3456585787  value)
	{
		___current_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T1484102588_H
#ifndef MONOIOSTAT_T2386973040_H
#define MONOIOSTAT_T2386973040_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IO.MonoIOStat
struct  MonoIOStat_t2386973040 
{
public:
	// System.String System.IO.MonoIOStat::Name
	String_t* ___Name_0;
	// System.IO.FileAttributes System.IO.MonoIOStat::Attributes
	int32_t ___Attributes_1;
	// System.Int64 System.IO.MonoIOStat::Length
	int64_t ___Length_2;
	// System.Int64 System.IO.MonoIOStat::CreationTime
	int64_t ___CreationTime_3;
	// System.Int64 System.IO.MonoIOStat::LastAccessTime
	int64_t ___LastAccessTime_4;
	// System.Int64 System.IO.MonoIOStat::LastWriteTime
	int64_t ___LastWriteTime_5;

public:
	inline static int32_t get_offset_of_Name_0() { return static_cast<int32_t>(offsetof(MonoIOStat_t2386973040, ___Name_0)); }
	inline String_t* get_Name_0() const { return ___Name_0; }
	inline String_t** get_address_of_Name_0() { return &___Name_0; }
	inline void set_Name_0(String_t* value)
	{
		___Name_0 = value;
		Il2CppCodeGenWriteBarrier((&___Name_0), value);
	}

	inline static int32_t get_offset_of_Attributes_1() { return static_cast<int32_t>(offsetof(MonoIOStat_t2386973040, ___Attributes_1)); }
	inline int32_t get_Attributes_1() const { return ___Attributes_1; }
	inline int32_t* get_address_of_Attributes_1() { return &___Attributes_1; }
	inline void set_Attributes_1(int32_t value)
	{
		___Attributes_1 = value;
	}

	inline static int32_t get_offset_of_Length_2() { return static_cast<int32_t>(offsetof(MonoIOStat_t2386973040, ___Length_2)); }
	inline int64_t get_Length_2() const { return ___Length_2; }
	inline int64_t* get_address_of_Length_2() { return &___Length_2; }
	inline void set_Length_2(int64_t value)
	{
		___Length_2 = value;
	}

	inline static int32_t get_offset_of_CreationTime_3() { return static_cast<int32_t>(offsetof(MonoIOStat_t2386973040, ___CreationTime_3)); }
	inline int64_t get_CreationTime_3() const { return ___CreationTime_3; }
	inline int64_t* get_address_of_CreationTime_3() { return &___CreationTime_3; }
	inline void set_CreationTime_3(int64_t value)
	{
		___CreationTime_3 = value;
	}

	inline static int32_t get_offset_of_LastAccessTime_4() { return static_cast<int32_t>(offsetof(MonoIOStat_t2386973040, ___LastAccessTime_4)); }
	inline int64_t get_LastAccessTime_4() const { return ___LastAccessTime_4; }
	inline int64_t* get_address_of_LastAccessTime_4() { return &___LastAccessTime_4; }
	inline void set_LastAccessTime_4(int64_t value)
	{
		___LastAccessTime_4 = value;
	}

	inline static int32_t get_offset_of_LastWriteTime_5() { return static_cast<int32_t>(offsetof(MonoIOStat_t2386973040, ___LastWriteTime_5)); }
	inline int64_t get_LastWriteTime_5() const { return ___LastWriteTime_5; }
	inline int64_t* get_address_of_LastWriteTime_5() { return &___LastWriteTime_5; }
	inline void set_LastWriteTime_5(int64_t value)
	{
		___LastWriteTime_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.IO.MonoIOStat
struct MonoIOStat_t2386973040_marshaled_pinvoke
{
	char* ___Name_0;
	int32_t ___Attributes_1;
	int64_t ___Length_2;
	int64_t ___CreationTime_3;
	int64_t ___LastAccessTime_4;
	int64_t ___LastWriteTime_5;
};
// Native definition for COM marshalling of System.IO.MonoIOStat
struct MonoIOStat_t2386973040_marshaled_com
{
	Il2CppChar* ___Name_0;
	int32_t ___Attributes_1;
	int64_t ___Length_2;
	int64_t ___CreationTime_3;
	int64_t ___LastAccessTime_4;
	int64_t ___LastWriteTime_5;
};
#endif // MONOIOSTAT_T2386973040_H
#ifndef AUDIOPLAYABLEOUTPUT_T2616039667_H
#define AUDIOPLAYABLEOUTPUT_T2616039667_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Audio.AudioPlayableOutput
struct  AudioPlayableOutput_t2616039667 
{
public:
	// UnityEngine.Playables.PlayableOutputHandle UnityEngine.Audio.AudioPlayableOutput::m_Handle
	PlayableOutputHandle_t4210482917  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(AudioPlayableOutput_t2616039667, ___m_Handle_0)); }
	inline PlayableOutputHandle_t4210482917  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableOutputHandle_t4210482917 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableOutputHandle_t4210482917  value)
	{
		___m_Handle_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AUDIOPLAYABLEOUTPUT_T2616039667_H
#ifndef PLAYABLEBINDING_T2470704133_H
#define PLAYABLEBINDING_T2470704133_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.PlayableBinding
struct  PlayableBinding_t2470704133 
{
public:
	union
	{
		struct
		{
			// System.String UnityEngine.Playables.PlayableBinding::<streamName>k__BackingField
			String_t* ___U3CstreamNameU3Ek__BackingField_2;
			// UnityEngine.Playables.DataStreamType UnityEngine.Playables.PlayableBinding::<streamType>k__BackingField
			int32_t ___U3CstreamTypeU3Ek__BackingField_3;
			// UnityEngine.Object UnityEngine.Playables.PlayableBinding::<sourceObject>k__BackingField
			Object_t3267094820 * ___U3CsourceObjectU3Ek__BackingField_4;
			// System.Type UnityEngine.Playables.PlayableBinding::<sourceBindingType>k__BackingField
			Type_t * ___U3CsourceBindingTypeU3Ek__BackingField_5;
		};
		uint8_t PlayableBinding_t2470704133__padding[1];
	};

public:
	inline static int32_t get_offset_of_U3CstreamNameU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(PlayableBinding_t2470704133, ___U3CstreamNameU3Ek__BackingField_2)); }
	inline String_t* get_U3CstreamNameU3Ek__BackingField_2() const { return ___U3CstreamNameU3Ek__BackingField_2; }
	inline String_t** get_address_of_U3CstreamNameU3Ek__BackingField_2() { return &___U3CstreamNameU3Ek__BackingField_2; }
	inline void set_U3CstreamNameU3Ek__BackingField_2(String_t* value)
	{
		___U3CstreamNameU3Ek__BackingField_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CstreamNameU3Ek__BackingField_2), value);
	}

	inline static int32_t get_offset_of_U3CstreamTypeU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(PlayableBinding_t2470704133, ___U3CstreamTypeU3Ek__BackingField_3)); }
	inline int32_t get_U3CstreamTypeU3Ek__BackingField_3() const { return ___U3CstreamTypeU3Ek__BackingField_3; }
	inline int32_t* get_address_of_U3CstreamTypeU3Ek__BackingField_3() { return &___U3CstreamTypeU3Ek__BackingField_3; }
	inline void set_U3CstreamTypeU3Ek__BackingField_3(int32_t value)
	{
		___U3CstreamTypeU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_U3CsourceObjectU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(PlayableBinding_t2470704133, ___U3CsourceObjectU3Ek__BackingField_4)); }
	inline Object_t3267094820 * get_U3CsourceObjectU3Ek__BackingField_4() const { return ___U3CsourceObjectU3Ek__BackingField_4; }
	inline Object_t3267094820 ** get_address_of_U3CsourceObjectU3Ek__BackingField_4() { return &___U3CsourceObjectU3Ek__BackingField_4; }
	inline void set_U3CsourceObjectU3Ek__BackingField_4(Object_t3267094820 * value)
	{
		___U3CsourceObjectU3Ek__BackingField_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsourceObjectU3Ek__BackingField_4), value);
	}

	inline static int32_t get_offset_of_U3CsourceBindingTypeU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(PlayableBinding_t2470704133, ___U3CsourceBindingTypeU3Ek__BackingField_5)); }
	inline Type_t * get_U3CsourceBindingTypeU3Ek__BackingField_5() const { return ___U3CsourceBindingTypeU3Ek__BackingField_5; }
	inline Type_t ** get_address_of_U3CsourceBindingTypeU3Ek__BackingField_5() { return &___U3CsourceBindingTypeU3Ek__BackingField_5; }
	inline void set_U3CsourceBindingTypeU3Ek__BackingField_5(Type_t * value)
	{
		___U3CsourceBindingTypeU3Ek__BackingField_5 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsourceBindingTypeU3Ek__BackingField_5), value);
	}
};

struct PlayableBinding_t2470704133_StaticFields
{
public:
	// UnityEngine.Playables.PlayableBinding[] UnityEngine.Playables.PlayableBinding::None
	PlayableBindingU5BU5D_t3564038728* ___None_0;
	// System.Double UnityEngine.Playables.PlayableBinding::DefaultDuration
	double ___DefaultDuration_1;

public:
	inline static int32_t get_offset_of_None_0() { return static_cast<int32_t>(offsetof(PlayableBinding_t2470704133_StaticFields, ___None_0)); }
	inline PlayableBindingU5BU5D_t3564038728* get_None_0() const { return ___None_0; }
	inline PlayableBindingU5BU5D_t3564038728** get_address_of_None_0() { return &___None_0; }
	inline void set_None_0(PlayableBindingU5BU5D_t3564038728* value)
	{
		___None_0 = value;
		Il2CppCodeGenWriteBarrier((&___None_0), value);
	}

	inline static int32_t get_offset_of_DefaultDuration_1() { return static_cast<int32_t>(offsetof(PlayableBinding_t2470704133_StaticFields, ___DefaultDuration_1)); }
	inline double get_DefaultDuration_1() const { return ___DefaultDuration_1; }
	inline double* get_address_of_DefaultDuration_1() { return &___DefaultDuration_1; }
	inline void set_DefaultDuration_1(double value)
	{
		___DefaultDuration_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Playables.PlayableBinding
struct PlayableBinding_t2470704133_marshaled_pinvoke
{
	union
	{
		struct
		{
			char* ___U3CstreamNameU3Ek__BackingField_2;
			int32_t ___U3CstreamTypeU3Ek__BackingField_3;
			Object_t3267094820_marshaled_pinvoke ___U3CsourceObjectU3Ek__BackingField_4;
			Type_t * ___U3CsourceBindingTypeU3Ek__BackingField_5;
		};
		uint8_t PlayableBinding_t2470704133__padding[1];
	};
};
// Native definition for COM marshalling of UnityEngine.Playables.PlayableBinding
struct PlayableBinding_t2470704133_marshaled_com
{
	union
	{
		struct
		{
			Il2CppChar* ___U3CstreamNameU3Ek__BackingField_2;
			int32_t ___U3CstreamTypeU3Ek__BackingField_3;
			Object_t3267094820_marshaled_com* ___U3CsourceObjectU3Ek__BackingField_4;
			Type_t * ___U3CsourceBindingTypeU3Ek__BackingField_5;
		};
		uint8_t PlayableBinding_t2470704133__padding[1];
	};
};
#endif // PLAYABLEBINDING_T2470704133_H
#ifndef DATETIME_T3836236387_H
#define DATETIME_T3836236387_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.DateTime
struct  DateTime_t3836236387 
{
public:
	// System.TimeSpan System.DateTime::ticks
	TimeSpan_t4182925364  ___ticks_0;
	// System.DateTimeKind System.DateTime::kind
	int32_t ___kind_1;

public:
	inline static int32_t get_offset_of_ticks_0() { return static_cast<int32_t>(offsetof(DateTime_t3836236387, ___ticks_0)); }
	inline TimeSpan_t4182925364  get_ticks_0() const { return ___ticks_0; }
	inline TimeSpan_t4182925364 * get_address_of_ticks_0() { return &___ticks_0; }
	inline void set_ticks_0(TimeSpan_t4182925364  value)
	{
		___ticks_0 = value;
	}

	inline static int32_t get_offset_of_kind_1() { return static_cast<int32_t>(offsetof(DateTime_t3836236387, ___kind_1)); }
	inline int32_t get_kind_1() const { return ___kind_1; }
	inline int32_t* get_address_of_kind_1() { return &___kind_1; }
	inline void set_kind_1(int32_t value)
	{
		___kind_1 = value;
	}
};

struct DateTime_t3836236387_StaticFields
{
public:
	// System.DateTime System.DateTime::MaxValue
	DateTime_t3836236387  ___MaxValue_2;
	// System.DateTime System.DateTime::MinValue
	DateTime_t3836236387  ___MinValue_3;
	// System.String[] System.DateTime::ParseTimeFormats
	StringU5BU5D_t1828641120* ___ParseTimeFormats_4;
	// System.String[] System.DateTime::ParseYearDayMonthFormats
	StringU5BU5D_t1828641120* ___ParseYearDayMonthFormats_5;
	// System.String[] System.DateTime::ParseYearMonthDayFormats
	StringU5BU5D_t1828641120* ___ParseYearMonthDayFormats_6;
	// System.String[] System.DateTime::ParseDayMonthYearFormats
	StringU5BU5D_t1828641120* ___ParseDayMonthYearFormats_7;
	// System.String[] System.DateTime::ParseMonthDayYearFormats
	StringU5BU5D_t1828641120* ___ParseMonthDayYearFormats_8;
	// System.String[] System.DateTime::MonthDayShortFormats
	StringU5BU5D_t1828641120* ___MonthDayShortFormats_9;
	// System.String[] System.DateTime::DayMonthShortFormats
	StringU5BU5D_t1828641120* ___DayMonthShortFormats_10;
	// System.Int32[] System.DateTime::daysmonth
	Int32U5BU5D_t1381360402* ___daysmonth_11;
	// System.Int32[] System.DateTime::daysmonthleap
	Int32U5BU5D_t1381360402* ___daysmonthleap_12;
	// System.Object System.DateTime::to_local_time_span_object
	RuntimeObject * ___to_local_time_span_object_13;
	// System.Int64 System.DateTime::last_now
	int64_t ___last_now_14;

public:
	inline static int32_t get_offset_of_MaxValue_2() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___MaxValue_2)); }
	inline DateTime_t3836236387  get_MaxValue_2() const { return ___MaxValue_2; }
	inline DateTime_t3836236387 * get_address_of_MaxValue_2() { return &___MaxValue_2; }
	inline void set_MaxValue_2(DateTime_t3836236387  value)
	{
		___MaxValue_2 = value;
	}

	inline static int32_t get_offset_of_MinValue_3() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___MinValue_3)); }
	inline DateTime_t3836236387  get_MinValue_3() const { return ___MinValue_3; }
	inline DateTime_t3836236387 * get_address_of_MinValue_3() { return &___MinValue_3; }
	inline void set_MinValue_3(DateTime_t3836236387  value)
	{
		___MinValue_3 = value;
	}

	inline static int32_t get_offset_of_ParseTimeFormats_4() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___ParseTimeFormats_4)); }
	inline StringU5BU5D_t1828641120* get_ParseTimeFormats_4() const { return ___ParseTimeFormats_4; }
	inline StringU5BU5D_t1828641120** get_address_of_ParseTimeFormats_4() { return &___ParseTimeFormats_4; }
	inline void set_ParseTimeFormats_4(StringU5BU5D_t1828641120* value)
	{
		___ParseTimeFormats_4 = value;
		Il2CppCodeGenWriteBarrier((&___ParseTimeFormats_4), value);
	}

	inline static int32_t get_offset_of_ParseYearDayMonthFormats_5() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___ParseYearDayMonthFormats_5)); }
	inline StringU5BU5D_t1828641120* get_ParseYearDayMonthFormats_5() const { return ___ParseYearDayMonthFormats_5; }
	inline StringU5BU5D_t1828641120** get_address_of_ParseYearDayMonthFormats_5() { return &___ParseYearDayMonthFormats_5; }
	inline void set_ParseYearDayMonthFormats_5(StringU5BU5D_t1828641120* value)
	{
		___ParseYearDayMonthFormats_5 = value;
		Il2CppCodeGenWriteBarrier((&___ParseYearDayMonthFormats_5), value);
	}

	inline static int32_t get_offset_of_ParseYearMonthDayFormats_6() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___ParseYearMonthDayFormats_6)); }
	inline StringU5BU5D_t1828641120* get_ParseYearMonthDayFormats_6() const { return ___ParseYearMonthDayFormats_6; }
	inline StringU5BU5D_t1828641120** get_address_of_ParseYearMonthDayFormats_6() { return &___ParseYearMonthDayFormats_6; }
	inline void set_ParseYearMonthDayFormats_6(StringU5BU5D_t1828641120* value)
	{
		___ParseYearMonthDayFormats_6 = value;
		Il2CppCodeGenWriteBarrier((&___ParseYearMonthDayFormats_6), value);
	}

	inline static int32_t get_offset_of_ParseDayMonthYearFormats_7() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___ParseDayMonthYearFormats_7)); }
	inline StringU5BU5D_t1828641120* get_ParseDayMonthYearFormats_7() const { return ___ParseDayMonthYearFormats_7; }
	inline StringU5BU5D_t1828641120** get_address_of_ParseDayMonthYearFormats_7() { return &___ParseDayMonthYearFormats_7; }
	inline void set_ParseDayMonthYearFormats_7(StringU5BU5D_t1828641120* value)
	{
		___ParseDayMonthYearFormats_7 = value;
		Il2CppCodeGenWriteBarrier((&___ParseDayMonthYearFormats_7), value);
	}

	inline static int32_t get_offset_of_ParseMonthDayYearFormats_8() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___ParseMonthDayYearFormats_8)); }
	inline StringU5BU5D_t1828641120* get_ParseMonthDayYearFormats_8() const { return ___ParseMonthDayYearFormats_8; }
	inline StringU5BU5D_t1828641120** get_address_of_ParseMonthDayYearFormats_8() { return &___ParseMonthDayYearFormats_8; }
	inline void set_ParseMonthDayYearFormats_8(StringU5BU5D_t1828641120* value)
	{
		___ParseMonthDayYearFormats_8 = value;
		Il2CppCodeGenWriteBarrier((&___ParseMonthDayYearFormats_8), value);
	}

	inline static int32_t get_offset_of_MonthDayShortFormats_9() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___MonthDayShortFormats_9)); }
	inline StringU5BU5D_t1828641120* get_MonthDayShortFormats_9() const { return ___MonthDayShortFormats_9; }
	inline StringU5BU5D_t1828641120** get_address_of_MonthDayShortFormats_9() { return &___MonthDayShortFormats_9; }
	inline void set_MonthDayShortFormats_9(StringU5BU5D_t1828641120* value)
	{
		___MonthDayShortFormats_9 = value;
		Il2CppCodeGenWriteBarrier((&___MonthDayShortFormats_9), value);
	}

	inline static int32_t get_offset_of_DayMonthShortFormats_10() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___DayMonthShortFormats_10)); }
	inline StringU5BU5D_t1828641120* get_DayMonthShortFormats_10() const { return ___DayMonthShortFormats_10; }
	inline StringU5BU5D_t1828641120** get_address_of_DayMonthShortFormats_10() { return &___DayMonthShortFormats_10; }
	inline void set_DayMonthShortFormats_10(StringU5BU5D_t1828641120* value)
	{
		___DayMonthShortFormats_10 = value;
		Il2CppCodeGenWriteBarrier((&___DayMonthShortFormats_10), value);
	}

	inline static int32_t get_offset_of_daysmonth_11() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___daysmonth_11)); }
	inline Int32U5BU5D_t1381360402* get_daysmonth_11() const { return ___daysmonth_11; }
	inline Int32U5BU5D_t1381360402** get_address_of_daysmonth_11() { return &___daysmonth_11; }
	inline void set_daysmonth_11(Int32U5BU5D_t1381360402* value)
	{
		___daysmonth_11 = value;
		Il2CppCodeGenWriteBarrier((&___daysmonth_11), value);
	}

	inline static int32_t get_offset_of_daysmonthleap_12() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___daysmonthleap_12)); }
	inline Int32U5BU5D_t1381360402* get_daysmonthleap_12() const { return ___daysmonthleap_12; }
	inline Int32U5BU5D_t1381360402** get_address_of_daysmonthleap_12() { return &___daysmonthleap_12; }
	inline void set_daysmonthleap_12(Int32U5BU5D_t1381360402* value)
	{
		___daysmonthleap_12 = value;
		Il2CppCodeGenWriteBarrier((&___daysmonthleap_12), value);
	}

	inline static int32_t get_offset_of_to_local_time_span_object_13() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___to_local_time_span_object_13)); }
	inline RuntimeObject * get_to_local_time_span_object_13() const { return ___to_local_time_span_object_13; }
	inline RuntimeObject ** get_address_of_to_local_time_span_object_13() { return &___to_local_time_span_object_13; }
	inline void set_to_local_time_span_object_13(RuntimeObject * value)
	{
		___to_local_time_span_object_13 = value;
		Il2CppCodeGenWriteBarrier((&___to_local_time_span_object_13), value);
	}

	inline static int32_t get_offset_of_last_now_14() { return static_cast<int32_t>(offsetof(DateTime_t3836236387_StaticFields, ___last_now_14)); }
	inline int64_t get_last_now_14() const { return ___last_now_14; }
	inline int64_t* get_address_of_last_now_14() { return &___last_now_14; }
	inline void set_last_now_14(int64_t value)
	{
		___last_now_14 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATETIME_T3836236387_H
#ifndef AUDIOCLIPPLAYABLE_T3295732336_H
#define AUDIOCLIPPLAYABLE_T3295732336_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Audio.AudioClipPlayable
struct  AudioClipPlayable_t3295732336 
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Audio.AudioClipPlayable::m_Handle
	PlayableHandle_t2910061178  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(AudioClipPlayable_t3295732336, ___m_Handle_0)); }
	inline PlayableHandle_t2910061178  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableHandle_t2910061178 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableHandle_t2910061178  value)
	{
		___m_Handle_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AUDIOCLIPPLAYABLE_T3295732336_H
#ifndef AUDIOMIXERPLAYABLE_T3345238233_H
#define AUDIOMIXERPLAYABLE_T3345238233_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Audio.AudioMixerPlayable
struct  AudioMixerPlayable_t3345238233 
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Audio.AudioMixerPlayable::m_Handle
	PlayableHandle_t2910061178  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(AudioMixerPlayable_t3345238233, ___m_Handle_0)); }
	inline PlayableHandle_t2910061178  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableHandle_t2910061178 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableHandle_t2910061178  value)
	{
		___m_Handle_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AUDIOMIXERPLAYABLE_T3345238233_H
#ifndef X509CHAINSTATUS_T2329993372_H
#define X509CHAINSTATUS_T2329993372_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Security.Cryptography.X509Certificates.X509ChainStatus
struct  X509ChainStatus_t2329993372 
{
public:
	// System.Security.Cryptography.X509Certificates.X509ChainStatusFlags System.Security.Cryptography.X509Certificates.X509ChainStatus::status
	int32_t ___status_0;
	// System.String System.Security.Cryptography.X509Certificates.X509ChainStatus::info
	String_t* ___info_1;

public:
	inline static int32_t get_offset_of_status_0() { return static_cast<int32_t>(offsetof(X509ChainStatus_t2329993372, ___status_0)); }
	inline int32_t get_status_0() const { return ___status_0; }
	inline int32_t* get_address_of_status_0() { return &___status_0; }
	inline void set_status_0(int32_t value)
	{
		___status_0 = value;
	}

	inline static int32_t get_offset_of_info_1() { return static_cast<int32_t>(offsetof(X509ChainStatus_t2329993372, ___info_1)); }
	inline String_t* get_info_1() const { return ___info_1; }
	inline String_t** get_address_of_info_1() { return &___info_1; }
	inline void set_info_1(String_t* value)
	{
		___info_1 = value;
		Il2CppCodeGenWriteBarrier((&___info_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Security.Cryptography.X509Certificates.X509ChainStatus
struct X509ChainStatus_t2329993372_marshaled_pinvoke
{
	int32_t ___status_0;
	char* ___info_1;
};
// Native definition for COM marshalling of System.Security.Cryptography.X509Certificates.X509ChainStatus
struct X509ChainStatus_t2329993372_marshaled_com
{
	int32_t ___status_0;
	Il2CppChar* ___info_1;
};
#endif // X509CHAINSTATUS_T2329993372_H
#ifndef URIFORMATEXCEPTION_T2885938561_H
#define URIFORMATEXCEPTION_T2885938561_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UriFormatException
struct  UriFormatException_t2885938561  : public FormatException_t2016869209
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // URIFORMATEXCEPTION_T2885938561_H
#ifndef FRAMEDATA_T231040801_H
#define FRAMEDATA_T231040801_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.FrameData
struct  FrameData_t231040801 
{
public:
	// System.UInt64 UnityEngine.Playables.FrameData::m_FrameID
	uint64_t ___m_FrameID_0;
	// System.Double UnityEngine.Playables.FrameData::m_DeltaTime
	double ___m_DeltaTime_1;
	// System.Single UnityEngine.Playables.FrameData::m_Weight
	float ___m_Weight_2;
	// System.Single UnityEngine.Playables.FrameData::m_EffectiveWeight
	float ___m_EffectiveWeight_3;
	// System.Single UnityEngine.Playables.FrameData::m_EffectiveSpeed
	float ___m_EffectiveSpeed_4;
	// UnityEngine.Playables.FrameData/Flags UnityEngine.Playables.FrameData::m_Flags
	int32_t ___m_Flags_5;

public:
	inline static int32_t get_offset_of_m_FrameID_0() { return static_cast<int32_t>(offsetof(FrameData_t231040801, ___m_FrameID_0)); }
	inline uint64_t get_m_FrameID_0() const { return ___m_FrameID_0; }
	inline uint64_t* get_address_of_m_FrameID_0() { return &___m_FrameID_0; }
	inline void set_m_FrameID_0(uint64_t value)
	{
		___m_FrameID_0 = value;
	}

	inline static int32_t get_offset_of_m_DeltaTime_1() { return static_cast<int32_t>(offsetof(FrameData_t231040801, ___m_DeltaTime_1)); }
	inline double get_m_DeltaTime_1() const { return ___m_DeltaTime_1; }
	inline double* get_address_of_m_DeltaTime_1() { return &___m_DeltaTime_1; }
	inline void set_m_DeltaTime_1(double value)
	{
		___m_DeltaTime_1 = value;
	}

	inline static int32_t get_offset_of_m_Weight_2() { return static_cast<int32_t>(offsetof(FrameData_t231040801, ___m_Weight_2)); }
	inline float get_m_Weight_2() const { return ___m_Weight_2; }
	inline float* get_address_of_m_Weight_2() { return &___m_Weight_2; }
	inline void set_m_Weight_2(float value)
	{
		___m_Weight_2 = value;
	}

	inline static int32_t get_offset_of_m_EffectiveWeight_3() { return static_cast<int32_t>(offsetof(FrameData_t231040801, ___m_EffectiveWeight_3)); }
	inline float get_m_EffectiveWeight_3() const { return ___m_EffectiveWeight_3; }
	inline float* get_address_of_m_EffectiveWeight_3() { return &___m_EffectiveWeight_3; }
	inline void set_m_EffectiveWeight_3(float value)
	{
		___m_EffectiveWeight_3 = value;
	}

	inline static int32_t get_offset_of_m_EffectiveSpeed_4() { return static_cast<int32_t>(offsetof(FrameData_t231040801, ___m_EffectiveSpeed_4)); }
	inline float get_m_EffectiveSpeed_4() const { return ___m_EffectiveSpeed_4; }
	inline float* get_address_of_m_EffectiveSpeed_4() { return &___m_EffectiveSpeed_4; }
	inline void set_m_EffectiveSpeed_4(float value)
	{
		___m_EffectiveSpeed_4 = value;
	}

	inline static int32_t get_offset_of_m_Flags_5() { return static_cast<int32_t>(offsetof(FrameData_t231040801, ___m_Flags_5)); }
	inline int32_t get_m_Flags_5() const { return ___m_Flags_5; }
	inline int32_t* get_address_of_m_Flags_5() { return &___m_Flags_5; }
	inline void set_m_Flags_5(int32_t value)
	{
		___m_Flags_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FRAMEDATA_T231040801_H
#ifndef SCRIPTPLAYABLEOUTPUT_T2716968363_H
#define SCRIPTPLAYABLEOUTPUT_T2716968363_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.ScriptPlayableOutput
struct  ScriptPlayableOutput_t2716968363 
{
public:
	// UnityEngine.Playables.PlayableOutputHandle UnityEngine.Playables.ScriptPlayableOutput::m_Handle
	PlayableOutputHandle_t4210482917  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(ScriptPlayableOutput_t2716968363, ___m_Handle_0)); }
	inline PlayableOutputHandle_t4210482917  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableOutputHandle_t4210482917 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableOutputHandle_t4210482917  value)
	{
		___m_Handle_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCRIPTPLAYABLEOUTPUT_T2716968363_H
#ifndef IPADDRESS_T3056411848_H
#define IPADDRESS_T3056411848_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Net.IPAddress
struct  IPAddress_t3056411848  : public RuntimeObject
{
public:
	// System.Int64 System.Net.IPAddress::m_Address
	int64_t ___m_Address_0;
	// System.Net.Sockets.AddressFamily System.Net.IPAddress::m_Family
	int32_t ___m_Family_1;
	// System.UInt16[] System.Net.IPAddress::m_Numbers
	UInt16U5BU5D_t3522456909* ___m_Numbers_2;
	// System.Int64 System.Net.IPAddress::m_ScopeId
	int64_t ___m_ScopeId_3;

public:
	inline static int32_t get_offset_of_m_Address_0() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848, ___m_Address_0)); }
	inline int64_t get_m_Address_0() const { return ___m_Address_0; }
	inline int64_t* get_address_of_m_Address_0() { return &___m_Address_0; }
	inline void set_m_Address_0(int64_t value)
	{
		___m_Address_0 = value;
	}

	inline static int32_t get_offset_of_m_Family_1() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848, ___m_Family_1)); }
	inline int32_t get_m_Family_1() const { return ___m_Family_1; }
	inline int32_t* get_address_of_m_Family_1() { return &___m_Family_1; }
	inline void set_m_Family_1(int32_t value)
	{
		___m_Family_1 = value;
	}

	inline static int32_t get_offset_of_m_Numbers_2() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848, ___m_Numbers_2)); }
	inline UInt16U5BU5D_t3522456909* get_m_Numbers_2() const { return ___m_Numbers_2; }
	inline UInt16U5BU5D_t3522456909** get_address_of_m_Numbers_2() { return &___m_Numbers_2; }
	inline void set_m_Numbers_2(UInt16U5BU5D_t3522456909* value)
	{
		___m_Numbers_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_Numbers_2), value);
	}

	inline static int32_t get_offset_of_m_ScopeId_3() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848, ___m_ScopeId_3)); }
	inline int64_t get_m_ScopeId_3() const { return ___m_ScopeId_3; }
	inline int64_t* get_address_of_m_ScopeId_3() { return &___m_ScopeId_3; }
	inline void set_m_ScopeId_3(int64_t value)
	{
		___m_ScopeId_3 = value;
	}
};

struct IPAddress_t3056411848_StaticFields
{
public:
	// System.Net.IPAddress System.Net.IPAddress::Any
	IPAddress_t3056411848 * ___Any_4;
	// System.Net.IPAddress System.Net.IPAddress::Broadcast
	IPAddress_t3056411848 * ___Broadcast_5;
	// System.Net.IPAddress System.Net.IPAddress::Loopback
	IPAddress_t3056411848 * ___Loopback_6;
	// System.Net.IPAddress System.Net.IPAddress::None
	IPAddress_t3056411848 * ___None_7;
	// System.Net.IPAddress System.Net.IPAddress::IPv6Any
	IPAddress_t3056411848 * ___IPv6Any_8;
	// System.Net.IPAddress System.Net.IPAddress::IPv6Loopback
	IPAddress_t3056411848 * ___IPv6Loopback_9;
	// System.Net.IPAddress System.Net.IPAddress::IPv6None
	IPAddress_t3056411848 * ___IPv6None_10;

public:
	inline static int32_t get_offset_of_Any_4() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848_StaticFields, ___Any_4)); }
	inline IPAddress_t3056411848 * get_Any_4() const { return ___Any_4; }
	inline IPAddress_t3056411848 ** get_address_of_Any_4() { return &___Any_4; }
	inline void set_Any_4(IPAddress_t3056411848 * value)
	{
		___Any_4 = value;
		Il2CppCodeGenWriteBarrier((&___Any_4), value);
	}

	inline static int32_t get_offset_of_Broadcast_5() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848_StaticFields, ___Broadcast_5)); }
	inline IPAddress_t3056411848 * get_Broadcast_5() const { return ___Broadcast_5; }
	inline IPAddress_t3056411848 ** get_address_of_Broadcast_5() { return &___Broadcast_5; }
	inline void set_Broadcast_5(IPAddress_t3056411848 * value)
	{
		___Broadcast_5 = value;
		Il2CppCodeGenWriteBarrier((&___Broadcast_5), value);
	}

	inline static int32_t get_offset_of_Loopback_6() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848_StaticFields, ___Loopback_6)); }
	inline IPAddress_t3056411848 * get_Loopback_6() const { return ___Loopback_6; }
	inline IPAddress_t3056411848 ** get_address_of_Loopback_6() { return &___Loopback_6; }
	inline void set_Loopback_6(IPAddress_t3056411848 * value)
	{
		___Loopback_6 = value;
		Il2CppCodeGenWriteBarrier((&___Loopback_6), value);
	}

	inline static int32_t get_offset_of_None_7() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848_StaticFields, ___None_7)); }
	inline IPAddress_t3056411848 * get_None_7() const { return ___None_7; }
	inline IPAddress_t3056411848 ** get_address_of_None_7() { return &___None_7; }
	inline void set_None_7(IPAddress_t3056411848 * value)
	{
		___None_7 = value;
		Il2CppCodeGenWriteBarrier((&___None_7), value);
	}

	inline static int32_t get_offset_of_IPv6Any_8() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848_StaticFields, ___IPv6Any_8)); }
	inline IPAddress_t3056411848 * get_IPv6Any_8() const { return ___IPv6Any_8; }
	inline IPAddress_t3056411848 ** get_address_of_IPv6Any_8() { return &___IPv6Any_8; }
	inline void set_IPv6Any_8(IPAddress_t3056411848 * value)
	{
		___IPv6Any_8 = value;
		Il2CppCodeGenWriteBarrier((&___IPv6Any_8), value);
	}

	inline static int32_t get_offset_of_IPv6Loopback_9() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848_StaticFields, ___IPv6Loopback_9)); }
	inline IPAddress_t3056411848 * get_IPv6Loopback_9() const { return ___IPv6Loopback_9; }
	inline IPAddress_t3056411848 ** get_address_of_IPv6Loopback_9() { return &___IPv6Loopback_9; }
	inline void set_IPv6Loopback_9(IPAddress_t3056411848 * value)
	{
		___IPv6Loopback_9 = value;
		Il2CppCodeGenWriteBarrier((&___IPv6Loopback_9), value);
	}

	inline static int32_t get_offset_of_IPv6None_10() { return static_cast<int32_t>(offsetof(IPAddress_t3056411848_StaticFields, ___IPv6None_10)); }
	inline IPAddress_t3056411848 * get_IPv6None_10() const { return ___IPv6None_10; }
	inline IPAddress_t3056411848 ** get_address_of_IPv6None_10() { return &___IPv6None_10; }
	inline void set_IPv6None_10(IPAddress_t3056411848 * value)
	{
		___IPv6None_10 = value;
		Il2CppCodeGenWriteBarrier((&___IPv6None_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // IPADDRESS_T3056411848_H
#ifndef CONTEXT_T1711146899_H
#define CONTEXT_T1711146899_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Globalization.Unicode.SimpleCollator/Context
struct  Context_t1711146899 
{
public:
	// System.Globalization.CompareOptions Mono.Globalization.Unicode.SimpleCollator/Context::Option
	int32_t ___Option_0;
	// System.Byte* Mono.Globalization.Unicode.SimpleCollator/Context::NeverMatchFlags
	uint8_t* ___NeverMatchFlags_1;
	// System.Byte* Mono.Globalization.Unicode.SimpleCollator/Context::AlwaysMatchFlags
	uint8_t* ___AlwaysMatchFlags_2;
	// System.Byte* Mono.Globalization.Unicode.SimpleCollator/Context::Buffer1
	uint8_t* ___Buffer1_3;
	// System.Byte* Mono.Globalization.Unicode.SimpleCollator/Context::Buffer2
	uint8_t* ___Buffer2_4;
	// System.Int32 Mono.Globalization.Unicode.SimpleCollator/Context::PrevCode
	int32_t ___PrevCode_5;
	// System.Byte* Mono.Globalization.Unicode.SimpleCollator/Context::PrevSortKey
	uint8_t* ___PrevSortKey_6;
	// System.Boolean Mono.Globalization.Unicode.SimpleCollator/Context::QuickCheckPossible
	bool ___QuickCheckPossible_7;

public:
	inline static int32_t get_offset_of_Option_0() { return static_cast<int32_t>(offsetof(Context_t1711146899, ___Option_0)); }
	inline int32_t get_Option_0() const { return ___Option_0; }
	inline int32_t* get_address_of_Option_0() { return &___Option_0; }
	inline void set_Option_0(int32_t value)
	{
		___Option_0 = value;
	}

	inline static int32_t get_offset_of_NeverMatchFlags_1() { return static_cast<int32_t>(offsetof(Context_t1711146899, ___NeverMatchFlags_1)); }
	inline uint8_t* get_NeverMatchFlags_1() const { return ___NeverMatchFlags_1; }
	inline uint8_t** get_address_of_NeverMatchFlags_1() { return &___NeverMatchFlags_1; }
	inline void set_NeverMatchFlags_1(uint8_t* value)
	{
		___NeverMatchFlags_1 = value;
	}

	inline static int32_t get_offset_of_AlwaysMatchFlags_2() { return static_cast<int32_t>(offsetof(Context_t1711146899, ___AlwaysMatchFlags_2)); }
	inline uint8_t* get_AlwaysMatchFlags_2() const { return ___AlwaysMatchFlags_2; }
	inline uint8_t** get_address_of_AlwaysMatchFlags_2() { return &___AlwaysMatchFlags_2; }
	inline void set_AlwaysMatchFlags_2(uint8_t* value)
	{
		___AlwaysMatchFlags_2 = value;
	}

	inline static int32_t get_offset_of_Buffer1_3() { return static_cast<int32_t>(offsetof(Context_t1711146899, ___Buffer1_3)); }
	inline uint8_t* get_Buffer1_3() const { return ___Buffer1_3; }
	inline uint8_t** get_address_of_Buffer1_3() { return &___Buffer1_3; }
	inline void set_Buffer1_3(uint8_t* value)
	{
		___Buffer1_3 = value;
	}

	inline static int32_t get_offset_of_Buffer2_4() { return static_cast<int32_t>(offsetof(Context_t1711146899, ___Buffer2_4)); }
	inline uint8_t* get_Buffer2_4() const { return ___Buffer2_4; }
	inline uint8_t** get_address_of_Buffer2_4() { return &___Buffer2_4; }
	inline void set_Buffer2_4(uint8_t* value)
	{
		___Buffer2_4 = value;
	}

	inline static int32_t get_offset_of_PrevCode_5() { return static_cast<int32_t>(offsetof(Context_t1711146899, ___PrevCode_5)); }
	inline int32_t get_PrevCode_5() const { return ___PrevCode_5; }
	inline int32_t* get_address_of_PrevCode_5() { return &___PrevCode_5; }
	inline void set_PrevCode_5(int32_t value)
	{
		___PrevCode_5 = value;
	}

	inline static int32_t get_offset_of_PrevSortKey_6() { return static_cast<int32_t>(offsetof(Context_t1711146899, ___PrevSortKey_6)); }
	inline uint8_t* get_PrevSortKey_6() const { return ___PrevSortKey_6; }
	inline uint8_t** get_address_of_PrevSortKey_6() { return &___PrevSortKey_6; }
	inline void set_PrevSortKey_6(uint8_t* value)
	{
		___PrevSortKey_6 = value;
	}

	inline static int32_t get_offset_of_QuickCheckPossible_7() { return static_cast<int32_t>(offsetof(Context_t1711146899, ___QuickCheckPossible_7)); }
	inline bool get_QuickCheckPossible_7() const { return ___QuickCheckPossible_7; }
	inline bool* get_address_of_QuickCheckPossible_7() { return &___QuickCheckPossible_7; }
	inline void set_QuickCheckPossible_7(bool value)
	{
		___QuickCheckPossible_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of Mono.Globalization.Unicode.SimpleCollator/Context
struct Context_t1711146899_marshaled_pinvoke
{
	int32_t ___Option_0;
	uint8_t* ___NeverMatchFlags_1;
	uint8_t* ___AlwaysMatchFlags_2;
	uint8_t* ___Buffer1_3;
	uint8_t* ___Buffer2_4;
	int32_t ___PrevCode_5;
	uint8_t* ___PrevSortKey_6;
	int32_t ___QuickCheckPossible_7;
};
// Native definition for COM marshalling of Mono.Globalization.Unicode.SimpleCollator/Context
struct Context_t1711146899_marshaled_com
{
	int32_t ___Option_0;
	uint8_t* ___NeverMatchFlags_1;
	uint8_t* ___AlwaysMatchFlags_2;
	uint8_t* ___Buffer1_3;
	uint8_t* ___Buffer2_4;
	int32_t ___PrevCode_5;
	uint8_t* ___PrevSortKey_6;
	int32_t ___QuickCheckPossible_7;
};
#endif // CONTEXT_T1711146899_H
#ifndef MULTICASTDELEGATE_T608486974_H
#define MULTICASTDELEGATE_T608486974_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t608486974  : public Delegate_t2990640460
{
public:
	// System.MulticastDelegate System.MulticastDelegate::prev
	MulticastDelegate_t608486974 * ___prev_9;
	// System.MulticastDelegate System.MulticastDelegate::kpm_next
	MulticastDelegate_t608486974 * ___kpm_next_10;

public:
	inline static int32_t get_offset_of_prev_9() { return static_cast<int32_t>(offsetof(MulticastDelegate_t608486974, ___prev_9)); }
	inline MulticastDelegate_t608486974 * get_prev_9() const { return ___prev_9; }
	inline MulticastDelegate_t608486974 ** get_address_of_prev_9() { return &___prev_9; }
	inline void set_prev_9(MulticastDelegate_t608486974 * value)
	{
		___prev_9 = value;
		Il2CppCodeGenWriteBarrier((&___prev_9), value);
	}

	inline static int32_t get_offset_of_kpm_next_10() { return static_cast<int32_t>(offsetof(MulticastDelegate_t608486974, ___kpm_next_10)); }
	inline MulticastDelegate_t608486974 * get_kpm_next_10() const { return ___kpm_next_10; }
	inline MulticastDelegate_t608486974 ** get_address_of_kpm_next_10() { return &___kpm_next_10; }
	inline void set_kpm_next_10(MulticastDelegate_t608486974 * value)
	{
		___kpm_next_10 = value;
		Il2CppCodeGenWriteBarrier((&___kpm_next_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MULTICASTDELEGATE_T608486974_H
#ifndef ENUMERATOR_T1463273643_H
#define ENUMERATOR_T1463273643_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2/Enumerator<System.IntPtr,System.Object>
struct  Enumerator_t1463273643 
{
public:
	// System.Collections.Generic.Dictionary`2<TKey,TValue> System.Collections.Generic.Dictionary`2/Enumerator::dictionary
	Dictionary_2_t2410526581 * ___dictionary_0;
	// System.Int32 System.Collections.Generic.Dictionary`2/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.Dictionary`2/Enumerator::stamp
	int32_t ___stamp_2;
	// System.Collections.Generic.KeyValuePair`2<TKey,TValue> System.Collections.Generic.Dictionary`2/Enumerator::current
	KeyValuePair_2_t2173232590  ___current_3;

public:
	inline static int32_t get_offset_of_dictionary_0() { return static_cast<int32_t>(offsetof(Enumerator_t1463273643, ___dictionary_0)); }
	inline Dictionary_2_t2410526581 * get_dictionary_0() const { return ___dictionary_0; }
	inline Dictionary_2_t2410526581 ** get_address_of_dictionary_0() { return &___dictionary_0; }
	inline void set_dictionary_0(Dictionary_2_t2410526581 * value)
	{
		___dictionary_0 = value;
		Il2CppCodeGenWriteBarrier((&___dictionary_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t1463273643, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_stamp_2() { return static_cast<int32_t>(offsetof(Enumerator_t1463273643, ___stamp_2)); }
	inline int32_t get_stamp_2() const { return ___stamp_2; }
	inline int32_t* get_address_of_stamp_2() { return &___stamp_2; }
	inline void set_stamp_2(int32_t value)
	{
		___stamp_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t1463273643, ___current_3)); }
	inline KeyValuePair_2_t2173232590  get_current_3() const { return ___current_3; }
	inline KeyValuePair_2_t2173232590 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(KeyValuePair_2_t2173232590  value)
	{
		___current_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T1463273643_H
#ifndef STREAMINGCONTEXT_T885793295_H
#define STREAMINGCONTEXT_T885793295_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.Serialization.StreamingContext
struct  StreamingContext_t885793295 
{
public:
	// System.Runtime.Serialization.StreamingContextStates System.Runtime.Serialization.StreamingContext::state
	int32_t ___state_0;
	// System.Object System.Runtime.Serialization.StreamingContext::additional
	RuntimeObject * ___additional_1;

public:
	inline static int32_t get_offset_of_state_0() { return static_cast<int32_t>(offsetof(StreamingContext_t885793295, ___state_0)); }
	inline int32_t get_state_0() const { return ___state_0; }
	inline int32_t* get_address_of_state_0() { return &___state_0; }
	inline void set_state_0(int32_t value)
	{
		___state_0 = value;
	}

	inline static int32_t get_offset_of_additional_1() { return static_cast<int32_t>(offsetof(StreamingContext_t885793295, ___additional_1)); }
	inline RuntimeObject * get_additional_1() const { return ___additional_1; }
	inline RuntimeObject ** get_address_of_additional_1() { return &___additional_1; }
	inline void set_additional_1(RuntimeObject * value)
	{
		___additional_1 = value;
		Il2CppCodeGenWriteBarrier((&___additional_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Runtime.Serialization.StreamingContext
struct StreamingContext_t885793295_marshaled_pinvoke
{
	int32_t ___state_0;
	Il2CppIUnknown* ___additional_1;
};
// Native definition for COM marshalling of System.Runtime.Serialization.StreamingContext
struct StreamingContext_t885793295_marshaled_com
{
	int32_t ___state_0;
	Il2CppIUnknown* ___additional_1;
};
#endif // STREAMINGCONTEXT_T885793295_H
#ifndef DATETIMEOFFSET_T3036919142_H
#define DATETIMEOFFSET_T3036919142_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.DateTimeOffset
struct  DateTimeOffset_t3036919142 
{
public:
	// System.DateTime System.DateTimeOffset::dt
	DateTime_t3836236387  ___dt_2;
	// System.TimeSpan System.DateTimeOffset::utc_offset
	TimeSpan_t4182925364  ___utc_offset_3;

public:
	inline static int32_t get_offset_of_dt_2() { return static_cast<int32_t>(offsetof(DateTimeOffset_t3036919142, ___dt_2)); }
	inline DateTime_t3836236387  get_dt_2() const { return ___dt_2; }
	inline DateTime_t3836236387 * get_address_of_dt_2() { return &___dt_2; }
	inline void set_dt_2(DateTime_t3836236387  value)
	{
		___dt_2 = value;
	}

	inline static int32_t get_offset_of_utc_offset_3() { return static_cast<int32_t>(offsetof(DateTimeOffset_t3036919142, ___utc_offset_3)); }
	inline TimeSpan_t4182925364  get_utc_offset_3() const { return ___utc_offset_3; }
	inline TimeSpan_t4182925364 * get_address_of_utc_offset_3() { return &___utc_offset_3; }
	inline void set_utc_offset_3(TimeSpan_t4182925364  value)
	{
		___utc_offset_3 = value;
	}
};

struct DateTimeOffset_t3036919142_StaticFields
{
public:
	// System.DateTimeOffset System.DateTimeOffset::MaxValue
	DateTimeOffset_t3036919142  ___MaxValue_0;
	// System.DateTimeOffset System.DateTimeOffset::MinValue
	DateTimeOffset_t3036919142  ___MinValue_1;

public:
	inline static int32_t get_offset_of_MaxValue_0() { return static_cast<int32_t>(offsetof(DateTimeOffset_t3036919142_StaticFields, ___MaxValue_0)); }
	inline DateTimeOffset_t3036919142  get_MaxValue_0() const { return ___MaxValue_0; }
	inline DateTimeOffset_t3036919142 * get_address_of_MaxValue_0() { return &___MaxValue_0; }
	inline void set_MaxValue_0(DateTimeOffset_t3036919142  value)
	{
		___MaxValue_0 = value;
	}

	inline static int32_t get_offset_of_MinValue_1() { return static_cast<int32_t>(offsetof(DateTimeOffset_t3036919142_StaticFields, ___MinValue_1)); }
	inline DateTimeOffset_t3036919142  get_MinValue_1() const { return ___MinValue_1; }
	inline DateTimeOffset_t3036919142 * get_address_of_MinValue_1() { return &___MinValue_1; }
	inline void set_MinValue_1(DateTimeOffset_t3036919142  value)
	{
		___MinValue_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATETIMEOFFSET_T3036919142_H
// System.Object[]
struct ObjectU5BU5D_t42211586  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) RuntimeObject * m_Items[1];

public:
	inline RuntimeObject * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, RuntimeObject * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
	inline RuntimeObject * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, RuntimeObject * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
};
// Mono.Globalization.Unicode.Contraction[]
struct ContractionU5BU5D_t572014478  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Contraction_t3155759031 * m_Items[1];

public:
	inline Contraction_t3155759031 * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Contraction_t3155759031 ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Contraction_t3155759031 * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
	inline Contraction_t3155759031 * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Contraction_t3155759031 ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Contraction_t3155759031 * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
};
// Mono.Globalization.Unicode.Level2Map[]
struct Level2MapU5BU5D_t3298050836  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Level2Map_t2835147305 * m_Items[1];

public:
	inline Level2Map_t2835147305 * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Level2Map_t2835147305 ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Level2Map_t2835147305 * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
	inline Level2Map_t2835147305 * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Level2Map_t2835147305 ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Level2Map_t2835147305 * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
};
// System.Byte[]
struct ByteU5BU5D_t3003616614  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) uint8_t m_Items[1];

public:
	inline uint8_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline uint8_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, uint8_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline uint8_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline uint8_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, uint8_t value)
	{
		m_Items[index] = value;
	}
};
// System.Runtime.Remoting.Messaging.Header[]
struct HeaderU5BU5D_t4052410742  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Header_t867743215 * m_Items[1];

public:
	inline Header_t867743215 * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Header_t867743215 ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Header_t867743215 * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
	inline Header_t867743215 * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Header_t867743215 ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Header_t867743215 * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
};
// System.Char[]
struct CharU5BU5D_t2816624037  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Il2CppChar m_Items[1];

public:
	inline Il2CppChar GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Il2CppChar* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Il2CppChar value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline Il2CppChar GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Il2CppChar* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Il2CppChar value)
	{
		m_Items[index] = value;
	}
};
// System.Int64[]
struct Int64U5BU5D_t110483415  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) int64_t m_Items[1];

public:
	inline int64_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline int64_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, int64_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline int64_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline int64_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, int64_t value)
	{
		m_Items[index] = value;
	}
};
// System.String[]
struct StringU5BU5D_t1828641120  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) String_t* m_Items[1];

public:
	inline String_t* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline String_t** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, String_t* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
	inline String_t* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline String_t** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, String_t* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
};
// System.Int32[]
struct Int32U5BU5D_t1381360402  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) int32_t m_Items[1];

public:
	inline int32_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline int32_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, int32_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline int32_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline int32_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, int32_t value)
	{
		m_Items[index] = value;
	}
};
// System.Reflection.CustomAttributeNamedArgument[]
struct CustomAttributeNamedArgumentU5BU5D_t2930047098  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) CustomAttributeNamedArgument_t3456585787  m_Items[1];

public:
	inline CustomAttributeNamedArgument_t3456585787  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline CustomAttributeNamedArgument_t3456585787 * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, CustomAttributeNamedArgument_t3456585787  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline CustomAttributeNamedArgument_t3456585787  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline CustomAttributeNamedArgument_t3456585787 * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, CustomAttributeNamedArgument_t3456585787  value)
	{
		m_Items[index] = value;
	}
};
// System.Reflection.CustomAttributeTypedArgument[]
struct CustomAttributeTypedArgumentU5BU5D_t3967009591  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) CustomAttributeTypedArgument_t2066493570  m_Items[1];

public:
	inline CustomAttributeTypedArgument_t2066493570  GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline CustomAttributeTypedArgument_t2066493570 * GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, CustomAttributeTypedArgument_t2066493570  value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline CustomAttributeTypedArgument_t2066493570  GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline CustomAttributeTypedArgument_t2066493570 * GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, CustomAttributeTypedArgument_t2066493570  value)
	{
		m_Items[index] = value;
	}
};



void* RuntimeInvoker_Void_t1421048318 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, const RuntimeMethod* method);
	((Func)methodPointer)(obj, methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, methodMetadata);
	return ret;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_ObjectU5BU5DU26_t1191207502 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, ObjectU5BU5D_t42211586** p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (ObjectU5BU5D_t42211586**)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_ObjectU5BU5DU26_t1191207502 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, ObjectU5BU5D_t42211586** p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (ObjectU5BU5D_t42211586**)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Byte_t1695016127_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Char_t4217985068_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	Il2CppChar ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Decimal_t2382302464_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_SByte_t1526744772_RuntimeObject_Int32_t438220675_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int8_t p1, RuntimeObject * p2, int32_t p3, Exception_t2443218823 ** p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), (Exception_t2443218823 **)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772_Int32U26_t3865694581_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int8_t p2, int32_t* p3, Exception_t2443218823 ** p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (int32_t*)args[2], (Exception_t2443218823 **)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675_SByte_t1526744772_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int8_t p2, Exception_t2443218823 ** p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), (Exception_t2443218823 **)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32U26_t3865694581_RuntimeObject_SByte_t1526744772_SByte_t1526744772_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, RuntimeObject * p2, int8_t p3, int8_t p4, Exception_t2443218823 ** p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (int32_t*)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), (Exception_t2443218823 **)args[4], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32U26_t3865694581_RuntimeObject_RuntimeObject_BooleanU26_t2626765736_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, RuntimeObject * p2, RuntimeObject * p3, bool* p4, bool* p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (int32_t*)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (bool*)args[3], (bool*)args[4], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32U26_t3865694581_RuntimeObject_RuntimeObject_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, RuntimeObject * p2, RuntimeObject * p3, bool* p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (int32_t*)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (bool*)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_Int32U26_t3865694581_RuntimeObject_Int32U26_t3865694581_SByte_t1526744772_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, RuntimeObject * p2, int32_t* p3, int8_t p4, Exception_t2443218823 ** p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (int32_t*)args[0], (RuntimeObject *)args[1], (int32_t*)args[2], *((int8_t*)args[3]), (Exception_t2443218823 **)args[4], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32U26_t3865694581_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (int32_t*)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int16_t674212087_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int16_t p1, int8_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int32U26_t3865694581_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int8_t p4, int32_t* p5, Exception_t2443218823 ** p6, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int8_t*)args[3]), (int32_t*)args[4], (Exception_t2443218823 **)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int32_t* p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (int32_t*)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772_Int64U26_t4087886318_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int8_t p2, int64_t* p3, Exception_t2443218823 ** p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (int64_t*)args[2], (Exception_t2443218823 **)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int64U26_t4087886318_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int8_t p4, int64_t* p5, Exception_t2443218823 ** p6, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int8_t*)args[3]), (int64_t*)args[4], (Exception_t2443218823 **)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int64U26_t4087886318 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int64_t* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int64_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_Int64U26_t4087886318 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int64_t* p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (int64_t*)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772_UInt32U26_t95126587_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int8_t p2, uint32_t* p3, Exception_t2443218823 ** p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (uint32_t*)args[2], (Exception_t2443218823 **)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_UInt32U26_t95126587_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int8_t p4, uint32_t* p5, Exception_t2443218823 ** p6, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int8_t*)args[3]), (uint32_t*)args[4], (Exception_t2443218823 **)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_UInt32U26_t95126587 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, uint32_t* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (uint32_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_UInt32U26_t95126587 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, uint32_t* p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (uint32_t*)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_UInt64U26_t2262658145_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int8_t p4, uint64_t* p5, Exception_t2443218823 ** p6, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int8_t*)args[3]), (uint64_t*)args[4], (Exception_t2443218823 **)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_UInt64U26_t2262658145 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, uint64_t* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (uint64_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Byte_t1695016127_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Byte_t1695016127_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_ByteU26_t3759632281 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, uint8_t* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (uint8_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_ByteU26_t3759632281 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, uint8_t* p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (uint8_t*)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772_SByteU26_t78712284_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int8_t p2, int8_t* p3, Exception_t2443218823 ** p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (int8_t*)args[2], (Exception_t2443218823 **)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByteU26_t78712284 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int8_t* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int8_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772_Int16U26_t2810341409_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int8_t p2, int16_t* p3, Exception_t2443218823 ** p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (int16_t*)args[2], (Exception_t2443218823 **)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int16U26_t2810341409 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int16_t* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int16_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_UInt16U26_t1481886716 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, uint16_t* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (uint16_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_UInt16U26_t1481886716 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, uint16_t* p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (uint16_t*)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_ByteU2AU26_t1130943835_ByteU2AU26_t1130943835_DoubleU2AU26_t4269392971_UInt16U2AU26_t2372128692_UInt16U2AU26_t2372128692_UInt16U2AU26_t2372128692_UInt16U2AU26_t2372128692 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t** p1, uint8_t** p2, double** p3, uint16_t** p4, uint16_t** p5, uint16_t** p6, uint16_t** p7, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (uint8_t**)args[0], (uint8_t**)args[1], (double**)args[2], (uint16_t**)args[3], (uint16_t**)args[4], (uint16_t**)args[5], (uint16_t**)args[6], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_UnicodeCategory_t47276028_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Char_t4217985068_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	Il2CppChar ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Char_t4217985068_Int16_t674212087_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, int16_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	Il2CppChar ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int16_t674212087_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Char_t4217985068_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	Il2CppChar ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RuntimeObject * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, int32_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_SByte_t1526744772_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int32_t p4, int32_t p5, int8_t p6, RuntimeObject * p7, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), (RuntimeObject *)args[6], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, int32_t p6, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Int16_t674212087_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, int32_t p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Int16_t674212087_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, int16_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int16_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int16_t674212087_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int16_t p1, int16_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32U26_t3865694581_Int32U26_t3865694581_Int32U26_t3865694581_BooleanU26_t2626765736_StringU26_t3235211963 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, int32_t* p3, int32_t* p4, bool* p5, String_t** p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], (int32_t*)args[2], (int32_t*)args[3], (bool*)args[4], (String_t**)args[5], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int16_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int16_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int16_t674212087_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int16_t p1, int32_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, float p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, float p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, double p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, double p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_DoubleU26_t4267954921_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int8_t p4, double* p5, Exception_t2443218823 ** p6, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int8_t*)args[3]), (double*)args[4], (Exception_t2443218823 **)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_DoubleU26_t4267954921 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, double* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (double*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int8_t p4, int8_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, double p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Decimal_t2382302464_Decimal_t2382302464_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, Decimal_t2382302464  p1, Decimal_t2382302464  p2, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), *((Decimal_t2382302464 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Decimal_t2382302464_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Decimal_t2382302464  p1, Decimal_t2382302464  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), *((Decimal_t2382302464 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Decimal_t2382302464_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Decimal_t2382302464_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t2382302464  p1, Decimal_t2382302464  p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), *((Decimal_t2382302464 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Decimal_t2382302464_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_Int32U26_t3865694581_BooleanU26_t2626765736_BooleanU26_t2626765736_Int32U26_t3865694581_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int32_t* p4, bool* p5, bool* p6, int32_t* p7, int8_t p8, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (int32_t*)args[3], (bool*)args[4], (bool*)args[5], (int32_t*)args[6], *((int8_t*)args[7]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Decimal_t2382302464_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_DecimalU26_t72776448_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, Decimal_t2382302464 * p4, int8_t p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (Decimal_t2382302464 *)args[3], *((int8_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_UInt64U26_t2262658145 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t2382302464 * p1, uint64_t* p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (Decimal_t2382302464 *)args[0], (uint64_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_Int64U26_t4087886318 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t2382302464 * p1, int64_t* p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (Decimal_t2382302464 *)args[0], (int64_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_DecimalU26_t72776448 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t2382302464 * p1, Decimal_t2382302464 * p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (Decimal_t2382302464 *)args[0], (Decimal_t2382302464 *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t2382302464 * p1, RuntimeObject * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (Decimal_t2382302464 *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t2382302464 * p1, int32_t p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (Decimal_t2382302464 *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_DecimalU26_t72776448 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Decimal_t2382302464 * p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, (Decimal_t2382302464 *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_DecimalU26_t72776448_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Decimal_t2382302464 * p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (Decimal_t2382302464 *)args[0], *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_DecimalU26_t72776448_DecimalU26_t72776448 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t2382302464 * p1, Decimal_t2382302464 * p2, Decimal_t2382302464 * p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (Decimal_t2382302464 *)args[0], (Decimal_t2382302464 *)args[1], (Decimal_t2382302464 *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Byte_t1695016127_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Decimal_t2382302464_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Decimal_t2382302464_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Decimal_t2382302464_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Decimal_t2382302464_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Decimal_t2382302464_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, float p1, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Decimal_t2382302464_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, double p1, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_StreamingContext_t885793295 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, StreamingContext_t885793295  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((StreamingContext_t885793295 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_IntPtr_t_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, IntPtr_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((IntPtr_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_IntPtr_t_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	IntPtr_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_IntPtr_t_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	IntPtr_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_IntPtr_t_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	IntPtr_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, IntPtr_t p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_UInt32_t1752406861 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, IntPtr_t p1, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, IntPtr_t p1, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UIntPtr_t_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef UIntPtr_t  (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	UIntPtr_t  ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UIntPtr_t_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef UIntPtr_t  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	UIntPtr_t  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UIntPtr_t_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef UIntPtr_t  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	UIntPtr_t  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_MulticastDelegateU26_t985825394 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, MulticastDelegate_t608486974 ** p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (MulticastDelegate_t608486974 **)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int8_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int8_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, int8_t p5, int8_t p6, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int8_t p4, int8_t p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int8_t*)args[3]), *((int8_t*)args[4]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_TypeCode_t842513060 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int8_t p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int8_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int8_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int16_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int16_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int64_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int64_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int64_t3733094498_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int64_t3733094498_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int64_t p1, int64_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int64_t3733094498_Int64_t3733094498_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int64_t p1, int64_t p2, int64_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), *((int64_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int64_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int64_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int64_t p2, int64_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int64_t*)args[1]), *((int64_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498_Int64_t3733094498_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int64_t p2, int64_t p3, int64_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int64_t*)args[1]), *((int64_t*)args[2]), *((int64_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, RuntimeObject * p5, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], (RuntimeObject *)args[4], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498_RuntimeObject_Int64_t3733094498_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int64_t p2, RuntimeObject * p3, int64_t p4, int64_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int64_t*)args[1]), (RuntimeObject *)args[2], *((int64_t*)args[3]), *((int64_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int64_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int64_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, RuntimeObject * p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (RuntimeObject *)args[4], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, IntPtr_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((IntPtr_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, int32_t p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_TypeAttributes_t1669384266 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_MemberTypes_t1145889401 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeTypeHandle_t1361003276 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeTypeHandle_t1361003276  (*Func)(void* obj, const RuntimeMethod* method);
	RuntimeTypeHandle_t1361003276  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int8_t p2, int8_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_TypeCode_t842513060_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeTypeHandle_t1361003276 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeTypeHandle_t1361003276  p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((RuntimeTypeHandle_t1361003276 *)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeTypeHandle_t1361003276_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeTypeHandle_t1361003276  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	RuntimeTypeHandle_t1361003276  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, RuntimeObject * p4, RuntimeObject * p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int32_t p4, RuntimeObject * p5, RuntimeObject * p6, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int32_t*)args[3]), (RuntimeObject *)args[4], (RuntimeObject *)args[5], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, RuntimeObject * p2, int32_t p3, RuntimeObject * p4, RuntimeObject * p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), (RuntimeObject *)args[3], (RuntimeObject *)args[4], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, RuntimeObject * p7, RuntimeObject * p8, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], (RuntimeObject *)args[6], (RuntimeObject *)args[7], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int8_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, const RuntimeMethod* method);
	IntPtr_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int8_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeFieldHandle_t2492430303 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeFieldHandle_t2492430303  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((RuntimeFieldHandle_t2492430303 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_IntPtr_t_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int8_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_ContractionU5BU5DU26_t4268913570_Level2MapU5BU5DU26_t1141995020 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, ContractionU5BU5D_t572014478** p3, Level2MapU5BU5D_t3298050836** p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (ContractionU5BU5D_t572014478**)args[2], (Level2MapU5BU5D_t3298050836**)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_CodePointIndexerU26_t3199325781_ByteU2AU26_t1130943835_ByteU2AU26_t1130943835_CodePointIndexerU26_t3199325781_ByteU2AU26_t1130943835 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, CodePointIndexer_t1787520931 ** p2, uint8_t** p3, uint8_t** p4, CodePointIndexer_t1787520931 ** p5, uint8_t** p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (CodePointIndexer_t1787520931 **)args[1], (uint8_t**)args[2], (uint8_t**)args[3], (CodePointIndexer_t1787520931 **)args[4], (uint8_t**)args[5], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Byte_t1695016127_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int8_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Byte_t1695016127_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int32_t p1, int32_t p2, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int32_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int32_t p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ExtenderType_t2570490418_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, RuntimeObject * p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_BooleanU26_t2626765736_BooleanU26_t2626765736_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, int32_t p6, bool* p7, bool* p8, int8_t p9, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), (bool*)args[6], (bool*)args[7], *((int8_t*)args[8]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, int32_t p6, int32_t p7, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, int32_t p6, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_BooleanU26_t2626765736_BooleanU26_t2626765736_SByte_t1526744772_SByte_t1526744772_ContextU26_t3128925157 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, int32_t p6, bool* p7, bool* p8, int8_t p9, int8_t p10, Context_t1711146899 * p11, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), (bool*)args[6], (bool*)args[7], *((int8_t*)args[8]), *((int8_t*)args[9]), (Context_t1711146899 *)args[10], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int8_t p1, int8_t p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_ContextU26_t3128925157 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, int8_t p5, Context_t1711146899 * p6, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int8_t*)args[4]), (Context_t1711146899 *)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, bool* p5, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (bool*)args[4], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int16_t674212087_Int32_t438220675_SByte_t1526744772_ContextU26_t3128925157 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int16_t p5, int32_t p6, int8_t p7, Context_t1711146899 * p8, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int16_t*)args[4]), *((int32_t*)args[5]), *((int8_t*)args[6]), (Context_t1711146899 *)args[7], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_ContextU26_t3128925157 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, RuntimeObject * p5, Context_t1711146899 * p6, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (RuntimeObject *)args[4], (Context_t1711146899 *)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_SByte_t1526744772_ContextU26_t3128925157 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, RuntimeObject * p5, int32_t p6, int8_t p7, Context_t1711146899 * p8, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), (RuntimeObject *)args[4], *((int32_t*)args[5]), *((int8_t*)args[6]), (Context_t1711146899 *)args[7], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_ContextU26_t3128925157 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, int32_t p3, int32_t p4, RuntimeObject * p5, int8_t p6, Context_t1711146899 * p7, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (RuntimeObject *)args[4], *((int8_t*)args[5]), (Context_t1711146899 *)args[6], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int32_t438220675_ContractionU26_t3984666465_ContextU26_t3128925157 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, int32_t p3, int32_t p4, RuntimeObject * p5, int8_t p6, int32_t p7, Contraction_t3155759031 ** p8, Context_t1711146899 * p9, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (RuntimeObject *)args[4], *((int8_t*)args[5]), *((int32_t*)args[6]), (Contraction_t3155759031 **)args[7], (Context_t1711146899 *)args[8], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, RuntimeObject * p2, int32_t p3, int32_t p4, RuntimeObject * p5, int32_t p6, int8_t p7, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (RuntimeObject *)args[4], *((int32_t*)args[5]), *((int8_t*)args[6]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_ContextU26_t3128925157 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, int32_t p3, int32_t p4, int32_t p5, RuntimeObject * p6, int8_t p7, Context_t1711146899 * p8, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (RuntimeObject *)args[5], *((int8_t*)args[6]), (Context_t1711146899 *)args[7], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int32_t438220675_ContractionU26_t3984666465_ContextU26_t3128925157 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, int32_t p3, int32_t p4, int32_t p5, RuntimeObject * p6, int8_t p7, int32_t p8, Contraction_t3155759031 ** p9, Context_t1711146899 * p10, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (RuntimeObject *)args[5], *((int8_t*)args[6]), *((int32_t*)args[7]), (Contraction_t3155759031 **)args[8], (Context_t1711146899 *)args[9], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, int8_t p7, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], *((int8_t*)args[6]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RuntimeObject * p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, int32_t p8, int32_t p9, int32_t p10, int32_t p11, int32_t p12, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), *((int32_t*)args[7]), *((int32_t*)args[8]), *((int32_t*)args[9]), *((int32_t*)args[10]), *((int32_t*)args[11]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, RuntimeObject * p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int8_t p3, int8_t p4, int8_t p5, int8_t p6, int8_t p7, int8_t p8, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), *((int8_t*)args[7]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int8_t p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_ByteU5BU5DU26_t1884214154_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, ByteU5BU5D_t3003616614** p2, int32_t* p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), (ByteU5BU5D_t3003616614**)args[1], (int32_t*)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int8_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ConfidenceFactor_t1730967935 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int8_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Sign_t170185131_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, int32_t p6, RuntimeObject * p7, int32_t p8, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), (RuntimeObject *)args[6], *((int32_t*)args[7]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, int32_t p6, RuntimeObject * p7, int32_t p8, int32_t p9, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), (RuntimeObject *)args[6], *((int32_t*)args[7]), *((int32_t*)args[8]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_DSAParameters_t4013484323_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DSAParameters_t4013484323  (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	DSAParameters_t4013484323  ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_DSAParameters_t4013484323 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, DSAParameters_t4013484323  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((DSAParameters_t4013484323 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, int8_t p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], *((int8_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_DSAParameters_t4013484323 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, DSAParameters_t4013484323  p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((DSAParameters_t4013484323 *)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RSAParameters_t3314567386_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RSAParameters_t3314567386  (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	RSAParameters_t3314567386  ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RSAParameters_t3314567386 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RSAParameters_t3314567386  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((RSAParameters_t3314567386 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int8_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_DSAParameters_t4013484323_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DSAParameters_t4013484323  (*Func)(void* obj, bool* p1, const RuntimeMethod* method);
	DSAParameters_t4013484323  ret = ((Func)methodPointer)(obj, (bool*)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int8_t p2, RuntimeObject * p3, int8_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (RuntimeObject *)args[2], *((int8_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Byte_t1695016127 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32U26_t3865694581_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32U26_t3865694581_ByteU26_t3759632281_Int32U26_t3865694581_ByteU5BU5DU26_t1884214154 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, uint8_t* p3, int32_t* p4, ByteU5BU5D_t3003616614** p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], (uint8_t*)args[2], (int32_t*)args[3], (ByteU5BU5D_t3003616614**)args[4], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, int8_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Int16_t674212087_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Int16_t674212087_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int16_t p1, int8_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Single_t3678960876_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, float p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((float*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, float p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((float*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Single_t3678960876_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, float p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((float*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Single_t3678960876_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, float p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((float*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_DictionaryEntry_t578375704 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DictionaryEntry_t578375704  (*Func)(void* obj, const RuntimeMethod* method);
	DictionaryEntry_t578375704  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675_SByte_t1526744772_MethodBaseU26_t1836863182_Int32U26_t3865694581_Int32U26_t3865694581_StringU26_t3235211963_Int32U26_t3865694581_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int8_t p2, MethodBase_t2010470530 ** p3, int32_t* p4, int32_t* p5, String_t** p6, int32_t* p7, int32_t* p8, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), (MethodBase_t2010470530 **)args[2], (int32_t*)args[3], (int32_t*)args[4], (String_t**)args[5], (int32_t*)args[6], (int32_t*)args[7], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int8_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int8_t p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int8_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Int32_t438220675_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DateTime_t3836236387  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DayOfWeek_t1380878247_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DateTime_t3836236387  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t* p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DayOfWeek_t1380878247_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32U26_t3865694581_Int32U26_t3865694581_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t* p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (int32_t*)args[0], (int32_t*)args[1], *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32U26_t3865694581_Int32U26_t3865694581_Int32U26_t3865694581_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t* p2, int32_t* p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (int32_t*)args[0], (int32_t*)args[1], (int32_t*)args[2], *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, int8_t p6, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), *((int8_t*)args[5]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int8_t p2, int8_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int8_t p2, int8_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_DateTime_t3836236387_DateTime_t3836236387_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, DateTime_t3836236387  p1, DateTime_t3836236387  p2, TimeSpan_t4182925364  p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), *((DateTime_t3836236387 *)args[1]), *((TimeSpan_t4182925364 *)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TimeSpan_t4182925364  (*Func)(void* obj, const RuntimeMethod* method);
	TimeSpan_t4182925364  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t* p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (int32_t*)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Char_t4217985068 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, const RuntimeMethod* method);
	Il2CppChar ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Decimal_t2382302464  (*Func)(void* obj, const RuntimeMethod* method);
	Decimal_t2382302464  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_IntPtr_t_Int32_t438220675_SByte_t1526744772_Int32_t438220675_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t p2, int8_t p3, int32_t p4, int8_t p5, int8_t p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), *((int32_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, int8_t p7, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, int32_t p7, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int32_t*)args[6]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, RuntimeObject * p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], (RuntimeObject *)args[4], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Int64_t3733094498_Int64_t3733094498_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int64_t p1, int32_t p2, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_IntPtr_t_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, RuntimeObject * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int8_t p4, int8_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int32_t p4, int32_t* p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (int32_t*)args[4], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t* p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (int32_t*)args[0], methodMetadata);
	return ret;
}

void* RuntimeInvoker_FileAttributes_t4239897840_RuntimeObject_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_MonoFileType_t2806097864_IntPtr_t_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, int32_t* p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (int32_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_MonoIOStatU26_t2472808464_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, MonoIOStat_t2386973040 * p2, int32_t* p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (MonoIOStat_t2386973040 *)args[1], (int32_t*)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_IntPtr_t_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int32_t* p6, const RuntimeMethod* method);
	IntPtr_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (int32_t*)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_IntPtr_t_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, int32_t* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (int32_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_IntPtr_t_RuntimeObject_Int32_t438220675_Int32_t438220675_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, RuntimeObject * p2, int32_t p3, int32_t p4, int32_t* p5, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (int32_t*)args[4], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_IntPtr_t_Int64_t3733094498_Int32_t438220675_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, IntPtr_t p1, int64_t p2, int32_t p3, int32_t* p4, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int64_t*)args[1]), *((int32_t*)args[2]), (int32_t*)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_IntPtr_t_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, IntPtr_t p1, int32_t* p2, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (int32_t*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_IntPtr_t_Int64_t3733094498_MonoIOErrorU26_t58253910 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, int64_t p2, int32_t* p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int64_t*)args[1]), (int32_t*)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_StringU26_t3235211963 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, String_t** p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (String_t**)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_SByte_t1526744772_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_CallingConventions_t369066136 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeMethodHandle_t4063774698 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeMethodHandle_t4063774698  (*Func)(void* obj, const RuntimeMethod* method);
	RuntimeMethodHandle_t4063774698  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_MethodAttributes_t1488178787 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_MethodToken_t1418749877 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef MethodToken_t1418749877  (*Func)(void* obj, const RuntimeMethod* method);
	MethodToken_t1418749877  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_FieldAttributes_t1558435749 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeFieldHandle_t2492430303 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeFieldHandle_t2492430303  (*Func)(void* obj, const RuntimeMethod* method);
	RuntimeFieldHandle_t2492430303  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, RuntimeObject * p4, RuntimeObject * p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), (RuntimeObject *)args[3], (RuntimeObject *)args[4], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_OpCode_t1117422012 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, OpCode_t1117422012  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((OpCode_t1117422012 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_OpCode_t1117422012_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, OpCode_t1117422012  p1, RuntimeObject * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((OpCode_t1117422012 *)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_StackBehaviour_t2397757739 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, int32_t p2, RuntimeObject * p3, RuntimeObject * p4, RuntimeObject * p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_SByte_t1526744772_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int8_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_IntPtr_t_RuntimeObject_Int32U26_t3865694581_ModuleU26_t2021568637 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, Module_t3479515451 ** p3, const RuntimeMethod* method);
	IntPtr_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], (Module_t3479515451 **)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, int8_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_AssemblyNameFlags_t1966831008 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_ObjectU5BU5DU26_t1191207502_RuntimeObject_RuntimeObject_RuntimeObject_ObjectU26_t1561828645 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, RuntimeObject * p2, ObjectU5BU5D_t42211586** p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, RuntimeObject ** p7, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], (ObjectU5BU5D_t42211586**)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], (RuntimeObject **)args[6], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_ObjectU5BU5DU26_t1191207502_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ObjectU5BU5D_t42211586** p1, RuntimeObject * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (ObjectU5BU5D_t42211586**)args[0], (RuntimeObject *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, RuntimeObject * p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_ObjectU5BU5DU26_t1191207502_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, ObjectU5BU5D_t42211586** p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (ObjectU5BU5D_t42211586**)args[1], (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, int8_t p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], *((int8_t*)args[4]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_EventAttributes_t1919574847 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_IntPtr_t_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, IntPtr_t p1, IntPtr_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((IntPtr_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeFieldHandle_t2492430303 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeFieldHandle_t2492430303  p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((RuntimeFieldHandle_t2492430303 *)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, int32_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], *((int32_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, int32_t p5, RuntimeObject * p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], *((int32_t*)args[4]), (RuntimeObject *)args[5], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_StreamingContext_t885793295 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, StreamingContext_t885793295  p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((StreamingContext_t885793295 *)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeMethodHandle_t4063774698 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeMethodHandle_t4063774698  p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((RuntimeMethodHandle_t4063774698 *)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_MonoEventInfoU26_t2960910389 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, MonoEventInfo_t2799518403 * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (MonoEventInfo_t2799518403 *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_MonoEventInfo_t2799518403_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef MonoEventInfo_t2799518403  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	MonoEventInfo_t2799518403  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_IntPtr_t_MonoMethodInfoU26_t828076379 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, MonoMethodInfo_t2273945901 * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (MonoMethodInfo_t2273945901 *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_MonoMethodInfo_t2273945901_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef MonoMethodInfo_t2273945901  (*Func)(void* obj, IntPtr_t p1, const RuntimeMethod* method);
	MonoMethodInfo_t2273945901  ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_MethodAttributes_t1488178787_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_CallingConventions_t369066136_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_IntPtr_t_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, IntPtr_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, Exception_t2443218823 ** p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (Exception_t2443218823 **)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_MonoPropertyInfoU26_t494941656_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, MonoPropertyInfo_t301114984 * p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (MonoPropertyInfo_t301114984 *)args[1], *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_PropertyAttributes_t974795916 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_ParameterAttributes_t2464461462 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int64_t3733094498_ResourceInfoU26_t2935277467 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, ResourceInfo_t1067968749 * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int64_t*)args[0]), (ResourceInfo_t1067968749 *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int64_t p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int64_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_GCHandle_t2291726809_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef GCHandle_t2291726809  (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	GCHandle_t2291726809  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_IntPtr_t_Int32_t438220675_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t p2, RuntimeObject * p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_IntPtr_t_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, RuntimeObject * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Byte_t1695016127_IntPtr_t_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, IntPtr_t p1, int32_t p2, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_IntPtr_t_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t p2, int8_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, bool* p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (bool*)args[0], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_StringU26_t3235211963 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, String_t** p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (String_t**)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_StringU26_t3235211963 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, String_t** p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (String_t**)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_RuntimeObject_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, RuntimeObject * p2, int8_t p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), (RuntimeObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, TimeSpan_t4182925364  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((TimeSpan_t4182925364 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Byte_t1695016127 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, uint8_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((uint8_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_SByte_t1526744772_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_StreamingContext_t885793295_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, StreamingContext_t885793295  p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((StreamingContext_t885793295 *)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_StreamingContext_t885793295_ISurrogateSelectorU26_t1457704766 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, StreamingContext_t885793295  p2, RuntimeObject** p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((StreamingContext_t885793295 *)args[1]), (RuntimeObject**)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_IntPtr_t_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, IntPtr_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((IntPtr_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_TimeSpan_t4182925364_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TimeSpan_t4182925364  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	TimeSpan_t4182925364  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_StringU26_t3235211963 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, String_t** p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (String_t**)args[0], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_ObjectU26_t1561828645 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject ** p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject **)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_StringU26_t3235211963_StringU26_t3235211963 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, String_t** p2, String_t** p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (String_t**)args[1], (String_t**)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_WellKnownObjectMode_t653959841 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_StreamingContext_t885793295 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef StreamingContext_t885793295  (*Func)(void* obj, const RuntimeMethod* method);
	StreamingContext_t885793295  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TypeFilterLevel_t1430716943 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, bool* p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (bool*)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, uint8_t p1, RuntimeObject * p2, int8_t p3, RuntimeObject * p4, RuntimeObject * p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((uint8_t*)args[0]), (RuntimeObject *)args[1], *((int8_t*)args[2]), (RuntimeObject *)args[3], (RuntimeObject *)args[4], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, uint8_t p1, RuntimeObject * p2, int8_t p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((uint8_t*)args[0]), (RuntimeObject *)args[1], *((int8_t*)args[2]), (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_ObjectU26_t1561828645_HeaderU5BU5DU26_t931609082 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int8_t p2, RuntimeObject ** p3, HeaderU5BU5D_t4052410742** p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (RuntimeObject **)args[2], (HeaderU5BU5D_t4052410742**)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Byte_t1695016127_RuntimeObject_SByte_t1526744772_ObjectU26_t1561828645_HeaderU5BU5DU26_t931609082 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, RuntimeObject * p2, int8_t p3, RuntimeObject ** p4, HeaderU5BU5D_t4052410742** p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((uint8_t*)args[0]), (RuntimeObject *)args[1], *((int8_t*)args[2]), (RuntimeObject **)args[3], (HeaderU5BU5D_t4052410742**)args[4], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_Byte_t1695016127_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, uint8_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((uint8_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Byte_t1695016127_RuntimeObject_Int64U26_t4087886318_ObjectU26_t1561828645_SerializationInfoU26_t1740520373 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, RuntimeObject * p2, int64_t* p3, RuntimeObject ** p4, SerializationInfo_t623100739 ** p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((uint8_t*)args[0]), (RuntimeObject *)args[1], (int64_t*)args[2], (RuntimeObject **)args[3], (SerializationInfo_t623100739 **)args[4], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_SByte_t1526744772_Int64U26_t4087886318_ObjectU26_t1561828645_SerializationInfoU26_t1740520373 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int8_t p2, int8_t p3, int64_t* p4, RuntimeObject ** p5, SerializationInfo_t623100739 ** p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), *((int8_t*)args[2]), (int64_t*)args[3], (RuntimeObject **)args[4], (SerializationInfo_t623100739 **)args[5], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64U26_t4087886318_ObjectU26_t1561828645_SerializationInfoU26_t1740520373 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int64_t* p2, RuntimeObject ** p3, SerializationInfo_t623100739 ** p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int64_t*)args[1], (RuntimeObject **)args[2], (SerializationInfo_t623100739 **)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int64_t3733094498_ObjectU26_t1561828645_SerializationInfoU26_t1740520373 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int64_t p3, RuntimeObject ** p4, SerializationInfo_t623100739 ** p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int64_t*)args[2]), (RuntimeObject **)args[3], (SerializationInfo_t623100739 **)args[4], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int64_t3733094498_RuntimeObject_RuntimeObject_Int64_t3733094498_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, RuntimeObject * p2, RuntimeObject * p3, int64_t p4, RuntimeObject * p5, RuntimeObject * p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int64_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int64_t*)args[3]), (RuntimeObject *)args[4], (RuntimeObject *)args[5], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64U26_t4087886318_ObjectU26_t1561828645 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int64_t* p2, RuntimeObject ** p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int64_t*)args[1], (RuntimeObject **)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int64U26_t4087886318_ObjectU26_t1561828645 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int64_t* p3, RuntimeObject ** p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (int64_t*)args[2], (RuntimeObject **)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int64_t3733094498_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int64_t p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, RuntimeObject * p7, RuntimeObject * p8, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int64_t*)args[2]), (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], (RuntimeObject *)args[6], (RuntimeObject *)args[7], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, RuntimeObject * p7, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], (RuntimeObject *)args[6], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int64_t3733094498_Int64_t3733094498_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, int64_t p2, RuntimeObject * p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, RuntimeObject * p7, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], (RuntimeObject *)args[6], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Int64_t3733094498_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int64_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Byte_t1695016127 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, uint8_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((uint8_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_Int64_t3733094498_Int32_t438220675_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, int32_t p2, int64_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int32_t*)args[1]), *((int64_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int64_t3733094498_RuntimeObject_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, RuntimeObject * p2, int64_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int64_t*)args[0]), (RuntimeObject *)args[1], *((int64_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498_RuntimeObject_Int64_t3733094498_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int64_t p2, RuntimeObject * p3, int64_t p4, RuntimeObject * p5, RuntimeObject * p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int64_t*)args[1]), (RuntimeObject *)args[2], *((int64_t*)args[3]), (RuntimeObject *)args[4], (RuntimeObject *)args[5], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_SByte_t1526744772_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int8_t p1, RuntimeObject * p2, int8_t p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), (RuntimeObject *)args[1], *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_StreamingContext_t885793295 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, StreamingContext_t885793295  p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((StreamingContext_t885793295 *)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_StreamingContext_t885793295 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, StreamingContext_t885793295  p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((StreamingContext_t885793295 *)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_StreamingContext_t885793295 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, StreamingContext_t885793295  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((StreamingContext_t885793295 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_StreamingContext_t885793295_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, StreamingContext_t885793295  p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((StreamingContext_t885793295 *)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int16_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int16_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, DateTime_t3836236387  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((DateTime_t3836236387 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, float p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((float*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_SerializationEntry_t2018126969 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef SerializationEntry_t2018126969  (*Func)(void* obj, const RuntimeMethod* method);
	SerializationEntry_t2018126969  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_StreamingContextStates_t317203920 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_CspProviderFlags_t613247746 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int8_t p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_UInt32_t1752406861_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int32_t p1, int32_t p2, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int64_t3733094498_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, RuntimeObject * p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int64_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_UInt32_t1752406861_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_UInt32U26_t95126587_Int32_t438220675_UInt32U26_t95126587_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint32_t* p1, int32_t p2, uint32_t* p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (uint32_t*)args[0], *((int32_t*)args[1]), (uint32_t*)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_IntPtr_t_IntPtr_t_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, IntPtr_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	IntPtr_t ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int64_t3733094498_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, int64_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_UInt64_t1261996727_Int64_t3733094498_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int64_t p1, int32_t p2, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_Int64_t3733094498_Int64_t3733094498_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int64_t p1, int64_t p2, int64_t p3, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), *((int64_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_CipherMode_t1510653764 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PaddingMode_t927572615 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_StringBuilderU26_t1573624750_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, StringBuilder_t718897314 ** p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (StringBuilder_t718897314 **)args[0], *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_IntPtr_t_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, IntPtr_t p1, int32_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_EncoderFallbackBufferU26_t2317053607_CharU5BU5DU26_t228440995 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, EncoderFallbackBuffer_t1850839809 ** p6, CharU5BU5D_t2816624037** p7, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), (EncoderFallbackBuffer_t1850839809 **)args[5], (CharU5BU5D_t2816624037**)args[6], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_DecoderFallbackBufferU26_t2638252675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, DecoderFallbackBuffer_t3917683653 ** p6, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), (DecoderFallbackBuffer_t3917683653 **)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int32_t p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int16_t674212087_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int16_t p1, int32_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int16_t674212087_Int16_t674212087_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int16_t p1, int16_t p2, int32_t p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int16_t674212087_Int16_t674212087_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, int16_t p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t* p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (int32_t*)args[0], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, RuntimeObject * p2, int32_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int8_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_Int32_t438220675_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int8_t p4, int32_t p5, int8_t p6, int8_t p7, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_SByte_t1526744772_Int32U26_t3865694581_BooleanU26_t2626765736_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, int8_t p6, int32_t* p7, bool* p8, int8_t p9, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), *((int8_t*)args[5]), (int32_t*)args[6], (bool*)args[7], *((int8_t*)args[8]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, int32_t* p6, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), (int32_t*)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_CharU26_t1135874228_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, Il2CppChar* p4, int8_t p5, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppChar*)args[3], *((int8_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_CharU26_t1135874228_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, Il2CppChar* p3, int8_t p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (Il2CppChar*)args[2], *((int8_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_CharU26_t1135874228_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, Il2CppChar* p6, int8_t p7, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), (Il2CppChar*)args[5], *((int8_t*)args[6]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_CharU26_t1135874228_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int32_t p4, Il2CppChar* p5, int8_t p6, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int32_t*)args[3]), (Il2CppChar*)args[4], *((int8_t*)args[5]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, RuntimeObject * p6, DecoderFallbackBuffer_t3917683653 ** p7, ByteU5BU5D_t3003616614** p8, int8_t p9, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (RuntimeObject *)args[5], (DecoderFallbackBuffer_t3917683653 **)args[6], (ByteU5BU5D_t3003616614**)args[7], *((int8_t*)args[8]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, RuntimeObject * p5, DecoderFallbackBuffer_t3917683653 ** p6, ByteU5BU5D_t3003616614** p7, int8_t p8, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), (RuntimeObject *)args[4], (DecoderFallbackBuffer_t3917683653 **)args[5], (ByteU5BU5D_t3003616614**)args[6], *((int8_t*)args[7]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_RuntimeObject_Int64_t3733094498_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, DecoderFallbackBuffer_t3917683653 ** p2, ByteU5BU5D_t3003616614** p3, RuntimeObject * p4, int64_t p5, int32_t p6, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (DecoderFallbackBuffer_t3917683653 **)args[1], (ByteU5BU5D_t3003616614**)args[2], (RuntimeObject *)args[3], *((int64_t*)args[4]), *((int32_t*)args[5]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_RuntimeObject_Int64_t3733094498_Int32_t438220675_RuntimeObject_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, DecoderFallbackBuffer_t3917683653 ** p2, ByteU5BU5D_t3003616614** p3, RuntimeObject * p4, int64_t p5, int32_t p6, RuntimeObject * p7, int32_t* p8, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (DecoderFallbackBuffer_t3917683653 **)args[1], (ByteU5BU5D_t3003616614**)args[2], (RuntimeObject *)args[3], *((int64_t*)args[4]), *((int32_t*)args[5]), (RuntimeObject *)args[6], (int32_t*)args[7], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_UInt32U26_t95126587_UInt32U26_t95126587_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t p5, uint32_t* p6, uint32_t* p7, RuntimeObject * p8, DecoderFallbackBuffer_t3917683653 ** p9, ByteU5BU5D_t3003616614** p10, int8_t p11, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int32_t*)args[4]), (uint32_t*)args[5], (uint32_t*)args[6], (RuntimeObject *)args[7], (DecoderFallbackBuffer_t3917683653 **)args[8], (ByteU5BU5D_t3003616614**)args[9], *((int8_t*)args[10]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_UInt32U26_t95126587_UInt32U26_t95126587_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int32_t p4, uint32_t* p5, uint32_t* p6, RuntimeObject * p7, DecoderFallbackBuffer_t3917683653 ** p8, ByteU5BU5D_t3003616614** p9, int8_t p10, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int32_t*)args[3]), (uint32_t*)args[4], (uint32_t*)args[5], (RuntimeObject *)args[6], (DecoderFallbackBuffer_t3917683653 **)args[7], (ByteU5BU5D_t3003616614**)args[8], *((int8_t*)args[9]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Single_t3678960876_SingleU26_t3887057396_Single_t3678960876_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, float* p1, float p2, float p3, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, (float*)args[0], *((float*)args[1]), *((float*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_IntPtr_t_SByte_t1526744772_RuntimeObject_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, int8_t p1, RuntimeObject * p2, bool* p3, const RuntimeMethod* method);
	IntPtr_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), (RuntimeObject *)args[1], (bool*)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_IntPtr_t_SByte_t1526744772_SByte_t1526744772_RuntimeObject_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, int8_t p1, int8_t p2, RuntimeObject * p3, bool* p4, const RuntimeMethod* method);
	IntPtr_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), (RuntimeObject *)args[2], (bool*)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_TimeSpan_t4182925364_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, TimeSpan_t4182925364  p1, TimeSpan_t4182925364  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((TimeSpan_t4182925364 *)args[0]), *((TimeSpan_t4182925364 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int64_t3733094498_Int64_t3733094498_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int64_t p1, int64_t p2, int8_t p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_IntPtr_t_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, int32_t p2, int8_t p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, double p1, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, double p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Int64_t3733094498_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_IntPtr_t_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, IntPtr_t p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Byte_t1695016127_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Byte_t1695016127_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Byte_t1695016127_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, double p1, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Byte_t1695016127_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, float p1, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Byte_t1695016127_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Char_t4217985068_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	Il2CppChar ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Char_t4217985068_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	Il2CppChar ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Char_t4217985068_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, float p1, const RuntimeMethod* method);
	Il2CppChar ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Char_t4217985068_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	Il2CppChar ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, float p1, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, double p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, float p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, double p1, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, float p1, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int16_t674212087_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	int16_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, float p1, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int64_t3733094498_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, double p1, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, float p1, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SByte_t1526744772_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	int8_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, double p1, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, float p1, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, double p1, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, float p1, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt16_t2530548644_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, double p1, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, float p1, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int64_t p1, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int8_t p1, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, double p1, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, float p1, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((float*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, TimeSpan_t4182925364  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), *((TimeSpan_t4182925364 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int64_t3733094498_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_DayOfWeek_t1380878247 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTimeKind_t588365666 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, TimeSpan_t4182925364  p1, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, *((TimeSpan_t4182925364 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, double p1, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_DateTime_t3836236387_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DateTime_t3836236387  p1, DateTime_t3836236387  p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), *((DateTime_t3836236387 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DateTime_t3836236387  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_DateTime_t3836236387_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, DateTime_t3836236387  p1, int32_t p2, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_Int32_t438220675_DateTimeU26_t636467605_DateTimeOffsetU26_t2503273354_SByte_t1526744772_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, DateTime_t3836236387 * p4, DateTimeOffset_t3036919142 * p5, int8_t p6, Exception_t2443218823 ** p7, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), (DateTime_t3836236387 *)args[3], (DateTimeOffset_t3036919142 *)args[4], *((int8_t*)args[5]), (Exception_t2443218823 **)args[6], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int8_t p2, Exception_t2443218823 ** p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (Exception_t2443218823 **)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, int8_t p5, int8_t p6, int32_t* p7, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), (int32_t*)args[6], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_SByte_t1526744772_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, RuntimeObject * p4, int8_t p5, int32_t* p6, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], *((int8_t*)args[4]), (int32_t*)args[5], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int32_t* p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], (int32_t*)args[4], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int32U26_t3865694581_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int8_t p5, int32_t* p6, int32_t* p7, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int8_t*)args[4]), (int32_t*)args[5], (int32_t*)args[6], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, int8_t p4, int32_t* p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], *((int8_t*)args[3]), (int32_t*)args[4], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772_DateTimeU26_t636467605_DateTimeOffsetU26_t2503273354_RuntimeObject_Int32_t438220675_SByte_t1526744772_BooleanU26_t2626765736_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int8_t p4, DateTime_t3836236387 * p5, DateTimeOffset_t3036919142 * p6, RuntimeObject * p7, int32_t p8, int8_t p9, bool* p10, bool* p11, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int8_t*)args[3]), (DateTime_t3836236387 *)args[4], (DateTimeOffset_t3036919142 *)args[5], (RuntimeObject *)args[6], *((int32_t*)args[7]), *((int8_t*)args[8]), (bool*)args[9], (bool*)args[10], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_DateTimeU26_t636467605_SByte_t1526744772_BooleanU26_t2626765736_SByte_t1526744772_ExceptionU26_t832299025 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, DateTime_t3836236387 * p5, int8_t p6, bool* p7, int8_t p8, Exception_t2443218823 ** p9, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), (DateTime_t3836236387 *)args[4], *((int8_t*)args[5]), (bool*)args[6], *((int8_t*)args[7]), (Exception_t2443218823 **)args[8], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_DateTime_t3836236387_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, DateTime_t3836236387  p1, TimeSpan_t4182925364  p2, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), *((TimeSpan_t4182925364 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_DateTime_t3836236387_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DateTime_t3836236387  p1, DateTime_t3836236387  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), *((DateTime_t3836236387 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, DateTime_t3836236387  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_DateTime_t3836236387_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, DateTime_t3836236387  p1, TimeSpan_t4182925364  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), *((TimeSpan_t4182925364 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int64_t3733094498_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, TimeSpan_t4182925364  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int64_t*)args[0]), *((TimeSpan_t4182925364 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_DateTimeOffset_t3036919142 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DateTimeOffset_t3036919142  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((DateTimeOffset_t3036919142 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_DateTimeOffset_t3036919142 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DateTimeOffset_t3036919142  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((DateTimeOffset_t3036919142 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int16_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int16_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Int16_t674212087_RuntimeObject_BooleanU26_t2626765736_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int16_t p1, RuntimeObject * p2, bool* p3, bool* p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), (RuntimeObject *)args[1], (bool*)args[2], (bool*)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int16_t674212087_RuntimeObject_BooleanU26_t2626765736_BooleanU26_t2626765736_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int16_t p1, RuntimeObject * p2, bool* p3, bool* p4, int8_t p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), (RuntimeObject *)args[1], (bool*)args[2], (bool*)args[3], *((int8_t*)args[4]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_DateTime_t3836236387_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, DateTime_t3836236387  p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_DateTime_t3836236387_Nullable_1_t534706120_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, DateTime_t3836236387  p1, Nullable_1_t534706120  p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), *((Nullable_1_t534706120 *)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_MonoEnumInfo_t2659694797 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, MonoEnumInfo_t2659694797  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((MonoEnumInfo_t2659694797 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_MonoEnumInfoU26_t2719236795 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, MonoEnumInfo_t2659694797 * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (MonoEnumInfo_t2659694797 *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_Int16_t674212087_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, int16_t p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Int64_t3733094498_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int64_t p1, int64_t p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PlatformID_t1036322677 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int16_t674212087_Int16_t674212087_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int16_t p2, int16_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int16_t*)args[1]), *((int16_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int16_t674212087_Int16_t674212087_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int16_t p2, int16_t p3, int8_t p4, int8_t p5, int8_t p6, int8_t p7, int8_t p8, int8_t p9, int8_t p10, int8_t p11, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int16_t*)args[1]), *((int16_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), *((int8_t*)args[7]), *((int8_t*)args[8]), *((int8_t*)args[9]), *((int8_t*)args[10]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int32_t438220675_Guid_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Guid_t  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((Guid_t *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Guid_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Guid_t  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Guid_t *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Guid_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Guid_t  (*Func)(void* obj, const RuntimeMethod* method);
	Guid_t  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int8_t p1, int8_t p2, int8_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Boolean_t402932760_Guid_t_Guid_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Guid_t  p1, Guid_t  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Guid_t *)args[0]), *((Guid_t *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt64_t1261996727_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int32_t p1, int8_t p2, const RuntimeMethod* method);
	uint64_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Double_t3420139759_Double_t3420139759_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, double p1, double p2, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, *((double*)args[0]), *((double*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TypeAttributes_t1669384266_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int8_t p1, int8_t p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_UInt64U2AU26_t2381774899_Int32U2AU26_t813507759_CharU2AU26_t1963721052_CharU2AU26_t1963721052_Int64U2AU26_t1594636970_Int32U2AU26_t813507759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint64_t** p1, int32_t** p2, Il2CppChar** p3, Il2CppChar** p4, int64_t** p5, int32_t** p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (uint64_t**)args[0], (int32_t**)args[1], (Il2CppChar**)args[2], (Il2CppChar**)args[3], (int64_t**)args[4], (int32_t**)args[5], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int64_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int64_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Double_t3420139759_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, double p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((double*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, Decimal_t2382302464  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((Decimal_t2382302464 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int8_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int16_t674212087_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int16_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int16_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int64_t3733094498_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int64_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int64_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Single_t3678960876_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, float p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((float*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Double_t3420139759_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, double p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((double*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Decimal_t2382302464_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, Decimal_t2382302464  p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((Decimal_t2382302464 *)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Single_t3678960876_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, float p1, RuntimeObject * p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((float*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Double_t3420139759_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, double p1, RuntimeObject * p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((double*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_BooleanU26_t2626765736_SByte_t1526744772_Int32U26_t3865694581_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, bool* p2, int8_t p3, int32_t* p4, int32_t* p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (bool*)args[1], *((int8_t*)args[2]), (int32_t*)args[3], (int32_t*)args[4], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int8_t p5, RuntimeObject * p6, RuntimeObject * p7, RuntimeObject * p8, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int8_t*)args[4]), (RuntimeObject *)args[5], (RuntimeObject *)args[6], (RuntimeObject *)args[7], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Int64_t3733094498_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	int64_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TimeSpan_t4182925364_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TimeSpan_t4182925364  (*Func)(void* obj, TimeSpan_t4182925364  p1, const RuntimeMethod* method);
	TimeSpan_t4182925364  ret = ((Func)methodPointer)(obj, *((TimeSpan_t4182925364 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_TimeSpan_t4182925364_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, TimeSpan_t4182925364  p1, TimeSpan_t4182925364  p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((TimeSpan_t4182925364 *)args[0]), *((TimeSpan_t4182925364 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, TimeSpan_t4182925364  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((TimeSpan_t4182925364 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, TimeSpan_t4182925364  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((TimeSpan_t4182925364 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TimeSpan_t4182925364_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TimeSpan_t4182925364  (*Func)(void* obj, double p1, const RuntimeMethod* method);
	TimeSpan_t4182925364  ret = ((Func)methodPointer)(obj, *((double*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TimeSpan_t4182925364_Double_t3420139759_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TimeSpan_t4182925364  (*Func)(void* obj, double p1, int64_t p2, const RuntimeMethod* method);
	TimeSpan_t4182925364  ret = ((Func)methodPointer)(obj, *((double*)args[0]), *((int64_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TimeSpan_t4182925364_TimeSpan_t4182925364_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TimeSpan_t4182925364  (*Func)(void* obj, TimeSpan_t4182925364  p1, TimeSpan_t4182925364  p2, const RuntimeMethod* method);
	TimeSpan_t4182925364  ret = ((Func)methodPointer)(obj, *((TimeSpan_t4182925364 *)args[0]), *((TimeSpan_t4182925364 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TimeSpan_t4182925364_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TimeSpan_t4182925364  (*Func)(void* obj, DateTime_t3836236387  p1, const RuntimeMethod* method);
	TimeSpan_t4182925364  ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_DateTime_t3836236387_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DateTime_t3836236387  p1, RuntimeObject * p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DateTime_t3836236387_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DateTime_t3836236387  (*Func)(void* obj, DateTime_t3836236387  p1, const RuntimeMethod* method);
	DateTime_t3836236387  ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TimeSpan_t4182925364_DateTime_t3836236387_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TimeSpan_t4182925364  (*Func)(void* obj, DateTime_t3836236387  p1, TimeSpan_t4182925364  p2, const RuntimeMethod* method);
	TimeSpan_t4182925364  ret = ((Func)methodPointer)(obj, *((DateTime_t3836236387 *)args[0]), *((TimeSpan_t4182925364 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int64U5BU5DU26_t3676363841_StringU5BU5DU26_t3807653280 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, Int64U5BU5D_t110483415** p2, StringU5BU5D_t1828641120** p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (Int64U5BU5D_t110483415**)args[1], (StringU5BU5D_t1828641120**)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_DictionaryNodeU26_t319976545 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, DictionaryNode_t4268507831 ** p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (DictionaryNode_t4268507831 **)args[1], methodMetadata);
	return ret;
}

void* RuntimeInvoker_EditorBrowsableState_t2901581142 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_IPAddressU26_t2963932792 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, IPAddress_t3056411848 ** p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (IPAddress_t3056411848 **)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_AddressFamily_t450096203 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_IPv6AddressU26_t2543423675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, IPv6Address_t2462431949 ** p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (IPv6Address_t2462431949 **)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SecurityProtocolType_t2871506216 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int32_t p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_AsnDecodeStatus_t361668025_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, RuntimeObject * p2, int8_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], *((int8_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_X509ChainStatusFlags_t3387568385_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_X509ChainStatusFlags_t3387568385_RuntimeObject_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int8_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_X509ChainStatusFlags_t3387568385_RuntimeObject_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_X509ChainStatusFlags_t3387568385 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_X509RevocationFlag_t3862259269 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_X509RevocationMode_t1666302436 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_X509VerificationFlags_t2857382038 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_X509KeyUsageFlags_t2405450781 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_X509KeyUsageFlags_t2405450781_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Byte_t1695016127_Int16_t674212087_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int16_t p1, int16_t p2, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, int32_t p8, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), *((int32_t*)args[7]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RegexOptions_t1904484159 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Category_t326181340_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_UInt16_t2530548644_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, uint16_t p1, int16_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((uint16_t*)args[0]), *((int16_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int16_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int16_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int16_t674212087_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, int8_t p2, int8_t p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_UInt16_t2530548644_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint16_t p1, int8_t p2, int8_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((uint16_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int16_t674212087_Int16_t674212087_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, int16_t p2, int8_t p3, int8_t p4, int8_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int16_t674212087_RuntimeObject_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, RuntimeObject * p2, int8_t p3, int8_t p4, int8_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int16_t*)args[0]), (RuntimeObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_UInt16_t2530548644 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint16_t p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((uint16_t*)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_SByte_t1526744772_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int8_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_SByte_t1526744772_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int32_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int32_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_UInt16_t2530548644_UInt16_t2530548644_UInt16_t2530548644 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, uint16_t p1, uint16_t p2, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, *((uint16_t*)args[0]), *((uint16_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_OpFlags_t871130963_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, int8_t p1, int8_t p2, int8_t p3, int8_t p4, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_UInt16_t2530548644_UInt16_t2530548644 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint16_t p1, uint16_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((uint16_t*)args[0]), *((uint16_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int32U26_t3865694581_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int32_t* p2, int32_t p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (int32_t*)args[1], *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int32U26_t3865694581_Int32U26_t3865694581_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int32_t* p2, int32_t* p3, int8_t p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (int32_t*)args[1], (int32_t*)args[2], *((int8_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32U26_t3865694581_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_UInt16_t2530548644_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, uint16_t p1, int32_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((uint16_t*)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int32_t438220675_SByte_t1526744772_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int32_t p2, int8_t p3, int32_t p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32U26_t3865694581_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t* p2, int32_t* p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), (int32_t*)args[1], (int32_t*)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int8_t p4, int32_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Interval_t176111467 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Interval_t176111467  (*Func)(void* obj, const RuntimeMethod* method);
	Interval_t176111467  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Interval_t176111467 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Interval_t176111467  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Interval_t176111467 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Interval_t176111467 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Interval_t176111467  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Interval_t176111467 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Interval_t176111467_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Interval_t176111467  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	Interval_t176111467  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Double_t3420139759_Interval_t176111467 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Interval_t176111467  p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, *((Interval_t176111467 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Interval_t176111467_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Interval_t176111467  p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Interval_t176111467 *)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32U26_t3865694581_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, int32_t p3, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, int32_t p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RegexOptionsU26_t2263882009 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t* p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (int32_t*)args[0], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RegexOptionsU26_t2263882009_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int8_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (int32_t*)args[0], *((int8_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_Int32U26_t3865694581_Int32U26_t3865694581_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t* p2, int32_t p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (int32_t*)args[0], (int32_t*)args[1], *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Category_t326181340 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Int32U26_t3865694581_Int32U26_t3865694581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t* p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (int32_t*)args[0], (int32_t*)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int8_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, int8_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_UInt16_t2530548644_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint16_t p1, int8_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((uint16_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int16_t674212087_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, int16_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, RuntimeObject * p4, int8_t p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (RuntimeObject *)args[3], *((int8_t*)args[4]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_UInt16_t2530548644 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, uint16_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((uint16_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Position_t731461718 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, const RuntimeMethod* method);
	uint16_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UriHostNameType_t1012973887_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_StringU26_t3235211963 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, String_t** p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (String_t**)args[0], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int8_t p2, int8_t p3, int8_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Char_t4217985068_RuntimeObject_Int32U26_t3865694581_CharU26_t1135874228 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, RuntimeObject * p1, int32_t* p2, Il2CppChar* p3, const RuntimeMethod* method);
	Il2CppChar ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (int32_t*)args[1], (Il2CppChar*)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_UriFormatExceptionU26_t1650653223 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, UriFormatException_t2885938561 ** p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (UriFormatException_t2885938561 **)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, RuntimeObject * p5, RuntimeObject * p6, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), (RuntimeObject *)args[4], (RuntimeObject *)args[5], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Sign_t170185132_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ConfidenceFactor_t1730967936 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UInt32_t1752406861_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int32_t p1, int8_t p2, const RuntimeMethod* method);
	uint32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_UInt32U26_t95126587_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint32_t* p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (uint32_t*)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_X509ChainStatusFlags_t2964126077 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Byte_t1695016127 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((uint8_t*)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Byte_t1695016127_Byte_t1695016127 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, uint8_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((uint8_t*)args[0]), *((uint8_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_AlertLevel_t393210211 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_AlertDescription_t1388230643 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Byte_t1695016127 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, uint8_t p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((uint8_t*)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_Int16_t674212087_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_Int16_t674212087_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, RuntimeObject * p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, int8_t p7, int8_t p8, int8_t p9, int16_t p10, int8_t p11, int8_t p12, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int16_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), *((int8_t*)args[7]), *((int8_t*)args[8]), *((int16_t*)args[9]), *((int8_t*)args[10]), *((int8_t*)args[11]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_CipherAlgorithmType_t976551082 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_HashAlgorithmType_t1587630734 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ExchangeAlgorithmType_t3448911736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int16_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int16_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int64_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int64_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_ByteU5BU5DU26_t1884214154_ByteU5BU5DU26_t1884214154 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, ByteU5BU5D_t3003616614** p2, ByteU5BU5D_t3003616614** p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (ByteU5BU5D_t3003616614**)args[1], (ByteU5BU5D_t3003616614**)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, uint8_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((uint8_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int16_t674212087_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_Int16_t674212087_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int16_t p1, RuntimeObject * p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, int8_t p7, int8_t p8, int8_t p9, int16_t p10, int8_t p11, int8_t p12, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), *((int8_t*)args[7]), *((int8_t*)args[8]), *((int16_t*)args[9]), *((int8_t*)args[10]), *((int8_t*)args[11]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int32_t p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_SecurityProtocolType_t1676794907 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SecurityCompressionType_t3510785785 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_HandshakeType_t1042630806 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_HandshakeState_t386269849 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_SecurityProtocolType_t1676794907_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int16_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, uint8_t p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((uint8_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, uint8_t p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((uint8_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_Byte_t1695016127_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((uint8_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, uint8_t p1, RuntimeObject * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((uint8_t*)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_SByte_t1526744772_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int8_t p3, int32_t p4, RuntimeObject * p5, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), *((int32_t*)args[3]), (RuntimeObject *)args[4], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, int32_t p4, int32_t p5, int8_t p6, int8_t p7, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Byte_t1695016127_Byte_t1695016127_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, uint8_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((uint8_t*)args[0]), *((uint8_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RSAParameters_t3314567386 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RSAParameters_t3314567386  (*Func)(void* obj, const RuntimeMethod* method);
	RSAParameters_t3314567386  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Byte_t1695016127_Byte_t1695016127 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, uint8_t p2, uint8_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((uint8_t*)args[1]), *((uint8_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Byte_t1695016127_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, uint8_t p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((uint8_t*)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_ContentType_t2215461912 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, RuntimeObject * p5, RuntimeObject * p6, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], (RuntimeObject *)args[5], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, int32_t p3, RuntimeObject * p4, RuntimeObject * p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((int32_t*)args[2]), (RuntimeObject *)args[3], (RuntimeObject *)args[4], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Rect_t1940963286 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Rect_t1940963286  (*Func)(void* obj, const RuntimeMethod* method);
	Rect_t1940963286  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RectU26_t3852249754 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t1940963286 * p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (Rect_t1940963286 *)args[0], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_CameraClearFlags_t1620199384 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Ray_t3298836202_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Ray_t3298836202  (*Func)(void* obj, Vector3_t2987449647  p1, const RuntimeMethod* method);
	Ray_t3298836202  ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Vector3U26_t1054175401_RayU26_t3897443494 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, Vector3_t2987449647 * p2, Ray_t3298836202 * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (Vector3_t2987449647 *)args[1], (Ray_t3298836202 *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_Ray_t3298836202_Single_t3678960876_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Ray_t3298836202  p1, float p2, int32_t p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), *((float*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RayU26_t3897443494_Single_t3678960876_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, Ray_t3298836202 * p2, float p3, int32_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (Ray_t3298836202 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_IntPtr_t_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, IntPtr_t p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((IntPtr_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_CullingGroupEvent_t3626597461 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CullingGroupEvent_t3626597461  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((CullingGroupEvent_t3626597461 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_CullingGroupEvent_t3626597461_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, CullingGroupEvent_t3626597461  p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((CullingGroupEvent_t3626597461 *)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int8_t p2, int8_t p3, int8_t p4, int8_t p5, RuntimeObject * p6, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), (RuntimeObject *)args[5], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Vector3_t2987449647  p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Vector3U26_t1054175401 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, Vector3_t2987449647 * p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (Vector3_t2987449647 *)args[1], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Vector3_t2987449647  (*Func)(void* obj, const RuntimeMethod* method);
	Vector3_t2987449647  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Vector3U26_t1054175401 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2987449647 * p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (Vector3_t2987449647 *)args[0], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Single_t3678960876_Single_t3678960876_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, float p2, float p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Vector3_t2987449647_Vector3_t2987449647_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Vector3_t2987449647  (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, const RuntimeMethod* method);
	Vector3_t2987449647  ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Vector3_t2987449647  (*Func)(void* obj, Vector3_t2987449647  p1, float p2, const RuntimeMethod* method);
	Vector3_t2987449647  ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((float*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Vector3_t2987449647_Single_t3678960876_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Vector3_t2987449647  (*Func)(void* obj, float p1, Vector3_t2987449647  p2, const RuntimeMethod* method);
	Vector3_t2987449647  ret = ((Func)methodPointer)(obj, *((float*)args[0]), *((Vector3_t2987449647 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Single_t3678960876_Single_t3678960876_Single_t3678960876_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, float p2, float p3, float p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), *((float*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Quaternion_t895809378_Quaternion_t895809378 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Quaternion_t895809378  (*Func)(void* obj, Quaternion_t895809378  p1, const RuntimeMethod* method);
	Quaternion_t895809378  ret = ((Func)methodPointer)(obj, *((Quaternion_t895809378 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_QuaternionU26_t1376965358_QuaternionU26_t1376965358 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Quaternion_t895809378 * p1, Quaternion_t895809378 * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (Quaternion_t895809378 *)args[0], (Quaternion_t895809378 *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2987449647  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Quaternion_t895809378_Single_t3678960876_Single_t3678960876_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Quaternion_t895809378  (*Func)(void* obj, float p1, float p2, float p3, const RuntimeMethod* method);
	Quaternion_t895809378  ret = ((Func)methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Quaternion_t895809378_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Quaternion_t895809378  (*Func)(void* obj, Vector3_t2987449647  p1, const RuntimeMethod* method);
	Quaternion_t895809378  ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Vector3U26_t1054175401_QuaternionU26_t1376965358 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2987449647 * p1, Quaternion_t895809378 * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (Vector3_t2987449647 *)args[0], (Quaternion_t895809378 *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Quaternion_t895809378_Quaternion_t895809378_Quaternion_t895809378 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Quaternion_t895809378  (*Func)(void* obj, Quaternion_t895809378  p1, Quaternion_t895809378  p2, const RuntimeMethod* method);
	Quaternion_t895809378  ret = ((Func)methodPointer)(obj, *((Quaternion_t895809378 *)args[0]), *((Quaternion_t895809378 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Single_t3678960876_Single_t3678960876_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef float (*Func)(void* obj, float p1, float p2, const RuntimeMethod* method);
	float ret = ((Func)methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Single_t3678960876_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, float p1, float p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Single_t3678960876_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, float p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Single_t3678960876_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, float p2, float p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((float*)args[1]), *((float*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Vector3_t2987449647_Quaternion_t895809378 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, Vector3_t2987449647  p2, Quaternion_t895809378  p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((Vector3_t2987449647 *)args[1]), *((Quaternion_t895809378 *)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Vector3U26_t1054175401_QuaternionU26_t1376965358 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, Vector3_t2987449647 * p2, Quaternion_t895809378 * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (Vector3_t2987449647 *)args[1], (Quaternion_t895809378 *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Vector3_t2987449647_Quaternion_t895809378 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, Vector3_t2987449647  p3, Quaternion_t895809378  p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((Vector3_t2987449647 *)args[2]), *((Quaternion_t895809378 *)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Vector3U26_t1054175401_QuaternionU26_t1376965358 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, Vector3_t2987449647 * p3, Quaternion_t895809378 * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (Vector3_t2987449647 *)args[2], (Quaternion_t895809378 *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_HideFlags_t1270484704 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_Vector3_t2987449647_Quaternion_t895809378_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, Vector3_t2987449647  p2, Quaternion_t895809378  p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((Vector3_t2987449647 *)args[1]), *((Quaternion_t895809378 *)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Boolean_t402932760_PlayableHandleU26_t2838161302 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, PlayableHandle_t2910061178 * p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (PlayableHandle_t2910061178 *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_PlayableHandleU26_t2838161302 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, PlayableHandle_t2910061178 * p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (PlayableHandle_t2910061178 *)args[0], methodMetadata);
	return ret;
}

void* RuntimeInvoker_PlayableHandle_t2910061178 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef PlayableHandle_t2910061178  (*Func)(void* obj, const RuntimeMethod* method);
	PlayableHandle_t2910061178  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PlayState_t540826789 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PlayState_t540826789_PlayableHandleU26_t2838161302 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, PlayableHandle_t2910061178 * p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (PlayableHandle_t2910061178 *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_PlayableHandleU26_t2838161302_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, PlayableHandle_t2910061178 * p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (PlayableHandle_t2910061178 *)args[0], *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_PlayableHandleU26_t2838161302_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, PlayableHandle_t2910061178 * p1, double p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (PlayableHandle_t2910061178 *)args[0], *((double*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_PlayableHandle_t2910061178_PlayableHandle_t2910061178 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, PlayableHandle_t2910061178  p1, PlayableHandle_t2910061178  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((PlayableHandle_t2910061178 *)args[0]), *((PlayableHandle_t2910061178 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_PlayableHandle_t2910061178 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, PlayableHandle_t2910061178  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((PlayableHandle_t2910061178 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Playable_t3436777522 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Playable_t3436777522  (*Func)(void* obj, const RuntimeMethod* method);
	Playable_t3436777522  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Playable_t3436777522_PlayableGraph_t4192197450_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Playable_t3436777522  (*Func)(void* obj, PlayableGraph_t4192197450  p1, int32_t p2, const RuntimeMethod* method);
	Playable_t3436777522  ret = ((Func)methodPointer)(obj, *((PlayableGraph_t4192197450 *)args[0]), *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Playable_t3436777522 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Playable_t3436777522  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Playable_t3436777522 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_PlayableGraphU26_t2161944390_RuntimeObject_PlayableOutputHandleU26_t1699804259 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, PlayableGraph_t4192197450 * p1, RuntimeObject * p2, PlayableOutputHandle_t4210482917 * p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (PlayableGraph_t4192197450 *)args[0], (RuntimeObject *)args[1], (PlayableOutputHandle_t4210482917 *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_PlayableGraphU26_t2161944390_PlayableHandleU26_t2838161302 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, PlayableGraph_t4192197450 * p1, PlayableHandle_t2910061178 * p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (PlayableGraph_t4192197450 *)args[0], (PlayableHandle_t2910061178 *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_PlayableOutputHandleU26_t1699804259 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, PlayableOutputHandle_t4210482917 * p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (PlayableOutputHandle_t4210482917 *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PlayableOutputHandle_t4210482917 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef PlayableOutputHandle_t4210482917  (*Func)(void* obj, const RuntimeMethod* method);
	PlayableOutputHandle_t4210482917  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_PlayableOutputHandleU26_t1699804259 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, PlayableOutputHandle_t4210482917 * p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (PlayableOutputHandle_t4210482917 *)args[0], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Boolean_t402932760_PlayableOutputHandle_t4210482917_PlayableOutputHandle_t4210482917 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, PlayableOutputHandle_t4210482917  p1, PlayableOutputHandle_t4210482917  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((PlayableOutputHandle_t4210482917 *)args[0]), *((PlayableOutputHandle_t4210482917 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_PlayableOutputHandle_t4210482917 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, PlayableOutputHandle_t4210482917  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((PlayableOutputHandle_t4210482917 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_PlayableOutput_t758663699 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef PlayableOutput_t758663699  (*Func)(void* obj, const RuntimeMethod* method);
	PlayableOutput_t758663699  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_PlayableOutput_t758663699 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, PlayableOutput_t758663699  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((PlayableOutput_t758663699 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Scene_t2009218140_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Scene_t2009218140  p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Scene_t2009218140 *)args[0]), *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Scene_t2009218140 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Scene_t2009218140  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Scene_t2009218140 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Scene_t2009218140_Scene_t2009218140 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Scene_t2009218140  p1, Scene_t2009218140  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Scene_t2009218140 *)args[0]), *((Scene_t2009218140 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Quaternion_t895809378 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Quaternion_t895809378  (*Func)(void* obj, const RuntimeMethod* method);
	Quaternion_t895809378  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Quaternion_t895809378 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Quaternion_t895809378  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Quaternion_t895809378 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_QuaternionU26_t1376965358 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Quaternion_t895809378 * p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (Quaternion_t895809378 *)args[0], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Vector3_t2987449647_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2987449647  p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Single_t3678960876_Single_t3678960876_Single_t3678960876_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, float p2, float p3, int32_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, float p3, int32_t p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, float p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), *((float*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, float p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_RaycastHitU26_t714001703_Single_t3678960876_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, RaycastHit_t2786726017 * p3, float p4, int32_t p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), (RaycastHit_t2786726017 *)args[2], *((float*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_RaycastHitU26_t714001703_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, RaycastHit_t2786726017 * p3, float p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), (RaycastHit_t2786726017 *)args[2], *((float*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_RaycastHitU26_t714001703 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, RaycastHit_t2786726017 * p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), (RaycastHit_t2786726017 *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_RaycastHitU26_t714001703_Single_t3678960876_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, RaycastHit_t2786726017 * p3, float p4, int32_t p5, int32_t p6, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), (RaycastHit_t2786726017 *)args[2], *((float*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_Single_t3678960876_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t3298836202  p1, float p2, int32_t p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), *((float*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t3298836202  p1, float p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), *((float*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Ray_t3298836202 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t3298836202  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_Single_t3678960876_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t3298836202  p1, float p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), *((float*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_RaycastHitU26_t714001703_Single_t3678960876_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t3298836202  p1, RaycastHit_t2786726017 * p2, float p3, int32_t p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), (RaycastHit_t2786726017 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_RaycastHitU26_t714001703_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t3298836202  p1, RaycastHit_t2786726017 * p2, float p3, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), (RaycastHit_t2786726017 *)args[1], *((float*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_RaycastHitU26_t714001703 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t3298836202  p1, RaycastHit_t2786726017 * p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), (RaycastHit_t2786726017 *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_RaycastHitU26_t714001703_Single_t3678960876_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t3298836202  p1, RaycastHit_t2786726017 * p2, float p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), (RaycastHit_t2786726017 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Ray_t3298836202_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Ray_t3298836202  p1, float p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), *((float*)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Ray_t3298836202 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Ray_t3298836202  p1, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Ray_t3298836202_Single_t3678960876_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Ray_t3298836202  p1, float p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Ray_t3298836202 *)args[0]), *((float*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, float p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, float p3, int32_t p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, float p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), *((float*)args[2]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Vector3_t2987449647_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Vector3_t2987449647  p1, Vector3_t2987449647  p2, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), *((Vector3_t2987449647 *)args[1]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Vector3U26_t1054175401_Vector3U26_t1054175401_Single_t3678960876_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Vector3_t2987449647 * p1, Vector3_t2987449647 * p2, float p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (Vector3_t2987449647 *)args[0], (Vector3_t2987449647 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return ret;
}

void* RuntimeInvoker_Boolean_t402932760_Vector3U26_t1054175401_Vector3U26_t1054175401_RaycastHitU26_t714001703_Single_t3678960876_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647 * p1, Vector3_t2987449647 * p2, RaycastHit_t2786726017 * p3, float p4, int32_t p5, int32_t p6, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (Vector3_t2987449647 *)args[0], (Vector3_t2987449647 *)args[1], (RaycastHit_t2786726017 *)args[2], *((float*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Vector3U26_t1054175401_Vector3U26_t1054175401_Single_t3678960876_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647 * p1, Vector3_t2987449647 * p2, float p3, int32_t p4, int32_t p5, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (Vector3_t2987449647 *)args[0], (Vector3_t2987449647 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Vector3_t2987449647_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Vector3_t2987449647  (*Func)(void* obj, Vector3_t2987449647  p1, const RuntimeMethod* method);
	Vector3_t2987449647  ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_Vector3U26_t1054175401_Vector3U26_t1054175401 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, Vector3_t2987449647 * p2, Vector3_t2987449647 * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (Vector3_t2987449647 *)args[1], (Vector3_t2987449647 *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Bounds_t1424290876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Bounds_t1424290876  (*Func)(void* obj, const RuntimeMethod* method);
	Bounds_t1424290876  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_BoundsU26_t2305519396 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Bounds_t1424290876 * p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (Bounds_t1424290876 *)args[0], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Ray_t3298836202_RaycastHitU26_t714001703_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, Ray_t3298836202  p2, RaycastHit_t2786726017 * p3, float p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((Ray_t3298836202 *)args[1]), (RaycastHit_t2786726017 *)args[2], *((float*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_RayU26_t3897443494_RaycastHitU26_t714001703_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, Ray_t3298836202 * p2, RaycastHit_t2786726017 * p3, float p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (Ray_t3298836202 *)args[1], (RaycastHit_t2786726017 *)args[2], *((float*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_CollisionFlags_t2921713114_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector3_t2987449647  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_CollisionFlags_t2921713114_RuntimeObject_Vector3U26_t1054175401 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, Vector3_t2987449647 * p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (Vector3_t2987449647 *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_AudioPlayableOutput_t2616039667_PlayableGraph_t4192197450_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef AudioPlayableOutput_t2616039667  (*Func)(void* obj, PlayableGraph_t4192197450  p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	AudioPlayableOutput_t2616039667  ret = ((Func)methodPointer)(obj, *((PlayableGraph_t4192197450 *)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_AudioPlayableOutput_t2616039667 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef AudioPlayableOutput_t2616039667  (*Func)(void* obj, const RuntimeMethod* method);
	AudioPlayableOutput_t2616039667  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PlayableOutput_t758663699_AudioPlayableOutput_t2616039667 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef PlayableOutput_t758663699  (*Func)(void* obj, AudioPlayableOutput_t2616039667  p1, const RuntimeMethod* method);
	PlayableOutput_t758663699  ret = ((Func)methodPointer)(obj, *((AudioPlayableOutput_t2616039667 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_AudioPlayableOutput_t2616039667_PlayableOutput_t758663699 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef AudioPlayableOutput_t2616039667  (*Func)(void* obj, PlayableOutput_t758663699  p1, const RuntimeMethod* method);
	AudioPlayableOutput_t2616039667  ret = ((Func)methodPointer)(obj, *((PlayableOutput_t758663699 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_PlayableOutputHandleU26_t1699804259_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, PlayableOutputHandle_t4210482917 * p1, RuntimeObject * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (PlayableOutputHandle_t4210482917 *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_AudioClipPlayable_t3295732336_PlayableGraph_t4192197450_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef AudioClipPlayable_t3295732336  (*Func)(void* obj, PlayableGraph_t4192197450  p1, RuntimeObject * p2, int8_t p3, const RuntimeMethod* method);
	AudioClipPlayable_t3295732336  ret = ((Func)methodPointer)(obj, *((PlayableGraph_t4192197450 *)args[0]), (RuntimeObject *)args[1], *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PlayableHandle_t2910061178_PlayableGraph_t4192197450_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef PlayableHandle_t2910061178  (*Func)(void* obj, PlayableGraph_t4192197450  p1, RuntimeObject * p2, int8_t p3, const RuntimeMethod* method);
	PlayableHandle_t2910061178  ret = ((Func)methodPointer)(obj, *((PlayableGraph_t4192197450 *)args[0]), (RuntimeObject *)args[1], *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Playable_t3436777522_AudioClipPlayable_t3295732336 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Playable_t3436777522  (*Func)(void* obj, AudioClipPlayable_t3295732336  p1, const RuntimeMethod* method);
	Playable_t3436777522  ret = ((Func)methodPointer)(obj, *((AudioClipPlayable_t3295732336 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_AudioClipPlayable_t3295732336_Playable_t3436777522 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef AudioClipPlayable_t3295732336  (*Func)(void* obj, Playable_t3436777522  p1, const RuntimeMethod* method);
	AudioClipPlayable_t3295732336  ret = ((Func)methodPointer)(obj, *((Playable_t3436777522 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_AudioClipPlayable_t3295732336 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, AudioClipPlayable_t3295732336  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((AudioClipPlayable_t3295732336 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_PlayableHandleU26_t2838161302_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, PlayableHandle_t2910061178 * p1, RuntimeObject * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (PlayableHandle_t2910061178 *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_PlayableHandleU26_t2838161302_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, PlayableHandle_t2910061178 * p1, int8_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (PlayableHandle_t2910061178 *)args[0], *((int8_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Double_t3420139759_PlayableHandleU26_t2838161302 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef double (*Func)(void* obj, PlayableHandle_t2910061178 * p1, const RuntimeMethod* method);
	double ret = ((Func)methodPointer)(obj, (PlayableHandle_t2910061178 *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_PlayableGraphU26_t2161944390_RuntimeObject_SByte_t1526744772_PlayableHandleU26_t2838161302 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, PlayableGraph_t4192197450 * p1, RuntimeObject * p2, int8_t p3, PlayableHandle_t2910061178 * p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (PlayableGraph_t4192197450 *)args[0], (RuntimeObject *)args[1], *((int8_t*)args[2]), (PlayableHandle_t2910061178 *)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_Double_t3420139759_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, double p1, double p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((double*)args[0]), *((double*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Double_t3420139759_Double_t3420139759_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, double p1, double p2, double p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((double*)args[0]), *((double*)args[1]), *((double*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_AudioMixerPlayable_t3345238233_PlayableGraph_t4192197450_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef AudioMixerPlayable_t3345238233  (*Func)(void* obj, PlayableGraph_t4192197450  p1, int32_t p2, int8_t p3, const RuntimeMethod* method);
	AudioMixerPlayable_t3345238233  ret = ((Func)methodPointer)(obj, *((PlayableGraph_t4192197450 *)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PlayableHandle_t2910061178_PlayableGraph_t4192197450_Int32_t438220675_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef PlayableHandle_t2910061178  (*Func)(void* obj, PlayableGraph_t4192197450  p1, int32_t p2, int8_t p3, const RuntimeMethod* method);
	PlayableHandle_t2910061178  ret = ((Func)methodPointer)(obj, *((PlayableGraph_t4192197450 *)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Playable_t3436777522_AudioMixerPlayable_t3345238233 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Playable_t3436777522  (*Func)(void* obj, AudioMixerPlayable_t3345238233  p1, const RuntimeMethod* method);
	Playable_t3436777522  ret = ((Func)methodPointer)(obj, *((AudioMixerPlayable_t3345238233 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_AudioMixerPlayable_t3345238233_Playable_t3436777522 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef AudioMixerPlayable_t3345238233  (*Func)(void* obj, Playable_t3436777522  p1, const RuntimeMethod* method);
	AudioMixerPlayable_t3345238233  ret = ((Func)methodPointer)(obj, *((Playable_t3436777522 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_AudioMixerPlayable_t3345238233 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, AudioMixerPlayable_t3345238233  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((AudioMixerPlayable_t3345238233 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_PlayableGraphU26_t2161944390_Int32_t438220675_SByte_t1526744772_PlayableHandleU26_t2838161302 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, PlayableGraph_t4192197450 * p1, int32_t p2, int8_t p3, PlayableHandle_t2910061178 * p4, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (PlayableGraph_t4192197450 *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), (PlayableHandle_t2910061178 *)args[3], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int8_t p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, int32_t p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int16_t674212087 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int16_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int16_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int64_t3733094498 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, int64_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int64_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, float p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((float*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, double p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((double*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, Decimal_t2382302464  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((Decimal_t2382302464 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_AnalyticsResult_t1733525867_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_AnalyticsResult_t1733525867_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, int8_t p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_HitInfo_t2681867412 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, HitInfo_t2681867412  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((HitInfo_t2681867412 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_HitInfo_t2681867412 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, HitInfo_t2681867412  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((HitInfo_t2681867412 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_HitInfo_t2681867412_HitInfo_t2681867412 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, HitInfo_t2681867412  p1, HitInfo_t2681867412  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((HitInfo_t2681867412 *)args[0]), *((HitInfo_t2681867412 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2987449647  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Vector3_t2987449647 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_StringU26_t3235211963_StringU26_t3235211963 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, String_t** p2, String_t** p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (String_t**)args[1], (String_t**)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_PersistentListenerMode_t2357711828 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Playable_t3436777522_PlayableGraph_t4192197450_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Playable_t3436777522  (*Func)(void* obj, PlayableGraph_t4192197450  p1, RuntimeObject * p2, const RuntimeMethod* method);
	Playable_t3436777522  ret = ((Func)methodPointer)(obj, *((PlayableGraph_t4192197450 *)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_PlayableGraph_t4192197450_RuntimeObject_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, PlayableGraph_t4192197450  p2, RuntimeObject * p3, IntPtr_t p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((PlayableGraph_t4192197450 *)args[1]), (RuntimeObject *)args[2], *((IntPtr_t*)args[3]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Playable_t3436777522 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3436777522  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Playable_t3436777522 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Playable_t3436777522_FrameData_t231040801 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3436777522  p1, FrameData_t231040801  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Playable_t3436777522 *)args[0]), *((FrameData_t231040801 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Playable_t3436777522_FrameData_t231040801_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3436777522  p1, FrameData_t231040801  p2, RuntimeObject * p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Playable_t3436777522 *)args[0]), *((FrameData_t231040801 *)args[1]), (RuntimeObject *)args[2], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_ScriptPlayableOutput_t2716968363_PlayableGraph_t4192197450_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ScriptPlayableOutput_t2716968363  (*Func)(void* obj, PlayableGraph_t4192197450  p1, RuntimeObject * p2, const RuntimeMethod* method);
	ScriptPlayableOutput_t2716968363  ret = ((Func)methodPointer)(obj, *((PlayableGraph_t4192197450 *)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ScriptPlayableOutput_t2716968363 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ScriptPlayableOutput_t2716968363  (*Func)(void* obj, const RuntimeMethod* method);
	ScriptPlayableOutput_t2716968363  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PlayableOutput_t758663699_ScriptPlayableOutput_t2716968363 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef PlayableOutput_t758663699  (*Func)(void* obj, ScriptPlayableOutput_t2716968363  p1, const RuntimeMethod* method);
	PlayableOutput_t758663699  ret = ((Func)methodPointer)(obj, *((ScriptPlayableOutput_t2716968363 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ScriptPlayableOutput_t2716968363_PlayableOutput_t758663699 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ScriptPlayableOutput_t2716968363  (*Func)(void* obj, PlayableOutput_t758663699  p1, const RuntimeMethod* method);
	ScriptPlayableOutput_t2716968363  ret = ((Func)methodPointer)(obj, *((PlayableOutput_t758663699 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_LogType_t310145821 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_IntPtr_t_Int64_t3733094498_Int64_t3733094498_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int64_t p2, int64_t p3, RuntimeObject * p4, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((int64_t*)args[1]), *((int64_t*)args[2]), (RuntimeObject *)args[3], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Guid_t_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Guid_t  p1, RuntimeObject * p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Guid_t *)args[0]), (RuntimeObject *)args[1], *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_ScriptableRenderContext_t3163458046_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ScriptableRenderContext_t3163458046  p1, RuntimeObject * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((ScriptableRenderContext_t3163458046 *)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, IntPtr_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((IntPtr_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_CSSSize_t478721537_IntPtr_t_Single_t3678960876_Int32_t438220675_Single_t3678960876_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef CSSSize_t478721537  (*Func)(void* obj, IntPtr_t p1, float p2, int32_t p3, float p4, int32_t p5, const RuntimeMethod* method);
	CSSSize_t478721537  ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((float*)args[1]), *((int32_t*)args[2]), *((float*)args[3]), *((int32_t*)args[4]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_IntPtr_t_Single_t3678960876_Int32_t438220675_Single_t3678960876_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, IntPtr_t p1, float p2, int32_t p3, float p4, int32_t p5, RuntimeObject * p6, RuntimeObject * p7, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((float*)args[1]), *((int32_t*)args[2]), *((float*)args[3]), *((int32_t*)args[4]), (RuntimeObject *)args[5], (RuntimeObject *)args[6], methodMetadata);
	return ret;
}

void* RuntimeInvoker_CSSSize_t478721537_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef CSSSize_t478721537  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	CSSSize_t478721537  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_IntPtr_t_Single_t3678960876_Int32_t438220675_Single_t3678960876_Int32_t438220675_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, float p2, int32_t p3, float p4, int32_t p5, IntPtr_t p6, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), *((float*)args[1]), *((int32_t*)args[2]), *((float*)args[3]), *((int32_t*)args[4]), *((IntPtr_t*)args[5]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_ObjectU26_t1561828645 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RuntimeObject ** p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), (RuntimeObject **)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_ObjectU5BU5DU26_t1191207502_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ObjectU5BU5D_t42211586** p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (ObjectU5BU5D_t42211586**)args[0], *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_ObjectU5BU5DU26_t1191207502_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ObjectU5BU5D_t42211586** p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (ObjectU5BU5D_t42211586**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_KeyValuePair_2_t3369932832 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, KeyValuePair_2_t3369932832  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((KeyValuePair_2_t3369932832 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_KeyValuePair_2_t3369932832 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, KeyValuePair_2_t3369932832  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((KeyValuePair_2_t3369932832 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3369932832_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3369932832  (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	KeyValuePair_2_t3369932832  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_ObjectU26_t1561828645 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, RuntimeObject ** p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject **)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Enumerator_t2659973885 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t2659973885  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t2659973885  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t578375704_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DictionaryEntry_t578375704  (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
	DictionaryEntry_t578375704  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3369932832 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3369932832  (*Func)(void* obj, const RuntimeMethod* method);
	KeyValuePair_2_t3369932832  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Enumerator_t2420502484 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t2420502484  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t2420502484  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_ObjectU26_t1561828645_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject ** p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject **)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Enumerator_t4263500154 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t4263500154  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t4263500154  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Enumerator_t2206974221 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t2206974221  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t2206974221  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, RuntimeObject * p5, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], (RuntimeObject *)args[4], methodMetadata);
	return ret;
}

void* RuntimeInvoker_Void_t1421048318_AudioClipPlayable_t3295732336_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, AudioClipPlayable_t3295732336  p1, double p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((AudioClipPlayable_t3295732336 *)args[0]), *((double*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Boolean_t402932760_IntPtr_t_ObjectU26_t1561828645 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, RuntimeObject ** p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (RuntimeObject **)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Single_t3678960876 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RuntimeObject * p1, RuntimeObject * p2, float p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (RuntimeObject *)args[0], (RuntimeObject *)args[1], *((float*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Playable_t3436777522_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3436777522  p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Playable_t3436777522 *)args[0]), *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_WorkRequest_t3203378897 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef WorkRequest_t3203378897  (*Func)(void* obj, const RuntimeMethod* method);
	WorkRequest_t3203378897  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_TableRange_t2080199027 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, TableRange_t2080199027  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((TableRange_t2080199027 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_DictionaryEntry_t578375704 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DictionaryEntry_t578375704  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((DictionaryEntry_t578375704 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_KeyValuePair_2_t2173232590 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, KeyValuePair_2_t2173232590  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((KeyValuePair_2_t2173232590 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_KeyValuePair_2_t3674847205 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, KeyValuePair_2_t3674847205  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((KeyValuePair_2_t3674847205 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_KeyValuePair_2_t3710135120 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, KeyValuePair_2_t3710135120  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((KeyValuePair_2_t3710135120 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Link_t808767725 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Link_t808767725  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Link_t808767725 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Slot_t2703514113 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Slot_t2703514113  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Slot_t2703514113 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Slot_t2810825829 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Slot_t2810825829  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Slot_t2810825829 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_CustomAttributeNamedArgument_t3456585787 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, CustomAttributeNamedArgument_t3456585787  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((CustomAttributeNamedArgument_t3456585787 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_CustomAttributeTypedArgument_t2066493570 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, CustomAttributeTypedArgument_t2066493570  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((CustomAttributeTypedArgument_t2066493570 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_LabelData_t2222154365 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, LabelData_t2222154365  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((LabelData_t2222154365 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_LabelFixup_t426630335 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, LabelFixup_t426630335  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((LabelFixup_t426630335 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_ILTokenInfo_t3857000042 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ILTokenInfo_t3857000042  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((ILTokenInfo_t3857000042 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_ParameterModifier_t1406754278 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ParameterModifier_t1406754278  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((ParameterModifier_t1406754278 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_ResourceCacheItem_t2576962992 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ResourceCacheItem_t2576962992  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((ResourceCacheItem_t2576962992 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_ResourceInfo_t1067968749 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ResourceInfo_t1067968749  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((ResourceInfo_t1067968749 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Byte_t1695016127 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, uint8_t p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((uint8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_X509ChainStatus_t2329993372 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, X509ChainStatus_t2329993372  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((X509ChainStatus_t2329993372 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Mark_t3306160088 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Mark_t3306160088  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Mark_t3306160088 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_UriScheme_t2520867868 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, UriScheme_t2520867868  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((UriScheme_t2520867868 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_ContactPoint_t3765348581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ContactPoint_t3765348581  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((ContactPoint_t3765348581 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Keyframe_t1047575712 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Keyframe_t1047575712  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Keyframe_t1047575712 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_PlayableBinding_t2470704133 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, PlayableBinding_t2470704133  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((PlayableBinding_t2470704133 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RaycastHit_t2786726017 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RaycastHit_t2786726017  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((RaycastHit_t2786726017 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_WorkRequest_t3203378897 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, WorkRequest_t3203378897  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((WorkRequest_t3203378897 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, int32_t p2, int32_t p3, int32_t p4, RuntimeObject * p5, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), (RuntimeObject *)args[4], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_CustomAttributeNamedArgument_t3456585787_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, CustomAttributeNamedArgument_t3456585787  p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((CustomAttributeNamedArgument_t3456585787 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_CustomAttributeNamedArgument_t3456585787 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, CustomAttributeNamedArgument_t3456585787  p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((CustomAttributeNamedArgument_t3456585787 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_CustomAttributeTypedArgument_t2066493570_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, CustomAttributeTypedArgument_t2066493570  p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((CustomAttributeTypedArgument_t2066493570 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RuntimeObject_CustomAttributeTypedArgument_t2066493570 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RuntimeObject * p1, CustomAttributeTypedArgument_t2066493570  p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((CustomAttributeTypedArgument_t2066493570 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_TableRange_t2080199027 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, TableRange_t2080199027  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((TableRange_t2080199027 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_DictionaryEntry_t578375704 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DictionaryEntry_t578375704  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((DictionaryEntry_t578375704 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_KeyValuePair_2_t2173232590 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, KeyValuePair_2_t2173232590  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((KeyValuePair_2_t2173232590 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_KeyValuePair_2_t3674847205 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, KeyValuePair_2_t3674847205  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((KeyValuePair_2_t3674847205 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_KeyValuePair_2_t3710135120 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, KeyValuePair_2_t3710135120  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((KeyValuePair_2_t3710135120 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_KeyValuePair_2_t3369932832 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, KeyValuePair_2_t3369932832  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((KeyValuePair_2_t3369932832 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Link_t808767725 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Link_t808767725  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((Link_t808767725 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Slot_t2703514113 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Slot_t2703514113  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((Slot_t2703514113 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Slot_t2810825829 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Slot_t2810825829  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((Slot_t2810825829 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_CustomAttributeNamedArgument_t3456585787 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, CustomAttributeNamedArgument_t3456585787  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((CustomAttributeNamedArgument_t3456585787 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_CustomAttributeTypedArgument_t2066493570 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, CustomAttributeTypedArgument_t2066493570  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((CustomAttributeTypedArgument_t2066493570 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_LabelData_t2222154365 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, LabelData_t2222154365  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((LabelData_t2222154365 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_LabelFixup_t426630335 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, LabelFixup_t426630335  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((LabelFixup_t426630335 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_ILTokenInfo_t3857000042 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ILTokenInfo_t3857000042  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((ILTokenInfo_t3857000042 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_ParameterModifier_t1406754278 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ParameterModifier_t1406754278  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((ParameterModifier_t1406754278 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_ResourceCacheItem_t2576962992 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ResourceCacheItem_t2576962992  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((ResourceCacheItem_t2576962992 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_ResourceInfo_t1067968749 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ResourceInfo_t1067968749  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((ResourceInfo_t1067968749 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Byte_t1695016127 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, uint8_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((uint8_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_X509ChainStatus_t2329993372 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, X509ChainStatus_t2329993372  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((X509ChainStatus_t2329993372 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Mark_t3306160088 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Mark_t3306160088  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((Mark_t3306160088 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_UriScheme_t2520867868 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UriScheme_t2520867868  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((UriScheme_t2520867868 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_ContactPoint_t3765348581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ContactPoint_t3765348581  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((ContactPoint_t3765348581 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Keyframe_t1047575712 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Keyframe_t1047575712  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((Keyframe_t1047575712 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_PlayableBinding_t2470704133 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, PlayableBinding_t2470704133  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((PlayableBinding_t2470704133 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_RaycastHit_t2786726017 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RaycastHit_t2786726017  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((RaycastHit_t2786726017 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_HitInfo_t2681867412 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, HitInfo_t2681867412  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((HitInfo_t2681867412 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_WorkRequest_t3203378897 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, WorkRequest_t3203378897  p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((WorkRequest_t3203378897 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_TableRange_t2080199027 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, TableRange_t2080199027  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((TableRange_t2080199027 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_DictionaryEntry_t578375704 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, DictionaryEntry_t578375704  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((DictionaryEntry_t578375704 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_KeyValuePair_2_t2173232590 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, KeyValuePair_2_t2173232590  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((KeyValuePair_2_t2173232590 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_KeyValuePair_2_t3674847205 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, KeyValuePair_2_t3674847205  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((KeyValuePair_2_t3674847205 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_KeyValuePair_2_t3710135120 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, KeyValuePair_2_t3710135120  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((KeyValuePair_2_t3710135120 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Link_t808767725 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Link_t808767725  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Link_t808767725 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Slot_t2703514113 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Slot_t2703514113  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Slot_t2703514113 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Slot_t2810825829 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Slot_t2810825829  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Slot_t2810825829 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Decimal_t2382302464  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Decimal_t2382302464 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_CustomAttributeNamedArgument_t3456585787 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeNamedArgument_t3456585787  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((CustomAttributeNamedArgument_t3456585787 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_CustomAttributeTypedArgument_t2066493570 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeTypedArgument_t2066493570  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((CustomAttributeTypedArgument_t2066493570 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_LabelData_t2222154365 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, LabelData_t2222154365  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((LabelData_t2222154365 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_LabelFixup_t426630335 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, LabelFixup_t426630335  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((LabelFixup_t426630335 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_ILTokenInfo_t3857000042 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ILTokenInfo_t3857000042  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((ILTokenInfo_t3857000042 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_ParameterModifier_t1406754278 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ParameterModifier_t1406754278  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((ParameterModifier_t1406754278 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_ResourceCacheItem_t2576962992 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ResourceCacheItem_t2576962992  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((ResourceCacheItem_t2576962992 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_ResourceInfo_t1067968749 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ResourceInfo_t1067968749  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((ResourceInfo_t1067968749 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_X509ChainStatus_t2329993372 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, X509ChainStatus_t2329993372  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((X509ChainStatus_t2329993372 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Mark_t3306160088 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Mark_t3306160088  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Mark_t3306160088 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_UriScheme_t2520867868 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UriScheme_t2520867868  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((UriScheme_t2520867868 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_ContactPoint_t3765348581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ContactPoint_t3765348581  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((ContactPoint_t3765348581 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Keyframe_t1047575712 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Keyframe_t1047575712  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((Keyframe_t1047575712 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_PlayableBinding_t2470704133 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, PlayableBinding_t2470704133  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((PlayableBinding_t2470704133 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_RaycastHit_t2786726017 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RaycastHit_t2786726017  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((RaycastHit_t2786726017 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_HitInfo_t2681867412 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, HitInfo_t2681867412  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((HitInfo_t2681867412 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_WorkRequest_t3203378897 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, WorkRequest_t3203378897  p1, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((WorkRequest_t3203378897 *)args[0]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_TableRange_t2080199027 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, TableRange_t2080199027  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((TableRange_t2080199027 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_DictionaryEntry_t578375704 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, DictionaryEntry_t578375704  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((DictionaryEntry_t578375704 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_KeyValuePair_2_t2173232590 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, KeyValuePair_2_t2173232590  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((KeyValuePair_2_t2173232590 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_KeyValuePair_2_t3674847205 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, KeyValuePair_2_t3674847205  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((KeyValuePair_2_t3674847205 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_KeyValuePair_2_t3710135120 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, KeyValuePair_2_t3710135120  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((KeyValuePair_2_t3710135120 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_KeyValuePair_2_t3369932832 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, KeyValuePair_2_t3369932832  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((KeyValuePair_2_t3369932832 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Link_t808767725 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Link_t808767725  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((Link_t808767725 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Slot_t2703514113 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Slot_t2703514113  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((Slot_t2703514113 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Slot_t2810825829 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Slot_t2810825829  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((Slot_t2810825829 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_DateTime_t3836236387 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, DateTime_t3836236387  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((DateTime_t3836236387 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Decimal_t2382302464 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Decimal_t2382302464  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((Decimal_t2382302464 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Double_t3420139759 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, double p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((double*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_IntPtr_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, IntPtr_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((IntPtr_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_CustomAttributeNamedArgument_t3456585787 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, CustomAttributeNamedArgument_t3456585787  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((CustomAttributeNamedArgument_t3456585787 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_CustomAttributeTypedArgument_t2066493570 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, CustomAttributeTypedArgument_t2066493570  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((CustomAttributeTypedArgument_t2066493570 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_LabelData_t2222154365 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, LabelData_t2222154365  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((LabelData_t2222154365 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_LabelFixup_t426630335 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, LabelFixup_t426630335  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((LabelFixup_t426630335 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_ILTokenInfo_t3857000042 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ILTokenInfo_t3857000042  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((ILTokenInfo_t3857000042 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_ParameterModifier_t1406754278 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ParameterModifier_t1406754278  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((ParameterModifier_t1406754278 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_ResourceCacheItem_t2576962992 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ResourceCacheItem_t2576962992  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((ResourceCacheItem_t2576962992 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_ResourceInfo_t1067968749 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ResourceInfo_t1067968749  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((ResourceInfo_t1067968749 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Byte_t1695016127 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, uint8_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((uint8_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_X509ChainStatus_t2329993372 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, X509ChainStatus_t2329993372  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((X509ChainStatus_t2329993372 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Mark_t3306160088 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Mark_t3306160088  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((Mark_t3306160088 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_TimeSpan_t4182925364 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, TimeSpan_t4182925364  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((TimeSpan_t4182925364 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_UriScheme_t2520867868 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, UriScheme_t2520867868  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((UriScheme_t2520867868 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_ContactPoint_t3765348581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ContactPoint_t3765348581  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((ContactPoint_t3765348581 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_Keyframe_t1047575712 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Keyframe_t1047575712  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((Keyframe_t1047575712 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_PlayableBinding_t2470704133 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, PlayableBinding_t2470704133  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((PlayableBinding_t2470704133 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_RaycastHit_t2786726017 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RaycastHit_t2786726017  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((RaycastHit_t2786726017 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32_t438220675_WorkRequest_t3203378897 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, WorkRequest_t3203378897  p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((int32_t*)args[0]), *((WorkRequest_t3203378897 *)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32U5BU5DU26_t2609758910_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Int32U5BU5D_t1381360402** p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (Int32U5BU5D_t1381360402**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_Int32U5BU5DU26_t2609758910_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Int32U5BU5D_t1381360402** p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (Int32U5BU5D_t1381360402**)args[0], *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_CustomAttributeNamedArgumentU5BU5DU26_t1774281110_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeNamedArgumentU5BU5D_t2930047098** p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (CustomAttributeNamedArgumentU5BU5D_t2930047098**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_CustomAttributeNamedArgumentU5BU5DU26_t1774281110_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeNamedArgumentU5BU5D_t2930047098** p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (CustomAttributeNamedArgumentU5BU5D_t2930047098**)args[0], *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_CustomAttributeTypedArgumentU5BU5DU26_t4198221793_Int32_t438220675_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeTypedArgumentU5BU5D_t3967009591** p1, int32_t p2, int32_t p3, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (CustomAttributeTypedArgumentU5BU5D_t3967009591**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Void_t1421048318_CustomAttributeTypedArgumentU5BU5DU26_t4198221793_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeTypedArgumentU5BU5D_t3967009591** p1, int32_t p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, (CustomAttributeTypedArgumentU5BU5D_t3967009591**)args[0], *((int32_t*)args[1]), methodMetadata);
	return NULL;
}

void* RuntimeInvoker_TableRange_t2080199027_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TableRange_t2080199027  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	TableRange_t2080199027  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ClientCertificateType_t2095209863_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t578375704_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DictionaryEntry_t578375704  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	DictionaryEntry_t578375704  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t2173232590_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t2173232590  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	KeyValuePair_2_t2173232590  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3674847205_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3674847205  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	KeyValuePair_2_t3674847205  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3710135120_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3710135120  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	KeyValuePair_2_t3710135120  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3369932832_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3369932832  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	KeyValuePair_2_t3369932832  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Link_t808767725_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Link_t808767725  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	Link_t808767725  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Slot_t2703514113_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Slot_t2703514113  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	Slot_t2703514113  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Slot_t2810825829_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Slot_t2810825829  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	Slot_t2810825829  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_CustomAttributeNamedArgument_t3456585787_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef CustomAttributeNamedArgument_t3456585787  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	CustomAttributeNamedArgument_t3456585787  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_CustomAttributeTypedArgument_t2066493570_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef CustomAttributeTypedArgument_t2066493570  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	CustomAttributeTypedArgument_t2066493570  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_LabelData_t2222154365_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef LabelData_t2222154365  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	LabelData_t2222154365  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_LabelFixup_t426630335_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef LabelFixup_t426630335  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	LabelFixup_t426630335  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ILTokenInfo_t3857000042_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ILTokenInfo_t3857000042  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	ILTokenInfo_t3857000042  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ParameterModifier_t1406754278_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ParameterModifier_t1406754278  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	ParameterModifier_t1406754278  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ResourceCacheItem_t2576962992_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ResourceCacheItem_t2576962992  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	ResourceCacheItem_t2576962992  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ResourceInfo_t1067968749_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ResourceInfo_t1067968749  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	ResourceInfo_t1067968749  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TypeTag_t1823465210_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_X509ChainStatus_t2329993372_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef X509ChainStatus_t2329993372  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	X509ChainStatus_t2329993372  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Mark_t3306160088_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Mark_t3306160088  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	Mark_t3306160088  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TimeSpan_t4182925364_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TimeSpan_t4182925364  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	TimeSpan_t4182925364  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UriScheme_t2520867868_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef UriScheme_t2520867868  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	UriScheme_t2520867868  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ContactPoint_t3765348581_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ContactPoint_t3765348581  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	ContactPoint_t3765348581  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Keyframe_t1047575712_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Keyframe_t1047575712  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	Keyframe_t1047575712  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PlayableBinding_t2470704133_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef PlayableBinding_t2470704133  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	PlayableBinding_t2470704133  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RaycastHit_t2786726017_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RaycastHit_t2786726017  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	RaycastHit_t2786726017  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_HitInfo_t2681867412_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef HitInfo_t2681867412  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	HitInfo_t2681867412  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_WorkRequest_t3203378897_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef WorkRequest_t3203378897  (*Func)(void* obj, int32_t p1, const RuntimeMethod* method);
	WorkRequest_t3203378897  ret = ((Func)methodPointer)(obj, *((int32_t*)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Single_t3678960876_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, float p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((float*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_CustomAttributeNamedArgument_t3456585787 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef CustomAttributeNamedArgument_t3456585787  (*Func)(void* obj, const RuntimeMethod* method);
	CustomAttributeNamedArgument_t3456585787  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_CustomAttributeTypedArgument_t2066493570 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef CustomAttributeTypedArgument_t2066493570  (*Func)(void* obj, const RuntimeMethod* method);
	CustomAttributeTypedArgument_t2066493570  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TableRange_t2080199027 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef TableRange_t2080199027  (*Func)(void* obj, const RuntimeMethod* method);
	TableRange_t2080199027  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ClientCertificateType_t2095209863 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t2173232590 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t2173232590  (*Func)(void* obj, const RuntimeMethod* method);
	KeyValuePair_2_t2173232590  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3674847205 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3674847205  (*Func)(void* obj, const RuntimeMethod* method);
	KeyValuePair_2_t3674847205  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3710135120 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3710135120  (*Func)(void* obj, const RuntimeMethod* method);
	KeyValuePair_2_t3710135120  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Link_t808767725 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Link_t808767725  (*Func)(void* obj, const RuntimeMethod* method);
	Link_t808767725  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Slot_t2703514113 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Slot_t2703514113  (*Func)(void* obj, const RuntimeMethod* method);
	Slot_t2703514113  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Slot_t2810825829 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Slot_t2810825829  (*Func)(void* obj, const RuntimeMethod* method);
	Slot_t2810825829  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_LabelData_t2222154365 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef LabelData_t2222154365  (*Func)(void* obj, const RuntimeMethod* method);
	LabelData_t2222154365  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_LabelFixup_t426630335 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef LabelFixup_t426630335  (*Func)(void* obj, const RuntimeMethod* method);
	LabelFixup_t426630335  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ILTokenInfo_t3857000042 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ILTokenInfo_t3857000042  (*Func)(void* obj, const RuntimeMethod* method);
	ILTokenInfo_t3857000042  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ParameterModifier_t1406754278 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ParameterModifier_t1406754278  (*Func)(void* obj, const RuntimeMethod* method);
	ParameterModifier_t1406754278  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ResourceCacheItem_t2576962992 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ResourceCacheItem_t2576962992  (*Func)(void* obj, const RuntimeMethod* method);
	ResourceCacheItem_t2576962992  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ResourceInfo_t1067968749 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ResourceInfo_t1067968749  (*Func)(void* obj, const RuntimeMethod* method);
	ResourceInfo_t1067968749  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_TypeTag_t1823465210 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const RuntimeMethod* method);
	uint8_t ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_X509ChainStatus_t2329993372 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef X509ChainStatus_t2329993372  (*Func)(void* obj, const RuntimeMethod* method);
	X509ChainStatus_t2329993372  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Mark_t3306160088 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Mark_t3306160088  (*Func)(void* obj, const RuntimeMethod* method);
	Mark_t3306160088  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_UriScheme_t2520867868 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef UriScheme_t2520867868  (*Func)(void* obj, const RuntimeMethod* method);
	UriScheme_t2520867868  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_ContactPoint_t3765348581 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef ContactPoint_t3765348581  (*Func)(void* obj, const RuntimeMethod* method);
	ContactPoint_t3765348581  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Keyframe_t1047575712 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Keyframe_t1047575712  (*Func)(void* obj, const RuntimeMethod* method);
	Keyframe_t1047575712  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_PlayableBinding_t2470704133 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef PlayableBinding_t2470704133  (*Func)(void* obj, const RuntimeMethod* method);
	PlayableBinding_t2470704133  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RaycastHit_t2786726017 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RaycastHit_t2786726017  (*Func)(void* obj, const RuntimeMethod* method);
	RaycastHit_t2786726017  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_HitInfo_t2681867412 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef HitInfo_t2681867412  (*Func)(void* obj, const RuntimeMethod* method);
	HitInfo_t2681867412  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_DateTimeOffset_t3036919142_DateTimeOffset_t3036919142 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DateTimeOffset_t3036919142  p1, DateTimeOffset_t3036919142  p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((DateTimeOffset_t3036919142 *)args[0]), *((DateTimeOffset_t3036919142 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Int32_t438220675_Guid_t_Guid_t (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Guid_t  p1, Guid_t  p2, const RuntimeMethod* method);
	int32_t ret = ((Func)methodPointer)(obj, *((Guid_t *)args[0]), *((Guid_t *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t578375704_IntPtr_t_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DictionaryEntry_t578375704  (*Func)(void* obj, IntPtr_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	DictionaryEntry_t578375704  ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_IntPtr_t_RuntimeObject_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, IntPtr_t p1, RuntimeObject * p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_DictionaryEntry_t578375704_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DictionaryEntry_t578375704  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	DictionaryEntry_t578375704  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t2173232590_IntPtr_t_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t2173232590  (*Func)(void* obj, IntPtr_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	KeyValuePair_2_t2173232590  ret = ((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t2173232590_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t2173232590  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	KeyValuePair_2_t2173232590  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t578375704_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DictionaryEntry_t578375704  (*Func)(void* obj, RuntimeObject * p1, int8_t p2, const RuntimeMethod* method);
	DictionaryEntry_t578375704  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, RuntimeObject * p1, int8_t p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_KeyValuePair_2_t3674847205_RuntimeObject_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3674847205  (*Func)(void* obj, RuntimeObject * p1, int8_t p2, const RuntimeMethod* method);
	KeyValuePair_2_t3674847205  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int8_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3674847205_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3674847205  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	KeyValuePair_2_t3674847205  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t578375704_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef DictionaryEntry_t578375704  (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	DictionaryEntry_t578375704  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3710135120_RuntimeObject_Int32_t438220675 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3710135120  (*Func)(void* obj, RuntimeObject * p1, int32_t p2, const RuntimeMethod* method);
	KeyValuePair_2_t3710135120  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], *((int32_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3710135120_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3710135120  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	KeyValuePair_2_t3710135120  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3369932832_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef KeyValuePair_2_t3369932832  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	KeyValuePair_2_t3369932832  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Void_t1421048318_IntPtr_t_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, RuntimeObject * p2, const RuntimeMethod* method);
	((Func)methodPointer)(obj, *((IntPtr_t*)args[0]), (RuntimeObject *)args[1], methodMetadata);
	return NULL;
}

void* RuntimeInvoker_Enumerator_t1463273643 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t1463273643  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t1463273643  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_RuntimeObject_BooleanU26_t2626765736 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RuntimeObject * p1, bool* p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], (bool*)args[1], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Enumerator_t2964888258 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t2964888258  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t2964888258  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Enumerator_t3000176173 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t3000176173  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t3000176173  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_SByte_t1526744772_SByte_t1526744772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int8_t p1, int8_t p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_DateTimeOffset_t3036919142_DateTimeOffset_t3036919142 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DateTimeOffset_t3036919142  p1, DateTimeOffset_t3036919142  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((DateTimeOffset_t3036919142 *)args[0]), *((DateTimeOffset_t3036919142 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_CustomAttributeNamedArgument_t3456585787_CustomAttributeNamedArgument_t3456585787 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, CustomAttributeNamedArgument_t3456585787  p1, CustomAttributeNamedArgument_t3456585787  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((CustomAttributeNamedArgument_t3456585787 *)args[0]), *((CustomAttributeNamedArgument_t3456585787 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_CustomAttributeTypedArgument_t2066493570_CustomAttributeTypedArgument_t2066493570 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, CustomAttributeTypedArgument_t2066493570  p1, CustomAttributeTypedArgument_t2066493570  p2, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((CustomAttributeTypedArgument_t2066493570 *)args[0]), *((CustomAttributeTypedArgument_t2066493570 *)args[1]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Enumerator_t2760704772 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t2760704772  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t2760704772  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Enumerator_t1484102588 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t1484102588  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t1484102588  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Enumerator_t94010371 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t94010371  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t94010371  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Enumerator_t3073893368 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef Enumerator_t3073893368  (*Func)(void* obj, const RuntimeMethod* method);
	Enumerator_t3073893368  ret = ((Func)methodPointer)(obj, methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_CustomAttributeNamedArgument_t3456585787_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef CustomAttributeNamedArgument_t3456585787  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	CustomAttributeNamedArgument_t3456585787  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_CustomAttributeTypedArgument_t2066493570_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef CustomAttributeTypedArgument_t2066493570  (*Func)(void* obj, RuntimeObject * p1, const RuntimeMethod* method);
	CustomAttributeTypedArgument_t2066493570  ret = ((Func)methodPointer)(obj, (RuntimeObject *)args[0], methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_Boolean_t402932760_Nullable_1_t534706120 (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Nullable_1_t534706120  p1, const RuntimeMethod* method);
	bool ret = ((Func)methodPointer)(obj, *((Nullable_1_t534706120 *)args[0]), methodMetadata);
	return Box(il2cpp_codegen_class_from_type (il2cpp_codegen_method_return_type(methodMetadata)), &ret);
}

void* RuntimeInvoker_RuntimeObject_Scene_t2009218140_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Scene_t2009218140  p1, RuntimeObject * p2, RuntimeObject * p3, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Scene_t2009218140 *)args[0]), (RuntimeObject *)args[1], (RuntimeObject *)args[2], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Scene_t2009218140_Int32_t438220675_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Scene_t2009218140  p1, int32_t p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Scene_t2009218140 *)args[0]), *((int32_t*)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

void* RuntimeInvoker_RuntimeObject_Scene_t2009218140_Scene_t2009218140_RuntimeObject_RuntimeObject (Il2CppMethodPointer methodPointer, const RuntimeMethod* methodMetadata, void* obj, void** args)
{
	typedef RuntimeObject * (*Func)(void* obj, Scene_t2009218140  p1, Scene_t2009218140  p2, RuntimeObject * p3, RuntimeObject * p4, const RuntimeMethod* method);
	RuntimeObject * ret = ((Func)methodPointer)(obj, *((Scene_t2009218140 *)args[0]), *((Scene_t2009218140 *)args[1]), (RuntimeObject *)args[2], (RuntimeObject *)args[3], methodMetadata);
	return ret;
}

extern const InvokerMethod g_Il2CppInvokerPointers[1155] = 
{
	RuntimeInvoker_Void_t1421048318,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Int32_t438220675,
	RuntimeInvoker_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_ObjectU5BU5DU26_t1191207502,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_ObjectU5BU5DU26_t1191207502,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Byte_t1695016127_RuntimeObject,
	RuntimeInvoker_Char_t4217985068_RuntimeObject,
	RuntimeInvoker_DateTime_t3836236387_RuntimeObject,
	RuntimeInvoker_Decimal_t2382302464_RuntimeObject,
	RuntimeInvoker_Double_t3420139759_RuntimeObject,
	RuntimeInvoker_Int16_t674212087_RuntimeObject,
	RuntimeInvoker_Int64_t3733094498_RuntimeObject,
	RuntimeInvoker_SByte_t1526744772_RuntimeObject,
	RuntimeInvoker_Single_t3678960876_RuntimeObject,
	RuntimeInvoker_UInt16_t2530548644_RuntimeObject,
	RuntimeInvoker_UInt32_t1752406861_RuntimeObject,
	RuntimeInvoker_UInt64_t1261996727_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_SByte_t1526744772_RuntimeObject_Int32_t438220675_ExceptionU26_t832299025,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772_Int32U26_t3865694581_ExceptionU26_t832299025,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675_SByte_t1526744772_ExceptionU26_t832299025,
	RuntimeInvoker_Boolean_t402932760_Int32U26_t3865694581_RuntimeObject_SByte_t1526744772_SByte_t1526744772_ExceptionU26_t832299025,
	RuntimeInvoker_Void_t1421048318_Int32U26_t3865694581_RuntimeObject_RuntimeObject_BooleanU26_t2626765736_BooleanU26_t2626765736,
	RuntimeInvoker_Void_t1421048318_Int32U26_t3865694581_RuntimeObject_RuntimeObject_BooleanU26_t2626765736,
	RuntimeInvoker_Boolean_t402932760_Int32U26_t3865694581_RuntimeObject_Int32U26_t3865694581_SByte_t1526744772_ExceptionU26_t832299025,
	RuntimeInvoker_Boolean_t402932760_Int32U26_t3865694581_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_Int16_t674212087_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int32U26_t3865694581_ExceptionU26_t832299025,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32U26_t3865694581,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_Int32U26_t3865694581,
	RuntimeInvoker_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_Int64_t3733094498,
	RuntimeInvoker_Boolean_t402932760_Int64_t3733094498,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772_Int64U26_t4087886318_ExceptionU26_t832299025,
	RuntimeInvoker_Int64_t3733094498_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int64U26_t4087886318_ExceptionU26_t832299025,
	RuntimeInvoker_Int64_t3733094498_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int64U26_t4087886318,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_Int64U26_t4087886318,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772_UInt32U26_t95126587_ExceptionU26_t832299025,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_UInt32U26_t95126587_ExceptionU26_t832299025,
	RuntimeInvoker_UInt32_t1752406861_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_UInt32_t1752406861_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_UInt32U26_t95126587,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_UInt32U26_t95126587,
	RuntimeInvoker_UInt64_t1261996727_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_UInt64U26_t2262658145_ExceptionU26_t832299025,
	RuntimeInvoker_UInt64_t1261996727_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_UInt64U26_t2262658145,
	RuntimeInvoker_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_SByte_t1526744772,
	RuntimeInvoker_Byte_t1695016127_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Byte_t1695016127_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_ByteU26_t3759632281,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_ByteU26_t3759632281,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772_SByteU26_t78712284_ExceptionU26_t832299025,
	RuntimeInvoker_SByte_t1526744772_RuntimeObject_RuntimeObject,
	RuntimeInvoker_SByte_t1526744772_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByteU26_t78712284,
	RuntimeInvoker_Int32_t438220675_Int16_t674212087,
	RuntimeInvoker_Boolean_t402932760_Int16_t674212087,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772_Int16U26_t2810341409_ExceptionU26_t832299025,
	RuntimeInvoker_Int16_t674212087_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Int16_t674212087_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int16U26_t2810341409,
	RuntimeInvoker_UInt16_t2530548644_RuntimeObject_RuntimeObject,
	RuntimeInvoker_UInt16_t2530548644_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_UInt16U26_t1481886716,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_UInt16U26_t1481886716,
	RuntimeInvoker_Void_t1421048318_ByteU2AU26_t1130943835_ByteU2AU26_t1130943835_DoubleU2AU26_t4269392971_UInt16U2AU26_t2372128692_UInt16U2AU26_t2372128692_UInt16U2AU26_t2372128692_UInt16U2AU26_t2372128692,
	RuntimeInvoker_UnicodeCategory_t47276028_Int16_t674212087,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Char_t4217985068_Int16_t674212087,
	RuntimeInvoker_Char_t4217985068_Int16_t674212087_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int16_t674212087_Int32_t438220675,
	RuntimeInvoker_Char_t4217985068_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_SByte_t1526744772_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_Int16_t674212087_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_Int16_t674212087_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_Int16_t674212087,
	RuntimeInvoker_RuntimeObject_Int16_t674212087_Int16_t674212087,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32U26_t3865694581_Int32U26_t3865694581_Int32U26_t3865694581_BooleanU26_t2626765736_StringU26_t3235211963,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32U26_t3865694581,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int16_t674212087,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Int16_t674212087_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_Single_t3678960876,
	RuntimeInvoker_Boolean_t402932760_Single_t3678960876,
	RuntimeInvoker_Single_t3678960876_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_Double_t3420139759,
	RuntimeInvoker_Boolean_t402932760_Double_t3420139759,
	RuntimeInvoker_Double_t3420139759_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Double_t3420139759_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_DoubleU26_t4267954921_ExceptionU26_t832299025,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_DoubleU26_t4267954921,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_Single_t3678960876,
	RuntimeInvoker_Void_t1421048318_Double_t3420139759,
	RuntimeInvoker_RuntimeObject_Decimal_t2382302464,
	RuntimeInvoker_Decimal_t2382302464_Decimal_t2382302464_Decimal_t2382302464,
	RuntimeInvoker_UInt64_t1261996727_Decimal_t2382302464,
	RuntimeInvoker_Int64_t3733094498_Decimal_t2382302464,
	RuntimeInvoker_Boolean_t402932760_Decimal_t2382302464_Decimal_t2382302464,
	RuntimeInvoker_Decimal_t2382302464_Decimal_t2382302464,
	RuntimeInvoker_Int32_t438220675_Decimal_t2382302464_Decimal_t2382302464,
	RuntimeInvoker_Int32_t438220675_Decimal_t2382302464,
	RuntimeInvoker_Boolean_t402932760_Decimal_t2382302464,
	RuntimeInvoker_Decimal_t2382302464_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_Int32U26_t3865694581_BooleanU26_t2626765736_BooleanU26_t2626765736_Int32U26_t3865694581_SByte_t1526744772,
	RuntimeInvoker_Decimal_t2382302464_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_DecimalU26_t72776448_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_UInt64U26_t2262658145,
	RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_Int64U26_t4087886318,
	RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_DecimalU26_t72776448,
	RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_Int32_t438220675,
	RuntimeInvoker_Double_t3420139759_DecimalU26_t72776448,
	RuntimeInvoker_Void_t1421048318_DecimalU26_t72776448_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_DecimalU26_t72776448_DecimalU26_t72776448_DecimalU26_t72776448,
	RuntimeInvoker_Byte_t1695016127_Decimal_t2382302464,
	RuntimeInvoker_SByte_t1526744772_Decimal_t2382302464,
	RuntimeInvoker_Int16_t674212087_Decimal_t2382302464,
	RuntimeInvoker_UInt16_t2530548644_Decimal_t2382302464,
	RuntimeInvoker_UInt32_t1752406861_Decimal_t2382302464,
	RuntimeInvoker_Decimal_t2382302464_SByte_t1526744772,
	RuntimeInvoker_Decimal_t2382302464_Int16_t674212087,
	RuntimeInvoker_Decimal_t2382302464_Int32_t438220675,
	RuntimeInvoker_Decimal_t2382302464_Int64_t3733094498,
	RuntimeInvoker_Decimal_t2382302464_Single_t3678960876,
	RuntimeInvoker_Decimal_t2382302464_Double_t3420139759,
	RuntimeInvoker_Single_t3678960876_Decimal_t2382302464,
	RuntimeInvoker_Double_t3420139759_Decimal_t2382302464,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_StreamingContext_t885793295,
	RuntimeInvoker_Int64_t3733094498,
	RuntimeInvoker_Boolean_t402932760_IntPtr_t_IntPtr_t,
	RuntimeInvoker_IntPtr_t_Int32_t438220675,
	RuntimeInvoker_IntPtr_t_Int64_t3733094498,
	RuntimeInvoker_IntPtr_t_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_IntPtr_t,
	RuntimeInvoker_RuntimeObject_IntPtr_t,
	RuntimeInvoker_UInt32_t1752406861,
	RuntimeInvoker_UInt64_t1261996727,
	RuntimeInvoker_UInt64_t1261996727_IntPtr_t,
	RuntimeInvoker_UInt32_t1752406861_IntPtr_t,
	RuntimeInvoker_UIntPtr_t_Int64_t3733094498,
	RuntimeInvoker_UIntPtr_t_RuntimeObject,
	RuntimeInvoker_UIntPtr_t_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_MulticastDelegateU26_t985825394,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_TypeCode_t842513060,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_UInt64_t1261996727_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int16_t674212087,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Int64_t3733094498_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Int64_t3733094498,
	RuntimeInvoker_RuntimeObject_Int64_t3733094498_Int64_t3733094498,
	RuntimeInvoker_RuntimeObject_Int64_t3733094498_Int64_t3733094498_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498_Int64_t3733094498_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498_RuntimeObject_Int64_t3733094498_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int64_t3733094498,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_IntPtr_t,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_TypeAttributes_t1669384266,
	RuntimeInvoker_MemberTypes_t1145889401,
	RuntimeInvoker_RuntimeTypeHandle_t1361003276,
	RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_TypeCode_t842513060_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeTypeHandle_t1361003276,
	RuntimeInvoker_RuntimeTypeHandle_t1361003276_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_IntPtr_t,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeFieldHandle_t2492430303,
	RuntimeInvoker_Void_t1421048318_IntPtr_t_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_ContractionU5BU5DU26_t4268913570_Level2MapU5BU5DU26_t1141995020,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_CodePointIndexerU26_t3199325781_ByteU2AU26_t1130943835_ByteU2AU26_t1130943835_CodePointIndexerU26_t3199325781_ByteU2AU26_t1130943835,
	RuntimeInvoker_Byte_t1695016127_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_UInt32_t1752406861_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Byte_t1695016127_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_ExtenderType_t2570490418_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_BooleanU26_t2626765736_BooleanU26_t2626765736_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_BooleanU26_t2626765736_BooleanU26_t2626765736_SByte_t1526744772_SByte_t1526744772_ContextU26_t3128925157,
	RuntimeInvoker_Int32_t438220675_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_ContextU26_t3128925157,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_BooleanU26_t2626765736,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int16_t674212087_Int32_t438220675_SByte_t1526744772_ContextU26_t3128925157,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_ContextU26_t3128925157,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_SByte_t1526744772_ContextU26_t3128925157,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_ContextU26_t3128925157,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int32_t438220675_ContractionU26_t3984666465_ContextU26_t3128925157,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_ContextU26_t3128925157,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int32_t438220675_ContractionU26_t3984666465_ContextU26_t3128925157,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_ByteU5BU5DU26_t1884214154_Int32U26_t3865694581,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_ConfidenceFactor_t1730967935,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Sign_t170185131_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_DSAParameters_t4013484323_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_DSAParameters_t4013484323,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_RuntimeObject_RuntimeObject_DSAParameters_t4013484323,
	RuntimeInvoker_RSAParameters_t3314567386_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RSAParameters_t3314567386,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_DSAParameters_t4013484323_BooleanU26_t2626765736,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_DateTime_t3836236387,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_RuntimeObject,
	RuntimeInvoker_Byte_t1695016127,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32U26_t3865694581_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32U26_t3865694581_ByteU26_t3759632281_Int32U26_t3865694581_ByteU5BU5DU26_t1884214154,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Int16_t674212087_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Single_t3678960876_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Double_t3420139759_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Int16_t674212087_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Single_t3678960876_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Single_t3678960876,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Single_t3678960876_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Single_t3678960876_RuntimeObject,
	RuntimeInvoker_DictionaryEntry_t578375704,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675_SByte_t1526744772_MethodBaseU26_t1836863182_Int32U26_t3865694581_Int32U26_t3865694581_StringU26_t3235211963_Int32U26_t3865694581_Int32U26_t3865694581,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_DateTime_t3836236387,
	RuntimeInvoker_DayOfWeek_t1380878247_DateTime_t3836236387,
	RuntimeInvoker_Int32_t438220675_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_DayOfWeek_t1380878247_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32U26_t3865694581_Int32U26_t3865694581_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32U26_t3865694581_Int32U26_t3865694581_Int32U26_t3865694581_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_RuntimeObject_Int16_t674212087,
	RuntimeInvoker_Void_t1421048318_DateTime_t3836236387_DateTime_t3836236387_TimeSpan_t4182925364,
	RuntimeInvoker_TimeSpan_t4182925364,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32U26_t3865694581,
	RuntimeInvoker_Char_t4217985068,
	RuntimeInvoker_Decimal_t2382302464,
	RuntimeInvoker_Double_t3420139759,
	RuntimeInvoker_Int16_t674212087,
	RuntimeInvoker_SByte_t1526744772,
	RuntimeInvoker_Single_t3678960876,
	RuntimeInvoker_UInt16_t2530548644,
	RuntimeInvoker_Void_t1421048318_IntPtr_t_Int32_t438220675_SByte_t1526744772_Int32_t438220675_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Int64_t3733094498_Int64_t3733094498_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_IntPtr_t_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_MonoIOErrorU26_t58253910,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_MonoIOErrorU26_t58253910,
	RuntimeInvoker_RuntimeObject_MonoIOErrorU26_t58253910,
	RuntimeInvoker_FileAttributes_t4239897840_RuntimeObject_MonoIOErrorU26_t58253910,
	RuntimeInvoker_MonoFileType_t2806097864_IntPtr_t_MonoIOErrorU26_t58253910,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_MonoIOStatU26_t2472808464_MonoIOErrorU26_t58253910,
	RuntimeInvoker_IntPtr_t_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_MonoIOErrorU26_t58253910,
	RuntimeInvoker_Boolean_t402932760_IntPtr_t_MonoIOErrorU26_t58253910,
	RuntimeInvoker_Int32_t438220675_IntPtr_t_RuntimeObject_Int32_t438220675_Int32_t438220675_MonoIOErrorU26_t58253910,
	RuntimeInvoker_Int64_t3733094498_IntPtr_t_Int64_t3733094498_Int32_t438220675_MonoIOErrorU26_t58253910,
	RuntimeInvoker_Int64_t3733094498_IntPtr_t_MonoIOErrorU26_t58253910,
	RuntimeInvoker_Boolean_t402932760_IntPtr_t_Int64_t3733094498_MonoIOErrorU26_t58253910,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_StringU26_t3235211963,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_SByte_t1526744772_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int16_t674212087,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_CallingConventions_t369066136,
	RuntimeInvoker_RuntimeMethodHandle_t4063774698,
	RuntimeInvoker_MethodAttributes_t1488178787,
	RuntimeInvoker_MethodToken_t1418749877,
	RuntimeInvoker_FieldAttributes_t1558435749,
	RuntimeInvoker_RuntimeFieldHandle_t2492430303,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_OpCode_t1117422012,
	RuntimeInvoker_Void_t1421048318_OpCode_t1117422012_RuntimeObject,
	RuntimeInvoker_StackBehaviour_t2397757739,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_SByte_t1526744772_RuntimeObject,
	RuntimeInvoker_IntPtr_t_RuntimeObject_Int32U26_t3865694581_ModuleU26_t2021568637,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_AssemblyNameFlags_t1966831008,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_ObjectU5BU5DU26_t1191207502_RuntimeObject_RuntimeObject_RuntimeObject_ObjectU26_t1561828645,
	RuntimeInvoker_Void_t1421048318_ObjectU5BU5DU26_t1191207502_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_ObjectU5BU5DU26_t1191207502_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_EventAttributes_t1919574847,
	RuntimeInvoker_RuntimeObject_IntPtr_t_IntPtr_t,
	RuntimeInvoker_RuntimeObject_RuntimeFieldHandle_t2492430303,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_RuntimeObject_StreamingContext_t885793295,
	RuntimeInvoker_RuntimeObject_RuntimeMethodHandle_t4063774698,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_MonoEventInfoU26_t2960910389,
	RuntimeInvoker_MonoEventInfo_t2799518403_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_IntPtr_t_MonoMethodInfoU26_t828076379,
	RuntimeInvoker_MonoMethodInfo_t2273945901_IntPtr_t,
	RuntimeInvoker_MethodAttributes_t1488178787_IntPtr_t,
	RuntimeInvoker_CallingConventions_t369066136_IntPtr_t,
	RuntimeInvoker_RuntimeObject_IntPtr_t_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_ExceptionU26_t832299025,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_MonoPropertyInfoU26_t494941656_Int32_t438220675,
	RuntimeInvoker_PropertyAttributes_t974795916,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_ParameterAttributes_t2464461462,
	RuntimeInvoker_Void_t1421048318_Int64_t3733094498_ResourceInfoU26_t2935277467,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498_Int32_t438220675,
	RuntimeInvoker_GCHandle_t2291726809_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_IntPtr_t_Int32_t438220675_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_IntPtr_t_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Byte_t1695016127_IntPtr_t_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_IntPtr_t_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_BooleanU26_t2626765736,
	RuntimeInvoker_Void_t1421048318_IntPtr_t,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_StringU26_t3235211963,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_StringU26_t3235211963,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_RuntimeObject_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_TimeSpan_t4182925364,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Byte_t1695016127,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_SByte_t1526744772_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_StreamingContext_t885793295_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_StreamingContext_t885793295_ISurrogateSelectorU26_t1457704766,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_IntPtr_t_RuntimeObject,
	RuntimeInvoker_TimeSpan_t4182925364_RuntimeObject,
	RuntimeInvoker_RuntimeObject_StringU26_t3235211963,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_ObjectU26_t1561828645,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_StringU26_t3235211963_StringU26_t3235211963,
	RuntimeInvoker_WellKnownObjectMode_t653959841,
	RuntimeInvoker_StreamingContext_t885793295,
	RuntimeInvoker_TypeFilterLevel_t1430716943,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_BooleanU26_t2626765736,
	RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_ObjectU26_t1561828645_HeaderU5BU5DU26_t931609082,
	RuntimeInvoker_Void_t1421048318_Byte_t1695016127_RuntimeObject_SByte_t1526744772_ObjectU26_t1561828645_HeaderU5BU5DU26_t931609082,
	RuntimeInvoker_Boolean_t402932760_Byte_t1695016127_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Byte_t1695016127_RuntimeObject_Int64U26_t4087886318_ObjectU26_t1561828645_SerializationInfoU26_t1740520373,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_SByte_t1526744772_Int64U26_t4087886318_ObjectU26_t1561828645_SerializationInfoU26_t1740520373,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64U26_t4087886318_ObjectU26_t1561828645_SerializationInfoU26_t1740520373,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int64_t3733094498_ObjectU26_t1561828645_SerializationInfoU26_t1740520373,
	RuntimeInvoker_Void_t1421048318_Int64_t3733094498_RuntimeObject_RuntimeObject_Int64_t3733094498_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64U26_t4087886318_ObjectU26_t1561828645,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int64U26_t4087886318_ObjectU26_t1561828645,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int64_t3733094498_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int64_t3733094498_Int64_t3733094498_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Int64_t3733094498_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Byte_t1695016127,
	RuntimeInvoker_Void_t1421048318_Int64_t3733094498_Int32_t438220675_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_Int64_t3733094498_RuntimeObject_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int64_t3733094498_RuntimeObject_Int64_t3733094498_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_SByte_t1526744772_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_StreamingContext_t885793295,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_StreamingContext_t885793295,
	RuntimeInvoker_Void_t1421048318_StreamingContext_t885793295,
	RuntimeInvoker_RuntimeObject_StreamingContext_t885793295_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int16_t674212087,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_DateTime_t3836236387,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Single_t3678960876,
	RuntimeInvoker_SerializationEntry_t2018126969,
	RuntimeInvoker_StreamingContextStates_t317203920,
	RuntimeInvoker_CspProviderFlags_t613247746,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject,
	RuntimeInvoker_UInt32_t1752406861_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_Int64_t3733094498_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_UInt32_t1752406861_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_UInt32U26_t95126587_Int32_t438220675_UInt32U26_t95126587_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_IntPtr_t_IntPtr_t_RuntimeObject,
	RuntimeInvoker_UInt32_t1752406861_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int64_t3733094498_Int64_t3733094498,
	RuntimeInvoker_UInt64_t1261996727_Int64_t3733094498_Int32_t438220675,
	RuntimeInvoker_UInt64_t1261996727_Int64_t3733094498_Int64_t3733094498_Int64_t3733094498,
	RuntimeInvoker_UInt64_t1261996727_Int64_t3733094498,
	RuntimeInvoker_CipherMode_t1510653764,
	RuntimeInvoker_PaddingMode_t927572615,
	RuntimeInvoker_Void_t1421048318_StringBuilderU26_t1573624750_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_IntPtr_t_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_EncoderFallbackBufferU26_t2317053607_CharU5BU5DU26_t228440995,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_DecoderFallbackBufferU26_t2638252675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Int16_t674212087_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Int16_t674212087_Int16_t674212087_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int16_t674212087_Int16_t674212087_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Int32U26_t3865694581,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_Int32_t438220675_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_SByte_t1526744772_Int32U26_t3865694581_BooleanU26_t2626765736_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32U26_t3865694581,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_CharU26_t1135874228_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_CharU26_t1135874228_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_CharU26_t1135874228_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_CharU26_t1135874228_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_RuntimeObject_Int64_t3733094498_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_RuntimeObject_Int64_t3733094498_Int32_t438220675_RuntimeObject_Int32U26_t3865694581,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32_t438220675_UInt32U26_t95126587_UInt32U26_t95126587_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_Int32_t438220675_UInt32U26_t95126587_UInt32U26_t95126587_RuntimeObject_DecoderFallbackBufferU26_t2638252675_ByteU5BU5DU26_t1884214154_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_Int32_t438220675,
	RuntimeInvoker_Single_t3678960876_SingleU26_t3887057396_Single_t3678960876_Single_t3678960876,
	RuntimeInvoker_IntPtr_t_SByte_t1526744772_RuntimeObject_BooleanU26_t2626765736,
	RuntimeInvoker_Boolean_t402932760_IntPtr_t,
	RuntimeInvoker_IntPtr_t_SByte_t1526744772_SByte_t1526744772_RuntimeObject_BooleanU26_t2626765736,
	RuntimeInvoker_Boolean_t402932760_TimeSpan_t4182925364_TimeSpan_t4182925364,
	RuntimeInvoker_Boolean_t402932760_Int64_t3733094498_Int64_t3733094498_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_IntPtr_t_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Int64_t3733094498_Double_t3420139759,
	RuntimeInvoker_RuntimeObject_Double_t3420139759,
	RuntimeInvoker_Int64_t3733094498_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_IntPtr_t_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Byte_t1695016127_SByte_t1526744772,
	RuntimeInvoker_Byte_t1695016127_Int16_t674212087,
	RuntimeInvoker_Byte_t1695016127_Double_t3420139759,
	RuntimeInvoker_Byte_t1695016127_Single_t3678960876,
	RuntimeInvoker_Byte_t1695016127_Int64_t3733094498,
	RuntimeInvoker_Char_t4217985068_SByte_t1526744772,
	RuntimeInvoker_Char_t4217985068_Int64_t3733094498,
	RuntimeInvoker_Char_t4217985068_Single_t3678960876,
	RuntimeInvoker_Char_t4217985068_RuntimeObject_RuntimeObject,
	RuntimeInvoker_DateTime_t3836236387_RuntimeObject_RuntimeObject,
	RuntimeInvoker_DateTime_t3836236387_Int16_t674212087,
	RuntimeInvoker_DateTime_t3836236387_Int32_t438220675,
	RuntimeInvoker_DateTime_t3836236387_Int64_t3733094498,
	RuntimeInvoker_DateTime_t3836236387_Single_t3678960876,
	RuntimeInvoker_DateTime_t3836236387_SByte_t1526744772,
	RuntimeInvoker_Double_t3420139759_SByte_t1526744772,
	RuntimeInvoker_Double_t3420139759_Double_t3420139759,
	RuntimeInvoker_Double_t3420139759_Single_t3678960876,
	RuntimeInvoker_Double_t3420139759_Int32_t438220675,
	RuntimeInvoker_Double_t3420139759_Int64_t3733094498,
	RuntimeInvoker_Double_t3420139759_Int16_t674212087,
	RuntimeInvoker_Int16_t674212087_SByte_t1526744772,
	RuntimeInvoker_Int16_t674212087_Int16_t674212087,
	RuntimeInvoker_Int16_t674212087_Double_t3420139759,
	RuntimeInvoker_Int16_t674212087_Single_t3678960876,
	RuntimeInvoker_Int16_t674212087_Int32_t438220675,
	RuntimeInvoker_Int16_t674212087_Int64_t3733094498,
	RuntimeInvoker_Int64_t3733094498_SByte_t1526744772,
	RuntimeInvoker_Int64_t3733094498_Int16_t674212087,
	RuntimeInvoker_Int64_t3733094498_Single_t3678960876,
	RuntimeInvoker_Int64_t3733094498_Int64_t3733094498,
	RuntimeInvoker_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_SByte_t1526744772_Int16_t674212087,
	RuntimeInvoker_SByte_t1526744772_Double_t3420139759,
	RuntimeInvoker_SByte_t1526744772_Single_t3678960876,
	RuntimeInvoker_SByte_t1526744772_Int32_t438220675,
	RuntimeInvoker_SByte_t1526744772_Int64_t3733094498,
	RuntimeInvoker_Single_t3678960876_SByte_t1526744772,
	RuntimeInvoker_Single_t3678960876_Double_t3420139759,
	RuntimeInvoker_Single_t3678960876_Single_t3678960876,
	RuntimeInvoker_Single_t3678960876_Int32_t438220675,
	RuntimeInvoker_Single_t3678960876_Int64_t3733094498,
	RuntimeInvoker_Single_t3678960876_Int16_t674212087,
	RuntimeInvoker_UInt16_t2530548644_SByte_t1526744772,
	RuntimeInvoker_UInt16_t2530548644_Int16_t674212087,
	RuntimeInvoker_UInt16_t2530548644_Double_t3420139759,
	RuntimeInvoker_UInt16_t2530548644_Single_t3678960876,
	RuntimeInvoker_UInt16_t2530548644_Int32_t438220675,
	RuntimeInvoker_UInt16_t2530548644_Int64_t3733094498,
	RuntimeInvoker_UInt32_t1752406861_SByte_t1526744772,
	RuntimeInvoker_UInt32_t1752406861_Int16_t674212087,
	RuntimeInvoker_UInt32_t1752406861_Double_t3420139759,
	RuntimeInvoker_UInt32_t1752406861_Single_t3678960876,
	RuntimeInvoker_UInt32_t1752406861_Int64_t3733094498,
	RuntimeInvoker_UInt64_t1261996727_SByte_t1526744772,
	RuntimeInvoker_UInt64_t1261996727_Int16_t674212087,
	RuntimeInvoker_UInt64_t1261996727_Double_t3420139759,
	RuntimeInvoker_UInt64_t1261996727_Single_t3678960876,
	RuntimeInvoker_UInt64_t1261996727_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_TimeSpan_t4182925364,
	RuntimeInvoker_Void_t1421048318_Int64_t3733094498_Int32_t438220675,
	RuntimeInvoker_DayOfWeek_t1380878247,
	RuntimeInvoker_DateTimeKind_t588365666,
	RuntimeInvoker_DateTime_t3836236387_TimeSpan_t4182925364,
	RuntimeInvoker_DateTime_t3836236387_Double_t3420139759,
	RuntimeInvoker_Int32_t438220675_DateTime_t3836236387_DateTime_t3836236387,
	RuntimeInvoker_Boolean_t402932760_DateTime_t3836236387,
	RuntimeInvoker_DateTime_t3836236387_DateTime_t3836236387_Int32_t438220675,
	RuntimeInvoker_DateTime_t3836236387_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_Int32_t438220675_DateTimeU26_t636467605_DateTimeOffsetU26_t2503273354_SByte_t1526744772_ExceptionU26_t832299025,
	RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_ExceptionU26_t832299025,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772_Int32U26_t3865694581,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject_SByte_t1526744772_Int32U26_t3865694581,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_Int32U26_t3865694581,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int32U26_t3865694581_Int32U26_t3865694581,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772_Int32U26_t3865694581,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject_SByte_t1526744772_DateTimeU26_t636467605_DateTimeOffsetU26_t2503273354_RuntimeObject_Int32_t438220675_SByte_t1526744772_BooleanU26_t2626765736_BooleanU26_t2626765736,
	RuntimeInvoker_DateTime_t3836236387_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_DateTimeU26_t636467605_SByte_t1526744772_BooleanU26_t2626765736_SByte_t1526744772_ExceptionU26_t832299025,
	RuntimeInvoker_DateTime_t3836236387_DateTime_t3836236387_TimeSpan_t4182925364,
	RuntimeInvoker_Boolean_t402932760_DateTime_t3836236387_DateTime_t3836236387,
	RuntimeInvoker_Void_t1421048318_DateTime_t3836236387,
	RuntimeInvoker_Void_t1421048318_DateTime_t3836236387_TimeSpan_t4182925364,
	RuntimeInvoker_Void_t1421048318_Int64_t3733094498_TimeSpan_t4182925364,
	RuntimeInvoker_Int32_t438220675_DateTimeOffset_t3036919142,
	RuntimeInvoker_Boolean_t402932760_DateTimeOffset_t3036919142,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int16_t674212087,
	RuntimeInvoker_RuntimeObject_Int16_t674212087_RuntimeObject_BooleanU26_t2626765736_BooleanU26_t2626765736,
	RuntimeInvoker_RuntimeObject_Int16_t674212087_RuntimeObject_BooleanU26_t2626765736_BooleanU26_t2626765736_SByte_t1526744772,
	RuntimeInvoker_RuntimeObject_DateTime_t3836236387_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_DateTime_t3836236387_Nullable_1_t534706120_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_MonoEnumInfo_t2659694797,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_MonoEnumInfoU26_t2719236795,
	RuntimeInvoker_Int32_t438220675_Int16_t674212087_Int16_t674212087,
	RuntimeInvoker_Int32_t438220675_Int64_t3733094498_Int64_t3733094498,
	RuntimeInvoker_PlatformID_t1036322677,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int16_t674212087_Int16_t674212087_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int16_t674212087_Int16_t674212087_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Int32_t438220675_Guid_t,
	RuntimeInvoker_Boolean_t402932760_Guid_t,
	RuntimeInvoker_Guid_t,
	RuntimeInvoker_RuntimeObject_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_Guid_t_Guid_t,
	RuntimeInvoker_UInt64_t1261996727_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Double_t3420139759_Double_t3420139759_Double_t3420139759,
	RuntimeInvoker_TypeAttributes_t1669384266_RuntimeObject,
	RuntimeInvoker_RuntimeObject_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_UInt64U2AU26_t2381774899_Int32U2AU26_t813507759_CharU2AU26_t1963721052_CharU2AU26_t1963721052_Int64U2AU26_t1594636970_Int32U2AU26_t813507759,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Double_t3420139759_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Decimal_t2382302464,
	RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int16_t674212087_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int64_t3733094498_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Single_t3678960876_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Double_t3420139759_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Decimal_t2382302464_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Single_t3678960876_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Double_t3420139759_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_BooleanU26_t2626765736_SByte_t1526744772_Int32U26_t3865694581_Int32U26_t3865694581,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int64_t3733094498_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_TimeSpan_t4182925364_TimeSpan_t4182925364,
	RuntimeInvoker_Int32_t438220675_TimeSpan_t4182925364_TimeSpan_t4182925364,
	RuntimeInvoker_Int32_t438220675_TimeSpan_t4182925364,
	RuntimeInvoker_Boolean_t402932760_TimeSpan_t4182925364,
	RuntimeInvoker_TimeSpan_t4182925364_Double_t3420139759,
	RuntimeInvoker_TimeSpan_t4182925364_Double_t3420139759_Int64_t3733094498,
	RuntimeInvoker_TimeSpan_t4182925364_TimeSpan_t4182925364_TimeSpan_t4182925364,
	RuntimeInvoker_TimeSpan_t4182925364_DateTime_t3836236387,
	RuntimeInvoker_Boolean_t402932760_DateTime_t3836236387_RuntimeObject,
	RuntimeInvoker_DateTime_t3836236387_DateTime_t3836236387,
	RuntimeInvoker_TimeSpan_t4182925364_DateTime_t3836236387_TimeSpan_t4182925364,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int64U5BU5DU26_t3676363841_StringU5BU5DU26_t3807653280,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_DictionaryNodeU26_t319976545,
	RuntimeInvoker_EditorBrowsableState_t2901581142,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_IPAddressU26_t2963932792,
	RuntimeInvoker_AddressFamily_t450096203,
	RuntimeInvoker_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_IPv6AddressU26_t2543423675,
	RuntimeInvoker_SecurityProtocolType_t2871506216,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_SByte_t1526744772_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_AsnDecodeStatus_t361668025_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_X509ChainStatusFlags_t3387568385_RuntimeObject,
	RuntimeInvoker_X509ChainStatusFlags_t3387568385_RuntimeObject_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_X509ChainStatusFlags_t3387568385_RuntimeObject_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_X509ChainStatusFlags_t3387568385,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_X509RevocationFlag_t3862259269,
	RuntimeInvoker_X509RevocationMode_t1666302436,
	RuntimeInvoker_X509VerificationFlags_t2857382038,
	RuntimeInvoker_X509KeyUsageFlags_t2405450781,
	RuntimeInvoker_X509KeyUsageFlags_t2405450781_Int32_t438220675,
	RuntimeInvoker_Byte_t1695016127_Int16_t674212087_Int16_t674212087,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RegexOptions_t1904484159,
	RuntimeInvoker_Category_t326181340_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_UInt16_t2530548644_Int16_t674212087,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int16_t674212087,
	RuntimeInvoker_Void_t1421048318_Int16_t674212087_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_UInt16_t2530548644_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_Int16_t674212087_Int16_t674212087_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_Int16_t674212087_RuntimeObject_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_UInt16_t2530548644,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_SByte_t1526744772_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_SByte_t1526744772_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_UInt16_t2530548644_UInt16_t2530548644_UInt16_t2530548644,
	RuntimeInvoker_OpFlags_t871130963_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_UInt16_t2530548644_UInt16_t2530548644,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int32U26_t3865694581_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int32U26_t3865694581_Int32U26_t3865694581_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_Int32U26_t3865694581_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_UInt16_t2530548644_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Int32_t438220675_Int32_t438220675_SByte_t1526744772_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32U26_t3865694581_Int32U26_t3865694581,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_Int32_t438220675,
	RuntimeInvoker_Interval_t176111467,
	RuntimeInvoker_Boolean_t402932760_Interval_t176111467,
	RuntimeInvoker_Void_t1421048318_Interval_t176111467,
	RuntimeInvoker_Interval_t176111467_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Double_t3420139759_Interval_t176111467,
	RuntimeInvoker_RuntimeObject_Interval_t176111467_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32U26_t3865694581_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32U26_t3865694581_Int32_t438220675_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Int32U26_t3865694581,
	RuntimeInvoker_RuntimeObject_RegexOptionsU26_t2263882009,
	RuntimeInvoker_Void_t1421048318_RegexOptionsU26_t2263882009_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_Int32U26_t3865694581_Int32U26_t3865694581_Int32_t438220675,
	RuntimeInvoker_Category_t326181340,
	RuntimeInvoker_Void_t1421048318_Int32U26_t3865694581_Int32U26_t3865694581,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_UInt16_t2530548644_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_Int16_t674212087_Int16_t674212087,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int32_t438220675_UInt16_t2530548644,
	RuntimeInvoker_Position_t731461718,
	RuntimeInvoker_UriHostNameType_t1012973887_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_StringU26_t3235211963,
	RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Char_t4217985068_RuntimeObject_Int32U26_t3865694581_CharU26_t1135874228,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_UriFormatExceptionU26_t1650653223,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Sign_t170185132_RuntimeObject_RuntimeObject,
	RuntimeInvoker_ConfidenceFactor_t1730967936,
	RuntimeInvoker_UInt32_t1752406861_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_UInt32U26_t95126587_Int32_t438220675_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_X509ChainStatusFlags_t2964126077,
	RuntimeInvoker_Void_t1421048318_Byte_t1695016127,
	RuntimeInvoker_Void_t1421048318_Byte_t1695016127_Byte_t1695016127,
	RuntimeInvoker_AlertLevel_t393210211,
	RuntimeInvoker_AlertDescription_t1388230643,
	RuntimeInvoker_RuntimeObject_Byte_t1695016127,
	RuntimeInvoker_Void_t1421048318_Int16_t674212087_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_Int16_t674212087_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_CipherAlgorithmType_t976551082,
	RuntimeInvoker_HashAlgorithmType_t1587630734,
	RuntimeInvoker_ExchangeAlgorithmType_t3448911736,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int16_t674212087,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_Int64_t3733094498,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_ByteU5BU5DU26_t1884214154_ByteU5BU5DU26_t1884214154,
	RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Int16_t674212087_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_Int16_t674212087_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_SecurityProtocolType_t1676794907,
	RuntimeInvoker_SecurityCompressionType_t3510785785,
	RuntimeInvoker_HandshakeType_t1042630806,
	RuntimeInvoker_HandshakeState_t386269849,
	RuntimeInvoker_SecurityProtocolType_t1676794907_Int16_t674212087,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Byte_t1695016127_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Byte_t1695016127_RuntimeObject_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_SByte_t1526744772_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_Int32_t438220675_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Void_t1421048318_Byte_t1695016127_Byte_t1695016127_RuntimeObject,
	RuntimeInvoker_RSAParameters_t3314567386,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Byte_t1695016127_Byte_t1695016127,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Byte_t1695016127_RuntimeObject,
	RuntimeInvoker_ContentType_t2215461912,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Rect_t1940963286,
	RuntimeInvoker_Void_t1421048318_RectU26_t3852249754,
	RuntimeInvoker_CameraClearFlags_t1620199384,
	RuntimeInvoker_Ray_t3298836202_Vector3_t2987449647,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Vector3U26_t1054175401_RayU26_t3897443494,
	RuntimeInvoker_RuntimeObject_Ray_t3298836202_Single_t3678960876_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RayU26_t3897443494_Single_t3678960876_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_IntPtr_t_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_CullingGroupEvent_t3626597461,
	RuntimeInvoker_RuntimeObject_CullingGroupEvent_t3626597461_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_SByte_t1526744772_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Vector3_t2987449647,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Vector3U26_t1054175401,
	RuntimeInvoker_Vector3_t2987449647,
	RuntimeInvoker_Void_t1421048318_Vector3U26_t1054175401,
	RuntimeInvoker_Void_t1421048318_Single_t3678960876_Single_t3678960876_Single_t3678960876,
	RuntimeInvoker_Vector3_t2987449647_Vector3_t2987449647_Vector3_t2987449647,
	RuntimeInvoker_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876,
	RuntimeInvoker_Vector3_t2987449647_Single_t3678960876_Vector3_t2987449647,
	RuntimeInvoker_Void_t1421048318_Single_t3678960876_Single_t3678960876_Single_t3678960876_Single_t3678960876,
	RuntimeInvoker_Quaternion_t895809378_Quaternion_t895809378,
	RuntimeInvoker_Void_t1421048318_QuaternionU26_t1376965358_QuaternionU26_t1376965358,
	RuntimeInvoker_Void_t1421048318_Vector3_t2987449647,
	RuntimeInvoker_Quaternion_t895809378_Single_t3678960876_Single_t3678960876_Single_t3678960876,
	RuntimeInvoker_Quaternion_t895809378_Vector3_t2987449647,
	RuntimeInvoker_Void_t1421048318_Vector3U26_t1054175401_QuaternionU26_t1376965358,
	RuntimeInvoker_Quaternion_t895809378_Quaternion_t895809378_Quaternion_t895809378,
	RuntimeInvoker_Single_t3678960876_Single_t3678960876_Single_t3678960876,
	RuntimeInvoker_Boolean_t402932760_Single_t3678960876_Single_t3678960876,
	RuntimeInvoker_Void_t1421048318_Single_t3678960876_Single_t3678960876,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Single_t3678960876_Single_t3678960876,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Vector3_t2987449647_Quaternion_t895809378,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Vector3U26_t1054175401_QuaternionU26_t1376965358,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Vector3_t2987449647_Quaternion_t895809378,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_Vector3U26_t1054175401_QuaternionU26_t1376965358,
	RuntimeInvoker_HideFlags_t1270484704,
	RuntimeInvoker_RuntimeObject_RuntimeObject_Vector3_t2987449647_Quaternion_t895809378_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_PlayableHandleU26_t2838161302,
	RuntimeInvoker_RuntimeObject_PlayableHandleU26_t2838161302,
	RuntimeInvoker_PlayableHandle_t2910061178,
	RuntimeInvoker_PlayState_t540826789,
	RuntimeInvoker_PlayState_t540826789_PlayableHandleU26_t2838161302,
	RuntimeInvoker_Void_t1421048318_PlayableHandleU26_t2838161302_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_PlayableHandleU26_t2838161302_Double_t3420139759,
	RuntimeInvoker_Boolean_t402932760_PlayableHandle_t2910061178_PlayableHandle_t2910061178,
	RuntimeInvoker_Void_t1421048318_PlayableHandle_t2910061178,
	RuntimeInvoker_Playable_t3436777522,
	RuntimeInvoker_Playable_t3436777522_PlayableGraph_t4192197450_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Playable_t3436777522,
	RuntimeInvoker_Boolean_t402932760_PlayableGraphU26_t2161944390_RuntimeObject_PlayableOutputHandleU26_t1699804259,
	RuntimeInvoker_Boolean_t402932760_PlayableGraphU26_t2161944390_PlayableHandleU26_t2838161302,
	RuntimeInvoker_Boolean_t402932760_PlayableOutputHandleU26_t1699804259,
	RuntimeInvoker_PlayableOutputHandle_t4210482917,
	RuntimeInvoker_RuntimeObject_PlayableOutputHandleU26_t1699804259,
	RuntimeInvoker_Boolean_t402932760_PlayableOutputHandle_t4210482917_PlayableOutputHandle_t4210482917,
	RuntimeInvoker_Void_t1421048318_PlayableOutputHandle_t4210482917,
	RuntimeInvoker_PlayableOutput_t758663699,
	RuntimeInvoker_Boolean_t402932760_PlayableOutput_t758663699,
	RuntimeInvoker_Void_t1421048318_Scene_t2009218140_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Scene_t2009218140,
	RuntimeInvoker_Void_t1421048318_Scene_t2009218140_Scene_t2009218140,
	RuntimeInvoker_Quaternion_t895809378,
	RuntimeInvoker_Void_t1421048318_Quaternion_t895809378,
	RuntimeInvoker_Void_t1421048318_QuaternionU26_t1376965358,
	RuntimeInvoker_Void_t1421048318_Vector3_t2987449647_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Single_t3678960876_Single_t3678960876_Single_t3678960876_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876,
	RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647,
	RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_RaycastHitU26_t714001703_Single_t3678960876_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_RaycastHitU26_t714001703_Single_t3678960876,
	RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_RaycastHitU26_t714001703,
	RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647_Vector3_t2987449647_RaycastHitU26_t714001703_Single_t3678960876_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_Single_t3678960876_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_Single_t3678960876,
	RuntimeInvoker_Boolean_t402932760_Ray_t3298836202,
	RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_Single_t3678960876_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_RaycastHitU26_t714001703_Single_t3678960876_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_RaycastHitU26_t714001703_Single_t3678960876,
	RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_RaycastHitU26_t714001703,
	RuntimeInvoker_Boolean_t402932760_Ray_t3298836202_RaycastHitU26_t714001703_Single_t3678960876_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Ray_t3298836202_Single_t3678960876,
	RuntimeInvoker_RuntimeObject_Ray_t3298836202,
	RuntimeInvoker_RuntimeObject_Ray_t3298836202_Single_t3678960876_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Vector3_t2987449647_Vector3_t2987449647_Single_t3678960876,
	RuntimeInvoker_RuntimeObject_Vector3_t2987449647_Vector3_t2987449647,
	RuntimeInvoker_RuntimeObject_Vector3U26_t1054175401_Vector3U26_t1054175401_Single_t3678960876_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Vector3U26_t1054175401_Vector3U26_t1054175401_RaycastHitU26_t714001703_Single_t3678960876_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Boolean_t402932760_Vector3U26_t1054175401_Vector3U26_t1054175401_Single_t3678960876_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Vector3_t2987449647_Vector3_t2987449647,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_Vector3U26_t1054175401_Vector3U26_t1054175401,
	RuntimeInvoker_Bounds_t1424290876,
	RuntimeInvoker_Void_t1421048318_BoundsU26_t2305519396,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Ray_t3298836202_RaycastHitU26_t714001703_Single_t3678960876,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_RayU26_t3897443494_RaycastHitU26_t714001703_Single_t3678960876,
	RuntimeInvoker_CollisionFlags_t2921713114_Vector3_t2987449647,
	RuntimeInvoker_CollisionFlags_t2921713114_RuntimeObject_Vector3U26_t1054175401,
	RuntimeInvoker_AudioPlayableOutput_t2616039667_PlayableGraph_t4192197450_RuntimeObject_RuntimeObject,
	RuntimeInvoker_AudioPlayableOutput_t2616039667,
	RuntimeInvoker_PlayableOutput_t758663699_AudioPlayableOutput_t2616039667,
	RuntimeInvoker_AudioPlayableOutput_t2616039667_PlayableOutput_t758663699,
	RuntimeInvoker_Void_t1421048318_PlayableOutputHandleU26_t1699804259_RuntimeObject,
	RuntimeInvoker_AudioClipPlayable_t3295732336_PlayableGraph_t4192197450_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_PlayableHandle_t2910061178_PlayableGraph_t4192197450_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_Playable_t3436777522_AudioClipPlayable_t3295732336,
	RuntimeInvoker_AudioClipPlayable_t3295732336_Playable_t3436777522,
	RuntimeInvoker_Boolean_t402932760_AudioClipPlayable_t3295732336,
	RuntimeInvoker_Void_t1421048318_PlayableHandleU26_t2838161302_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_PlayableHandleU26_t2838161302_SByte_t1526744772,
	RuntimeInvoker_Double_t3420139759_PlayableHandleU26_t2838161302,
	RuntimeInvoker_Boolean_t402932760_PlayableGraphU26_t2161944390_RuntimeObject_SByte_t1526744772_PlayableHandleU26_t2838161302,
	RuntimeInvoker_Void_t1421048318_Double_t3420139759_Double_t3420139759,
	RuntimeInvoker_Void_t1421048318_Double_t3420139759_Double_t3420139759_Double_t3420139759,
	RuntimeInvoker_AudioMixerPlayable_t3345238233_PlayableGraph_t4192197450_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_PlayableHandle_t2910061178_PlayableGraph_t4192197450_Int32_t438220675_SByte_t1526744772,
	RuntimeInvoker_Playable_t3436777522_AudioMixerPlayable_t3345238233,
	RuntimeInvoker_AudioMixerPlayable_t3345238233_Playable_t3436777522,
	RuntimeInvoker_Boolean_t402932760_AudioMixerPlayable_t3345238233,
	RuntimeInvoker_Boolean_t402932760_PlayableGraphU26_t2161944390_Int32_t438220675_SByte_t1526744772_PlayableHandleU26_t2838161302,
	RuntimeInvoker_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int16_t674212087,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Int64_t3733094498,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Single_t3678960876,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Double_t3420139759,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_Decimal_t2382302464,
	RuntimeInvoker_AnalyticsResult_t1733525867_RuntimeObject_RuntimeObject,
	RuntimeInvoker_AnalyticsResult_t1733525867_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_SByte_t1526744772_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_HitInfo_t2681867412,
	RuntimeInvoker_Boolean_t402932760_HitInfo_t2681867412,
	RuntimeInvoker_Boolean_t402932760_HitInfo_t2681867412_HitInfo_t2681867412,
	RuntimeInvoker_Boolean_t402932760_Vector3_t2987449647,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_StringU26_t3235211963_StringU26_t3235211963,
	RuntimeInvoker_PersistentListenerMode_t2357711828,
	RuntimeInvoker_Playable_t3436777522_PlayableGraph_t4192197450_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_PlayableGraph_t4192197450_RuntimeObject_IntPtr_t,
	RuntimeInvoker_Void_t1421048318_Playable_t3436777522,
	RuntimeInvoker_Void_t1421048318_Playable_t3436777522_FrameData_t231040801,
	RuntimeInvoker_Void_t1421048318_Playable_t3436777522_FrameData_t231040801_RuntimeObject,
	RuntimeInvoker_ScriptPlayableOutput_t2716968363_PlayableGraph_t4192197450_RuntimeObject,
	RuntimeInvoker_ScriptPlayableOutput_t2716968363,
	RuntimeInvoker_PlayableOutput_t758663699_ScriptPlayableOutput_t2716968363,
	RuntimeInvoker_ScriptPlayableOutput_t2716968363_PlayableOutput_t758663699,
	RuntimeInvoker_LogType_t310145821,
	RuntimeInvoker_Void_t1421048318_IntPtr_t_Int64_t3733094498_Int64_t3733094498_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_Guid_t_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_ScriptableRenderContext_t3163458046_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_IntPtr_t,
	RuntimeInvoker_CSSSize_t478721537_IntPtr_t_Single_t3678960876_Int32_t438220675_Single_t3678960876_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_IntPtr_t_Single_t3678960876_Int32_t438220675_Single_t3678960876_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_CSSSize_t478721537_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_IntPtr_t_Single_t3678960876_Int32_t438220675_Single_t3678960876_Int32_t438220675_IntPtr_t,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_ObjectU26_t1561828645,
	RuntimeInvoker_Void_t1421048318_ObjectU5BU5DU26_t1191207502_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_ObjectU5BU5DU26_t1191207502_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_KeyValuePair_2_t3369932832,
	RuntimeInvoker_Boolean_t402932760_KeyValuePair_2_t3369932832,
	RuntimeInvoker_KeyValuePair_2_t3369932832_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_ObjectU26_t1561828645,
	RuntimeInvoker_Enumerator_t2659973885,
	RuntimeInvoker_DictionaryEntry_t578375704_RuntimeObject_RuntimeObject,
	RuntimeInvoker_KeyValuePair_2_t3369932832,
	RuntimeInvoker_Enumerator_t2420502484,
	RuntimeInvoker_RuntimeObject_ObjectU26_t1561828645_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Enumerator_t4263500154,
	RuntimeInvoker_Enumerator_t2206974221,
	RuntimeInvoker_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_AudioClipPlayable_t3295732336_Double_t3420139759,
	RuntimeInvoker_Boolean_t402932760_IntPtr_t_ObjectU26_t1561828645,
	RuntimeInvoker_Void_t1421048318_RuntimeObject_RuntimeObject_Single_t3678960876,
	RuntimeInvoker_Void_t1421048318_Playable_t3436777522_Int32_t438220675,
	RuntimeInvoker_WorkRequest_t3203378897,
	RuntimeInvoker_Boolean_t402932760_TableRange_t2080199027,
	RuntimeInvoker_Boolean_t402932760_DictionaryEntry_t578375704,
	RuntimeInvoker_Boolean_t402932760_KeyValuePair_2_t2173232590,
	RuntimeInvoker_Boolean_t402932760_KeyValuePair_2_t3674847205,
	RuntimeInvoker_Boolean_t402932760_KeyValuePair_2_t3710135120,
	RuntimeInvoker_Boolean_t402932760_Link_t808767725,
	RuntimeInvoker_Boolean_t402932760_Slot_t2703514113,
	RuntimeInvoker_Boolean_t402932760_Slot_t2810825829,
	RuntimeInvoker_Boolean_t402932760_CustomAttributeNamedArgument_t3456585787,
	RuntimeInvoker_Boolean_t402932760_CustomAttributeTypedArgument_t2066493570,
	RuntimeInvoker_Boolean_t402932760_LabelData_t2222154365,
	RuntimeInvoker_Boolean_t402932760_LabelFixup_t426630335,
	RuntimeInvoker_Boolean_t402932760_ILTokenInfo_t3857000042,
	RuntimeInvoker_Boolean_t402932760_ParameterModifier_t1406754278,
	RuntimeInvoker_Boolean_t402932760_ResourceCacheItem_t2576962992,
	RuntimeInvoker_Boolean_t402932760_ResourceInfo_t1067968749,
	RuntimeInvoker_Boolean_t402932760_Byte_t1695016127,
	RuntimeInvoker_Boolean_t402932760_X509ChainStatus_t2329993372,
	RuntimeInvoker_Boolean_t402932760_Mark_t3306160088,
	RuntimeInvoker_Boolean_t402932760_UriScheme_t2520867868,
	RuntimeInvoker_Boolean_t402932760_ContactPoint_t3765348581,
	RuntimeInvoker_Boolean_t402932760_Keyframe_t1047575712,
	RuntimeInvoker_Boolean_t402932760_PlayableBinding_t2470704133,
	RuntimeInvoker_Boolean_t402932760_RaycastHit_t2786726017,
	RuntimeInvoker_Boolean_t402932760_WorkRequest_t3203378897,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_Int32_t438220675_Int32_t438220675_Int32_t438220675_RuntimeObject,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_CustomAttributeNamedArgument_t3456585787_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_CustomAttributeNamedArgument_t3456585787,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_CustomAttributeTypedArgument_t2066493570_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Int32_t438220675_RuntimeObject_CustomAttributeTypedArgument_t2066493570,
	RuntimeInvoker_Int32_t438220675_TableRange_t2080199027,
	RuntimeInvoker_Int32_t438220675_DictionaryEntry_t578375704,
	RuntimeInvoker_Int32_t438220675_KeyValuePair_2_t2173232590,
	RuntimeInvoker_Int32_t438220675_KeyValuePair_2_t3674847205,
	RuntimeInvoker_Int32_t438220675_KeyValuePair_2_t3710135120,
	RuntimeInvoker_Int32_t438220675_KeyValuePair_2_t3369932832,
	RuntimeInvoker_Int32_t438220675_Link_t808767725,
	RuntimeInvoker_Int32_t438220675_Slot_t2703514113,
	RuntimeInvoker_Int32_t438220675_Slot_t2810825829,
	RuntimeInvoker_Int32_t438220675_CustomAttributeNamedArgument_t3456585787,
	RuntimeInvoker_Int32_t438220675_CustomAttributeTypedArgument_t2066493570,
	RuntimeInvoker_Int32_t438220675_LabelData_t2222154365,
	RuntimeInvoker_Int32_t438220675_LabelFixup_t426630335,
	RuntimeInvoker_Int32_t438220675_ILTokenInfo_t3857000042,
	RuntimeInvoker_Int32_t438220675_ParameterModifier_t1406754278,
	RuntimeInvoker_Int32_t438220675_ResourceCacheItem_t2576962992,
	RuntimeInvoker_Int32_t438220675_ResourceInfo_t1067968749,
	RuntimeInvoker_Int32_t438220675_Byte_t1695016127,
	RuntimeInvoker_Int32_t438220675_X509ChainStatus_t2329993372,
	RuntimeInvoker_Int32_t438220675_Mark_t3306160088,
	RuntimeInvoker_Int32_t438220675_UriScheme_t2520867868,
	RuntimeInvoker_Int32_t438220675_ContactPoint_t3765348581,
	RuntimeInvoker_Int32_t438220675_Keyframe_t1047575712,
	RuntimeInvoker_Int32_t438220675_PlayableBinding_t2470704133,
	RuntimeInvoker_Int32_t438220675_RaycastHit_t2786726017,
	RuntimeInvoker_Int32_t438220675_HitInfo_t2681867412,
	RuntimeInvoker_Int32_t438220675_WorkRequest_t3203378897,
	RuntimeInvoker_Void_t1421048318_TableRange_t2080199027,
	RuntimeInvoker_Void_t1421048318_DictionaryEntry_t578375704,
	RuntimeInvoker_Void_t1421048318_KeyValuePair_2_t2173232590,
	RuntimeInvoker_Void_t1421048318_KeyValuePair_2_t3674847205,
	RuntimeInvoker_Void_t1421048318_KeyValuePair_2_t3710135120,
	RuntimeInvoker_Void_t1421048318_Link_t808767725,
	RuntimeInvoker_Void_t1421048318_Slot_t2703514113,
	RuntimeInvoker_Void_t1421048318_Slot_t2810825829,
	RuntimeInvoker_Void_t1421048318_Decimal_t2382302464,
	RuntimeInvoker_Void_t1421048318_CustomAttributeNamedArgument_t3456585787,
	RuntimeInvoker_Void_t1421048318_CustomAttributeTypedArgument_t2066493570,
	RuntimeInvoker_Void_t1421048318_LabelData_t2222154365,
	RuntimeInvoker_Void_t1421048318_LabelFixup_t426630335,
	RuntimeInvoker_Void_t1421048318_ILTokenInfo_t3857000042,
	RuntimeInvoker_Void_t1421048318_ParameterModifier_t1406754278,
	RuntimeInvoker_Void_t1421048318_ResourceCacheItem_t2576962992,
	RuntimeInvoker_Void_t1421048318_ResourceInfo_t1067968749,
	RuntimeInvoker_Void_t1421048318_X509ChainStatus_t2329993372,
	RuntimeInvoker_Void_t1421048318_Mark_t3306160088,
	RuntimeInvoker_Void_t1421048318_UriScheme_t2520867868,
	RuntimeInvoker_Void_t1421048318_ContactPoint_t3765348581,
	RuntimeInvoker_Void_t1421048318_Keyframe_t1047575712,
	RuntimeInvoker_Void_t1421048318_PlayableBinding_t2470704133,
	RuntimeInvoker_Void_t1421048318_RaycastHit_t2786726017,
	RuntimeInvoker_Void_t1421048318_HitInfo_t2681867412,
	RuntimeInvoker_Void_t1421048318_WorkRequest_t3203378897,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_TableRange_t2080199027,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_DictionaryEntry_t578375704,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_KeyValuePair_2_t2173232590,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_KeyValuePair_2_t3674847205,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_KeyValuePair_2_t3710135120,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_KeyValuePair_2_t3369932832,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Link_t808767725,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Slot_t2703514113,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Slot_t2810825829,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_DateTime_t3836236387,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Decimal_t2382302464,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Double_t3420139759,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_IntPtr_t,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_CustomAttributeNamedArgument_t3456585787,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_CustomAttributeTypedArgument_t2066493570,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_LabelData_t2222154365,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_LabelFixup_t426630335,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_ILTokenInfo_t3857000042,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_ParameterModifier_t1406754278,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_ResourceCacheItem_t2576962992,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_ResourceInfo_t1067968749,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Byte_t1695016127,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_X509ChainStatus_t2329993372,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Mark_t3306160088,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_TimeSpan_t4182925364,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_UriScheme_t2520867868,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_ContactPoint_t3765348581,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_Keyframe_t1047575712,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_PlayableBinding_t2470704133,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_RaycastHit_t2786726017,
	RuntimeInvoker_Void_t1421048318_Int32_t438220675_WorkRequest_t3203378897,
	RuntimeInvoker_Void_t1421048318_Int32U5BU5DU26_t2609758910_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_Int32U5BU5DU26_t2609758910_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_CustomAttributeNamedArgumentU5BU5DU26_t1774281110_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_CustomAttributeNamedArgumentU5BU5DU26_t1774281110_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_CustomAttributeTypedArgumentU5BU5DU26_t4198221793_Int32_t438220675_Int32_t438220675,
	RuntimeInvoker_Void_t1421048318_CustomAttributeTypedArgumentU5BU5DU26_t4198221793_Int32_t438220675,
	RuntimeInvoker_TableRange_t2080199027_Int32_t438220675,
	RuntimeInvoker_ClientCertificateType_t2095209863_Int32_t438220675,
	RuntimeInvoker_DictionaryEntry_t578375704_Int32_t438220675,
	RuntimeInvoker_KeyValuePair_2_t2173232590_Int32_t438220675,
	RuntimeInvoker_KeyValuePair_2_t3674847205_Int32_t438220675,
	RuntimeInvoker_KeyValuePair_2_t3710135120_Int32_t438220675,
	RuntimeInvoker_KeyValuePair_2_t3369932832_Int32_t438220675,
	RuntimeInvoker_Link_t808767725_Int32_t438220675,
	RuntimeInvoker_Slot_t2703514113_Int32_t438220675,
	RuntimeInvoker_Slot_t2810825829_Int32_t438220675,
	RuntimeInvoker_CustomAttributeNamedArgument_t3456585787_Int32_t438220675,
	RuntimeInvoker_CustomAttributeTypedArgument_t2066493570_Int32_t438220675,
	RuntimeInvoker_LabelData_t2222154365_Int32_t438220675,
	RuntimeInvoker_LabelFixup_t426630335_Int32_t438220675,
	RuntimeInvoker_ILTokenInfo_t3857000042_Int32_t438220675,
	RuntimeInvoker_ParameterModifier_t1406754278_Int32_t438220675,
	RuntimeInvoker_ResourceCacheItem_t2576962992_Int32_t438220675,
	RuntimeInvoker_ResourceInfo_t1067968749_Int32_t438220675,
	RuntimeInvoker_TypeTag_t1823465210_Int32_t438220675,
	RuntimeInvoker_X509ChainStatus_t2329993372_Int32_t438220675,
	RuntimeInvoker_Mark_t3306160088_Int32_t438220675,
	RuntimeInvoker_TimeSpan_t4182925364_Int32_t438220675,
	RuntimeInvoker_UriScheme_t2520867868_Int32_t438220675,
	RuntimeInvoker_ContactPoint_t3765348581_Int32_t438220675,
	RuntimeInvoker_Keyframe_t1047575712_Int32_t438220675,
	RuntimeInvoker_PlayableBinding_t2470704133_Int32_t438220675,
	RuntimeInvoker_RaycastHit_t2786726017_Int32_t438220675,
	RuntimeInvoker_HitInfo_t2681867412_Int32_t438220675,
	RuntimeInvoker_WorkRequest_t3203378897_Int32_t438220675,
	RuntimeInvoker_RuntimeObject_Single_t3678960876_RuntimeObject_RuntimeObject,
	RuntimeInvoker_CustomAttributeNamedArgument_t3456585787,
	RuntimeInvoker_CustomAttributeTypedArgument_t2066493570,
	RuntimeInvoker_TableRange_t2080199027,
	RuntimeInvoker_ClientCertificateType_t2095209863,
	RuntimeInvoker_KeyValuePair_2_t2173232590,
	RuntimeInvoker_KeyValuePair_2_t3674847205,
	RuntimeInvoker_KeyValuePair_2_t3710135120,
	RuntimeInvoker_Link_t808767725,
	RuntimeInvoker_Slot_t2703514113,
	RuntimeInvoker_Slot_t2810825829,
	RuntimeInvoker_LabelData_t2222154365,
	RuntimeInvoker_LabelFixup_t426630335,
	RuntimeInvoker_ILTokenInfo_t3857000042,
	RuntimeInvoker_ParameterModifier_t1406754278,
	RuntimeInvoker_ResourceCacheItem_t2576962992,
	RuntimeInvoker_ResourceInfo_t1067968749,
	RuntimeInvoker_TypeTag_t1823465210,
	RuntimeInvoker_X509ChainStatus_t2329993372,
	RuntimeInvoker_Mark_t3306160088,
	RuntimeInvoker_UriScheme_t2520867868,
	RuntimeInvoker_ContactPoint_t3765348581,
	RuntimeInvoker_Keyframe_t1047575712,
	RuntimeInvoker_PlayableBinding_t2470704133,
	RuntimeInvoker_RaycastHit_t2786726017,
	RuntimeInvoker_HitInfo_t2681867412,
	RuntimeInvoker_Int32_t438220675_DateTimeOffset_t3036919142_DateTimeOffset_t3036919142,
	RuntimeInvoker_Int32_t438220675_Guid_t_Guid_t,
	RuntimeInvoker_DictionaryEntry_t578375704_IntPtr_t_RuntimeObject,
	RuntimeInvoker_RuntimeObject_IntPtr_t_RuntimeObject_RuntimeObject_RuntimeObject,
	RuntimeInvoker_DictionaryEntry_t578375704_RuntimeObject,
	RuntimeInvoker_KeyValuePair_2_t2173232590_IntPtr_t_RuntimeObject,
	RuntimeInvoker_KeyValuePair_2_t2173232590_RuntimeObject,
	RuntimeInvoker_DictionaryEntry_t578375704_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_RuntimeObject_RuntimeObject_SByte_t1526744772_RuntimeObject_RuntimeObject,
	RuntimeInvoker_KeyValuePair_2_t3674847205_RuntimeObject_SByte_t1526744772,
	RuntimeInvoker_KeyValuePair_2_t3674847205_RuntimeObject,
	RuntimeInvoker_DictionaryEntry_t578375704_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_KeyValuePair_2_t3710135120_RuntimeObject_Int32_t438220675,
	RuntimeInvoker_KeyValuePair_2_t3710135120_RuntimeObject,
	RuntimeInvoker_KeyValuePair_2_t3369932832_RuntimeObject,
	RuntimeInvoker_Void_t1421048318_IntPtr_t_RuntimeObject,
	RuntimeInvoker_Enumerator_t1463273643,
	RuntimeInvoker_Boolean_t402932760_RuntimeObject_BooleanU26_t2626765736,
	RuntimeInvoker_Enumerator_t2964888258,
	RuntimeInvoker_Enumerator_t3000176173,
	RuntimeInvoker_Boolean_t402932760_SByte_t1526744772_SByte_t1526744772,
	RuntimeInvoker_Boolean_t402932760_DateTimeOffset_t3036919142_DateTimeOffset_t3036919142,
	RuntimeInvoker_Boolean_t402932760_CustomAttributeNamedArgument_t3456585787_CustomAttributeNamedArgument_t3456585787,
	RuntimeInvoker_Boolean_t402932760_CustomAttributeTypedArgument_t2066493570_CustomAttributeTypedArgument_t2066493570,
	RuntimeInvoker_Enumerator_t2760704772,
	RuntimeInvoker_Enumerator_t1484102588,
	RuntimeInvoker_Enumerator_t94010371,
	RuntimeInvoker_Enumerator_t3073893368,
	RuntimeInvoker_CustomAttributeNamedArgument_t3456585787_RuntimeObject,
	RuntimeInvoker_CustomAttributeTypedArgument_t2066493570_RuntimeObject,
	RuntimeInvoker_Boolean_t402932760_Nullable_1_t534706120,
	RuntimeInvoker_RuntimeObject_Scene_t2009218140_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Scene_t2009218140_Int32_t438220675_RuntimeObject_RuntimeObject,
	RuntimeInvoker_RuntimeObject_Scene_t2009218140_Scene_t2009218140_RuntimeObject_RuntimeObject,
};
