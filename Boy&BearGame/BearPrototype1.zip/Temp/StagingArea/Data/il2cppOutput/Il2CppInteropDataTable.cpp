﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"








extern "C" void Context_t1711146899_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Context_t1711146899_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Context_t1711146899_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType Context_t1711146899_0_0_0;
extern "C" void Escape_t1669148627_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Escape_t1669148627_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Escape_t1669148627_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType Escape_t1669148627_0_0_0;
extern "C" void PreviousInfo_t369224553_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void PreviousInfo_t369224553_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void PreviousInfo_t369224553_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType PreviousInfo_t369224553_0_0_0;
extern "C" void DelegatePInvokeWrapper_AppDomainInitializer_t749344933();
extern const RuntimeType AppDomainInitializer_t749344933_0_0_0;
extern "C" void DelegatePInvokeWrapper_Swapper_t39528967();
extern const RuntimeType Swapper_t39528967_0_0_0;
extern "C" void DictionaryEntry_t578375704_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void DictionaryEntry_t578375704_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void DictionaryEntry_t578375704_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType DictionaryEntry_t578375704_0_0_0;
extern "C" void Slot_t2703514113_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Slot_t2703514113_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Slot_t2703514113_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType Slot_t2703514113_0_0_0;
extern "C" void Slot_t2810825829_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Slot_t2810825829_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Slot_t2810825829_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType Slot_t2810825829_0_0_0;
extern "C" void Enum_t4088700107_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Enum_t4088700107_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Enum_t4088700107_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType Enum_t4088700107_0_0_0;
extern "C" void DelegatePInvokeWrapper_ReadDelegate_t763997283();
extern const RuntimeType ReadDelegate_t763997283_0_0_0;
extern "C" void DelegatePInvokeWrapper_WriteDelegate_t3012109505();
extern const RuntimeType WriteDelegate_t3012109505_0_0_0;
extern "C" void MonoIOStat_t2386973040_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void MonoIOStat_t2386973040_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void MonoIOStat_t2386973040_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType MonoIOStat_t2386973040_0_0_0;
extern "C" void MonoEnumInfo_t2659694797_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void MonoEnumInfo_t2659694797_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void MonoEnumInfo_t2659694797_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType MonoEnumInfo_t2659694797_0_0_0;
extern "C" void CustomAttributeNamedArgument_t3456585787_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void CustomAttributeNamedArgument_t3456585787_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void CustomAttributeNamedArgument_t3456585787_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType CustomAttributeNamedArgument_t3456585787_0_0_0;
extern "C" void CustomAttributeTypedArgument_t2066493570_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void CustomAttributeTypedArgument_t2066493570_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void CustomAttributeTypedArgument_t2066493570_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType CustomAttributeTypedArgument_t2066493570_0_0_0;
extern "C" void ILTokenInfo_t3857000042_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ILTokenInfo_t3857000042_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ILTokenInfo_t3857000042_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType ILTokenInfo_t3857000042_0_0_0;
extern "C" void MonoEventInfo_t2799518403_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void MonoEventInfo_t2799518403_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void MonoEventInfo_t2799518403_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType MonoEventInfo_t2799518403_0_0_0;
extern "C" void MonoMethodInfo_t2273945901_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void MonoMethodInfo_t2273945901_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void MonoMethodInfo_t2273945901_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType MonoMethodInfo_t2273945901_0_0_0;
extern "C" void MonoPropertyInfo_t301114984_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void MonoPropertyInfo_t301114984_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void MonoPropertyInfo_t301114984_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType MonoPropertyInfo_t301114984_0_0_0;
extern "C" void ParameterModifier_t1406754278_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ParameterModifier_t1406754278_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ParameterModifier_t1406754278_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType ParameterModifier_t1406754278_0_0_0;
extern "C" void ResourceCacheItem_t2576962992_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ResourceCacheItem_t2576962992_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ResourceCacheItem_t2576962992_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType ResourceCacheItem_t2576962992_0_0_0;
extern "C" void ResourceInfo_t1067968749_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ResourceInfo_t1067968749_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ResourceInfo_t1067968749_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType ResourceInfo_t1067968749_0_0_0;
extern "C" void DelegatePInvokeWrapper_CrossContextDelegate_t3119470076();
extern const RuntimeType CrossContextDelegate_t3119470076_0_0_0;
extern "C" void DelegatePInvokeWrapper_CallbackHandler_t3021787474();
extern const RuntimeType CallbackHandler_t3021787474_0_0_0;
extern "C" void SerializationEntry_t2018126969_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void SerializationEntry_t2018126969_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void SerializationEntry_t2018126969_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType SerializationEntry_t2018126969_0_0_0;
extern "C" void StreamingContext_t885793295_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void StreamingContext_t885793295_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void StreamingContext_t885793295_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType StreamingContext_t885793295_0_0_0;
extern "C" void DSAParameters_t4013484323_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void DSAParameters_t4013484323_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void DSAParameters_t4013484323_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType DSAParameters_t4013484323_0_0_0;
extern "C" void RSAParameters_t3314567386_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void RSAParameters_t3314567386_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void RSAParameters_t3314567386_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType RSAParameters_t3314567386_0_0_0;
extern "C" void SecurityFrame_t3461677235_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void SecurityFrame_t3461677235_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void SecurityFrame_t3461677235_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType SecurityFrame_t3461677235_0_0_0;
extern "C" void DelegatePInvokeWrapper_ThreadStart_t16934496();
extern const RuntimeType ThreadStart_t16934496_0_0_0;
extern "C" void ValueType_t3348802692_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ValueType_t3348802692_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ValueType_t3348802692_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType ValueType_t3348802692_0_0_0;
extern "C" void X509ChainStatus_t2329993372_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void X509ChainStatus_t2329993372_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void X509ChainStatus_t2329993372_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType X509ChainStatus_t2329993372_0_0_0;
extern "C" void IntStack_t1039583213_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void IntStack_t1039583213_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void IntStack_t1039583213_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType IntStack_t1039583213_0_0_0;
extern "C" void Interval_t176111467_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Interval_t176111467_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Interval_t176111467_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType Interval_t176111467_0_0_0;
extern "C" void DelegatePInvokeWrapper_CostDelegate_t528458667();
extern const RuntimeType CostDelegate_t528458667_0_0_0;
extern "C" void UriScheme_t2520867868_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void UriScheme_t2520867868_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void UriScheme_t2520867868_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType UriScheme_t2520867868_0_0_0;
extern "C" void DelegatePInvokeWrapper_Action_t4042858631();
extern const RuntimeType Action_t4042858631_0_0_0;
extern "C" void CustomEventData_t4212110146_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void CustomEventData_t4212110146_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void CustomEventData_t4212110146_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType CustomEventData_t4212110146_0_0_0;
extern "C" void UnityAnalyticsHandler_t627637005_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void UnityAnalyticsHandler_t627637005_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void UnityAnalyticsHandler_t627637005_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType UnityAnalyticsHandler_t627637005_0_0_0;
extern "C" void AnimationCurve_t2995615556_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void AnimationCurve_t2995615556_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void AnimationCurve_t2995615556_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType AnimationCurve_t2995615556_0_0_0;
extern "C" void DelegatePInvokeWrapper_LogCallback_t3275865818();
extern const RuntimeType LogCallback_t3275865818_0_0_0;
extern "C" void DelegatePInvokeWrapper_LowMemoryCallback_t2147800842();
extern const RuntimeType LowMemoryCallback_t2147800842_0_0_0;
extern "C" void AssetBundleRequest_t988638785_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void AssetBundleRequest_t988638785_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void AssetBundleRequest_t988638785_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType AssetBundleRequest_t988638785_0_0_0;
extern "C" void AsyncOperation_t1216045970_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void AsyncOperation_t1216045970_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void AsyncOperation_t1216045970_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType AsyncOperation_t1216045970_0_0_0;
extern "C" void DelegatePInvokeWrapper_PCMReaderCallback_t1418821679();
extern const RuntimeType PCMReaderCallback_t1418821679_0_0_0;
extern "C" void DelegatePInvokeWrapper_PCMSetPositionCallback_t1845778073();
extern const RuntimeType PCMSetPositionCallback_t1845778073_0_0_0;
extern "C" void DelegatePInvokeWrapper_AudioConfigurationChangeHandler_t279396608();
extern const RuntimeType AudioConfigurationChangeHandler_t279396608_0_0_0;
extern "C" void Collision_t1992409213_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Collision_t1992409213_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Collision_t1992409213_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType Collision_t1992409213_0_0_0;
extern "C" void ControllerColliderHit_t3057575995_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ControllerColliderHit_t3057575995_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ControllerColliderHit_t3057575995_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType ControllerColliderHit_t3057575995_0_0_0;
extern "C" void Coroutine_t56146755_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Coroutine_t56146755_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Coroutine_t56146755_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType Coroutine_t56146755_0_0_0;
extern "C" void DelegatePInvokeWrapper_CSSMeasureFunc_t2981734212();
extern const RuntimeType CSSMeasureFunc_t2981734212_0_0_0;
extern "C" void CullingGroup_t3411111508_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void CullingGroup_t3411111508_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void CullingGroup_t3411111508_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType CullingGroup_t3411111508_0_0_0;
extern "C" void DelegatePInvokeWrapper_StateChanged_t3796850174();
extern const RuntimeType StateChanged_t3796850174_0_0_0;
extern "C" void DelegatePInvokeWrapper_DisplaysUpdatedDelegate_t345952990();
extern const RuntimeType DisplaysUpdatedDelegate_t345952990_0_0_0;
extern "C" void DelegatePInvokeWrapper_UnityAction_t825079890();
extern const RuntimeType UnityAction_t825079890_0_0_0;
extern "C" void FailedToLoadScriptObject_t1581619330_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void FailedToLoadScriptObject_t1581619330_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void FailedToLoadScriptObject_t1581619330_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType FailedToLoadScriptObject_t1581619330_0_0_0;
extern "C" void DelegatePInvokeWrapper_FontTextureRebuildCallback_t940970719();
extern const RuntimeType FontTextureRebuildCallback_t940970719_0_0_0;
extern "C" void Gradient_t19391121_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Gradient_t19391121_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Gradient_t19391121_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType Gradient_t19391121_0_0_0;
extern "C" void Object_t3267094820_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void Object_t3267094820_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void Object_t3267094820_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType Object_t3267094820_0_0_0;
extern "C" void PlayableBinding_t2470704133_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void PlayableBinding_t2470704133_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void PlayableBinding_t2470704133_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType PlayableBinding_t2470704133_0_0_0;
extern "C" void RaycastHit_t2786726017_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void RaycastHit_t2786726017_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void RaycastHit_t2786726017_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType RaycastHit_t2786726017_0_0_0;
extern "C" void DelegatePInvokeWrapper_UpdatedEventHandler_t1756707821();
extern const RuntimeType UpdatedEventHandler_t1756707821_0_0_0;
extern "C" void ResourceRequest_t2922114009_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ResourceRequest_t2922114009_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ResourceRequest_t2922114009_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType ResourceRequest_t2922114009_0_0_0;
extern "C" void ScriptableObject_t643150937_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void ScriptableObject_t643150937_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void ScriptableObject_t643150937_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType ScriptableObject_t643150937_0_0_0;
extern "C" void HitInfo_t2681867412_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void HitInfo_t2681867412_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void HitInfo_t2681867412_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType HitInfo_t2681867412_0_0_0;
extern "C" void DelegatePInvokeWrapper_RequestAtlasCallback_t1919579472();
extern const RuntimeType RequestAtlasCallback_t1919579472_0_0_0;
extern "C" void WorkRequest_t3203378897_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void WorkRequest_t3203378897_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void WorkRequest_t3203378897_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType WorkRequest_t3203378897_0_0_0;
extern "C" void WaitForSeconds_t2172464514_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void WaitForSeconds_t2172464514_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void WaitForSeconds_t2172464514_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType WaitForSeconds_t2172464514_0_0_0;
extern "C" void YieldInstruction_t2994650433_marshal_pinvoke(void* managedStructure, void* marshaledStructure);
extern "C" void YieldInstruction_t2994650433_marshal_pinvoke_back(void* marshaledStructure, void* managedStructure);
extern "C" void YieldInstruction_t2994650433_marshal_pinvoke_cleanup(void* marshaledStructure);
extern const RuntimeType YieldInstruction_t2994650433_0_0_0;
extern Il2CppInteropData g_Il2CppInteropData[70] = 
{
	{ NULL, Context_t1711146899_marshal_pinvoke, Context_t1711146899_marshal_pinvoke_back, Context_t1711146899_marshal_pinvoke_cleanup, NULL, NULL, &Context_t1711146899_0_0_0 } /* Mono.Globalization.Unicode.SimpleCollator/Context */,
	{ NULL, Escape_t1669148627_marshal_pinvoke, Escape_t1669148627_marshal_pinvoke_back, Escape_t1669148627_marshal_pinvoke_cleanup, NULL, NULL, &Escape_t1669148627_0_0_0 } /* Mono.Globalization.Unicode.SimpleCollator/Escape */,
	{ NULL, PreviousInfo_t369224553_marshal_pinvoke, PreviousInfo_t369224553_marshal_pinvoke_back, PreviousInfo_t369224553_marshal_pinvoke_cleanup, NULL, NULL, &PreviousInfo_t369224553_0_0_0 } /* Mono.Globalization.Unicode.SimpleCollator/PreviousInfo */,
	{ DelegatePInvokeWrapper_AppDomainInitializer_t749344933, NULL, NULL, NULL, NULL, NULL, &AppDomainInitializer_t749344933_0_0_0 } /* System.AppDomainInitializer */,
	{ DelegatePInvokeWrapper_Swapper_t39528967, NULL, NULL, NULL, NULL, NULL, &Swapper_t39528967_0_0_0 } /* System.Array/Swapper */,
	{ NULL, DictionaryEntry_t578375704_marshal_pinvoke, DictionaryEntry_t578375704_marshal_pinvoke_back, DictionaryEntry_t578375704_marshal_pinvoke_cleanup, NULL, NULL, &DictionaryEntry_t578375704_0_0_0 } /* System.Collections.DictionaryEntry */,
	{ NULL, Slot_t2703514113_marshal_pinvoke, Slot_t2703514113_marshal_pinvoke_back, Slot_t2703514113_marshal_pinvoke_cleanup, NULL, NULL, &Slot_t2703514113_0_0_0 } /* System.Collections.Hashtable/Slot */,
	{ NULL, Slot_t2810825829_marshal_pinvoke, Slot_t2810825829_marshal_pinvoke_back, Slot_t2810825829_marshal_pinvoke_cleanup, NULL, NULL, &Slot_t2810825829_0_0_0 } /* System.Collections.SortedList/Slot */,
	{ NULL, Enum_t4088700107_marshal_pinvoke, Enum_t4088700107_marshal_pinvoke_back, Enum_t4088700107_marshal_pinvoke_cleanup, NULL, NULL, &Enum_t4088700107_0_0_0 } /* System.Enum */,
	{ DelegatePInvokeWrapper_ReadDelegate_t763997283, NULL, NULL, NULL, NULL, NULL, &ReadDelegate_t763997283_0_0_0 } /* System.IO.FileStream/ReadDelegate */,
	{ DelegatePInvokeWrapper_WriteDelegate_t3012109505, NULL, NULL, NULL, NULL, NULL, &WriteDelegate_t3012109505_0_0_0 } /* System.IO.FileStream/WriteDelegate */,
	{ NULL, MonoIOStat_t2386973040_marshal_pinvoke, MonoIOStat_t2386973040_marshal_pinvoke_back, MonoIOStat_t2386973040_marshal_pinvoke_cleanup, NULL, NULL, &MonoIOStat_t2386973040_0_0_0 } /* System.IO.MonoIOStat */,
	{ NULL, MonoEnumInfo_t2659694797_marshal_pinvoke, MonoEnumInfo_t2659694797_marshal_pinvoke_back, MonoEnumInfo_t2659694797_marshal_pinvoke_cleanup, NULL, NULL, &MonoEnumInfo_t2659694797_0_0_0 } /* System.MonoEnumInfo */,
	{ NULL, CustomAttributeNamedArgument_t3456585787_marshal_pinvoke, CustomAttributeNamedArgument_t3456585787_marshal_pinvoke_back, CustomAttributeNamedArgument_t3456585787_marshal_pinvoke_cleanup, NULL, NULL, &CustomAttributeNamedArgument_t3456585787_0_0_0 } /* System.Reflection.CustomAttributeNamedArgument */,
	{ NULL, CustomAttributeTypedArgument_t2066493570_marshal_pinvoke, CustomAttributeTypedArgument_t2066493570_marshal_pinvoke_back, CustomAttributeTypedArgument_t2066493570_marshal_pinvoke_cleanup, NULL, NULL, &CustomAttributeTypedArgument_t2066493570_0_0_0 } /* System.Reflection.CustomAttributeTypedArgument */,
	{ NULL, ILTokenInfo_t3857000042_marshal_pinvoke, ILTokenInfo_t3857000042_marshal_pinvoke_back, ILTokenInfo_t3857000042_marshal_pinvoke_cleanup, NULL, NULL, &ILTokenInfo_t3857000042_0_0_0 } /* System.Reflection.Emit.ILTokenInfo */,
	{ NULL, MonoEventInfo_t2799518403_marshal_pinvoke, MonoEventInfo_t2799518403_marshal_pinvoke_back, MonoEventInfo_t2799518403_marshal_pinvoke_cleanup, NULL, NULL, &MonoEventInfo_t2799518403_0_0_0 } /* System.Reflection.MonoEventInfo */,
	{ NULL, MonoMethodInfo_t2273945901_marshal_pinvoke, MonoMethodInfo_t2273945901_marshal_pinvoke_back, MonoMethodInfo_t2273945901_marshal_pinvoke_cleanup, NULL, NULL, &MonoMethodInfo_t2273945901_0_0_0 } /* System.Reflection.MonoMethodInfo */,
	{ NULL, MonoPropertyInfo_t301114984_marshal_pinvoke, MonoPropertyInfo_t301114984_marshal_pinvoke_back, MonoPropertyInfo_t301114984_marshal_pinvoke_cleanup, NULL, NULL, &MonoPropertyInfo_t301114984_0_0_0 } /* System.Reflection.MonoPropertyInfo */,
	{ NULL, ParameterModifier_t1406754278_marshal_pinvoke, ParameterModifier_t1406754278_marshal_pinvoke_back, ParameterModifier_t1406754278_marshal_pinvoke_cleanup, NULL, NULL, &ParameterModifier_t1406754278_0_0_0 } /* System.Reflection.ParameterModifier */,
	{ NULL, ResourceCacheItem_t2576962992_marshal_pinvoke, ResourceCacheItem_t2576962992_marshal_pinvoke_back, ResourceCacheItem_t2576962992_marshal_pinvoke_cleanup, NULL, NULL, &ResourceCacheItem_t2576962992_0_0_0 } /* System.Resources.ResourceReader/ResourceCacheItem */,
	{ NULL, ResourceInfo_t1067968749_marshal_pinvoke, ResourceInfo_t1067968749_marshal_pinvoke_back, ResourceInfo_t1067968749_marshal_pinvoke_cleanup, NULL, NULL, &ResourceInfo_t1067968749_0_0_0 } /* System.Resources.ResourceReader/ResourceInfo */,
	{ DelegatePInvokeWrapper_CrossContextDelegate_t3119470076, NULL, NULL, NULL, NULL, NULL, &CrossContextDelegate_t3119470076_0_0_0 } /* System.Runtime.Remoting.Contexts.CrossContextDelegate */,
	{ DelegatePInvokeWrapper_CallbackHandler_t3021787474, NULL, NULL, NULL, NULL, NULL, &CallbackHandler_t3021787474_0_0_0 } /* System.Runtime.Serialization.SerializationCallbacks/CallbackHandler */,
	{ NULL, SerializationEntry_t2018126969_marshal_pinvoke, SerializationEntry_t2018126969_marshal_pinvoke_back, SerializationEntry_t2018126969_marshal_pinvoke_cleanup, NULL, NULL, &SerializationEntry_t2018126969_0_0_0 } /* System.Runtime.Serialization.SerializationEntry */,
	{ NULL, StreamingContext_t885793295_marshal_pinvoke, StreamingContext_t885793295_marshal_pinvoke_back, StreamingContext_t885793295_marshal_pinvoke_cleanup, NULL, NULL, &StreamingContext_t885793295_0_0_0 } /* System.Runtime.Serialization.StreamingContext */,
	{ NULL, DSAParameters_t4013484323_marshal_pinvoke, DSAParameters_t4013484323_marshal_pinvoke_back, DSAParameters_t4013484323_marshal_pinvoke_cleanup, NULL, NULL, &DSAParameters_t4013484323_0_0_0 } /* System.Security.Cryptography.DSAParameters */,
	{ NULL, RSAParameters_t3314567386_marshal_pinvoke, RSAParameters_t3314567386_marshal_pinvoke_back, RSAParameters_t3314567386_marshal_pinvoke_cleanup, NULL, NULL, &RSAParameters_t3314567386_0_0_0 } /* System.Security.Cryptography.RSAParameters */,
	{ NULL, SecurityFrame_t3461677235_marshal_pinvoke, SecurityFrame_t3461677235_marshal_pinvoke_back, SecurityFrame_t3461677235_marshal_pinvoke_cleanup, NULL, NULL, &SecurityFrame_t3461677235_0_0_0 } /* System.Security.SecurityFrame */,
	{ DelegatePInvokeWrapper_ThreadStart_t16934496, NULL, NULL, NULL, NULL, NULL, &ThreadStart_t16934496_0_0_0 } /* System.Threading.ThreadStart */,
	{ NULL, ValueType_t3348802692_marshal_pinvoke, ValueType_t3348802692_marshal_pinvoke_back, ValueType_t3348802692_marshal_pinvoke_cleanup, NULL, NULL, &ValueType_t3348802692_0_0_0 } /* System.ValueType */,
	{ NULL, X509ChainStatus_t2329993372_marshal_pinvoke, X509ChainStatus_t2329993372_marshal_pinvoke_back, X509ChainStatus_t2329993372_marshal_pinvoke_cleanup, NULL, NULL, &X509ChainStatus_t2329993372_0_0_0 } /* System.Security.Cryptography.X509Certificates.X509ChainStatus */,
	{ NULL, IntStack_t1039583213_marshal_pinvoke, IntStack_t1039583213_marshal_pinvoke_back, IntStack_t1039583213_marshal_pinvoke_cleanup, NULL, NULL, &IntStack_t1039583213_0_0_0 } /* System.Text.RegularExpressions.Interpreter/IntStack */,
	{ NULL, Interval_t176111467_marshal_pinvoke, Interval_t176111467_marshal_pinvoke_back, Interval_t176111467_marshal_pinvoke_cleanup, NULL, NULL, &Interval_t176111467_0_0_0 } /* System.Text.RegularExpressions.Interval */,
	{ DelegatePInvokeWrapper_CostDelegate_t528458667, NULL, NULL, NULL, NULL, NULL, &CostDelegate_t528458667_0_0_0 } /* System.Text.RegularExpressions.IntervalCollection/CostDelegate */,
	{ NULL, UriScheme_t2520867868_marshal_pinvoke, UriScheme_t2520867868_marshal_pinvoke_back, UriScheme_t2520867868_marshal_pinvoke_cleanup, NULL, NULL, &UriScheme_t2520867868_0_0_0 } /* System.Uri/UriScheme */,
	{ DelegatePInvokeWrapper_Action_t4042858631, NULL, NULL, NULL, NULL, NULL, &Action_t4042858631_0_0_0 } /* System.Action */,
	{ NULL, CustomEventData_t4212110146_marshal_pinvoke, CustomEventData_t4212110146_marshal_pinvoke_back, CustomEventData_t4212110146_marshal_pinvoke_cleanup, NULL, NULL, &CustomEventData_t4212110146_0_0_0 } /* UnityEngine.Analytics.CustomEventData */,
	{ NULL, UnityAnalyticsHandler_t627637005_marshal_pinvoke, UnityAnalyticsHandler_t627637005_marshal_pinvoke_back, UnityAnalyticsHandler_t627637005_marshal_pinvoke_cleanup, NULL, NULL, &UnityAnalyticsHandler_t627637005_0_0_0 } /* UnityEngine.Analytics.UnityAnalyticsHandler */,
	{ NULL, AnimationCurve_t2995615556_marshal_pinvoke, AnimationCurve_t2995615556_marshal_pinvoke_back, AnimationCurve_t2995615556_marshal_pinvoke_cleanup, NULL, NULL, &AnimationCurve_t2995615556_0_0_0 } /* UnityEngine.AnimationCurve */,
	{ DelegatePInvokeWrapper_LogCallback_t3275865818, NULL, NULL, NULL, NULL, NULL, &LogCallback_t3275865818_0_0_0 } /* UnityEngine.Application/LogCallback */,
	{ DelegatePInvokeWrapper_LowMemoryCallback_t2147800842, NULL, NULL, NULL, NULL, NULL, &LowMemoryCallback_t2147800842_0_0_0 } /* UnityEngine.Application/LowMemoryCallback */,
	{ NULL, AssetBundleRequest_t988638785_marshal_pinvoke, AssetBundleRequest_t988638785_marshal_pinvoke_back, AssetBundleRequest_t988638785_marshal_pinvoke_cleanup, NULL, NULL, &AssetBundleRequest_t988638785_0_0_0 } /* UnityEngine.AssetBundleRequest */,
	{ NULL, AsyncOperation_t1216045970_marshal_pinvoke, AsyncOperation_t1216045970_marshal_pinvoke_back, AsyncOperation_t1216045970_marshal_pinvoke_cleanup, NULL, NULL, &AsyncOperation_t1216045970_0_0_0 } /* UnityEngine.AsyncOperation */,
	{ DelegatePInvokeWrapper_PCMReaderCallback_t1418821679, NULL, NULL, NULL, NULL, NULL, &PCMReaderCallback_t1418821679_0_0_0 } /* UnityEngine.AudioClip/PCMReaderCallback */,
	{ DelegatePInvokeWrapper_PCMSetPositionCallback_t1845778073, NULL, NULL, NULL, NULL, NULL, &PCMSetPositionCallback_t1845778073_0_0_0 } /* UnityEngine.AudioClip/PCMSetPositionCallback */,
	{ DelegatePInvokeWrapper_AudioConfigurationChangeHandler_t279396608, NULL, NULL, NULL, NULL, NULL, &AudioConfigurationChangeHandler_t279396608_0_0_0 } /* UnityEngine.AudioSettings/AudioConfigurationChangeHandler */,
	{ NULL, Collision_t1992409213_marshal_pinvoke, Collision_t1992409213_marshal_pinvoke_back, Collision_t1992409213_marshal_pinvoke_cleanup, NULL, NULL, &Collision_t1992409213_0_0_0 } /* UnityEngine.Collision */,
	{ NULL, ControllerColliderHit_t3057575995_marshal_pinvoke, ControllerColliderHit_t3057575995_marshal_pinvoke_back, ControllerColliderHit_t3057575995_marshal_pinvoke_cleanup, NULL, NULL, &ControllerColliderHit_t3057575995_0_0_0 } /* UnityEngine.ControllerColliderHit */,
	{ NULL, Coroutine_t56146755_marshal_pinvoke, Coroutine_t56146755_marshal_pinvoke_back, Coroutine_t56146755_marshal_pinvoke_cleanup, NULL, NULL, &Coroutine_t56146755_0_0_0 } /* UnityEngine.Coroutine */,
	{ DelegatePInvokeWrapper_CSSMeasureFunc_t2981734212, NULL, NULL, NULL, NULL, NULL, &CSSMeasureFunc_t2981734212_0_0_0 } /* UnityEngine.CSSLayout.CSSMeasureFunc */,
	{ NULL, CullingGroup_t3411111508_marshal_pinvoke, CullingGroup_t3411111508_marshal_pinvoke_back, CullingGroup_t3411111508_marshal_pinvoke_cleanup, NULL, NULL, &CullingGroup_t3411111508_0_0_0 } /* UnityEngine.CullingGroup */,
	{ DelegatePInvokeWrapper_StateChanged_t3796850174, NULL, NULL, NULL, NULL, NULL, &StateChanged_t3796850174_0_0_0 } /* UnityEngine.CullingGroup/StateChanged */,
	{ DelegatePInvokeWrapper_DisplaysUpdatedDelegate_t345952990, NULL, NULL, NULL, NULL, NULL, &DisplaysUpdatedDelegate_t345952990_0_0_0 } /* UnityEngine.Display/DisplaysUpdatedDelegate */,
	{ DelegatePInvokeWrapper_UnityAction_t825079890, NULL, NULL, NULL, NULL, NULL, &UnityAction_t825079890_0_0_0 } /* UnityEngine.Events.UnityAction */,
	{ NULL, FailedToLoadScriptObject_t1581619330_marshal_pinvoke, FailedToLoadScriptObject_t1581619330_marshal_pinvoke_back, FailedToLoadScriptObject_t1581619330_marshal_pinvoke_cleanup, NULL, NULL, &FailedToLoadScriptObject_t1581619330_0_0_0 } /* UnityEngine.FailedToLoadScriptObject */,
	{ DelegatePInvokeWrapper_FontTextureRebuildCallback_t940970719, NULL, NULL, NULL, NULL, NULL, &FontTextureRebuildCallback_t940970719_0_0_0 } /* UnityEngine.Font/FontTextureRebuildCallback */,
	{ NULL, Gradient_t19391121_marshal_pinvoke, Gradient_t19391121_marshal_pinvoke_back, Gradient_t19391121_marshal_pinvoke_cleanup, NULL, NULL, &Gradient_t19391121_0_0_0 } /* UnityEngine.Gradient */,
	{ NULL, Object_t3267094820_marshal_pinvoke, Object_t3267094820_marshal_pinvoke_back, Object_t3267094820_marshal_pinvoke_cleanup, NULL, NULL, &Object_t3267094820_0_0_0 } /* UnityEngine.Object */,
	{ NULL, PlayableBinding_t2470704133_marshal_pinvoke, PlayableBinding_t2470704133_marshal_pinvoke_back, PlayableBinding_t2470704133_marshal_pinvoke_cleanup, NULL, NULL, &PlayableBinding_t2470704133_0_0_0 } /* UnityEngine.Playables.PlayableBinding */,
	{ NULL, RaycastHit_t2786726017_marshal_pinvoke, RaycastHit_t2786726017_marshal_pinvoke_back, RaycastHit_t2786726017_marshal_pinvoke_cleanup, NULL, NULL, &RaycastHit_t2786726017_0_0_0 } /* UnityEngine.RaycastHit */,
	{ DelegatePInvokeWrapper_UpdatedEventHandler_t1756707821, NULL, NULL, NULL, NULL, NULL, &UpdatedEventHandler_t1756707821_0_0_0 } /* UnityEngine.RemoteSettings/UpdatedEventHandler */,
	{ NULL, ResourceRequest_t2922114009_marshal_pinvoke, ResourceRequest_t2922114009_marshal_pinvoke_back, ResourceRequest_t2922114009_marshal_pinvoke_cleanup, NULL, NULL, &ResourceRequest_t2922114009_0_0_0 } /* UnityEngine.ResourceRequest */,
	{ NULL, ScriptableObject_t643150937_marshal_pinvoke, ScriptableObject_t643150937_marshal_pinvoke_back, ScriptableObject_t643150937_marshal_pinvoke_cleanup, NULL, NULL, &ScriptableObject_t643150937_0_0_0 } /* UnityEngine.ScriptableObject */,
	{ NULL, HitInfo_t2681867412_marshal_pinvoke, HitInfo_t2681867412_marshal_pinvoke_back, HitInfo_t2681867412_marshal_pinvoke_cleanup, NULL, NULL, &HitInfo_t2681867412_0_0_0 } /* UnityEngine.SendMouseEvents/HitInfo */,
	{ DelegatePInvokeWrapper_RequestAtlasCallback_t1919579472, NULL, NULL, NULL, NULL, NULL, &RequestAtlasCallback_t1919579472_0_0_0 } /* UnityEngine.U2D.SpriteAtlasManager/RequestAtlasCallback */,
	{ NULL, WorkRequest_t3203378897_marshal_pinvoke, WorkRequest_t3203378897_marshal_pinvoke_back, WorkRequest_t3203378897_marshal_pinvoke_cleanup, NULL, NULL, &WorkRequest_t3203378897_0_0_0 } /* UnityEngine.UnitySynchronizationContext/WorkRequest */,
	{ NULL, WaitForSeconds_t2172464514_marshal_pinvoke, WaitForSeconds_t2172464514_marshal_pinvoke_back, WaitForSeconds_t2172464514_marshal_pinvoke_cleanup, NULL, NULL, &WaitForSeconds_t2172464514_0_0_0 } /* UnityEngine.WaitForSeconds */,
	{ NULL, YieldInstruction_t2994650433_marshal_pinvoke, YieldInstruction_t2994650433_marshal_pinvoke_back, YieldInstruction_t2994650433_marshal_pinvoke_cleanup, NULL, NULL, &YieldInstruction_t2994650433_0_0_0 } /* UnityEngine.YieldInstruction */,
	NULL,
};
