﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"








extern "C" void Locale_GetText_m1265146595 ();
extern "C" void Locale_GetText_m17960088 ();
extern "C" void SafeHandleZeroOrMinusOneIsInvalid__ctor_m1494848290 ();
extern "C" void SafeHandleZeroOrMinusOneIsInvalid_get_IsInvalid_m82959384 ();
extern "C" void SafeWaitHandle__ctor_m1749943790 ();
extern "C" void SafeWaitHandle_ReleaseHandle_m4165000905 ();
extern "C" void CodePointIndexer__ctor_m2188730405 ();
extern "C" void CodePointIndexer_ToIndex_m4068374705 ();
extern "C" void TableRange__ctor_m4223564055_AdjustorThunk ();
extern "C" void Contraction__ctor_m2980607259 ();
extern "C" void ContractionComparer__ctor_m1040251622 ();
extern "C" void ContractionComparer__cctor_m2446220411 ();
extern "C" void ContractionComparer_Compare_m1742180961 ();
extern "C" void Level2Map__ctor_m1597067058 ();
extern "C" void Level2MapComparer__ctor_m1190930255 ();
extern "C" void Level2MapComparer__cctor_m1746154148 ();
extern "C" void Level2MapComparer_Compare_m2901646138 ();
extern "C" void MSCompatUnicodeTable__cctor_m3713475796 ();
extern "C" void MSCompatUnicodeTable_GetTailoringInfo_m3078878392 ();
extern "C" void MSCompatUnicodeTable_BuildTailoringTables_m62717087 ();
extern "C" void MSCompatUnicodeTable_SetCJKReferences_m1405448475 ();
extern "C" void MSCompatUnicodeTable_Category_m3334123752 ();
extern "C" void MSCompatUnicodeTable_Level1_m1651883004 ();
extern "C" void MSCompatUnicodeTable_Level2_m3282328441 ();
extern "C" void MSCompatUnicodeTable_Level3_m1965057036 ();
extern "C" void MSCompatUnicodeTable_IsIgnorable_m498011888 ();
extern "C" void MSCompatUnicodeTable_IsIgnorableNonSpacing_m2195028588 ();
extern "C" void MSCompatUnicodeTable_ToKanaTypeInsensitive_m2905559152 ();
extern "C" void MSCompatUnicodeTable_ToWidthCompat_m3468994605 ();
extern "C" void MSCompatUnicodeTable_HasSpecialWeight_m2586706208 ();
extern "C" void MSCompatUnicodeTable_IsHalfWidthKana_m1890435412 ();
extern "C" void MSCompatUnicodeTable_IsHiragana_m68825819 ();
extern "C" void MSCompatUnicodeTable_IsJapaneseSmallLetter_m3471584530 ();
extern "C" void MSCompatUnicodeTable_get_IsReady_m2610718509 ();
extern "C" void MSCompatUnicodeTable_GetResource_m4210200220 ();
extern "C" void MSCompatUnicodeTable_UInt32FromBytePtr_m598979490 ();
extern "C" void MSCompatUnicodeTable_FillCJK_m3611444464 ();
extern "C" void MSCompatUnicodeTable_FillCJKCore_m2706440031 ();
extern "C" void MSCompatUnicodeTableUtil__cctor_m3741964204 ();
extern "C" void SimpleCollator__ctor_m2134046065 ();
extern "C" void SimpleCollator__cctor_m3499935719 ();
extern "C" void SimpleCollator_SetCJKTable_m2489383572 ();
extern "C" void SimpleCollator_GetNeutralCulture_m2904101762 ();
extern "C" void SimpleCollator_Category_m529974984 ();
extern "C" void SimpleCollator_Level1_m2496649243 ();
extern "C" void SimpleCollator_Level2_m676254063 ();
extern "C" void SimpleCollator_IsHalfKana_m3397869166 ();
extern "C" void SimpleCollator_GetContraction_m1878785680 ();
extern "C" void SimpleCollator_GetContraction_m3880760887 ();
extern "C" void SimpleCollator_GetTailContraction_m1591628111 ();
extern "C" void SimpleCollator_GetTailContraction_m2196500563 ();
extern "C" void SimpleCollator_FilterOptions_m2372795395 ();
extern "C" void SimpleCollator_GetExtenderType_m2671644325 ();
extern "C" void SimpleCollator_ToDashTypeValue_m2698099990 ();
extern "C" void SimpleCollator_FilterExtender_m975810900 ();
extern "C" void SimpleCollator_IsIgnorable_m2431316413 ();
extern "C" void SimpleCollator_IsSafe_m3146679031 ();
extern "C" void SimpleCollator_GetSortKey_m2448976682 ();
extern "C" void SimpleCollator_GetSortKey_m3673552269 ();
extern "C" void SimpleCollator_GetSortKey_m795125130 ();
extern "C" void SimpleCollator_FillSortKeyRaw_m2400297059 ();
extern "C" void SimpleCollator_FillSurrogateSortKeyRaw_m506828680 ();
extern "C" void SimpleCollator_CompareOrdinal_m4131903739 ();
extern "C" void SimpleCollator_CompareQuick_m1382920344 ();
extern "C" void SimpleCollator_CompareOrdinalIgnoreCase_m2004027341 ();
extern "C" void SimpleCollator_Compare_m585522997 ();
extern "C" void SimpleCollator_ClearBuffer_m670263399 ();
extern "C" void SimpleCollator_QuickCheckPossible_m3949857928 ();
extern "C" void SimpleCollator_CompareInternal_m4192545282 ();
extern "C" void SimpleCollator_CompareFlagPair_m2916215989 ();
extern "C" void SimpleCollator_IsPrefix_m411737590 ();
extern "C" void SimpleCollator_IsPrefix_m1716959922 ();
extern "C" void SimpleCollator_IsPrefix_m3370175993 ();
extern "C" void SimpleCollator_IsSuffix_m2087245658 ();
extern "C" void SimpleCollator_IsSuffix_m114126246 ();
extern "C" void SimpleCollator_QuickIndexOf_m2371624288 ();
extern "C" void SimpleCollator_IndexOf_m1611014549 ();
extern "C" void SimpleCollator_IndexOfOrdinal_m3462019578 ();
extern "C" void SimpleCollator_IndexOfOrdinalIgnoreCase_m490462133 ();
extern "C" void SimpleCollator_IndexOfSortKey_m281127086 ();
extern "C" void SimpleCollator_IndexOf_m2414080135 ();
extern "C" void SimpleCollator_LastIndexOf_m112368596 ();
extern "C" void SimpleCollator_LastIndexOfOrdinal_m1965663055 ();
extern "C" void SimpleCollator_LastIndexOfOrdinalIgnoreCase_m625315705 ();
extern "C" void SimpleCollator_LastIndexOfSortKey_m431080072 ();
extern "C" void SimpleCollator_LastIndexOf_m923630408 ();
extern "C" void SimpleCollator_MatchesForward_m2731549659 ();
extern "C" void SimpleCollator_MatchesForwardCore_m4057978367 ();
extern "C" void SimpleCollator_MatchesPrimitive_m626887649 ();
extern "C" void SimpleCollator_MatchesBackward_m3319999137 ();
extern "C" void SimpleCollator_MatchesBackwardCore_m3781926410 ();
extern "C" void Context__ctor_m285010020_AdjustorThunk ();
extern "C" void PreviousInfo__ctor_m363904324_AdjustorThunk ();
extern "C" void SortKeyBuffer__ctor_m4023860722 ();
extern "C" void SortKeyBuffer_Reset_m4192375915 ();
extern "C" void SortKeyBuffer_Initialize_m4052992156 ();
extern "C" void SortKeyBuffer_AppendCJKExtension_m2400234299 ();
extern "C" void SortKeyBuffer_AppendKana_m2514523172 ();
extern "C" void SortKeyBuffer_AppendNormal_m1830981725 ();
extern "C" void SortKeyBuffer_AppendLevel5_m849136411 ();
extern "C" void SortKeyBuffer_AppendBufferPrimitive_m381964935 ();
extern "C" void SortKeyBuffer_GetResultAndReset_m4161461551 ();
extern "C" void SortKeyBuffer_GetOptimizedLength_m1064586387 ();
extern "C" void SortKeyBuffer_GetResult_m3316895793 ();
extern "C" void TailoringInfo__ctor_m1019043692 ();
extern "C" void BigInteger__ctor_m749285921 ();
extern "C" void BigInteger__ctor_m1548060905 ();
extern "C" void BigInteger__ctor_m359944000 ();
extern "C" void BigInteger__ctor_m1361740461 ();
extern "C" void BigInteger__ctor_m739268725 ();
extern "C" void BigInteger__cctor_m687928097 ();
extern "C" void BigInteger_get_Rng_m4192306485 ();
extern "C" void BigInteger_GenerateRandom_m2236311969 ();
extern "C" void BigInteger_GenerateRandom_m3914896300 ();
extern "C" void BigInteger_Randomize_m1582361938 ();
extern "C" void BigInteger_Randomize_m2254548478 ();
extern "C" void BigInteger_BitCount_m418591107 ();
extern "C" void BigInteger_TestBit_m1331180400 ();
extern "C" void BigInteger_TestBit_m4046385986 ();
extern "C" void BigInteger_SetBit_m425458138 ();
extern "C" void BigInteger_SetBit_m2097412955 ();
extern "C" void BigInteger_LowestSetBit_m3166892152 ();
extern "C" void BigInteger_GetBytes_m639480215 ();
extern "C" void BigInteger_ToString_m4080627353 ();
extern "C" void BigInteger_ToString_m2837278763 ();
extern "C" void BigInteger_Normalize_m128016676 ();
extern "C" void BigInteger_Clear_m628128920 ();
extern "C" void BigInteger_GetHashCode_m2553221631 ();
extern "C" void BigInteger_ToString_m4176690768 ();
extern "C" void BigInteger_Equals_m543243295 ();
extern "C" void BigInteger_ModInverse_m275294484 ();
extern "C" void BigInteger_ModPow_m2545909939 ();
extern "C" void BigInteger_IsProbablePrime_m3566037144 ();
extern "C" void BigInteger_GeneratePseudoPrime_m2194202988 ();
extern "C" void BigInteger_Incr2_m2242053949 ();
extern "C" void BigInteger_op_Implicit_m2646846758 ();
extern "C" void BigInteger_op_Implicit_m2269995082 ();
extern "C" void BigInteger_op_Addition_m1710113902 ();
extern "C" void BigInteger_op_Subtraction_m4293640053 ();
extern "C" void BigInteger_op_Modulus_m3315194349 ();
extern "C" void BigInteger_op_Modulus_m1676214227 ();
extern "C" void BigInteger_op_Division_m2202532690 ();
extern "C" void BigInteger_op_Multiply_m2577593846 ();
extern "C" void BigInteger_op_Multiply_m1311148295 ();
extern "C" void BigInteger_op_LeftShift_m1642370140 ();
extern "C" void BigInteger_op_RightShift_m1121795638 ();
extern "C" void BigInteger_op_Equality_m2075306021 ();
extern "C" void BigInteger_op_Inequality_m130367573 ();
extern "C" void BigInteger_op_Equality_m4205992796 ();
extern "C" void BigInteger_op_Inequality_m4211291346 ();
extern "C" void BigInteger_op_GreaterThan_m1868107497 ();
extern "C" void BigInteger_op_LessThan_m2363164644 ();
extern "C" void BigInteger_op_GreaterThanOrEqual_m2819743712 ();
extern "C" void BigInteger_op_LessThanOrEqual_m1501457970 ();
extern "C" void Kernel_AddSameSign_m1710157416 ();
extern "C" void Kernel_Subtract_m3200698040 ();
extern "C" void Kernel_MinusEq_m3453643272 ();
extern "C" void Kernel_PlusEq_m2076902192 ();
extern "C" void Kernel_Compare_m2772920044 ();
extern "C" void Kernel_SingleByteDivideInPlace_m3969322353 ();
extern "C" void Kernel_DwordMod_m538231209 ();
extern "C" void Kernel_DwordDivMod_m638557122 ();
extern "C" void Kernel_multiByteDivide_m2557810668 ();
extern "C" void Kernel_LeftShift_m3419189056 ();
extern "C" void Kernel_RightShift_m707895963 ();
extern "C" void Kernel_MultiplyByDword_m3417453857 ();
extern "C" void Kernel_Multiply_m2696208436 ();
extern "C" void Kernel_MultiplyMod2p32pmod_m3089237537 ();
extern "C" void Kernel_modInverse_m3924577278 ();
extern "C" void Kernel_modInverse_m478118115 ();
extern "C" void ModulusRing__ctor_m3459439119 ();
extern "C" void ModulusRing_BarrettReduction_m953332471 ();
extern "C" void ModulusRing_Multiply_m2306156272 ();
extern "C" void ModulusRing_Difference_m3165112467 ();
extern "C" void ModulusRing_Pow_m3903062554 ();
extern "C" void ModulusRing_Pow_m3028377471 ();
extern "C" void PrimeGeneratorBase__ctor_m3810842403 ();
extern "C" void PrimeGeneratorBase_get_Confidence_m2751166709 ();
extern "C" void PrimeGeneratorBase_get_PrimalityTest_m653630235 ();
extern "C" void PrimeGeneratorBase_get_TrialDivisionBounds_m3141706556 ();
extern "C" void SequentialSearchPrimeGeneratorBase__ctor_m3036742961 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateSearchBase_m397757294 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m3422829138 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m409742484 ();
extern "C" void SequentialSearchPrimeGeneratorBase_IsPrimeAcceptable_m509833446 ();
extern "C" void PrimalityTest__ctor_m1741929263 ();
extern "C" void PrimalityTest_Invoke_m734476009 ();
extern "C" void PrimalityTest_BeginInvoke_m780686148 ();
extern "C" void PrimalityTest_EndInvoke_m3513513734 ();
extern "C" void PrimalityTests_GetSPPRounds_m1356488336 ();
extern "C" void PrimalityTests_Test_m2404702103 ();
extern "C" void PrimalityTests_RabinMillerTest_m1209091924 ();
extern "C" void PrimalityTests_SmallPrimeSppTest_m712000020 ();
extern "C" void Runtime_GetDisplayName_m2543745802 ();
extern "C" void ASN1__ctor_m3516316147 ();
extern "C" void ASN1__ctor_m900389283 ();
extern "C" void ASN1__ctor_m3702032794 ();
extern "C" void ASN1_get_Count_m3480232352 ();
extern "C" void ASN1_get_Tag_m3464757002 ();
extern "C" void ASN1_get_Length_m1225159393 ();
extern "C" void ASN1_get_Value_m3871082636 ();
extern "C" void ASN1_set_Value_m1466677899 ();
extern "C" void ASN1_CompareArray_m3660389124 ();
extern "C" void ASN1_CompareValue_m1304964968 ();
extern "C" void ASN1_Add_m1182244447 ();
extern "C" void ASN1_GetBytes_m3669971745 ();
extern "C" void ASN1_Decode_m907784624 ();
extern "C" void ASN1_DecodeTLV_m673487284 ();
extern "C" void ASN1_get_Item_m2436150169 ();
extern "C" void ASN1_Element_m4122926611 ();
extern "C" void ASN1_ToString_m1043110734 ();
extern "C" void ASN1Convert_FromInt32_m2998434422 ();
extern "C" void ASN1Convert_FromOid_m1489798743 ();
extern "C" void ASN1Convert_ToInt32_m354484360 ();
extern "C" void ASN1Convert_ToOid_m3096819508 ();
extern "C" void ASN1Convert_ToDateTime_m2361833227 ();
extern "C" void BitConverterLE_GetUIntBytes_m1730778039 ();
extern "C" void BitConverterLE_GetBytes_m2148648680 ();
extern "C" void BitConverterLE_UShortFromBytes_m980213359 ();
extern "C" void BitConverterLE_UIntFromBytes_m3407605456 ();
extern "C" void BitConverterLE_ULongFromBytes_m1264961194 ();
extern "C" void BitConverterLE_ToInt16_m3333209264 ();
extern "C" void BitConverterLE_ToInt32_m2015589102 ();
extern "C" void BitConverterLE_ToSingle_m1256583513 ();
extern "C" void BitConverterLE_ToDouble_m3434335877 ();
extern "C" void BlockProcessor__ctor_m1542591421 ();
extern "C" void BlockProcessor_Finalize_m2193875010 ();
extern "C" void BlockProcessor_Initialize_m1617464021 ();
extern "C" void BlockProcessor_Core_m1467748329 ();
extern "C" void BlockProcessor_Core_m1163585696 ();
extern "C" void BlockProcessor_Final_m466767243 ();
extern "C" void CryptoConvert_ToInt32LE_m2881796413 ();
extern "C" void CryptoConvert_ToUInt32LE_m3826477295 ();
extern "C" void CryptoConvert_GetBytesLE_m1542846119 ();
extern "C" void CryptoConvert_ToCapiPrivateKeyBlob_m700900379 ();
extern "C" void CryptoConvert_FromCapiPublicKeyBlob_m1029150686 ();
extern "C" void CryptoConvert_FromCapiPublicKeyBlob_m3664124753 ();
extern "C" void CryptoConvert_ToCapiPublicKeyBlob_m127107459 ();
extern "C" void CryptoConvert_ToCapiKeyBlob_m2703135777 ();
extern "C" void DSAManaged__ctor_m2239731715 ();
extern "C" void DSAManaged_add_KeyGenerated_m617634834 ();
extern "C" void DSAManaged_remove_KeyGenerated_m4203967072 ();
extern "C" void DSAManaged_Finalize_m658091490 ();
extern "C" void DSAManaged_Generate_m2213327800 ();
extern "C" void DSAManaged_GenerateKeyPair_m3676828895 ();
extern "C" void DSAManaged_add_m2563244335 ();
extern "C" void DSAManaged_GenerateParams_m893203057 ();
extern "C" void DSAManaged_get_Random_m1552973763 ();
extern "C" void DSAManaged_get_KeySize_m195244546 ();
extern "C" void DSAManaged_get_PublicOnly_m937331592 ();
extern "C" void DSAManaged_NormalizeArray_m3031469125 ();
extern "C" void DSAManaged_ExportParameters_m129436677 ();
extern "C" void DSAManaged_ImportParameters_m674300461 ();
extern "C" void DSAManaged_CreateSignature_m112797504 ();
extern "C" void DSAManaged_VerifySignature_m1409117526 ();
extern "C" void DSAManaged_Dispose_m3559808758 ();
extern "C" void KeyGeneratedEventHandler__ctor_m3350971851 ();
extern "C" void KeyGeneratedEventHandler_Invoke_m3584036176 ();
extern "C" void KeyGeneratedEventHandler_BeginInvoke_m949536046 ();
extern "C" void KeyGeneratedEventHandler_EndInvoke_m4180032083 ();
extern "C" void KeyBuilder_get_Rng_m1520795798 ();
extern "C" void KeyBuilder_Key_m1913521515 ();
extern "C" void KeyBuilder_IV_m3397957894 ();
extern "C" void KeyPairPersistence__ctor_m2118809332 ();
extern "C" void KeyPairPersistence__ctor_m1640484989 ();
extern "C" void KeyPairPersistence__cctor_m2075445627 ();
extern "C" void KeyPairPersistence_get_Filename_m4173945282 ();
extern "C" void KeyPairPersistence_get_KeyValue_m91066153 ();
extern "C" void KeyPairPersistence_set_KeyValue_m2107494925 ();
extern "C" void KeyPairPersistence_Load_m4121548623 ();
extern "C" void KeyPairPersistence_Save_m1521804892 ();
extern "C" void KeyPairPersistence_Remove_m40363756 ();
extern "C" void KeyPairPersistence_get_UserPath_m53187470 ();
extern "C" void KeyPairPersistence_get_MachinePath_m2891279717 ();
extern "C" void KeyPairPersistence__CanSecure_m3650261141 ();
extern "C" void KeyPairPersistence__ProtectUser_m2853364577 ();
extern "C" void KeyPairPersistence__ProtectMachine_m241429997 ();
extern "C" void KeyPairPersistence__IsUserProtected_m1693323233 ();
extern "C" void KeyPairPersistence__IsMachineProtected_m2948499064 ();
extern "C" void KeyPairPersistence_CanSecure_m2985875540 ();
extern "C" void KeyPairPersistence_ProtectUser_m2970823568 ();
extern "C" void KeyPairPersistence_ProtectMachine_m4187282752 ();
extern "C" void KeyPairPersistence_IsUserProtected_m895119154 ();
extern "C" void KeyPairPersistence_IsMachineProtected_m2274466442 ();
extern "C" void KeyPairPersistence_get_CanChange_m3024654040 ();
extern "C" void KeyPairPersistence_get_UseDefaultKeyContainer_m2357983573 ();
extern "C" void KeyPairPersistence_get_UseMachineKeyStore_m1620036962 ();
extern "C" void KeyPairPersistence_get_ContainerName_m1066794494 ();
extern "C" void KeyPairPersistence_Copy_m2963737075 ();
extern "C" void KeyPairPersistence_FromXml_m2913457645 ();
extern "C" void KeyPairPersistence_ToXml_m452787328 ();
extern "C" void MACAlgorithm__ctor_m2285878648 ();
extern "C" void MACAlgorithm_Initialize_m4293111044 ();
extern "C" void MACAlgorithm_Core_m3245577984 ();
extern "C" void MACAlgorithm_Final_m170881330 ();
extern "C" void PKCS1__cctor_m52301062 ();
extern "C" void PKCS1_Compare_m2586713663 ();
extern "C" void PKCS1_I2OSP_m4089279014 ();
extern "C" void PKCS1_OS2IP_m1652482794 ();
extern "C" void PKCS1_RSAEP_m4204322655 ();
extern "C" void PKCS1_RSASP1_m1153951364 ();
extern "C" void PKCS1_RSAVP1_m3043513750 ();
extern "C" void PKCS1_Encrypt_v15_m2483357299 ();
extern "C" void PKCS1_Sign_v15_m3799722850 ();
extern "C" void PKCS1_Verify_v15_m3628112885 ();
extern "C" void PKCS1_Verify_v15_m1698944143 ();
extern "C" void PKCS1_Encode_v15_m1278782954 ();
extern "C" void EncryptedPrivateKeyInfo__ctor_m1728384237 ();
extern "C" void EncryptedPrivateKeyInfo__ctor_m255380445 ();
extern "C" void EncryptedPrivateKeyInfo_get_Algorithm_m3572697726 ();
extern "C" void EncryptedPrivateKeyInfo_get_EncryptedData_m1951388053 ();
extern "C" void EncryptedPrivateKeyInfo_get_Salt_m3047726094 ();
extern "C" void EncryptedPrivateKeyInfo_get_IterationCount_m567960696 ();
extern "C" void EncryptedPrivateKeyInfo_Decode_m2698506670 ();
extern "C" void PrivateKeyInfo__ctor_m2373384519 ();
extern "C" void PrivateKeyInfo__ctor_m2058598109 ();
extern "C" void PrivateKeyInfo_get_PrivateKey_m1774610424 ();
extern "C" void PrivateKeyInfo_Decode_m1597257289 ();
extern "C" void PrivateKeyInfo_RemoveLeadingZero_m1745558997 ();
extern "C" void PrivateKeyInfo_Normalize_m3535728914 ();
extern "C" void PrivateKeyInfo_DecodeRSA_m1088370069 ();
extern "C" void PrivateKeyInfo_DecodeDSA_m341342618 ();
extern "C" void RSAManaged__ctor_m108813814 ();
extern "C" void RSAManaged_add_KeyGenerated_m2026269581 ();
extern "C" void RSAManaged_remove_KeyGenerated_m452081817 ();
extern "C" void RSAManaged_Finalize_m3127602112 ();
extern "C" void RSAManaged_GenerateKeyPair_m4239154883 ();
extern "C" void RSAManaged_get_KeySize_m1415201630 ();
extern "C" void RSAManaged_get_PublicOnly_m3761587738 ();
extern "C" void RSAManaged_DecryptValue_m761789094 ();
extern "C" void RSAManaged_EncryptValue_m891368688 ();
extern "C" void RSAManaged_ExportParameters_m2802579325 ();
extern "C" void RSAManaged_ImportParameters_m1700317438 ();
extern "C" void RSAManaged_Dispose_m3115457227 ();
extern "C" void RSAManaged_ToXmlString_m1925737693 ();
extern "C" void RSAManaged_get_IsCrtPossible_m2378749780 ();
extern "C" void RSAManaged_GetPaddedValue_m3978405718 ();
extern "C" void KeyGeneratedEventHandler__ctor_m593853528 ();
extern "C" void KeyGeneratedEventHandler_Invoke_m2062799578 ();
extern "C" void KeyGeneratedEventHandler_BeginInvoke_m2450128886 ();
extern "C" void KeyGeneratedEventHandler_EndInvoke_m1662721951 ();
extern "C" void SymmetricTransform__ctor_m853900815 ();
extern "C" void SymmetricTransform_System_IDisposable_Dispose_m3767183876 ();
extern "C" void SymmetricTransform_Finalize_m2106608140 ();
extern "C" void SymmetricTransform_Dispose_m894001198 ();
extern "C" void SymmetricTransform_get_CanReuseTransform_m1766410615 ();
extern "C" void SymmetricTransform_Transform_m2228531694 ();
extern "C" void SymmetricTransform_CBC_m745169718 ();
extern "C" void SymmetricTransform_CFB_m3470641285 ();
extern "C" void SymmetricTransform_OFB_m3231919770 ();
extern "C" void SymmetricTransform_CTS_m3003575812 ();
extern "C" void SymmetricTransform_CheckInput_m3581390890 ();
extern "C" void SymmetricTransform_TransformBlock_m3148898394 ();
extern "C" void SymmetricTransform_get_KeepLastBlock_m220816450 ();
extern "C" void SymmetricTransform_InternalTransformBlock_m2736239174 ();
extern "C" void SymmetricTransform_Random_m914001586 ();
extern "C" void SymmetricTransform_ThrowBadPaddingException_m2057381031 ();
extern "C" void SymmetricTransform_FinalEncrypt_m1005064906 ();
extern "C" void SymmetricTransform_FinalDecrypt_m3448120181 ();
extern "C" void SymmetricTransform_TransformFinalBlock_m265074875 ();
extern "C" void ContentInfo__ctor_m1832218908 ();
extern "C" void ContentInfo__ctor_m1779824867 ();
extern "C" void ContentInfo__ctor_m3140128459 ();
extern "C" void ContentInfo__ctor_m4164959615 ();
extern "C" void ContentInfo_get_ASN1_m166893374 ();
extern "C" void ContentInfo_get_Content_m1913362825 ();
extern "C" void ContentInfo_set_Content_m1406202593 ();
extern "C" void ContentInfo_get_ContentType_m110609955 ();
extern "C" void ContentInfo_set_ContentType_m3631529987 ();
extern "C" void ContentInfo_GetASN1_m201596048 ();
extern "C" void EncryptedData__ctor_m1898214232 ();
extern "C" void EncryptedData__ctor_m3497954096 ();
extern "C" void EncryptedData_get_EncryptionAlgorithm_m3445649904 ();
extern "C" void EncryptedData_get_EncryptedContent_m2948139942 ();
extern "C" void StrongName__cctor_m294083825 ();
extern "C" void StrongName_get_PublicKey_m1706935160 ();
extern "C" void StrongName_get_PublicKeyToken_m719854356 ();
extern "C" void StrongName_get_TokenAlgorithm_m4024404966 ();
extern "C" void PKCS12__ctor_m2607338998 ();
extern "C" void PKCS12__ctor_m319934187 ();
extern "C" void PKCS12__ctor_m2663475186 ();
extern "C" void PKCS12__cctor_m1290954702 ();
extern "C" void PKCS12_Decode_m268156216 ();
extern "C" void PKCS12_Finalize_m2608254785 ();
extern "C" void PKCS12_set_Password_m2199572200 ();
extern "C" void PKCS12_get_IterationCount_m3773304382 ();
extern "C" void PKCS12_set_IterationCount_m2132687009 ();
extern "C" void PKCS12_get_Certificates_m1381826362 ();
extern "C" void PKCS12_get_RNG_m3472201106 ();
extern "C" void PKCS12_Compare_m2307221893 ();
extern "C" void PKCS12_GetSymmetricAlgorithm_m3020658701 ();
extern "C" void PKCS12_Decrypt_m191955830 ();
extern "C" void PKCS12_Decrypt_m572625802 ();
extern "C" void PKCS12_Encrypt_m3932021359 ();
extern "C" void PKCS12_GetExistingParameters_m2032210035 ();
extern "C" void PKCS12_AddPrivateKey_m1320150318 ();
extern "C" void PKCS12_ReadSafeBag_m4279133587 ();
extern "C" void PKCS12_CertificateSafeBag_m3727737016 ();
extern "C" void PKCS12_MAC_m2855112721 ();
extern "C" void PKCS12_GetBytes_m3443008688 ();
extern "C" void PKCS12_EncryptedContentInfo_m1107912104 ();
extern "C" void PKCS12_AddCertificate_m463544853 ();
extern "C" void PKCS12_AddCertificate_m3561584230 ();
extern "C" void PKCS12_RemoveCertificate_m870596409 ();
extern "C" void PKCS12_RemoveCertificate_m1025206712 ();
extern "C" void PKCS12_Clone_m1313211850 ();
extern "C" void PKCS12_get_MaximumPasswordLength_m1938263851 ();
extern "C" void DeriveBytes__ctor_m1344968137 ();
extern "C" void DeriveBytes__cctor_m3280374767 ();
extern "C" void DeriveBytes_set_HashName_m3610593785 ();
extern "C" void DeriveBytes_set_IterationCount_m3841365578 ();
extern "C" void DeriveBytes_set_Password_m3989191716 ();
extern "C" void DeriveBytes_set_Salt_m3743207440 ();
extern "C" void DeriveBytes_Adjust_m3420119091 ();
extern "C" void DeriveBytes_Derive_m2793777471 ();
extern "C" void DeriveBytes_DeriveKey_m2144372235 ();
extern "C" void DeriveBytes_DeriveIV_m406641218 ();
extern "C" void DeriveBytes_DeriveMAC_m3603767249 ();
extern "C" void SafeBag__ctor_m1363243494 ();
extern "C" void SafeBag_get_BagOID_m160591319 ();
extern "C" void SafeBag_get_ASN1_m91629621 ();
extern "C" void X501__cctor_m400093648 ();
extern "C" void X501_ToString_m536875646 ();
extern "C" void X501_ToString_m2552468539 ();
extern "C" void X501_AppendEntry_m3313183578 ();
extern "C" void X509Certificate__ctor_m86942042 ();
extern "C" void X509Certificate__cctor_m2591603522 ();
extern "C" void X509Certificate_Parse_m79522769 ();
extern "C" void X509Certificate_GetUnsignedBigInteger_m103534235 ();
extern "C" void X509Certificate_get_DSA_m125307315 ();
extern "C" void X509Certificate_get_IssuerName_m1372933285 ();
extern "C" void X509Certificate_get_KeyAlgorithmParameters_m259126965 ();
extern "C" void X509Certificate_get_PublicKey_m903953322 ();
extern "C" void X509Certificate_get_RawData_m3072015885 ();
extern "C" void X509Certificate_get_SubjectName_m2916400271 ();
extern "C" void X509Certificate_get_ValidFrom_m1988458040 ();
extern "C" void X509Certificate_get_ValidUntil_m3972607305 ();
extern "C" void X509Certificate_GetIssuerName_m3495765435 ();
extern "C" void X509Certificate_GetSubjectName_m4220029087 ();
extern "C" void X509Certificate_GetObjectData_m3812944410 ();
extern "C" void X509Certificate_PEM_m530892051 ();
extern "C" void X509CertificateCollection__ctor_m606653116 ();
extern "C" void X509CertificateCollection_System_Collections_IEnumerable_GetEnumerator_m2410698127 ();
extern "C" void X509CertificateCollection_get_Item_m3186270884 ();
extern "C" void X509CertificateCollection_Add_m1462393188 ();
extern "C" void X509CertificateCollection_GetEnumerator_m4046104381 ();
extern "C" void X509CertificateCollection_GetHashCode_m1380129870 ();
extern "C" void X509CertificateEnumerator__ctor_m1274818248 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m3062908215 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m2645324201 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m2508570363 ();
extern "C" void X509CertificateEnumerator_get_Current_m4235283862 ();
extern "C" void X509CertificateEnumerator_MoveNext_m2034424191 ();
extern "C" void X509CertificateEnumerator_Reset_m1034788171 ();
extern "C" void X509Extension__ctor_m1463351804 ();
extern "C" void X509Extension_Decode_m2035257366 ();
extern "C" void X509Extension_Equals_m2104989699 ();
extern "C" void X509Extension_GetHashCode_m2090282208 ();
extern "C" void X509Extension_WriteLine_m3232243657 ();
extern "C" void X509Extension_ToString_m4137855591 ();
extern "C" void X509ExtensionCollection__ctor_m2269405799 ();
extern "C" void X509ExtensionCollection__ctor_m2440266315 ();
extern "C" void X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m3430909382 ();
extern "C" void SecurityParser__ctor_m1273613094 ();
extern "C" void SecurityParser_LoadXml_m1797635359 ();
extern "C" void SecurityParser_ToXml_m3602313894 ();
extern "C" void SecurityParser_OnStartParsing_m1744558128 ();
extern "C" void SecurityParser_OnProcessingInstruction_m3895856679 ();
extern "C" void SecurityParser_OnIgnorableWhitespace_m296220286 ();
extern "C" void SecurityParser_OnStartElement_m916634736 ();
extern "C" void SecurityParser_OnEndElement_m1435563271 ();
extern "C" void SecurityParser_OnChars_m1997930175 ();
extern "C" void SecurityParser_OnEndParsing_m361052126 ();
extern "C" void SmallXmlParser__ctor_m2714448770 ();
extern "C" void SmallXmlParser_Error_m3310666497 ();
extern "C" void SmallXmlParser_UnexpectedEndError_m1697868618 ();
extern "C" void SmallXmlParser_IsNameChar_m3586087961 ();
extern "C" void SmallXmlParser_IsWhitespace_m2373230202 ();
extern "C" void SmallXmlParser_SkipWhitespaces_m3529124521 ();
extern "C" void SmallXmlParser_HandleWhitespaces_m1522810214 ();
extern "C" void SmallXmlParser_SkipWhitespaces_m1748557517 ();
extern "C" void SmallXmlParser_Peek_m3468987475 ();
extern "C" void SmallXmlParser_Read_m3051998616 ();
extern "C" void SmallXmlParser_Expect_m1605783117 ();
extern "C" void SmallXmlParser_ReadUntil_m3037577210 ();
extern "C" void SmallXmlParser_ReadName_m1236298014 ();
extern "C" void SmallXmlParser_Parse_m1329943518 ();
extern "C" void SmallXmlParser_Cleanup_m413266235 ();
extern "C" void SmallXmlParser_ReadContent_m2421724154 ();
extern "C" void SmallXmlParser_HandleBufferedContent_m727380410 ();
extern "C" void SmallXmlParser_ReadCharacters_m991777765 ();
extern "C" void SmallXmlParser_ReadReference_m422931399 ();
extern "C" void SmallXmlParser_ReadCharacterReference_m154840048 ();
extern "C" void SmallXmlParser_ReadAttribute_m1940026198 ();
extern "C" void SmallXmlParser_ReadCDATASection_m2631873034 ();
extern "C" void SmallXmlParser_ReadComment_m921257417 ();
extern "C" void AttrListImpl__ctor_m3819032856 ();
extern "C" void AttrListImpl_get_Length_m3324056078 ();
extern "C" void AttrListImpl_GetName_m3288491946 ();
extern "C" void AttrListImpl_GetValue_m2040757343 ();
extern "C" void AttrListImpl_GetValue_m1746824538 ();
extern "C" void AttrListImpl_get_Names_m242773466 ();
extern "C" void AttrListImpl_get_Values_m3954266095 ();
extern "C" void AttrListImpl_Clear_m495494231 ();
extern "C" void AttrListImpl_Add_m361290632 ();
extern "C" void SmallXmlParserException__ctor_m2671100442 ();
extern "C" void __Il2CppComDelegate_Finalize_m3194155022 ();
extern "C" void __Il2CppComObject_Finalize_m472148246 ();
extern "C" void AccessViolationException__ctor_m3997653685 ();
extern "C" void AccessViolationException__ctor_m809197134 ();
extern "C" void ActivationContext_System_Runtime_Serialization_ISerializable_GetObjectData_m1919074653 ();
extern "C" void ActivationContext_Finalize_m3174481347 ();
extern "C" void ActivationContext_Dispose_m1269565227 ();
extern "C" void ActivationContext_Dispose_m3011612522 ();
extern "C" void Activator_CreateInstance_m2419494272 ();
extern "C" void Activator_CreateInstance_m444130951 ();
extern "C" void Activator_CreateInstance_m2510174607 ();
extern "C" void Activator_CreateInstance_m3570299959 ();
extern "C" void Activator_CreateInstance_m191354027 ();
extern "C" void Activator_CheckType_m2851234608 ();
extern "C" void Activator_CheckAbstractType_m2572289794 ();
extern "C" void Activator_CreateInstanceInternal_m2226342982 ();
extern "C" void AppDomain_getFriendlyName_m983563881 ();
extern "C" void AppDomain_getCurDomain_m2930406338 ();
extern "C" void AppDomain_get_CurrentDomain_m2846368349 ();
extern "C" void AppDomain_LoadAssembly_m1553013027 ();
extern "C" void AppDomain_Load_m2443754192 ();
extern "C" void AppDomain_Load_m3338809057 ();
extern "C" void AppDomain_InternalSetContext_m624087841 ();
extern "C" void AppDomain_InternalGetContext_m1818197205 ();
extern "C" void AppDomain_InternalGetDefaultContext_m1487816137 ();
extern "C" void AppDomain_InternalGetProcessGuid_m1562017383 ();
extern "C" void AppDomain_GetProcessGuid_m3012047762 ();
extern "C" void AppDomain_ToString_m974557331 ();
extern "C" void AppDomain_DoTypeResolve_m2118823759 ();
extern "C" void AppDomainInitializer__ctor_m782952305 ();
extern "C" void AppDomainInitializer_Invoke_m934188694 ();
extern "C" void AppDomainInitializer_BeginInvoke_m2280557570 ();
extern "C" void AppDomainInitializer_EndInvoke_m3937990410 ();
extern "C" void AppDomainSetup__ctor_m2358764403 ();
extern "C" void ApplicationException__ctor_m2495185969 ();
extern "C" void ApplicationException__ctor_m3367108494 ();
extern "C" void ApplicationException__ctor_m158055564 ();
extern "C" void ApplicationIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m2267909380 ();
extern "C" void ApplicationIdentity_ToString_m3128027746 ();
extern "C" void ArgIterator_Equals_m1058506493_AdjustorThunk ();
extern "C" void ArgIterator_GetHashCode_m3507889379_AdjustorThunk ();
extern "C" void ArgumentException__ctor_m917890632 ();
extern "C" void ArgumentException__ctor_m1701432879 ();
extern "C" void ArgumentException__ctor_m2600437157 ();
extern "C" void ArgumentException__ctor_m2347857543 ();
extern "C" void ArgumentException__ctor_m1940164295 ();
extern "C" void ArgumentException__ctor_m3975556065 ();
extern "C" void ArgumentException_get_ParamName_m3589050748 ();
extern "C" void ArgumentException_get_Message_m1764127082 ();
extern "C" void ArgumentException_GetObjectData_m2722433088 ();
extern "C" void ArgumentNullException__ctor_m915127396 ();
extern "C" void ArgumentNullException__ctor_m4205025980 ();
extern "C" void ArgumentNullException__ctor_m4284127825 ();
extern "C" void ArgumentNullException__ctor_m2667105974 ();
extern "C" void ArgumentOutOfRangeException__ctor_m2230262647 ();
extern "C" void ArgumentOutOfRangeException__ctor_m3511757557 ();
extern "C" void ArgumentOutOfRangeException__ctor_m361638018 ();
extern "C" void ArgumentOutOfRangeException__ctor_m4208192147 ();
extern "C" void ArgumentOutOfRangeException__ctor_m2463331922 ();
extern "C" void ArgumentOutOfRangeException_get_Message_m1307317189 ();
extern "C" void ArgumentOutOfRangeException_GetObjectData_m2906848175 ();
extern "C" void ArithmeticException__ctor_m160911504 ();
extern "C" void ArithmeticException__ctor_m1603322801 ();
extern "C" void ArithmeticException__ctor_m314251061 ();
extern "C" void Array__ctor_m1209187327 ();
extern "C" void Array_System_Collections_IList_get_Item_m1062386384 ();
extern "C" void Array_System_Collections_IList_set_Item_m2964370625 ();
extern "C" void Array_System_Collections_IList_Add_m2805768866 ();
extern "C" void Array_System_Collections_IList_Clear_m2749207785 ();
extern "C" void Array_System_Collections_IList_Contains_m2850619077 ();
extern "C" void Array_System_Collections_IList_IndexOf_m4113384025 ();
extern "C" void Array_System_Collections_IList_Insert_m3768045023 ();
extern "C" void Array_System_Collections_IList_Remove_m2149856583 ();
extern "C" void Array_System_Collections_IList_RemoveAt_m2920498054 ();
extern "C" void Array_System_Collections_ICollection_get_Count_m3978114653 ();
extern "C" void Array_InternalArray__ICollection_get_Count_m2312395473 ();
extern "C" void Array_InternalArray__ICollection_get_IsReadOnly_m3484210382 ();
extern "C" void Array_InternalArray__ICollection_Clear_m2645052154 ();
extern "C" void Array_InternalArray__RemoveAt_m1098161393 ();
extern "C" void Array_get_Length_m1237849133 ();
extern "C" void Array_get_LongLength_m3574060956 ();
extern "C" void Array_get_Rank_m4210679277 ();
extern "C" void Array_GetRank_m2678416706 ();
extern "C" void Array_GetLength_m765962577 ();
extern "C" void Array_GetLongLength_m1831760985 ();
extern "C" void Array_GetLowerBound_m3549496906 ();
extern "C" void Array_GetValue_m2729068147 ();
extern "C" void Array_SetValue_m3241852505 ();
extern "C" void Array_GetValueImpl_m2886657017 ();
extern "C" void Array_SetValueImpl_m3938984347 ();
extern "C" void Array_FastCopy_m2430275015 ();
extern "C" void Array_CreateInstanceImpl_m3302315738 ();
extern "C" void Array_get_IsSynchronized_m1719268192 ();
extern "C" void Array_get_SyncRoot_m4203173386 ();
extern "C" void Array_get_IsFixedSize_m2241026129 ();
extern "C" void Array_get_IsReadOnly_m3320326657 ();
extern "C" void Array_GetEnumerator_m3833411737 ();
extern "C" void Array_GetUpperBound_m3033662308 ();
extern "C" void Array_GetValue_m1884911572 ();
extern "C" void Array_GetValue_m133190562 ();
extern "C" void Array_GetValue_m3481955035 ();
extern "C" void Array_GetValue_m1672823197 ();
extern "C" void Array_GetValue_m3499512431 ();
extern "C" void Array_GetValue_m170746175 ();
extern "C" void Array_SetValue_m63377824 ();
extern "C" void Array_SetValue_m485573868 ();
extern "C" void Array_SetValue_m1031266616 ();
extern "C" void Array_SetValue_m1575116602 ();
extern "C" void Array_SetValue_m214456090 ();
extern "C" void Array_SetValue_m3710452129 ();
extern "C" void Array_CreateInstance_m1019985487 ();
extern "C" void Array_CreateInstance_m2264326752 ();
extern "C" void Array_CreateInstance_m549464094 ();
extern "C" void Array_CreateInstance_m917197603 ();
extern "C" void Array_CreateInstance_m1901379298 ();
extern "C" void Array_GetIntArray_m2999725396 ();
extern "C" void Array_CreateInstance_m3507446064 ();
extern "C" void Array_GetValue_m2322609327 ();
extern "C" void Array_SetValue_m193787568 ();
extern "C" void Array_BinarySearch_m545470185 ();
extern "C" void Array_BinarySearch_m2794424496 ();
extern "C" void Array_BinarySearch_m787838226 ();
extern "C" void Array_BinarySearch_m3034756551 ();
extern "C" void Array_DoBinarySearch_m535885162 ();
extern "C" void Array_Clear_m3931267648 ();
extern "C" void Array_ClearInternal_m103549485 ();
extern "C" void Array_Clone_m75013923 ();
extern "C" void Array_Copy_m3083719085 ();
extern "C" void Array_Copy_m1665823352 ();
extern "C" void Array_Copy_m3124468677 ();
extern "C" void Array_Copy_m795970186 ();
extern "C" void Array_IndexOf_m1347597055 ();
extern "C" void Array_IndexOf_m955672662 ();
extern "C" void Array_IndexOf_m4006329155 ();
extern "C" void Array_Initialize_m2964546196 ();
extern "C" void Array_LastIndexOf_m3392868261 ();
extern "C" void Array_LastIndexOf_m1832984276 ();
extern "C" void Array_LastIndexOf_m191882863 ();
extern "C" void Array_get_swapper_m350703700 ();
extern "C" void Array_Reverse_m1652786737 ();
extern "C" void Array_Reverse_m2907565334 ();
extern "C" void Array_Sort_m4258351672 ();
extern "C" void Array_Sort_m1768924099 ();
extern "C" void Array_Sort_m2963189028 ();
extern "C" void Array_Sort_m3451521996 ();
extern "C" void Array_Sort_m2647962771 ();
extern "C" void Array_Sort_m4051743636 ();
extern "C" void Array_Sort_m1552933164 ();
extern "C" void Array_Sort_m3631368508 ();
extern "C" void Array_int_swapper_m4216640094 ();
extern "C" void Array_obj_swapper_m2273014594 ();
extern "C" void Array_slow_swapper_m1367639156 ();
extern "C" void Array_double_swapper_m2405493383 ();
extern "C" void Array_new_gap_m2764239473 ();
extern "C" void Array_combsort_m9958672 ();
extern "C" void Array_combsort_m3504304741 ();
extern "C" void Array_combsort_m1698085190 ();
extern "C" void Array_qsort_m2567273609 ();
extern "C" void Array_swap_m1454175609 ();
extern "C" void Array_compare_m1463750278 ();
extern "C" void Array_CopyTo_m2156848031 ();
extern "C" void Array_CopyTo_m3827090518 ();
extern "C" void Array_ConstrainedCopy_m2507976525 ();
extern "C" void SimpleEnumerator__ctor_m700162411 ();
extern "C" void SimpleEnumerator_get_Current_m1082998432 ();
extern "C" void SimpleEnumerator_MoveNext_m2557818901 ();
extern "C" void SimpleEnumerator_Reset_m3441273370 ();
extern "C" void SimpleEnumerator_Clone_m1283088169 ();
extern "C" void Swapper__ctor_m2076169497 ();
extern "C" void Swapper_Invoke_m704171303 ();
extern "C" void Swapper_BeginInvoke_m3902783594 ();
extern "C" void Swapper_EndInvoke_m1400482523 ();
extern "C" void ArrayTypeMismatchException__ctor_m693030731 ();
extern "C" void ArrayTypeMismatchException__ctor_m3549357969 ();
extern "C" void ArrayTypeMismatchException__ctor_m4117155091 ();
extern "C" void AssemblyLoadEventHandler__ctor_m2895683782 ();
extern "C" void AssemblyLoadEventHandler_Invoke_m4239709152 ();
extern "C" void AssemblyLoadEventHandler_BeginInvoke_m1552964803 ();
extern "C" void AssemblyLoadEventHandler_EndInvoke_m2252211627 ();
extern "C" void AsyncCallback__ctor_m250615163 ();
extern "C" void AsyncCallback_Invoke_m3489379354 ();
extern "C" void AsyncCallback_BeginInvoke_m2371063382 ();
extern "C" void AsyncCallback_EndInvoke_m199067018 ();
extern "C" void Attribute__ctor_m2510047006 ();
extern "C" void Attribute_CheckParameters_m3890139648 ();
extern "C" void Attribute_GetCustomAttribute_m2649713033 ();
extern "C" void Attribute_GetCustomAttribute_m767122931 ();
extern "C" void Attribute_GetHashCode_m2233302810 ();
extern "C" void Attribute_IsDefined_m41000727 ();
extern "C" void Attribute_IsDefined_m3038256223 ();
extern "C" void Attribute_IsDefined_m3101618329 ();
extern "C" void Attribute_IsDefined_m520826945 ();
extern "C" void Attribute_Equals_m3887674838 ();
extern "C" void AttributeUsageAttribute__ctor_m250482755 ();
extern "C" void AttributeUsageAttribute_get_AllowMultiple_m1373505120 ();
extern "C" void AttributeUsageAttribute_set_AllowMultiple_m3716379228 ();
extern "C" void AttributeUsageAttribute_get_Inherited_m2698594048 ();
extern "C" void AttributeUsageAttribute_set_Inherited_m2568117843 ();
extern "C" void BitConverter__cctor_m772220037 ();
extern "C" void BitConverter_AmILittleEndian_m3548951445 ();
extern "C" void BitConverter_DoubleWordsAreSwapped_m2886911556 ();
extern "C" void BitConverter_DoubleToInt64Bits_m3487324405 ();
extern "C" void BitConverter_GetBytes_m679788222 ();
extern "C" void BitConverter_GetBytes_m3390757298 ();
extern "C" void BitConverter_PutBytes_m1032922327 ();
extern "C" void BitConverter_ToInt64_m2350763810 ();
extern "C" void BitConverter_ToString_m1424207950 ();
extern "C" void BitConverter_ToString_m682142286 ();
extern "C" void Boolean__cctor_m2960660260 ();
extern "C" void Boolean_System_IConvertible_ToType_m3575264036_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToBoolean_m2843312221_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToByte_m3154011034_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToChar_m463812418_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToDateTime_m2560029344_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToDecimal_m2933246224_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToDouble_m3674645531_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToInt16_m1262197955_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToInt32_m1439073499_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToInt64_m2177417439_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToSByte_m1378217193_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToSingle_m4205260307_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToUInt16_m3266496623_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToUInt32_m1981649399_AdjustorThunk ();
extern "C" void Boolean_System_IConvertible_ToUInt64_m4279218169_AdjustorThunk ();
extern "C" void Boolean_CompareTo_m3210426891_AdjustorThunk ();
extern "C" void Boolean_Equals_m2568005781_AdjustorThunk ();
extern "C" void Boolean_CompareTo_m355555321_AdjustorThunk ();
extern "C" void Boolean_Equals_m2447193697_AdjustorThunk ();
extern "C" void Boolean_GetHashCode_m3342500017_AdjustorThunk ();
extern "C" void Boolean_Parse_m2343626245 ();
extern "C" void Boolean_ToString_m1641143563_AdjustorThunk ();
extern "C" void Boolean_ToString_m2668319895_AdjustorThunk ();
extern "C" void Buffer_ByteLength_m3432156039 ();
extern "C" void Buffer_BlockCopy_m3342110362 ();
extern "C" void Buffer_ByteLengthInternal_m1169895470 ();
extern "C" void Buffer_BlockCopyInternal_m2215447715 ();
extern "C" void Byte_System_IConvertible_ToType_m282257076_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToBoolean_m2144421286_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToByte_m2863304106_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToChar_m203885835_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToDateTime_m4058337789_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToDecimal_m2081691731_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToDouble_m4171630369_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToInt16_m3743536406_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToInt32_m3131424033_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToInt64_m269272912_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToSByte_m843068237_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToSingle_m3009948894_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToUInt16_m1452228093_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToUInt32_m775575532_AdjustorThunk ();
extern "C" void Byte_System_IConvertible_ToUInt64_m2585642112_AdjustorThunk ();
extern "C" void Byte_CompareTo_m4258539704_AdjustorThunk ();
extern "C" void Byte_Equals_m3126389867_AdjustorThunk ();
extern "C" void Byte_GetHashCode_m3721817931_AdjustorThunk ();
extern "C" void Byte_CompareTo_m1892343665_AdjustorThunk ();
extern "C" void Byte_Equals_m1337305152_AdjustorThunk ();
extern "C" void Byte_Parse_m1814198899 ();
extern "C" void Byte_Parse_m554247074 ();
extern "C" void Byte_Parse_m868734818 ();
extern "C" void Byte_TryParse_m2685450601 ();
extern "C" void Byte_TryParse_m4209699724 ();
extern "C" void Byte_ToString_m2616748329_AdjustorThunk ();
extern "C" void Byte_ToString_m671282125_AdjustorThunk ();
extern "C" void Byte_ToString_m2546846173_AdjustorThunk ();
extern "C" void Byte_ToString_m3577895365_AdjustorThunk ();
extern "C" void Char__cctor_m452321216 ();
extern "C" void Char_System_IConvertible_ToType_m2538743012_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToBoolean_m537010113_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToByte_m368092121_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToChar_m3896722647_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToDateTime_m2921645934_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToDecimal_m1460935499_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToDouble_m2269302409_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToInt16_m3424988284_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToInt32_m2299257141_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToInt64_m2275506076_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToSByte_m2022971182_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToSingle_m582798654_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToUInt16_m539785571_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToUInt32_m1570679825_AdjustorThunk ();
extern "C" void Char_System_IConvertible_ToUInt64_m1789501143_AdjustorThunk ();
extern "C" void Char_GetDataTablePointers_m1405454895 ();
extern "C" void Char_CompareTo_m2732644691_AdjustorThunk ();
extern "C" void Char_Equals_m1419514540_AdjustorThunk ();
extern "C" void Char_CompareTo_m1002092952_AdjustorThunk ();
extern "C" void Char_Equals_m1776645521_AdjustorThunk ();
extern "C" void Char_GetHashCode_m2979657488_AdjustorThunk ();
extern "C" void Char_GetUnicodeCategory_m2717630522 ();
extern "C" void Char_IsDigit_m3338391214 ();
extern "C" void Char_IsLetter_m3403728967 ();
extern "C" void Char_IsLetterOrDigit_m3737247547 ();
extern "C" void Char_IsLower_m1385832003 ();
extern "C" void Char_IsSurrogate_m1060330939 ();
extern "C" void Char_IsWhiteSpace_m2502232923 ();
extern "C" void Char_IsWhiteSpace_m1302760694 ();
extern "C" void Char_CheckParameter_m3148718057 ();
extern "C" void Char_Parse_m3763735221 ();
extern "C" void Char_ToLower_m533698221 ();
extern "C" void Char_ToLowerInvariant_m3711249777 ();
extern "C" void Char_ToLower_m3209221761 ();
extern "C" void Char_ToUpper_m2799342664 ();
extern "C" void Char_ToUpperInvariant_m715162991 ();
extern "C" void Char_ToString_m2071629826_AdjustorThunk ();
extern "C" void Char_ToString_m4030094967_AdjustorThunk ();
extern "C" void CharEnumerator__ctor_m816598078 ();
extern "C" void CharEnumerator_System_Collections_IEnumerator_get_Current_m2584858255 ();
extern "C" void CharEnumerator_System_IDisposable_Dispose_m3736572190 ();
extern "C" void CharEnumerator_get_Current_m3833544873 ();
extern "C" void CharEnumerator_Clone_m1959063807 ();
extern "C" void CharEnumerator_MoveNext_m3698672156 ();
extern "C" void CharEnumerator_Reset_m2494774291 ();
extern "C" void CLSCompliantAttribute__ctor_m737514648 ();
extern "C" void ArrayList__ctor_m70425822 ();
extern "C" void ArrayList__ctor_m2581062138 ();
extern "C" void ArrayList__ctor_m4231495083 ();
extern "C" void ArrayList__ctor_m1063251359 ();
extern "C" void ArrayList__cctor_m4247768616 ();
extern "C" void ArrayList_get_Item_m1355466954 ();
extern "C" void ArrayList_set_Item_m1710296082 ();
extern "C" void ArrayList_get_Count_m4127613678 ();
extern "C" void ArrayList_get_Capacity_m1752503341 ();
extern "C" void ArrayList_set_Capacity_m1006741663 ();
extern "C" void ArrayList_get_IsReadOnly_m3126774583 ();
extern "C" void ArrayList_get_IsSynchronized_m516421544 ();
extern "C" void ArrayList_get_SyncRoot_m1474613974 ();
extern "C" void ArrayList_EnsureCapacity_m2860619830 ();
extern "C" void ArrayList_Shift_m570081894 ();
extern "C" void ArrayList_Add_m157538779 ();
extern "C" void ArrayList_Clear_m2610601776 ();
extern "C" void ArrayList_Contains_m2499310892 ();
extern "C" void ArrayList_IndexOf_m2232959246 ();
extern "C" void ArrayList_IndexOf_m2621741218 ();
extern "C" void ArrayList_IndexOf_m586361265 ();
extern "C" void ArrayList_Insert_m2426273317 ();
extern "C" void ArrayList_InsertRange_m2857979734 ();
extern "C" void ArrayList_Remove_m3885363094 ();
extern "C" void ArrayList_RemoveAt_m2796573225 ();
extern "C" void ArrayList_CopyTo_m3012638111 ();
extern "C" void ArrayList_CopyTo_m3145284264 ();
extern "C" void ArrayList_CopyTo_m2961909916 ();
extern "C" void ArrayList_GetEnumerator_m4023866036 ();
extern "C" void ArrayList_AddRange_m1925203467 ();
extern "C" void ArrayList_Sort_m1218270835 ();
extern "C" void ArrayList_Sort_m3021096803 ();
extern "C" void ArrayList_ToArray_m1200471464 ();
extern "C" void ArrayList_ToArray_m1867007925 ();
extern "C" void ArrayList_Clone_m100144916 ();
extern "C" void ArrayList_ThrowNewArgumentOutOfRangeException_m2252161667 ();
extern "C" void ArrayList_Synchronized_m2483064372 ();
extern "C" void ArrayList_ReadOnly_m91252091 ();
extern "C" void ArrayListWrapper__ctor_m3899135388 ();
extern "C" void ArrayListWrapper_get_Item_m2139389851 ();
extern "C" void ArrayListWrapper_set_Item_m2576274800 ();
extern "C" void ArrayListWrapper_get_Count_m585664997 ();
extern "C" void ArrayListWrapper_get_Capacity_m321457925 ();
extern "C" void ArrayListWrapper_set_Capacity_m1854908382 ();
extern "C" void ArrayListWrapper_get_IsReadOnly_m1516100188 ();
extern "C" void ArrayListWrapper_get_IsSynchronized_m1380460345 ();
extern "C" void ArrayListWrapper_get_SyncRoot_m1551171319 ();
extern "C" void ArrayListWrapper_Add_m1618290023 ();
extern "C" void ArrayListWrapper_Clear_m1968562395 ();
extern "C" void ArrayListWrapper_Contains_m3388742496 ();
extern "C" void ArrayListWrapper_IndexOf_m4032143405 ();
extern "C" void ArrayListWrapper_IndexOf_m1380666464 ();
extern "C" void ArrayListWrapper_IndexOf_m4005555211 ();
extern "C" void ArrayListWrapper_Insert_m2350735743 ();
extern "C" void ArrayListWrapper_InsertRange_m996305444 ();
extern "C" void ArrayListWrapper_Remove_m1536517963 ();
extern "C" void ArrayListWrapper_RemoveAt_m1604324386 ();
extern "C" void ArrayListWrapper_CopyTo_m638148083 ();
extern "C" void ArrayListWrapper_CopyTo_m55533230 ();
extern "C" void ArrayListWrapper_CopyTo_m67152964 ();
extern "C" void ArrayListWrapper_GetEnumerator_m462054671 ();
extern "C" void ArrayListWrapper_AddRange_m3354276885 ();
extern "C" void ArrayListWrapper_Clone_m3762341118 ();
extern "C" void ArrayListWrapper_Sort_m2710892576 ();
extern "C" void ArrayListWrapper_Sort_m3931576544 ();
extern "C" void ArrayListWrapper_ToArray_m3610130614 ();
extern "C" void ArrayListWrapper_ToArray_m2818105233 ();
extern "C" void FixedSizeArrayListWrapper__ctor_m1339347849 ();
extern "C" void FixedSizeArrayListWrapper_get_ErrorMessage_m598057428 ();
extern "C" void FixedSizeArrayListWrapper_get_Capacity_m1143681750 ();
extern "C" void FixedSizeArrayListWrapper_set_Capacity_m1786958233 ();
extern "C" void FixedSizeArrayListWrapper_Add_m4013748259 ();
extern "C" void FixedSizeArrayListWrapper_AddRange_m734417375 ();
extern "C" void FixedSizeArrayListWrapper_Clear_m2323207240 ();
extern "C" void FixedSizeArrayListWrapper_Insert_m2489443233 ();
extern "C" void FixedSizeArrayListWrapper_InsertRange_m61442832 ();
extern "C" void FixedSizeArrayListWrapper_Remove_m2839585768 ();
extern "C" void FixedSizeArrayListWrapper_RemoveAt_m3801664381 ();
extern "C" void ReadOnlyArrayListWrapper__ctor_m883851205 ();
extern "C" void ReadOnlyArrayListWrapper_get_ErrorMessage_m1560397620 ();
extern "C" void ReadOnlyArrayListWrapper_get_IsReadOnly_m1722342459 ();
extern "C" void ReadOnlyArrayListWrapper_get_Item_m4156760050 ();
extern "C" void ReadOnlyArrayListWrapper_set_Item_m2152307432 ();
extern "C" void ReadOnlyArrayListWrapper_Sort_m2935735686 ();
extern "C" void ReadOnlyArrayListWrapper_Sort_m2841153375 ();
extern "C" void SimpleEnumerator__ctor_m1607516457 ();
extern "C" void SimpleEnumerator__cctor_m688277358 ();
extern "C" void SimpleEnumerator_Clone_m2545363783 ();
extern "C" void SimpleEnumerator_MoveNext_m1479781237 ();
extern "C" void SimpleEnumerator_get_Current_m4120015282 ();
extern "C" void SimpleEnumerator_Reset_m972226863 ();
extern "C" void SynchronizedArrayListWrapper__ctor_m2878473993 ();
extern "C" void SynchronizedArrayListWrapper_get_Item_m358168471 ();
extern "C" void SynchronizedArrayListWrapper_set_Item_m431710062 ();
extern "C" void SynchronizedArrayListWrapper_get_Count_m1824482348 ();
extern "C" void SynchronizedArrayListWrapper_get_Capacity_m494532482 ();
extern "C" void SynchronizedArrayListWrapper_set_Capacity_m3751911178 ();
extern "C" void SynchronizedArrayListWrapper_get_IsReadOnly_m382158438 ();
extern "C" void SynchronizedArrayListWrapper_get_IsSynchronized_m2278830943 ();
extern "C" void SynchronizedArrayListWrapper_get_SyncRoot_m946396334 ();
extern "C" void SynchronizedArrayListWrapper_Add_m1304395445 ();
extern "C" void SynchronizedArrayListWrapper_Clear_m2740166537 ();
extern "C" void SynchronizedArrayListWrapper_Contains_m817992432 ();
extern "C" void SynchronizedArrayListWrapper_IndexOf_m3481712645 ();
extern "C" void SynchronizedArrayListWrapper_IndexOf_m3030774803 ();
extern "C" void SynchronizedArrayListWrapper_IndexOf_m542789323 ();
extern "C" void SynchronizedArrayListWrapper_Insert_m2908780893 ();
extern "C" void SynchronizedArrayListWrapper_InsertRange_m616773182 ();
extern "C" void SynchronizedArrayListWrapper_Remove_m451513 ();
extern "C" void SynchronizedArrayListWrapper_RemoveAt_m3250877830 ();
extern "C" void SynchronizedArrayListWrapper_CopyTo_m1203270203 ();
extern "C" void SynchronizedArrayListWrapper_CopyTo_m4129451812 ();
extern "C" void SynchronizedArrayListWrapper_CopyTo_m3469183378 ();
extern "C" void SynchronizedArrayListWrapper_GetEnumerator_m3776320929 ();
extern "C" void SynchronizedArrayListWrapper_AddRange_m468224541 ();
extern "C" void SynchronizedArrayListWrapper_Clone_m1454917992 ();
extern "C" void SynchronizedArrayListWrapper_Sort_m4054587096 ();
extern "C" void SynchronizedArrayListWrapper_Sort_m2230728101 ();
extern "C" void SynchronizedArrayListWrapper_ToArray_m1932530011 ();
extern "C" void SynchronizedArrayListWrapper_ToArray_m3791919948 ();
extern "C" void BitArray__ctor_m557858207 ();
extern "C" void BitArray__ctor_m284741893 ();
extern "C" void BitArray_getByte_m304351007 ();
extern "C" void BitArray_get_Count_m718376312 ();
extern "C" void BitArray_get_Item_m3173645844 ();
extern "C" void BitArray_set_Item_m2690807699 ();
extern "C" void BitArray_get_Length_m529007171 ();
extern "C" void BitArray_get_SyncRoot_m2524613174 ();
extern "C" void BitArray_Clone_m3731712203 ();
extern "C" void BitArray_CopyTo_m1556941566 ();
extern "C" void BitArray_Get_m1899066644 ();
extern "C" void BitArray_Set_m4046644063 ();
extern "C" void BitArray_GetEnumerator_m948738958 ();
extern "C" void BitArrayEnumerator__ctor_m2931067439 ();
extern "C" void BitArrayEnumerator_Clone_m80699169 ();
extern "C" void BitArrayEnumerator_get_Current_m105604645 ();
extern "C" void BitArrayEnumerator_MoveNext_m1136090680 ();
extern "C" void BitArrayEnumerator_Reset_m1553789913 ();
extern "C" void BitArrayEnumerator_checkVersion_m1310474920 ();
extern "C" void CaseInsensitiveComparer__ctor_m3394790491 ();
extern "C" void CaseInsensitiveComparer__ctor_m1540511401 ();
extern "C" void CaseInsensitiveComparer__cctor_m1608601064 ();
extern "C" void CaseInsensitiveComparer_get_DefaultInvariant_m1657624612 ();
extern "C" void CaseInsensitiveComparer_Compare_m3521105559 ();
extern "C" void CaseInsensitiveHashCodeProvider__ctor_m824792119 ();
extern "C" void CaseInsensitiveHashCodeProvider__ctor_m53391934 ();
extern "C" void CaseInsensitiveHashCodeProvider__cctor_m4056930009 ();
extern "C" void CaseInsensitiveHashCodeProvider_AreEqual_m4116505741 ();
extern "C" void CaseInsensitiveHashCodeProvider_AreEqual_m246872803 ();
extern "C" void CaseInsensitiveHashCodeProvider_get_DefaultInvariant_m1271415162 ();
extern "C" void CaseInsensitiveHashCodeProvider_GetHashCode_m1025902239 ();
extern "C" void CollectionBase__ctor_m64526301 ();
extern "C" void CollectionBase_System_Collections_ICollection_CopyTo_m1186223115 ();
extern "C" void CollectionBase_System_Collections_ICollection_get_SyncRoot_m2009406771 ();
extern "C" void CollectionBase_System_Collections_IList_Add_m3513351711 ();
extern "C" void CollectionBase_System_Collections_IList_Contains_m3583405864 ();
extern "C" void CollectionBase_System_Collections_IList_IndexOf_m1135629131 ();
extern "C" void CollectionBase_System_Collections_IList_Insert_m1082419815 ();
extern "C" void CollectionBase_System_Collections_IList_Remove_m3378308850 ();
extern "C" void CollectionBase_System_Collections_IList_get_Item_m2445814078 ();
extern "C" void CollectionBase_System_Collections_IList_set_Item_m4129363821 ();
extern "C" void CollectionBase_get_Count_m2616627533 ();
extern "C" void CollectionBase_GetEnumerator_m3044469114 ();
extern "C" void CollectionBase_Clear_m263220074 ();
extern "C" void CollectionBase_RemoveAt_m660112964 ();
extern "C" void CollectionBase_get_InnerList_m2963615431 ();
extern "C" void CollectionBase_get_List_m1608088501 ();
extern "C" void CollectionBase_OnClear_m388760764 ();
extern "C" void CollectionBase_OnClearComplete_m2008662635 ();
extern "C" void CollectionBase_OnInsert_m3012729704 ();
extern "C" void CollectionBase_OnInsertComplete_m2949237076 ();
extern "C" void CollectionBase_OnRemove_m1044728288 ();
extern "C" void CollectionBase_OnRemoveComplete_m2998598348 ();
extern "C" void CollectionBase_OnSet_m1421124237 ();
extern "C" void CollectionBase_OnSetComplete_m2165368507 ();
extern "C" void CollectionBase_OnValidate_m131111051 ();
extern "C" void Comparer__ctor_m323909656 ();
extern "C" void Comparer__ctor_m2235688870 ();
extern "C" void Comparer__cctor_m2014499048 ();
extern "C" void Comparer_Compare_m1640866209 ();
extern "C" void Comparer_GetObjectData_m1518991269 ();
extern "C" void DictionaryEntry__ctor_m2063096505_AdjustorThunk ();
extern "C" void DictionaryEntry_get_Key_m905225745_AdjustorThunk ();
extern "C" void DictionaryEntry_get_Value_m2234983563_AdjustorThunk ();
extern "C" void KeyNotFoundException__ctor_m949509995 ();
extern "C" void KeyNotFoundException__ctor_m1245077268 ();
extern "C" void KeyNotFoundException__ctor_m4164238210 ();
extern "C" void Hashtable__ctor_m845111805 ();
extern "C" void Hashtable__ctor_m2531087936 ();
extern "C" void Hashtable__ctor_m1409638163 ();
extern "C" void Hashtable__ctor_m465423475 ();
extern "C" void Hashtable__ctor_m3063561525 ();
extern "C" void Hashtable__ctor_m4115579798 ();
extern "C" void Hashtable__ctor_m2991153945 ();
extern "C" void Hashtable__ctor_m3453182740 ();
extern "C" void Hashtable__ctor_m2767843923 ();
extern "C" void Hashtable__ctor_m951508135 ();
extern "C" void Hashtable__ctor_m492426044 ();
extern "C" void Hashtable__ctor_m3196409060 ();
extern "C" void Hashtable__cctor_m1851349339 ();
extern "C" void Hashtable_System_Collections_IEnumerable_GetEnumerator_m437113998 ();
extern "C" void Hashtable_set_comparer_m2487397675 ();
extern "C" void Hashtable_set_hcp_m3808793454 ();
extern "C" void Hashtable_get_Count_m2964937294 ();
extern "C" void Hashtable_get_SyncRoot_m4112442421 ();
extern "C" void Hashtable_get_Keys_m2621026335 ();
extern "C" void Hashtable_get_Values_m3348718762 ();
extern "C" void Hashtable_get_Item_m4212788697 ();
extern "C" void Hashtable_set_Item_m3837373968 ();
extern "C" void Hashtable_CopyTo_m3145836984 ();
extern "C" void Hashtable_Add_m2095220904 ();
extern "C" void Hashtable_Clear_m4221147505 ();
extern "C" void Hashtable_Contains_m942197096 ();
extern "C" void Hashtable_GetEnumerator_m2066958023 ();
extern "C" void Hashtable_Remove_m3318034014 ();
extern "C" void Hashtable_ContainsKey_m1475605912 ();
extern "C" void Hashtable_Clone_m2835046085 ();
extern "C" void Hashtable_GetObjectData_m610578011 ();
extern "C" void Hashtable_OnDeserialization_m2722627116 ();
extern "C" void Hashtable_Synchronized_m4050155833 ();
extern "C" void Hashtable_GetHash_m3196631685 ();
extern "C" void Hashtable_KeyEquals_m1206006735 ();
extern "C" void Hashtable_AdjustThreshold_m4151578734 ();
extern "C" void Hashtable_SetTable_m2328234381 ();
extern "C" void Hashtable_Find_m1372428189 ();
extern "C" void Hashtable_Rehash_m1394039683 ();
extern "C" void Hashtable_PutImpl_m1536427327 ();
extern "C" void Hashtable_CopyToArray_m292146207 ();
extern "C" void Hashtable_TestPrime_m150100682 ();
extern "C" void Hashtable_CalcPrime_m3698159848 ();
extern "C" void Hashtable_ToPrime_m4218640530 ();
extern "C" void Enumerator__ctor_m2116331586 ();
extern "C" void Enumerator__cctor_m160908549 ();
extern "C" void Enumerator_FailFast_m3323592279 ();
extern "C" void Enumerator_Reset_m2830298090 ();
extern "C" void Enumerator_MoveNext_m605642959 ();
extern "C" void Enumerator_get_Entry_m605716437 ();
extern "C" void Enumerator_get_Key_m3505377930 ();
extern "C" void Enumerator_get_Value_m2630880774 ();
extern "C" void Enumerator_get_Current_m2016534146 ();
extern "C" void HashKeys__ctor_m2069026984 ();
extern "C" void HashKeys_get_Count_m803578660 ();
extern "C" void HashKeys_get_SyncRoot_m1360220610 ();
extern "C" void HashKeys_CopyTo_m3826682869 ();
extern "C" void HashKeys_GetEnumerator_m2700559596 ();
extern "C" void HashValues__ctor_m2856824715 ();
extern "C" void HashValues_get_Count_m3268869044 ();
extern "C" void HashValues_get_SyncRoot_m1468680878 ();
extern "C" void HashValues_CopyTo_m3362116997 ();
extern "C" void HashValues_GetEnumerator_m3272952739 ();
extern "C" void KeyMarker__ctor_m1746200090 ();
extern "C" void KeyMarker__cctor_m355977784 ();
extern "C" void SyncHashtable__ctor_m1416406087 ();
extern "C" void SyncHashtable__ctor_m4259573849 ();
extern "C" void SyncHashtable_System_Collections_IEnumerable_GetEnumerator_m3567539983 ();
extern "C" void SyncHashtable_GetObjectData_m2886177721 ();
extern "C" void SyncHashtable_get_Count_m3914611452 ();
extern "C" void SyncHashtable_get_SyncRoot_m1630311250 ();
extern "C" void SyncHashtable_get_Keys_m3976306703 ();
extern "C" void SyncHashtable_get_Values_m3263999743 ();
extern "C" void SyncHashtable_get_Item_m3883387363 ();
extern "C" void SyncHashtable_set_Item_m3140123867 ();
extern "C" void SyncHashtable_CopyTo_m2922163603 ();
extern "C" void SyncHashtable_Add_m2676378853 ();
extern "C" void SyncHashtable_Clear_m644445575 ();
extern "C" void SyncHashtable_Contains_m2611691164 ();
extern "C" void SyncHashtable_GetEnumerator_m3088435708 ();
extern "C" void SyncHashtable_Remove_m2135837390 ();
extern "C" void SyncHashtable_ContainsKey_m2888735141 ();
extern "C" void SyncHashtable_Clone_m1003912175 ();
extern "C" void SortedList__ctor_m3018506472 ();
extern "C" void SortedList__ctor_m2465239628 ();
extern "C" void SortedList__ctor_m126780072 ();
extern "C" void SortedList__ctor_m2326936499 ();
extern "C" void SortedList__cctor_m2523980940 ();
extern "C" void SortedList_System_Collections_IEnumerable_GetEnumerator_m3871906508 ();
extern "C" void SortedList_get_Count_m3966073133 ();
extern "C" void SortedList_get_SyncRoot_m1289287974 ();
extern "C" void SortedList_get_IsFixedSize_m1492404192 ();
extern "C" void SortedList_get_IsReadOnly_m3632497429 ();
extern "C" void SortedList_get_Item_m3087767982 ();
extern "C" void SortedList_set_Item_m4106950526 ();
extern "C" void SortedList_get_Capacity_m468427824 ();
extern "C" void SortedList_set_Capacity_m2666993721 ();
extern "C" void SortedList_Add_m3773519169 ();
extern "C" void SortedList_Contains_m2476056822 ();
extern "C" void SortedList_GetEnumerator_m3806466162 ();
extern "C" void SortedList_Remove_m2925628248 ();
extern "C" void SortedList_CopyTo_m1975587912 ();
extern "C" void SortedList_Clone_m649794916 ();
extern "C" void SortedList_RemoveAt_m1692307306 ();
extern "C" void SortedList_IndexOfKey_m4035592023 ();
extern "C" void SortedList_ContainsKey_m70250271 ();
extern "C" void SortedList_GetByIndex_m2974579137 ();
extern "C" void SortedList_EnsureCapacity_m755143429 ();
extern "C" void SortedList_PutImpl_m2910780230 ();
extern "C" void SortedList_GetImpl_m573218660 ();
extern "C" void SortedList_InitTable_m3274319759 ();
extern "C" void SortedList_Find_m2120694659 ();
extern "C" void Enumerator__ctor_m899540130 ();
extern "C" void Enumerator__cctor_m2471822497 ();
extern "C" void Enumerator_Reset_m1021019657 ();
extern "C" void Enumerator_MoveNext_m427993968 ();
extern "C" void Enumerator_get_Entry_m3247439187 ();
extern "C" void Enumerator_get_Key_m581327934 ();
extern "C" void Enumerator_get_Value_m905791323 ();
extern "C" void Enumerator_get_Current_m3792662002 ();
extern "C" void Enumerator_Clone_m2132804677 ();
extern "C" void Stack__ctor_m226659344 ();
extern "C" void Stack__ctor_m1585753039 ();
extern "C" void Stack__ctor_m4037460071 ();
extern "C" void Stack_Resize_m3618767241 ();
extern "C" void Stack_get_Count_m1451039529 ();
extern "C" void Stack_get_SyncRoot_m12094254 ();
extern "C" void Stack_Clear_m1214438660 ();
extern "C" void Stack_Clone_m2977777692 ();
extern "C" void Stack_CopyTo_m223801485 ();
extern "C" void Stack_GetEnumerator_m2293825770 ();
extern "C" void Stack_Peek_m1718230687 ();
extern "C" void Stack_Pop_m3135319567 ();
extern "C" void Stack_Push_m1840909377 ();
extern "C" void Enumerator__ctor_m57585216 ();
extern "C" void Enumerator_Clone_m2688689214 ();
extern "C" void Enumerator_get_Current_m785454466 ();
extern "C" void Enumerator_MoveNext_m951516890 ();
extern "C" void Enumerator_Reset_m4254584650 ();
extern "C" void Console__cctor_m3665180519 ();
extern "C" void Console_SetEncodings_m3388682721 ();
extern "C" void Console_get_Error_m2959955103 ();
extern "C" void Console_Open_m2222222234 ();
extern "C" void Console_OpenStandardError_m3945139383 ();
extern "C" void Console_OpenStandardInput_m4255021723 ();
extern "C" void Console_OpenStandardOutput_m4244304095 ();
extern "C" void ContextBoundObject__ctor_m2389594085 ();
extern "C" void Convert__cctor_m1348217113 ();
extern "C" void Convert_InternalFromBase64String_m1999808388 ();
extern "C" void Convert_FromBase64String_m1814398667 ();
extern "C" void Convert_ToBase64String_m1844775360 ();
extern "C" void Convert_ToBase64String_m3328115434 ();
extern "C" void Convert_ToBoolean_m1910542813 ();
extern "C" void Convert_ToBoolean_m1131559381 ();
extern "C" void Convert_ToBoolean_m1621594009 ();
extern "C" void Convert_ToBoolean_m2918377884 ();
extern "C" void Convert_ToBoolean_m2062582429 ();
extern "C" void Convert_ToBoolean_m3415677277 ();
extern "C" void Convert_ToBoolean_m1887725282 ();
extern "C" void Convert_ToBoolean_m4032852316 ();
extern "C" void Convert_ToBoolean_m1974261568 ();
extern "C" void Convert_ToBoolean_m707738265 ();
extern "C" void Convert_ToBoolean_m1122829536 ();
extern "C" void Convert_ToBoolean_m3283955427 ();
extern "C" void Convert_ToBoolean_m141721054 ();
extern "C" void Convert_ToBoolean_m2126966028 ();
extern "C" void Convert_ToByte_m2418019072 ();
extern "C" void Convert_ToByte_m1629144100 ();
extern "C" void Convert_ToByte_m943279547 ();
extern "C" void Convert_ToByte_m2006661353 ();
extern "C" void Convert_ToByte_m2688521858 ();
extern "C" void Convert_ToByte_m720591656 ();
extern "C" void Convert_ToByte_m428988434 ();
extern "C" void Convert_ToByte_m1519340743 ();
extern "C" void Convert_ToByte_m1994836698 ();
extern "C" void Convert_ToByte_m61718991 ();
extern "C" void Convert_ToByte_m1661043916 ();
extern "C" void Convert_ToByte_m1674698270 ();
extern "C" void Convert_ToByte_m3099814251 ();
extern "C" void Convert_ToByte_m2153487333 ();
extern "C" void Convert_ToByte_m2328740238 ();
extern "C" void Convert_ToChar_m341655201 ();
extern "C" void Convert_ToChar_m1417206938 ();
extern "C" void Convert_ToChar_m2194714762 ();
extern "C" void Convert_ToChar_m2289024986 ();
extern "C" void Convert_ToChar_m1568898469 ();
extern "C" void Convert_ToChar_m341774582 ();
extern "C" void Convert_ToChar_m2449990607 ();
extern "C" void Convert_ToChar_m337390725 ();
extern "C" void Convert_ToChar_m2214938048 ();
extern "C" void Convert_ToChar_m453700468 ();
extern "C" void Convert_ToChar_m1502158591 ();
extern "C" void Convert_ToDateTime_m3022706915 ();
extern "C" void Convert_ToDateTime_m3123344040 ();
extern "C" void Convert_ToDateTime_m2349462082 ();
extern "C" void Convert_ToDateTime_m144170519 ();
extern "C" void Convert_ToDateTime_m3523522050 ();
extern "C" void Convert_ToDateTime_m2080905788 ();
extern "C" void Convert_ToDateTime_m3011399261 ();
extern "C" void Convert_ToDateTime_m1737814825 ();
extern "C" void Convert_ToDateTime_m3526800699 ();
extern "C" void Convert_ToDateTime_m1351566174 ();
extern "C" void Convert_ToDecimal_m917895651 ();
extern "C" void Convert_ToDecimal_m1035337631 ();
extern "C" void Convert_ToDecimal_m3992210978 ();
extern "C" void Convert_ToDecimal_m346154981 ();
extern "C" void Convert_ToDecimal_m2765597768 ();
extern "C" void Convert_ToDecimal_m1301317035 ();
extern "C" void Convert_ToDecimal_m3074456322 ();
extern "C" void Convert_ToDecimal_m3255111027 ();
extern "C" void Convert_ToDecimal_m3776158860 ();
extern "C" void Convert_ToDecimal_m71072042 ();
extern "C" void Convert_ToDecimal_m362315142 ();
extern "C" void Convert_ToDecimal_m690090213 ();
extern "C" void Convert_ToDecimal_m1381390199 ();
extern "C" void Convert_ToDecimal_m4261852857 ();
extern "C" void Convert_ToDouble_m1756601764 ();
extern "C" void Convert_ToDouble_m3163203741 ();
extern "C" void Convert_ToDouble_m603356361 ();
extern "C" void Convert_ToDouble_m3378959113 ();
extern "C" void Convert_ToDouble_m1478598732 ();
extern "C" void Convert_ToDouble_m2832031852 ();
extern "C" void Convert_ToDouble_m2711196326 ();
extern "C" void Convert_ToDouble_m2409248499 ();
extern "C" void Convert_ToDouble_m897723048 ();
extern "C" void Convert_ToDouble_m2204999786 ();
extern "C" void Convert_ToDouble_m2406944942 ();
extern "C" void Convert_ToDouble_m132850532 ();
extern "C" void Convert_ToDouble_m2474254574 ();
extern "C" void Convert_ToDouble_m2045000883 ();
extern "C" void Convert_ToInt16_m168570275 ();
extern "C" void Convert_ToInt16_m3628395616 ();
extern "C" void Convert_ToInt16_m4032762688 ();
extern "C" void Convert_ToInt16_m3551750683 ();
extern "C" void Convert_ToInt16_m1306446694 ();
extern "C" void Convert_ToInt16_m2684953918 ();
extern "C" void Convert_ToInt16_m4075378878 ();
extern "C" void Convert_ToInt16_m2073193617 ();
extern "C" void Convert_ToInt16_m3142197079 ();
extern "C" void Convert_ToInt16_m613514068 ();
extern "C" void Convert_ToInt16_m2943709440 ();
extern "C" void Convert_ToInt16_m3910677062 ();
extern "C" void Convert_ToInt16_m4194599106 ();
extern "C" void Convert_ToInt16_m2462923612 ();
extern "C" void Convert_ToInt16_m2376763746 ();
extern "C" void Convert_ToInt16_m1068380511 ();
extern "C" void Convert_ToInt32_m1913871629 ();
extern "C" void Convert_ToInt32_m269108287 ();
extern "C" void Convert_ToInt32_m2887001068 ();
extern "C" void Convert_ToInt32_m3621959368 ();
extern "C" void Convert_ToInt32_m3479988113 ();
extern "C" void Convert_ToInt32_m539814434 ();
extern "C" void Convert_ToInt32_m2094411742 ();
extern "C" void Convert_ToInt32_m2414750495 ();
extern "C" void Convert_ToInt32_m916183032 ();
extern "C" void Convert_ToInt32_m1734262585 ();
extern "C" void Convert_ToInt32_m2422887349 ();
extern "C" void Convert_ToInt32_m2545494139 ();
extern "C" void Convert_ToInt32_m1812481528 ();
extern "C" void Convert_ToInt32_m4119363714 ();
extern "C" void Convert_ToInt32_m2423655579 ();
extern "C" void Convert_ToInt64_m2482280580 ();
extern "C" void Convert_ToInt64_m214907410 ();
extern "C" void Convert_ToInt64_m1580918798 ();
extern "C" void Convert_ToInt64_m914666505 ();
extern "C" void Convert_ToInt64_m2761514965 ();
extern "C" void Convert_ToInt64_m1737805477 ();
extern "C" void Convert_ToInt64_m198370789 ();
extern "C" void Convert_ToInt64_m1189889578 ();
extern "C" void Convert_ToInt64_m2719224162 ();
extern "C" void Convert_ToInt64_m3285416634 ();
extern "C" void Convert_ToInt64_m363300557 ();
extern "C" void Convert_ToInt64_m420957009 ();
extern "C" void Convert_ToInt64_m513460999 ();
extern "C" void Convert_ToInt64_m1220027300 ();
extern "C" void Convert_ToInt64_m3686795582 ();
extern "C" void Convert_ToInt64_m3118196590 ();
extern "C" void Convert_ToInt64_m753440118 ();
extern "C" void Convert_ToSByte_m3654808220 ();
extern "C" void Convert_ToSByte_m2221295796 ();
extern "C" void Convert_ToSByte_m1198711592 ();
extern "C" void Convert_ToSByte_m4039538944 ();
extern "C" void Convert_ToSByte_m2255796510 ();
extern "C" void Convert_ToSByte_m1171878403 ();
extern "C" void Convert_ToSByte_m2364369564 ();
extern "C" void Convert_ToSByte_m2473384867 ();
extern "C" void Convert_ToSByte_m1899553949 ();
extern "C" void Convert_ToSByte_m1260639261 ();
extern "C" void Convert_ToSByte_m3263476780 ();
extern "C" void Convert_ToSByte_m621137857 ();
extern "C" void Convert_ToSByte_m502382709 ();
extern "C" void Convert_ToSByte_m1923387717 ();
extern "C" void Convert_ToSingle_m3318222669 ();
extern "C" void Convert_ToSingle_m497029939 ();
extern "C" void Convert_ToSingle_m3061264469 ();
extern "C" void Convert_ToSingle_m2124907566 ();
extern "C" void Convert_ToSingle_m1485709412 ();
extern "C" void Convert_ToSingle_m3497393878 ();
extern "C" void Convert_ToSingle_m3170522883 ();
extern "C" void Convert_ToSingle_m2927637723 ();
extern "C" void Convert_ToSingle_m3251546179 ();
extern "C" void Convert_ToSingle_m333023240 ();
extern "C" void Convert_ToSingle_m263664334 ();
extern "C" void Convert_ToSingle_m108240803 ();
extern "C" void Convert_ToSingle_m4264044771 ();
extern "C" void Convert_ToSingle_m1813734906 ();
extern "C" void Convert_ToString_m3326707857 ();
extern "C" void Convert_ToString_m3608477782 ();
extern "C" void Convert_ToUInt16_m3589406227 ();
extern "C" void Convert_ToUInt16_m262507043 ();
extern "C" void Convert_ToUInt16_m1916842140 ();
extern "C" void Convert_ToUInt16_m1590911059 ();
extern "C" void Convert_ToUInt16_m1460061451 ();
extern "C" void Convert_ToUInt16_m2605846227 ();
extern "C" void Convert_ToUInt16_m3441577881 ();
extern "C" void Convert_ToUInt16_m2315016985 ();
extern "C" void Convert_ToUInt16_m3851674843 ();
extern "C" void Convert_ToUInt16_m598870541 ();
extern "C" void Convert_ToUInt16_m1969507677 ();
extern "C" void Convert_ToUInt16_m271993144 ();
extern "C" void Convert_ToUInt16_m3417160479 ();
extern "C" void Convert_ToUInt16_m848830585 ();
extern "C" void Convert_ToUInt32_m2890507400 ();
extern "C" void Convert_ToUInt32_m4225679663 ();
extern "C" void Convert_ToUInt32_m1139469487 ();
extern "C" void Convert_ToUInt32_m899358007 ();
extern "C" void Convert_ToUInt32_m3538128733 ();
extern "C" void Convert_ToUInt32_m2750411885 ();
extern "C" void Convert_ToUInt32_m1509256923 ();
extern "C" void Convert_ToUInt32_m413938554 ();
extern "C" void Convert_ToUInt32_m3371003386 ();
extern "C" void Convert_ToUInt32_m1967326106 ();
extern "C" void Convert_ToUInt32_m3357398318 ();
extern "C" void Convert_ToUInt32_m2624224331 ();
extern "C" void Convert_ToUInt32_m4087217800 ();
extern "C" void Convert_ToUInt32_m441301288 ();
extern "C" void Convert_ToUInt64_m3421432777 ();
extern "C" void Convert_ToUInt64_m588351329 ();
extern "C" void Convert_ToUInt64_m1305628260 ();
extern "C" void Convert_ToUInt64_m152153280 ();
extern "C" void Convert_ToUInt64_m1532445467 ();
extern "C" void Convert_ToUInt64_m332078237 ();
extern "C" void Convert_ToUInt64_m2034597942 ();
extern "C" void Convert_ToUInt64_m2644784328 ();
extern "C" void Convert_ToUInt64_m1758528004 ();
extern "C" void Convert_ToUInt64_m4235029228 ();
extern "C" void Convert_ToUInt64_m441916607 ();
extern "C" void Convert_ToUInt64_m2608704228 ();
extern "C" void Convert_ToUInt64_m2802651835 ();
extern "C" void Convert_ToUInt64_m2087886788 ();
extern "C" void Convert_ToUInt64_m2300482675 ();
extern "C" void Convert_ChangeType_m4075677086 ();
extern "C" void Convert_ToType_m1179773789 ();
extern "C" void CultureAwareComparer__ctor_m1207791012 ();
extern "C" void CultureAwareComparer_Compare_m3648725758 ();
extern "C" void CultureAwareComparer_Equals_m2362988938 ();
extern "C" void CultureAwareComparer_GetHashCode_m570187225 ();
extern "C" void CurrentSystemTimeZone__ctor_m3019315113 ();
extern "C" void CurrentSystemTimeZone__ctor_m2626520283 ();
extern "C" void CurrentSystemTimeZone_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m259544414 ();
extern "C" void CurrentSystemTimeZone_GetTimeZoneData_m215114922 ();
extern "C" void CurrentSystemTimeZone_GetDaylightChanges_m2566143843 ();
extern "C" void CurrentSystemTimeZone_GetUtcOffset_m2935116097 ();
extern "C" void CurrentSystemTimeZone_OnDeserialization_m4190759288 ();
extern "C" void CurrentSystemTimeZone_GetDaylightTimeFromData_m3408586635 ();
extern "C" void DateTime__ctor_m1027259371_AdjustorThunk ();
extern "C" void DateTime__ctor_m3541836835_AdjustorThunk ();
extern "C" void DateTime__ctor_m2644107222_AdjustorThunk ();
extern "C" void DateTime__ctor_m1926671090_AdjustorThunk ();
extern "C" void DateTime__ctor_m1384254117_AdjustorThunk ();
extern "C" void DateTime__cctor_m3460172510 ();
extern "C" void DateTime_System_IConvertible_ToBoolean_m3632788782_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToByte_m140177676_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToChar_m664934809_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToDateTime_m1263645741_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToDecimal_m3890829851_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToDouble_m1162257995_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToInt16_m1402526305_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToInt32_m3197463939_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToInt64_m1064366169_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToSByte_m4208861919_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToSingle_m2351654096_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToType_m768938949_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToUInt16_m2777441341_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToUInt32_m1274319574_AdjustorThunk ();
extern "C" void DateTime_System_IConvertible_ToUInt64_m1734005549_AdjustorThunk ();
extern "C" void DateTime_AbsoluteDays_m662719526 ();
extern "C" void DateTime_FromTicks_m485172754_AdjustorThunk ();
extern "C" void DateTime_get_Month_m4165080545_AdjustorThunk ();
extern "C" void DateTime_get_Day_m896245515_AdjustorThunk ();
extern "C" void DateTime_get_DayOfWeek_m2939993125_AdjustorThunk ();
extern "C" void DateTime_get_Hour_m2800068934_AdjustorThunk ();
extern "C" void DateTime_get_Minute_m2080337245_AdjustorThunk ();
extern "C" void DateTime_get_Second_m1756323831_AdjustorThunk ();
extern "C" void DateTime_GetTimeMonotonic_m3455016556 ();
extern "C" void DateTime_GetNow_m4053549187 ();
extern "C" void DateTime_get_Now_m1925541424 ();
extern "C" void DateTime_get_Ticks_m1568760618_AdjustorThunk ();
extern "C" void DateTime_get_Today_m3230239018 ();
extern "C" void DateTime_get_UtcNow_m3828112662 ();
extern "C" void DateTime_get_Year_m4152477509_AdjustorThunk ();
extern "C" void DateTime_get_Kind_m1602235531_AdjustorThunk ();
extern "C" void DateTime_Add_m592174673_AdjustorThunk ();
extern "C" void DateTime_AddTicks_m1235861880_AdjustorThunk ();
extern "C" void DateTime_AddMilliseconds_m2189489516_AdjustorThunk ();
extern "C" void DateTime_AddSeconds_m916727128_AdjustorThunk ();
extern "C" void DateTime_Compare_m453481671 ();
extern "C" void DateTime_CompareTo_m39293199_AdjustorThunk ();
extern "C" void DateTime_CompareTo_m2611454681_AdjustorThunk ();
extern "C" void DateTime_Equals_m2876590215_AdjustorThunk ();
extern "C" void DateTime_FromBinary_m2399234721 ();
extern "C" void DateTime_SpecifyKind_m3350820625 ();
extern "C" void DateTime_DaysInMonth_m2570372843 ();
extern "C" void DateTime_Equals_m3711038146_AdjustorThunk ();
extern "C" void DateTime_CheckDateTimeKind_m1552287883_AdjustorThunk ();
extern "C" void DateTime_GetHashCode_m3696582555_AdjustorThunk ();
extern "C" void DateTime_IsLeapYear_m3299279581 ();
extern "C" void DateTime_Parse_m1095371782 ();
extern "C" void DateTime_Parse_m2695626789 ();
extern "C" void DateTime_CoreParse_m557529197 ();
extern "C" void DateTime_YearMonthDayFormats_m741320887 ();
extern "C" void DateTime__ParseNumber_m4238331684 ();
extern "C" void DateTime__ParseEnum_m2419676920 ();
extern "C" void DateTime__ParseString_m2294737794 ();
extern "C" void DateTime__ParseAmPm_m2558690232 ();
extern "C" void DateTime__ParseTimeSeparator_m1035910457 ();
extern "C" void DateTime__ParseDateSeparator_m1823941406 ();
extern "C" void DateTime_IsLetter_m2365043383 ();
extern "C" void DateTime__DoParse_m1912887474 ();
extern "C" void DateTime_ParseExact_m2553678435 ();
extern "C" void DateTime_ParseExact_m3456146807 ();
extern "C" void DateTime_CheckStyle_m3808154593 ();
extern "C" void DateTime_ParseExact_m3984936769 ();
extern "C" void DateTime_Subtract_m3350263303_AdjustorThunk ();
extern "C" void DateTime_ToString_m3729341423_AdjustorThunk ();
extern "C" void DateTime_ToString_m1414090114_AdjustorThunk ();
extern "C" void DateTime_ToString_m3183648526_AdjustorThunk ();
extern "C" void DateTime_ToLocalTime_m4017440156_AdjustorThunk ();
extern "C" void DateTime_ToUniversalTime_m2779765572_AdjustorThunk ();
extern "C" void DateTime_op_Addition_m1787700689 ();
extern "C" void DateTime_op_Equality_m3013014607 ();
extern "C" void DateTime_op_GreaterThan_m1806441651 ();
extern "C" void DateTime_op_GreaterThanOrEqual_m914020694 ();
extern "C" void DateTime_op_Inequality_m4036645441 ();
extern "C" void DateTime_op_LessThan_m3146868751 ();
extern "C" void DateTime_op_LessThanOrEqual_m1144734147 ();
extern "C" void DateTime_op_Subtraction_m646944166 ();
extern "C" void DateTimeOffset__ctor_m393815523_AdjustorThunk ();
extern "C" void DateTimeOffset__ctor_m690748493_AdjustorThunk ();
extern "C" void DateTimeOffset__ctor_m2315704004_AdjustorThunk ();
extern "C" void DateTimeOffset__ctor_m3565797660_AdjustorThunk ();
extern "C" void DateTimeOffset__cctor_m4092712168 ();
extern "C" void DateTimeOffset_System_IComparable_CompareTo_m2751518275_AdjustorThunk ();
extern "C" void DateTimeOffset_System_Runtime_Serialization_ISerializable_GetObjectData_m2791453454_AdjustorThunk ();
extern "C" void DateTimeOffset_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m2865451658_AdjustorThunk ();
extern "C" void DateTimeOffset_CompareTo_m2878534399_AdjustorThunk ();
extern "C" void DateTimeOffset_Equals_m1208643636_AdjustorThunk ();
extern "C" void DateTimeOffset_Equals_m3867471892_AdjustorThunk ();
extern "C" void DateTimeOffset_GetHashCode_m1491551126_AdjustorThunk ();
extern "C" void DateTimeOffset_ToString_m573727808_AdjustorThunk ();
extern "C" void DateTimeOffset_ToString_m268102416_AdjustorThunk ();
extern "C" void DateTimeOffset_get_DateTime_m3102418896_AdjustorThunk ();
extern "C" void DateTimeOffset_get_Offset_m2501267323_AdjustorThunk ();
extern "C" void DateTimeOffset_get_UtcDateTime_m4198775470_AdjustorThunk ();
extern "C" void DateTimeUtils_CountRepeat_m1875087316 ();
extern "C" void DateTimeUtils_ZeroPad_m4061994436 ();
extern "C" void DateTimeUtils_ParseQuotedString_m1500812331 ();
extern "C" void DateTimeUtils_GetStandardPattern_m899129541 ();
extern "C" void DateTimeUtils_GetStandardPattern_m3209988641 ();
extern "C" void DateTimeUtils_ToString_m943113255 ();
extern "C" void DateTimeUtils_ToString_m1660361122 ();
extern "C" void DBNull__ctor_m1760941697 ();
extern "C" void DBNull__ctor_m3761983109 ();
extern "C" void DBNull__cctor_m24967054 ();
extern "C" void DBNull_System_IConvertible_ToBoolean_m2364984202 ();
extern "C" void DBNull_System_IConvertible_ToByte_m3424062133 ();
extern "C" void DBNull_System_IConvertible_ToChar_m2773824425 ();
extern "C" void DBNull_System_IConvertible_ToDateTime_m1876132951 ();
extern "C" void DBNull_System_IConvertible_ToDecimal_m1768131063 ();
extern "C" void DBNull_System_IConvertible_ToDouble_m4030181152 ();
extern "C" void DBNull_System_IConvertible_ToInt16_m4130785595 ();
extern "C" void DBNull_System_IConvertible_ToInt32_m3582990580 ();
extern "C" void DBNull_System_IConvertible_ToInt64_m2437803837 ();
extern "C" void DBNull_System_IConvertible_ToSByte_m2927018638 ();
extern "C" void DBNull_System_IConvertible_ToSingle_m1319016320 ();
extern "C" void DBNull_System_IConvertible_ToType_m2866590128 ();
extern "C" void DBNull_System_IConvertible_ToUInt16_m3550134390 ();
extern "C" void DBNull_System_IConvertible_ToUInt32_m165681718 ();
extern "C" void DBNull_System_IConvertible_ToUInt64_m3568278568 ();
extern "C" void DBNull_GetObjectData_m1645577515 ();
extern "C" void DBNull_ToString_m852284939 ();
extern "C" void DBNull_ToString_m1304363896 ();
extern "C" void Decimal__ctor_m2375467100_AdjustorThunk ();
extern "C" void Decimal__ctor_m1233034355_AdjustorThunk ();
extern "C" void Decimal__ctor_m2545903267_AdjustorThunk ();
extern "C" void Decimal__ctor_m1632238500_AdjustorThunk ();
extern "C" void Decimal__ctor_m3377077937_AdjustorThunk ();
extern "C" void Decimal__ctor_m1426586083_AdjustorThunk ();
extern "C" void Decimal__ctor_m3781718484_AdjustorThunk ();
extern "C" void Decimal__cctor_m952889160 ();
extern "C" void Decimal_System_IConvertible_ToType_m1041976950_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToBoolean_m448140043_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToByte_m3090076580_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToChar_m29672976_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToDateTime_m64040985_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToDecimal_m2186204236_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToDouble_m3800580116_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToInt16_m72561042_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToInt32_m3196844544_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToInt64_m1310352674_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToSByte_m1240667516_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToSingle_m1684053230_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToUInt16_m1392242618_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToUInt32_m1541164744_AdjustorThunk ();
extern "C" void Decimal_System_IConvertible_ToUInt64_m1292652844_AdjustorThunk ();
extern "C" void Decimal_GetBits_m2327903701 ();
extern "C" void Decimal_Add_m2113577551 ();
extern "C" void Decimal_Subtract_m3576317969 ();
extern "C" void Decimal_GetHashCode_m3714536886_AdjustorThunk ();
extern "C" void Decimal_u64_m989125512 ();
extern "C" void Decimal_s64_m2348649978 ();
extern "C" void Decimal_Equals_m747729212 ();
extern "C" void Decimal_Equals_m631014508_AdjustorThunk ();
extern "C" void Decimal_IsZero_m40595514_AdjustorThunk ();
extern "C" void Decimal_Floor_m2290876548 ();
extern "C" void Decimal_Multiply_m3373936600 ();
extern "C" void Decimal_Divide_m2503346782 ();
extern "C" void Decimal_Compare_m3646660628 ();
extern "C" void Decimal_CompareTo_m2097498843_AdjustorThunk ();
extern "C" void Decimal_CompareTo_m3857970533_AdjustorThunk ();
extern "C" void Decimal_Equals_m3693295319_AdjustorThunk ();
extern "C" void Decimal_Parse_m178433692 ();
extern "C" void Decimal_ThrowAtPos_m4275655439 ();
extern "C" void Decimal_ThrowInvalidExp_m2284341434 ();
extern "C" void Decimal_stripStyles_m3902823558 ();
extern "C" void Decimal_Parse_m3400819519 ();
extern "C" void Decimal_PerformParse_m2858098378 ();
extern "C" void Decimal_ToString_m3060605991_AdjustorThunk ();
extern "C" void Decimal_ToString_m2927434073_AdjustorThunk ();
extern "C" void Decimal_ToString_m3544392991_AdjustorThunk ();
extern "C" void Decimal_decimal2UInt64_m2672947272 ();
extern "C" void Decimal_decimal2Int64_m2561288189 ();
extern "C" void Decimal_decimalIncr_m2154115687 ();
extern "C" void Decimal_string2decimal_m1084491150 ();
extern "C" void Decimal_decimalSetExponent_m568585892 ();
extern "C" void Decimal_decimal2double_m703402254 ();
extern "C" void Decimal_decimalFloorAndTrunc_m1022640108 ();
extern "C" void Decimal_decimalMult_m2114411602 ();
extern "C" void Decimal_decimalDiv_m300208215 ();
extern "C" void Decimal_decimalCompare_m1863112118 ();
extern "C" void Decimal_op_Increment_m1974443191 ();
extern "C" void Decimal_op_Subtraction_m930621160 ();
extern "C" void Decimal_op_Multiply_m3784923707 ();
extern "C" void Decimal_op_Division_m4273106878 ();
extern "C" void Decimal_op_Explicit_m1253500197 ();
extern "C" void Decimal_op_Explicit_m1503313322 ();
extern "C" void Decimal_op_Explicit_m284229644 ();
extern "C" void Decimal_op_Explicit_m1521124198 ();
extern "C" void Decimal_op_Explicit_m4264442304 ();
extern "C" void Decimal_op_Explicit_m1054949672 ();
extern "C" void Decimal_op_Explicit_m1320737014 ();
extern "C" void Decimal_op_Explicit_m2818597674 ();
extern "C" void Decimal_op_Implicit_m1321015723 ();
extern "C" void Decimal_op_Implicit_m1540208279 ();
extern "C" void Decimal_op_Implicit_m2474035815 ();
extern "C" void Decimal_op_Implicit_m980199957 ();
extern "C" void Decimal_op_Implicit_m2978332954 ();
extern "C" void Decimal_op_Implicit_m881253395 ();
extern "C" void Decimal_op_Implicit_m3473468664 ();
extern "C" void Decimal_op_Implicit_m809477236 ();
extern "C" void Decimal_op_Explicit_m3470941409 ();
extern "C" void Decimal_op_Explicit_m2236159626 ();
extern "C" void Decimal_op_Explicit_m4098952179 ();
extern "C" void Decimal_op_Explicit_m1643748915 ();
extern "C" void Decimal_op_Inequality_m2362282707 ();
extern "C" void Decimal_op_Equality_m63189074 ();
extern "C" void Decimal_op_GreaterThan_m1575087537 ();
extern "C" void Decimal_op_LessThan_m2754705003 ();
extern "C" void Delegate_get_Method_m722699673 ();
extern "C" void Delegate_get_Target_m4255055791 ();
extern "C" void Delegate_CreateDelegate_internal_m1804039199 ();
extern "C" void Delegate_SetMulticastInvoke_m2431511429 ();
extern "C" void Delegate_arg_type_match_m3839365790 ();
extern "C" void Delegate_return_type_match_m35901976 ();
extern "C" void Delegate_CreateDelegate_m1528872118 ();
extern "C" void Delegate_CreateDelegate_m1475733018 ();
extern "C" void Delegate_CreateDelegate_m1719653086 ();
extern "C" void Delegate_CreateDelegate_m2037718425 ();
extern "C" void Delegate_GetCandidateMethod_m3741128559 ();
extern "C" void Delegate_CreateDelegate_m2565795613 ();
extern "C" void Delegate_CreateDelegate_m1955057739 ();
extern "C" void Delegate_CreateDelegate_m1770444889 ();
extern "C" void Delegate_CreateDelegate_m3279529823 ();
extern "C" void Delegate_Clone_m631165656 ();
extern "C" void Delegate_Equals_m1707779987 ();
extern "C" void Delegate_GetHashCode_m2388227318 ();
extern "C" void Delegate_GetObjectData_m1078969361 ();
extern "C" void Delegate_GetInvocationList_m2881246543 ();
extern "C" void Delegate_Combine_m1818817617 ();
extern "C" void Delegate_Combine_m1500603169 ();
extern "C" void Delegate_CombineImpl_m233686841 ();
extern "C" void Delegate_Remove_m2436345873 ();
extern "C" void Delegate_RemoveImpl_m4202643787 ();
extern "C" void DelegateSerializationHolder__ctor_m2950190668 ();
extern "C" void DelegateSerializationHolder_GetDelegateData_m1287770054 ();
extern "C" void DelegateSerializationHolder_GetObjectData_m2048210184 ();
extern "C" void DelegateSerializationHolder_GetRealObject_m2761320795 ();
extern "C" void DelegateEntry__ctor_m596353592 ();
extern "C" void DelegateEntry_DeserializeDelegate_m179836656 ();
extern "C" void DebuggableAttribute__ctor_m2582985872 ();
extern "C" void DebuggerBrowsableAttribute__ctor_m2340592270 ();
extern "C" void DebuggerDisplayAttribute__ctor_m4023377227 ();
extern "C" void DebuggerDisplayAttribute_set_Name_m528775879 ();
extern "C" void DebuggerHiddenAttribute__ctor_m1902081030 ();
extern "C" void DebuggerStepThroughAttribute__ctor_m4239143502 ();
extern "C" void DebuggerTypeProxyAttribute__ctor_m716875895 ();
extern "C" void StackFrame__ctor_m3047066617 ();
extern "C" void StackFrame__ctor_m2822438684 ();
extern "C" void StackFrame_get_frame_info_m1855966903 ();
extern "C" void StackFrame_GetFileLineNumber_m2815894532 ();
extern "C" void StackFrame_GetFileName_m1839350649 ();
extern "C" void StackFrame_GetSecureFileName_m5595071 ();
extern "C" void StackFrame_GetILOffset_m242737610 ();
extern "C" void StackFrame_GetMethod_m3559755628 ();
extern "C" void StackFrame_GetNativeOffset_m225286671 ();
extern "C" void StackFrame_GetInternalMethodName_m3598100589 ();
extern "C" void StackFrame_ToString_m353061470 ();
extern "C" void StackTrace__ctor_m3421260247 ();
extern "C" void StackTrace__ctor_m2586972645 ();
extern "C" void StackTrace__ctor_m1174316567 ();
extern "C" void StackTrace__ctor_m2775913378 ();
extern "C" void StackTrace__ctor_m4038793957 ();
extern "C" void StackTrace_init_frames_m451976113 ();
extern "C" void StackTrace_get_trace_m87107404 ();
extern "C" void StackTrace_get_FrameCount_m3366875035 ();
extern "C" void StackTrace_GetFrame_m3312688971 ();
extern "C" void StackTrace_ToString_m324270236 ();
extern "C" void DivideByZeroException__ctor_m686050583 ();
extern "C" void DivideByZeroException__ctor_m33029225 ();
extern "C" void DllNotFoundException__ctor_m1841441813 ();
extern "C" void DllNotFoundException__ctor_m1149151497 ();
extern "C" void Double_System_IConvertible_ToType_m950968201_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToBoolean_m156639669_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToByte_m3237704766_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToChar_m4163693792_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToDateTime_m2408138350_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToDecimal_m2112247527_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToDouble_m2588339855_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToInt16_m2545112260_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToInt32_m2575974537_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToInt64_m951275453_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToSByte_m4038606575_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToSingle_m2268595922_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToUInt16_m289568425_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToUInt32_m2811496434_AdjustorThunk ();
extern "C" void Double_System_IConvertible_ToUInt64_m1064701039_AdjustorThunk ();
extern "C" void Double_CompareTo_m1498322386_AdjustorThunk ();
extern "C" void Double_Equals_m2453452523_AdjustorThunk ();
extern "C" void Double_CompareTo_m1296920832_AdjustorThunk ();
extern "C" void Double_Equals_m1537334590_AdjustorThunk ();
extern "C" void Double_GetHashCode_m2774968031_AdjustorThunk ();
extern "C" void Double_IsInfinity_m3491993807 ();
extern "C" void Double_IsNaN_m372022469 ();
extern "C" void Double_IsNegativeInfinity_m2038118090 ();
extern "C" void Double_IsPositiveInfinity_m1010549376 ();
extern "C" void Double_Parse_m2069326782 ();
extern "C" void Double_Parse_m3156113049 ();
extern "C" void Double_Parse_m2014590239 ();
extern "C" void Double_Parse_m1455251062 ();
extern "C" void Double_TryParseStringConstant_m2044222428 ();
extern "C" void Double_ParseImpl_m652289071 ();
extern "C" void Double_ToString_m3526598450_AdjustorThunk ();
extern "C" void Double_ToString_m3425342682_AdjustorThunk ();
extern "C" void Double_ToString_m498721196_AdjustorThunk ();
extern "C" void EntryPointNotFoundException__ctor_m3921716307 ();
extern "C" void EntryPointNotFoundException__ctor_m1098388418 ();
extern "C" void Enum__ctor_m4213025137 ();
extern "C" void Enum__cctor_m2049588518 ();
extern "C" void Enum_System_IConvertible_ToBoolean_m1850576853 ();
extern "C" void Enum_System_IConvertible_ToByte_m1253629655 ();
extern "C" void Enum_System_IConvertible_ToChar_m2632223723 ();
extern "C" void Enum_System_IConvertible_ToDateTime_m4226917540 ();
extern "C" void Enum_System_IConvertible_ToDecimal_m2519275684 ();
extern "C" void Enum_System_IConvertible_ToDouble_m1455222111 ();
extern "C" void Enum_System_IConvertible_ToInt16_m3169802136 ();
extern "C" void Enum_System_IConvertible_ToInt32_m1691541055 ();
extern "C" void Enum_System_IConvertible_ToInt64_m2002405858 ();
extern "C" void Enum_System_IConvertible_ToSByte_m128325077 ();
extern "C" void Enum_System_IConvertible_ToSingle_m2765862699 ();
extern "C" void Enum_System_IConvertible_ToType_m1457416255 ();
extern "C" void Enum_System_IConvertible_ToUInt16_m1201277658 ();
extern "C" void Enum_System_IConvertible_ToUInt32_m3371194579 ();
extern "C" void Enum_System_IConvertible_ToUInt64_m464125294 ();
extern "C" void Enum_GetTypeCode_m2021821451 ();
extern "C" void Enum_get_value_m4175244741 ();
extern "C" void Enum_get_Value_m53431365 ();
extern "C" void Enum_FindPosition_m265007466 ();
extern "C" void Enum_GetName_m874261310 ();
extern "C" void Enum_IsDefined_m680461013 ();
extern "C" void Enum_get_underlying_type_m3626539537 ();
extern "C" void Enum_GetUnderlyingType_m1443556329 ();
extern "C" void Enum_FindName_m1104374038 ();
extern "C" void Enum_GetValue_m4025338855 ();
extern "C" void Enum_Parse_m2788862954 ();
extern "C" void Enum_compare_value_to_m3888943458 ();
extern "C" void Enum_CompareTo_m1687633388 ();
extern "C" void Enum_ToString_m4292412120 ();
extern "C" void Enum_ToString_m4269924258 ();
extern "C" void Enum_ToString_m3441869701 ();
extern "C" void Enum_ToString_m3300782106 ();
extern "C" void Enum_ToObject_m78379513 ();
extern "C" void Enum_ToObject_m4274442607 ();
extern "C" void Enum_ToObject_m2048232900 ();
extern "C" void Enum_ToObject_m3196673333 ();
extern "C" void Enum_ToObject_m2696618385 ();
extern "C" void Enum_ToObject_m887634324 ();
extern "C" void Enum_ToObject_m2147101483 ();
extern "C" void Enum_ToObject_m1741150068 ();
extern "C" void Enum_ToObject_m3978950197 ();
extern "C" void Enum_Equals_m823693965 ();
extern "C" void Enum_get_hashcode_m2444713561 ();
extern "C" void Enum_GetHashCode_m2610622810 ();
extern "C" void Enum_FormatSpecifier_X_m3029026223 ();
extern "C" void Enum_FormatFlags_m2409305353 ();
extern "C" void Enum_Format_m1584462606 ();
extern "C" void Environment_get_SocketSecurityEnabled_m544320776 ();
extern "C" void Environment_get_NewLine_m3932835213 ();
extern "C" void Environment_get_Platform_m849787314 ();
extern "C" void Environment_GetOSVersionString_m1737537524 ();
extern "C" void Environment_get_OSVersion_m609277843 ();
extern "C" void Environment_internalGetEnvironmentVariable_m2005550798 ();
extern "C" void Environment_GetEnvironmentVariable_m217924105 ();
extern "C" void Environment_GetWindowsFolderPath_m3651701357 ();
extern "C" void Environment_GetFolderPath_m932095549 ();
extern "C" void Environment_ReadXdgUserDir_m1690141482 ();
extern "C" void Environment_InternalGetFolderPath_m3667664563 ();
extern "C" void Environment_get_IsRunningOnWindows_m394340488 ();
extern "C" void Environment_GetMachineConfigPath_m441963722 ();
extern "C" void Environment_internalGetHome_m2584361417 ();
extern "C" void EventArgs__ctor_m45418584 ();
extern "C" void EventArgs__cctor_m3062301783 ();
extern "C" void EventHandler__ctor_m1973508153 ();
extern "C" void EventHandler_Invoke_m2463096176 ();
extern "C" void EventHandler_BeginInvoke_m3931632318 ();
extern "C" void EventHandler_EndInvoke_m3496186603 ();
extern "C" void Exception__ctor_m1963162063 ();
extern "C" void Exception__ctor_m3522669789 ();
extern "C" void Exception__ctor_m3004450192 ();
extern "C" void Exception__ctor_m4213837374 ();
extern "C" void Exception_get_InnerException_m2520160954 ();
extern "C" void Exception_get_HResult_m3981263987 ();
extern "C" void Exception_set_HResult_m3582735346 ();
extern "C" void Exception_get_ClassName_m2614214744 ();
extern "C" void Exception_get_Message_m571842362 ();
extern "C" void Exception_get_Source_m2477393952 ();
extern "C" void Exception_get_StackTrace_m1179238353 ();
extern "C" void Exception_GetObjectData_m4118996056 ();
extern "C" void Exception_ToString_m653446967 ();
extern "C" void Exception_GetFullNameForStackTrace_m2913020021 ();
extern "C" void Exception_GetType_m3778669904 ();
extern "C" void ExecutionEngineException__ctor_m131762956 ();
extern "C" void ExecutionEngineException__ctor_m1849804984 ();
extern "C" void FieldAccessException__ctor_m3252623332 ();
extern "C" void FieldAccessException__ctor_m1439472429 ();
extern "C" void FieldAccessException__ctor_m3101973560 ();
extern "C" void FlagsAttribute__ctor_m1689062726 ();
extern "C" void FormatException__ctor_m2526052426 ();
extern "C" void FormatException__ctor_m3427739798 ();
extern "C" void FormatException__ctor_m2521959026 ();
extern "C" void GC_SuppressFinalize_m2436602860 ();
extern "C" void Calendar__ctor_m4252530830 ();
extern "C" void Calendar_Clone_m339556131 ();
extern "C" void Calendar_CheckReadOnly_m1443013959 ();
extern "C" void Calendar_get_EraNames_m119638893 ();
extern "C" void CCFixed_FromDateTime_m3601535931 ();
extern "C" void CCFixed_day_of_week_m2094560398 ();
extern "C" void CCGregorianCalendar_is_leap_year_m2352458385 ();
extern "C" void CCGregorianCalendar_fixed_from_dmy_m954821772 ();
extern "C" void CCGregorianCalendar_year_from_fixed_m733920312 ();
extern "C" void CCGregorianCalendar_my_from_fixed_m553562571 ();
extern "C" void CCGregorianCalendar_dmy_from_fixed_m3954005869 ();
extern "C" void CCGregorianCalendar_month_from_fixed_m259489726 ();
extern "C" void CCGregorianCalendar_day_from_fixed_m4237301666 ();
extern "C" void CCGregorianCalendar_GetDayOfMonth_m3715926045 ();
extern "C" void CCGregorianCalendar_GetMonth_m294498333 ();
extern "C" void CCGregorianCalendar_GetYear_m2300336658 ();
extern "C" void CCMath_div_m2825256666 ();
extern "C" void CCMath_mod_m2191621029 ();
extern "C" void CCMath_div_mod_m3469524691 ();
extern "C" void CompareInfo__ctor_m1267878636 ();
extern "C" void CompareInfo__ctor_m3083190225 ();
extern "C" void CompareInfo__cctor_m1359236201 ();
extern "C" void CompareInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m4213073829 ();
extern "C" void CompareInfo_get_UseManagedCollation_m3854275125 ();
extern "C" void CompareInfo_construct_compareinfo_m1203849545 ();
extern "C" void CompareInfo_free_internal_collator_m1219030985 ();
extern "C" void CompareInfo_internal_compare_m138559236 ();
extern "C" void CompareInfo_assign_sortkey_m4278962796 ();
extern "C" void CompareInfo_internal_index_m1140031158 ();
extern "C" void CompareInfo_Finalize_m340112025 ();
extern "C" void CompareInfo_internal_compare_managed_m2182411895 ();
extern "C" void CompareInfo_internal_compare_switch_m1609918365 ();
extern "C" void CompareInfo_Compare_m3932333838 ();
extern "C" void CompareInfo_Compare_m2627226942 ();
extern "C" void CompareInfo_Compare_m2201188574 ();
extern "C" void CompareInfo_Equals_m1097688160 ();
extern "C" void CompareInfo_GetHashCode_m1281902164 ();
extern "C" void CompareInfo_GetSortKey_m1445508551 ();
extern "C" void CompareInfo_IndexOf_m226749063 ();
extern "C" void CompareInfo_internal_index_managed_m593633239 ();
extern "C" void CompareInfo_internal_index_switch_m3526247840 ();
extern "C" void CompareInfo_IndexOf_m2306060771 ();
extern "C" void CompareInfo_IsPrefix_m2747811208 ();
extern "C" void CompareInfo_IsSuffix_m3717393673 ();
extern "C" void CompareInfo_LastIndexOf_m4148412737 ();
extern "C" void CompareInfo_LastIndexOf_m3067704173 ();
extern "C" void CompareInfo_ToString_m3146053996 ();
extern "C" void CompareInfo_get_LCID_m318761828 ();
extern "C" void CultureInfo__ctor_m1901159171 ();
extern "C" void CultureInfo__ctor_m3763344666 ();
extern "C" void CultureInfo__ctor_m2929979851 ();
extern "C" void CultureInfo__ctor_m1991789257 ();
extern "C" void CultureInfo__ctor_m385466406 ();
extern "C" void CultureInfo__cctor_m2379690457 ();
extern "C" void CultureInfo_get_InvariantCulture_m2703857018 ();
extern "C" void CultureInfo_get_CurrentCulture_m3825006640 ();
extern "C" void CultureInfo_get_CurrentUICulture_m4078896923 ();
extern "C" void CultureInfo_ConstructCurrentCulture_m2590567962 ();
extern "C" void CultureInfo_ConstructCurrentUICulture_m1469273297 ();
extern "C" void CultureInfo_get_LCID_m3817325705 ();
extern "C" void CultureInfo_get_Name_m1725862915 ();
extern "C" void CultureInfo_get_Parent_m3935099926 ();
extern "C" void CultureInfo_get_TextInfo_m1735258217 ();
extern "C" void CultureInfo_get_IcuName_m1272887519 ();
extern "C" void CultureInfo_Clone_m1865674518 ();
extern "C" void CultureInfo_Equals_m997543062 ();
extern "C" void CultureInfo_GetHashCode_m1877941735 ();
extern "C" void CultureInfo_ToString_m2906022157 ();
extern "C" void CultureInfo_get_CompareInfo_m4273505092 ();
extern "C" void CultureInfo_get_IsNeutralCulture_m27834099 ();
extern "C" void CultureInfo_CheckNeutral_m1206549274 ();
extern "C" void CultureInfo_get_NumberFormat_m2033804725 ();
extern "C" void CultureInfo_set_NumberFormat_m3286432673 ();
extern "C" void CultureInfo_get_DateTimeFormat_m2788164208 ();
extern "C" void CultureInfo_set_DateTimeFormat_m3462553177 ();
extern "C" void CultureInfo_get_IsReadOnly_m2576711096 ();
extern "C" void CultureInfo_GetFormat_m2988593869 ();
extern "C" void CultureInfo_Construct_m2088591410 ();
extern "C" void CultureInfo_ConstructInternalLocaleFromName_m3836733798 ();
extern "C" void CultureInfo_ConstructInternalLocaleFromLcid_m1660685822 ();
extern "C" void CultureInfo_ConstructInternalLocaleFromCurrentLocale_m3508427564 ();
extern "C" void CultureInfo_construct_internal_locale_from_lcid_m1705957113 ();
extern "C" void CultureInfo_construct_internal_locale_from_name_m498853986 ();
extern "C" void CultureInfo_construct_internal_locale_from_current_locale_m279034963 ();
extern "C" void CultureInfo_construct_datetime_format_m3134253742 ();
extern "C" void CultureInfo_construct_number_format_m926162420 ();
extern "C" void CultureInfo_ConstructInvariant_m748079512 ();
extern "C" void CultureInfo_CreateTextInfo_m1905477652 ();
extern "C" void CultureInfo_CreateCulture_m1951261937 ();
extern "C" void DateTimeFormatInfo__ctor_m1064973436 ();
extern "C" void DateTimeFormatInfo__ctor_m4067902793 ();
extern "C" void DateTimeFormatInfo__cctor_m2312692094 ();
extern "C" void DateTimeFormatInfo_GetInstance_m3501920895 ();
extern "C" void DateTimeFormatInfo_get_IsReadOnly_m3887541955 ();
extern "C" void DateTimeFormatInfo_ReadOnly_m1827068842 ();
extern "C" void DateTimeFormatInfo_Clone_m212216615 ();
extern "C" void DateTimeFormatInfo_GetFormat_m949390545 ();
extern "C" void DateTimeFormatInfo_GetAbbreviatedMonthName_m1384042871 ();
extern "C" void DateTimeFormatInfo_GetEraName_m2370973419 ();
extern "C" void DateTimeFormatInfo_GetMonthName_m580830951 ();
extern "C" void DateTimeFormatInfo_get_RawAbbreviatedDayNames_m771339539 ();
extern "C" void DateTimeFormatInfo_get_RawAbbreviatedMonthNames_m3313163664 ();
extern "C" void DateTimeFormatInfo_get_RawDayNames_m813648654 ();
extern "C" void DateTimeFormatInfo_get_RawMonthNames_m2737417785 ();
extern "C" void DateTimeFormatInfo_get_AMDesignator_m3344343874 ();
extern "C" void DateTimeFormatInfo_get_PMDesignator_m302707128 ();
extern "C" void DateTimeFormatInfo_get_DateSeparator_m716221337 ();
extern "C" void DateTimeFormatInfo_get_TimeSeparator_m1661466174 ();
extern "C" void DateTimeFormatInfo_get_LongDatePattern_m2705252258 ();
extern "C" void DateTimeFormatInfo_get_ShortDatePattern_m554218357 ();
extern "C" void DateTimeFormatInfo_get_ShortTimePattern_m3942384882 ();
extern "C" void DateTimeFormatInfo_get_LongTimePattern_m3610205894 ();
extern "C" void DateTimeFormatInfo_get_MonthDayPattern_m1818175938 ();
extern "C" void DateTimeFormatInfo_get_YearMonthPattern_m3767604897 ();
extern "C" void DateTimeFormatInfo_get_FullDateTimePattern_m3977924960 ();
extern "C" void DateTimeFormatInfo_get_CurrentInfo_m1517247120 ();
extern "C" void DateTimeFormatInfo_get_InvariantInfo_m2896349598 ();
extern "C" void DateTimeFormatInfo_get_Calendar_m3249748714 ();
extern "C" void DateTimeFormatInfo_set_Calendar_m4204099551 ();
extern "C" void DateTimeFormatInfo_get_RFC1123Pattern_m2280292587 ();
extern "C" void DateTimeFormatInfo_get_RoundtripPattern_m1737362490 ();
extern "C" void DateTimeFormatInfo_get_SortableDateTimePattern_m1688789742 ();
extern "C" void DateTimeFormatInfo_get_UniversalSortableDateTimePattern_m3187108552 ();
extern "C" void DateTimeFormatInfo_GetAllDateTimePatternsInternal_m2245060199 ();
extern "C" void DateTimeFormatInfo_FillAllDateTimePatterns_m3641747943 ();
extern "C" void DateTimeFormatInfo_GetAllRawDateTimePatterns_m383470066 ();
extern "C" void DateTimeFormatInfo_GetDayName_m3886558945 ();
extern "C" void DateTimeFormatInfo_GetAbbreviatedDayName_m2980152815 ();
extern "C" void DateTimeFormatInfo_FillInvariantPatterns_m4210018192 ();
extern "C" void DateTimeFormatInfo_PopulateCombinedList_m580969887 ();
extern "C" void DaylightTime__ctor_m3952422893 ();
extern "C" void DaylightTime_get_Start_m1617525025 ();
extern "C" void DaylightTime_get_End_m4047658457 ();
extern "C" void DaylightTime_get_Delta_m347033140 ();
extern "C" void GregorianCalendar__ctor_m118695340 ();
extern "C" void GregorianCalendar__ctor_m2574627420 ();
extern "C" void GregorianCalendar_get_Eras_m3677190740 ();
extern "C" void GregorianCalendar_set_CalendarType_m2401608579 ();
extern "C" void GregorianCalendar_GetDayOfMonth_m3249599849 ();
extern "C" void GregorianCalendar_GetDayOfWeek_m2029231875 ();
extern "C" void GregorianCalendar_GetEra_m1148855638 ();
extern "C" void GregorianCalendar_GetMonth_m3540651416 ();
extern "C" void GregorianCalendar_GetYear_m4044223495 ();
extern "C" void NumberFormatInfo__ctor_m2749641968 ();
extern "C" void NumberFormatInfo__ctor_m640347805 ();
extern "C" void NumberFormatInfo__ctor_m2233308711 ();
extern "C" void NumberFormatInfo__cctor_m951634967 ();
extern "C" void NumberFormatInfo_get_CurrencyDecimalDigits_m3386147374 ();
extern "C" void NumberFormatInfo_get_CurrencyDecimalSeparator_m301819200 ();
extern "C" void NumberFormatInfo_get_CurrencyGroupSeparator_m3551634584 ();
extern "C" void NumberFormatInfo_get_RawCurrencyGroupSizes_m1103619441 ();
extern "C" void NumberFormatInfo_get_CurrencyNegativePattern_m3399374263 ();
extern "C" void NumberFormatInfo_get_CurrencyPositivePattern_m1855739149 ();
extern "C" void NumberFormatInfo_get_CurrencySymbol_m1993166409 ();
extern "C" void NumberFormatInfo_get_CurrentInfo_m3962739977 ();
extern "C" void NumberFormatInfo_get_InvariantInfo_m2020392346 ();
extern "C" void NumberFormatInfo_get_NaNSymbol_m2462412584 ();
extern "C" void NumberFormatInfo_get_NegativeInfinitySymbol_m3044548863 ();
extern "C" void NumberFormatInfo_get_NegativeSign_m304021131 ();
extern "C" void NumberFormatInfo_get_NumberDecimalDigits_m3231800403 ();
extern "C" void NumberFormatInfo_get_NumberDecimalSeparator_m1579432527 ();
extern "C" void NumberFormatInfo_get_NumberGroupSeparator_m3116325849 ();
extern "C" void NumberFormatInfo_get_RawNumberGroupSizes_m139744770 ();
extern "C" void NumberFormatInfo_get_NumberNegativePattern_m3784302135 ();
extern "C" void NumberFormatInfo_set_NumberNegativePattern_m2710420588 ();
extern "C" void NumberFormatInfo_get_PercentDecimalDigits_m697654847 ();
extern "C" void NumberFormatInfo_get_PercentDecimalSeparator_m2303567846 ();
extern "C" void NumberFormatInfo_get_PercentGroupSeparator_m4081103831 ();
extern "C" void NumberFormatInfo_get_RawPercentGroupSizes_m2158439602 ();
extern "C" void NumberFormatInfo_get_PercentNegativePattern_m1825402758 ();
extern "C" void NumberFormatInfo_get_PercentPositivePattern_m1676569335 ();
extern "C" void NumberFormatInfo_get_PercentSymbol_m4225002416 ();
extern "C" void NumberFormatInfo_get_PerMilleSymbol_m3108752395 ();
extern "C" void NumberFormatInfo_get_PositiveInfinitySymbol_m525671517 ();
extern "C" void NumberFormatInfo_get_PositiveSign_m3777856571 ();
extern "C" void NumberFormatInfo_GetFormat_m3221635202 ();
extern "C" void NumberFormatInfo_Clone_m516656634 ();
extern "C" void NumberFormatInfo_GetInstance_m464741399 ();
extern "C" void SortKey__ctor_m2186020651 ();
extern "C" void SortKey__ctor_m1265572398 ();
extern "C" void SortKey_Compare_m1528777764 ();
extern "C" void SortKey_get_OriginalString_m3942611402 ();
extern "C" void SortKey_get_KeyData_m3882341771 ();
extern "C" void SortKey_Equals_m2613032493 ();
extern "C" void SortKey_GetHashCode_m2119632448 ();
extern "C" void SortKey_ToString_m3597365547 ();
extern "C" void TextInfo__ctor_m2743443081 ();
extern "C" void TextInfo__ctor_m909355147 ();
extern "C" void TextInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m3019484889 ();
extern "C" void TextInfo_get_ListSeparator_m3791815108 ();
extern "C" void TextInfo_get_CultureName_m3977656513 ();
extern "C" void TextInfo_Equals_m742173566 ();
extern "C" void TextInfo_GetHashCode_m3293153969 ();
extern "C" void TextInfo_ToString_m3487185234 ();
extern "C" void TextInfo_ToLower_m1674718553 ();
extern "C" void TextInfo_ToUpper_m1689424880 ();
extern "C" void TextInfo_ToLower_m2933028113 ();
extern "C" void TextInfo_Clone_m808132933 ();
extern "C" void Guid__ctor_m863034180_AdjustorThunk ();
extern "C" void Guid__ctor_m64311516_AdjustorThunk ();
extern "C" void Guid__ctor_m3914967784_AdjustorThunk ();
extern "C" void Guid__ctor_m4104065248_AdjustorThunk ();
extern "C" void Guid__cctor_m720166842 ();
extern "C" void Guid_CheckNull_m1244079130 ();
extern "C" void Guid_CheckLength_m339047510 ();
extern "C" void Guid_CheckArray_m1158178513 ();
extern "C" void Guid_Compare_m1114556690 ();
extern "C" void Guid_CompareTo_m1281599267_AdjustorThunk ();
extern "C" void Guid_Equals_m569984024_AdjustorThunk ();
extern "C" void Guid_CompareTo_m601707037_AdjustorThunk ();
extern "C" void Guid_Equals_m3462938272_AdjustorThunk ();
extern "C" void Guid_GetHashCode_m2438320146_AdjustorThunk ();
extern "C" void Guid_ToHex_m1755027096 ();
extern "C" void Guid_NewGuid_m2831319107 ();
extern "C" void Guid_AppendInt_m1964984663 ();
extern "C" void Guid_AppendShort_m2185748500 ();
extern "C" void Guid_AppendByte_m3270752582 ();
extern "C" void Guid_BaseToString_m1958182798_AdjustorThunk ();
extern "C" void Guid_ToString_m2413444111_AdjustorThunk ();
extern "C" void Guid_ToString_m3682994952_AdjustorThunk ();
extern "C" void Guid_ToString_m2480233691_AdjustorThunk ();
extern "C" void Guid_op_Equality_m3232899884 ();
extern "C" void GuidParser__ctor_m1875340791 ();
extern "C" void GuidParser_Reset_m3446695483 ();
extern "C" void GuidParser_AtEnd_m894422050 ();
extern "C" void GuidParser_ThrowFormatException_m3592788942 ();
extern "C" void GuidParser_ParseHex_m1488080526 ();
extern "C" void GuidParser_ParseOptChar_m3263489376 ();
extern "C" void GuidParser_ParseChar_m224736205 ();
extern "C" void GuidParser_ParseGuid1_m529274067 ();
extern "C" void GuidParser_ParseHexPrefix_m2663518229 ();
extern "C" void GuidParser_ParseGuid2_m1534974221 ();
extern "C" void GuidParser_Parse_m3175475972 ();
extern "C" void IndexOutOfRangeException__ctor_m3853417735 ();
extern "C" void IndexOutOfRangeException__ctor_m90218927 ();
extern "C" void IndexOutOfRangeException__ctor_m3328578087 ();
extern "C" void Int16_System_IConvertible_ToBoolean_m1258257395_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToByte_m2047265631_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToChar_m2059138803_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToDateTime_m3256244351_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToDecimal_m3246902503_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToDouble_m2690798103_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToInt16_m276356287_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToInt32_m2249015168_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToInt64_m478817829_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToSByte_m3576027355_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToSingle_m2912735131_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToType_m2023455022_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToUInt16_m4185862917_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToUInt32_m55848512_AdjustorThunk ();
extern "C" void Int16_System_IConvertible_ToUInt64_m1715011417_AdjustorThunk ();
extern "C" void Int16_CompareTo_m4024223808_AdjustorThunk ();
extern "C" void Int16_Equals_m3822415117_AdjustorThunk ();
extern "C" void Int16_GetHashCode_m1828654929_AdjustorThunk ();
extern "C" void Int16_CompareTo_m141684664_AdjustorThunk ();
extern "C" void Int16_Equals_m1153284509_AdjustorThunk ();
extern "C" void Int16_Parse_m2627575781 ();
extern "C" void Int16_Parse_m2026714680 ();
extern "C" void Int16_Parse_m775125160 ();
extern "C" void Int16_TryParse_m321727795 ();
extern "C" void Int16_ToString_m1232102406_AdjustorThunk ();
extern "C" void Int16_ToString_m1509215832_AdjustorThunk ();
extern "C" void Int16_ToString_m3409160761_AdjustorThunk ();
extern "C" void Int16_ToString_m1443892894_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToBoolean_m3258957888_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToByte_m2070645424_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToChar_m3088783839_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToDateTime_m2219281517_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToDecimal_m3396258874_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToDouble_m3772203874_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToInt16_m1067875339_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToInt32_m618586708_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToInt64_m847339591_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToSByte_m2152861902_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToSingle_m1947062248_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToType_m1509005928_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToUInt16_m3662245354_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToUInt32_m1952288927_AdjustorThunk ();
extern "C" void Int32_System_IConvertible_ToUInt64_m1534412572_AdjustorThunk ();
extern "C" void Int32_CompareTo_m2108777184_AdjustorThunk ();
extern "C" void Int32_Equals_m1472643624_AdjustorThunk ();
extern "C" void Int32_GetHashCode_m2878632975_AdjustorThunk ();
extern "C" void Int32_CompareTo_m3032984351_AdjustorThunk ();
extern "C" void Int32_Equals_m1171805382_AdjustorThunk ();
extern "C" void Int32_ProcessTrailingWhitespace_m3281536092 ();
extern "C" void Int32_Parse_m2255291836 ();
extern "C" void Int32_Parse_m2436415266 ();
extern "C" void Int32_CheckStyle_m4200511423 ();
extern "C" void Int32_JumpOverWhite_m3402590262 ();
extern "C" void Int32_FindSign_m2017552105 ();
extern "C" void Int32_FindCurrency_m57662827 ();
extern "C" void Int32_FindExponent_m3328029059 ();
extern "C" void Int32_FindOther_m965379402 ();
extern "C" void Int32_ValidDigit_m1336563760 ();
extern "C" void Int32_GetFormatException_m3862582761 ();
extern "C" void Int32_Parse_m4189501286 ();
extern "C" void Int32_Parse_m4103558534 ();
extern "C" void Int32_Parse_m306671424 ();
extern "C" void Int32_TryParse_m277953443 ();
extern "C" void Int32_TryParse_m481432822 ();
extern "C" void Int32_ToString_m4174161400_AdjustorThunk ();
extern "C" void Int32_ToString_m1361605161_AdjustorThunk ();
extern "C" void Int32_ToString_m3663029280_AdjustorThunk ();
extern "C" void Int32_ToString_m3533529712_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToBoolean_m2295333455_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToByte_m1392815635_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToChar_m3228587634_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToDateTime_m943848141_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToDecimal_m2204058327_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToDouble_m2475420994_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToInt16_m3964579642_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToInt32_m388817291_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToInt64_m2195678983_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToSByte_m96230497_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToSingle_m2198186823_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToType_m38176658_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToUInt16_m2877320216_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToUInt32_m3679147888_AdjustorThunk ();
extern "C" void Int64_System_IConvertible_ToUInt64_m1765812422_AdjustorThunk ();
extern "C" void Int64_CompareTo_m3258845120_AdjustorThunk ();
extern "C" void Int64_Equals_m1972435155_AdjustorThunk ();
extern "C" void Int64_GetHashCode_m647083287_AdjustorThunk ();
extern "C" void Int64_CompareTo_m1266407916_AdjustorThunk ();
extern "C" void Int64_Equals_m2668032080_AdjustorThunk ();
extern "C" void Int64_Parse_m1780576393 ();
extern "C" void Int64_Parse_m1940098924 ();
extern "C" void Int64_Parse_m825191817 ();
extern "C" void Int64_Parse_m3225783458 ();
extern "C" void Int64_Parse_m1796909491 ();
extern "C" void Int64_TryParse_m2364289788 ();
extern "C" void Int64_TryParse_m4162357809 ();
extern "C" void Int64_ToString_m4270274408_AdjustorThunk ();
extern "C" void Int64_ToString_m2602785239_AdjustorThunk ();
extern "C" void Int64_ToString_m2243382644_AdjustorThunk ();
extern "C" void Int64_ToString_m1262429736_AdjustorThunk ();
extern "C" void IntPtr__ctor_m2251341938_AdjustorThunk ();
extern "C" void IntPtr__ctor_m2356916849_AdjustorThunk ();
extern "C" void IntPtr__ctor_m3657584931_AdjustorThunk ();
extern "C" void IntPtr__ctor_m516753180_AdjustorThunk ();
extern "C" void IntPtr_System_Runtime_Serialization_ISerializable_GetObjectData_m3532600940_AdjustorThunk ();
extern "C" void IntPtr_get_Size_m2786508229 ();
extern "C" void IntPtr_Equals_m256578012_AdjustorThunk ();
extern "C" void IntPtr_GetHashCode_m3456713861_AdjustorThunk ();
extern "C" void IntPtr_ToInt64_m1557689473_AdjustorThunk ();
extern "C" void IntPtr_ToPointer_m237804402_AdjustorThunk ();
extern "C" void IntPtr_ToString_m2234603100_AdjustorThunk ();
extern "C" void IntPtr_ToString_m3428022440_AdjustorThunk ();
extern "C" void IntPtr_op_Equality_m2182604147 ();
extern "C" void IntPtr_op_Inequality_m3520486347 ();
extern "C" void IntPtr_op_Explicit_m509961701 ();
extern "C" void IntPtr_op_Explicit_m267845794 ();
extern "C" void IntPtr_op_Explicit_m1997376062 ();
extern "C" void IntPtr_op_Explicit_m2084967252 ();
extern "C" void IntPtr_op_Explicit_m2617312562 ();
extern "C" void InvalidCastException__ctor_m1844616025 ();
extern "C" void InvalidCastException__ctor_m434084184 ();
extern "C" void InvalidCastException__ctor_m2429454138 ();
extern "C" void InvalidOperationException__ctor_m1407392843 ();
extern "C" void InvalidOperationException__ctor_m1898731946 ();
extern "C" void InvalidOperationException__ctor_m2949829146 ();
extern "C" void InvalidOperationException__ctor_m1650147031 ();
extern "C" void BinaryReader__ctor_m127904526 ();
extern "C" void BinaryReader__ctor_m508621868 ();
extern "C" void BinaryReader_System_IDisposable_Dispose_m4193894860 ();
extern "C" void BinaryReader_get_BaseStream_m779836333 ();
extern "C" void BinaryReader_Close_m3328725372 ();
extern "C" void BinaryReader_Dispose_m1538121967 ();
extern "C" void BinaryReader_FillBuffer_m2330151936 ();
extern "C" void BinaryReader_Read_m1785560935 ();
extern "C" void BinaryReader_Read_m935245691 ();
extern "C" void BinaryReader_Read_m2004985024 ();
extern "C" void BinaryReader_ReadCharBytes_m1517619070 ();
extern "C" void BinaryReader_Read7BitEncodedInt_m1499153484 ();
extern "C" void BinaryReader_ReadBoolean_m1042722974 ();
extern "C" void BinaryReader_ReadByte_m1646621174 ();
extern "C" void BinaryReader_ReadBytes_m3764775317 ();
extern "C" void BinaryReader_ReadChar_m3621400607 ();
extern "C" void BinaryReader_ReadDecimal_m1204388083 ();
extern "C" void BinaryReader_ReadDouble_m534280174 ();
extern "C" void BinaryReader_ReadInt16_m2698845981 ();
extern "C" void BinaryReader_ReadInt32_m1355074789 ();
extern "C" void BinaryReader_ReadInt64_m2454328709 ();
extern "C" void BinaryReader_ReadSByte_m3974961331 ();
extern "C" void BinaryReader_ReadString_m3512432278 ();
extern "C" void BinaryReader_ReadSingle_m2289939537 ();
extern "C" void BinaryReader_ReadUInt16_m1631681507 ();
extern "C" void BinaryReader_ReadUInt32_m3322182293 ();
extern "C" void BinaryReader_ReadUInt64_m723726215 ();
extern "C" void BinaryReader_CheckBuffer_m3790516384 ();
extern "C" void Directory_CreateDirectory_m3622336168 ();
extern "C" void Directory_CreateDirectoriesInternal_m3499929365 ();
extern "C" void Directory_Exists_m286263487 ();
extern "C" void Directory_GetCurrentDirectory_m480039028 ();
extern "C" void Directory_GetFiles_m1041759854 ();
extern "C" void Directory_GetFileSystemEntries_m255688542 ();
extern "C" void DirectoryInfo__ctor_m890681190 ();
extern "C" void DirectoryInfo__ctor_m2258013287 ();
extern "C" void DirectoryInfo__ctor_m838735434 ();
extern "C" void DirectoryInfo_Initialize_m2498797325 ();
extern "C" void DirectoryInfo_get_Exists_m629159675 ();
extern "C" void DirectoryInfo_get_Parent_m2557650280 ();
extern "C" void DirectoryInfo_Create_m2034435267 ();
extern "C" void DirectoryInfo_ToString_m3006265559 ();
extern "C" void DirectoryNotFoundException__ctor_m2619724215 ();
extern "C" void DirectoryNotFoundException__ctor_m2363294465 ();
extern "C" void DirectoryNotFoundException__ctor_m2354623603 ();
extern "C" void EndOfStreamException__ctor_m2065854546 ();
extern "C" void EndOfStreamException__ctor_m2887185695 ();
extern "C" void File_Delete_m2544592848 ();
extern "C" void File_Exists_m3793058406 ();
extern "C" void File_Open_m3068617715 ();
extern "C" void File_OpenRead_m1308289889 ();
extern "C" void File_OpenText_m2736292869 ();
extern "C" void FileLoadException__ctor_m923884332 ();
extern "C" void FileLoadException__ctor_m1090799071 ();
extern "C" void FileLoadException_get_Message_m944617484 ();
extern "C" void FileLoadException_GetObjectData_m2307742994 ();
extern "C" void FileLoadException_ToString_m34549924 ();
extern "C" void FileNotFoundException__ctor_m3208471487 ();
extern "C" void FileNotFoundException__ctor_m3553372217 ();
extern "C" void FileNotFoundException__ctor_m983032520 ();
extern "C" void FileNotFoundException_get_Message_m3978484121 ();
extern "C" void FileNotFoundException_GetObjectData_m2478998761 ();
extern "C" void FileNotFoundException_ToString_m3182305104 ();
extern "C" void FileStream__ctor_m3046344057 ();
extern "C" void FileStream__ctor_m2734166934 ();
extern "C" void FileStream__ctor_m1140102067 ();
extern "C" void FileStream__ctor_m2709936877 ();
extern "C" void FileStream__ctor_m2116713316 ();
extern "C" void FileStream_get_CanRead_m666643764 ();
extern "C" void FileStream_get_CanWrite_m186121616 ();
extern "C" void FileStream_get_CanSeek_m2311366262 ();
extern "C" void FileStream_get_Length_m1713916082 ();
extern "C" void FileStream_get_Position_m3714403878 ();
extern "C" void FileStream_set_Position_m1694103145 ();
extern "C" void FileStream_ReadByte_m3615959641 ();
extern "C" void FileStream_WriteByte_m2506315408 ();
extern "C" void FileStream_Read_m2860719275 ();
extern "C" void FileStream_ReadInternal_m2997987951 ();
extern "C" void FileStream_BeginRead_m2954422331 ();
extern "C" void FileStream_EndRead_m1205138216 ();
extern "C" void FileStream_Write_m2223228153 ();
extern "C" void FileStream_WriteInternal_m3820674018 ();
extern "C" void FileStream_BeginWrite_m2423455615 ();
extern "C" void FileStream_EndWrite_m221857023 ();
extern "C" void FileStream_Seek_m997384136 ();
extern "C" void FileStream_SetLength_m39513663 ();
extern "C" void FileStream_Flush_m1921908460 ();
extern "C" void FileStream_Finalize_m881020330 ();
extern "C" void FileStream_Dispose_m1737393572 ();
extern "C" void FileStream_ReadSegment_m495286510 ();
extern "C" void FileStream_WriteSegment_m4215388663 ();
extern "C" void FileStream_FlushBuffer_m3842147122 ();
extern "C" void FileStream_FlushBuffer_m3511979903 ();
extern "C" void FileStream_FlushBufferIfDirty_m289846570 ();
extern "C" void FileStream_RefillBuffer_m2458517104 ();
extern "C" void FileStream_ReadData_m2038918228 ();
extern "C" void FileStream_InitBuffer_m3035975423 ();
extern "C" void FileStream_GetSecureFileName_m3450104283 ();
extern "C" void FileStream_GetSecureFileName_m2178803856 ();
extern "C" void ReadDelegate__ctor_m2896200933 ();
extern "C" void ReadDelegate_Invoke_m1435222661 ();
extern "C" void ReadDelegate_BeginInvoke_m3682657179 ();
extern "C" void ReadDelegate_EndInvoke_m3922614789 ();
extern "C" void WriteDelegate__ctor_m2217994847 ();
extern "C" void WriteDelegate_Invoke_m2081157572 ();
extern "C" void WriteDelegate_BeginInvoke_m2549882639 ();
extern "C" void WriteDelegate_EndInvoke_m1743509461 ();
extern "C" void FileStreamAsyncResult__ctor_m4018330226 ();
extern "C" void FileStreamAsyncResult_CBWrapper_m1314311834 ();
extern "C" void FileStreamAsyncResult_get_AsyncState_m501126754 ();
extern "C" void FileStreamAsyncResult_get_AsyncWaitHandle_m2498636443 ();
extern "C" void FileStreamAsyncResult_get_IsCompleted_m1169080242 ();
extern "C" void FileSystemInfo__ctor_m1107743831 ();
extern "C" void FileSystemInfo__ctor_m3949366445 ();
extern "C" void FileSystemInfo_GetObjectData_m2634626544 ();
extern "C" void FileSystemInfo_get_FullName_m981435160 ();
extern "C" void FileSystemInfo_Refresh_m1493407733 ();
extern "C" void FileSystemInfo_InternalRefresh_m522189018 ();
extern "C" void FileSystemInfo_CheckPath_m3615706202 ();
extern "C" void IOException__ctor_m254247112 ();
extern "C" void IOException__ctor_m1331548362 ();
extern "C" void IOException__ctor_m60105582 ();
extern "C" void IOException__ctor_m2917865815 ();
extern "C" void IOException__ctor_m2914775989 ();
extern "C" void IsolatedStorageException__ctor_m2399319154 ();
extern "C" void IsolatedStorageException__ctor_m2355975989 ();
extern "C" void IsolatedStorageException__ctor_m2595576856 ();
extern "C" void MemoryStream__ctor_m1153506571 ();
extern "C" void MemoryStream__ctor_m2245000628 ();
extern "C" void MemoryStream__ctor_m377488078 ();
extern "C" void MemoryStream_InternalConstructor_m764544276 ();
extern "C" void MemoryStream_CheckIfClosedThrowDisposed_m2360140578 ();
extern "C" void MemoryStream_get_CanRead_m3835421718 ();
extern "C" void MemoryStream_get_CanSeek_m1628625286 ();
extern "C" void MemoryStream_get_CanWrite_m1686271500 ();
extern "C" void MemoryStream_set_Capacity_m1883230090 ();
extern "C" void MemoryStream_get_Length_m437856634 ();
extern "C" void MemoryStream_get_Position_m3120176485 ();
extern "C" void MemoryStream_set_Position_m339672209 ();
extern "C" void MemoryStream_Dispose_m4136771425 ();
extern "C" void MemoryStream_Flush_m44869571 ();
extern "C" void MemoryStream_Read_m1003576465 ();
extern "C" void MemoryStream_ReadByte_m3310399510 ();
extern "C" void MemoryStream_Seek_m4210270740 ();
extern "C" void MemoryStream_CalculateNewCapacity_m1885293639 ();
extern "C" void MemoryStream_Expand_m1736095174 ();
extern "C" void MemoryStream_SetLength_m1317118839 ();
extern "C" void MemoryStream_ToArray_m33743234 ();
extern "C" void MemoryStream_Write_m1872118689 ();
extern "C" void MemoryStream_WriteByte_m487133489 ();
extern "C" void MonoIO__cctor_m2274322288 ();
extern "C" void MonoIO_GetException_m325073311 ();
extern "C" void MonoIO_GetException_m3873616703 ();
extern "C" void MonoIO_CreateDirectory_m690223787 ();
extern "C" void MonoIO_GetFileSystemEntries_m4228557655 ();
extern "C" void MonoIO_GetCurrentDirectory_m2440528746 ();
extern "C" void MonoIO_DeleteFile_m1747178908 ();
extern "C" void MonoIO_GetFileAttributes_m1330330292 ();
extern "C" void MonoIO_GetFileType_m3548209312 ();
extern "C" void MonoIO_ExistsFile_m4083328030 ();
extern "C" void MonoIO_ExistsDirectory_m460199877 ();
extern "C" void MonoIO_GetFileStat_m1421349297 ();
extern "C" void MonoIO_Open_m2707446436 ();
extern "C" void MonoIO_Close_m4094611200 ();
extern "C" void MonoIO_Read_m717585534 ();
extern "C" void MonoIO_Write_m1714668158 ();
extern "C" void MonoIO_Seek_m1453563591 ();
extern "C" void MonoIO_GetLength_m2748600653 ();
extern "C" void MonoIO_SetLength_m1395012412 ();
extern "C" void MonoIO_get_ConsoleOutput_m381562867 ();
extern "C" void MonoIO_get_ConsoleInput_m2790956149 ();
extern "C" void MonoIO_get_ConsoleError_m458167241 ();
extern "C" void MonoIO_get_VolumeSeparatorChar_m3290860617 ();
extern "C" void MonoIO_get_DirectorySeparatorChar_m460683398 ();
extern "C" void MonoIO_get_AltDirectorySeparatorChar_m2410372317 ();
extern "C" void MonoIO_get_PathSeparator_m1187498872 ();
extern "C" void MonoIO_RemapPath_m4108562258 ();
extern "C" void NullStream__ctor_m333121183 ();
extern "C" void NullStream_get_CanRead_m2203648577 ();
extern "C" void NullStream_get_CanSeek_m1963679271 ();
extern "C" void NullStream_get_CanWrite_m1009926118 ();
extern "C" void NullStream_get_Length_m2279762536 ();
extern "C" void NullStream_get_Position_m1949705829 ();
extern "C" void NullStream_set_Position_m212895867 ();
extern "C" void NullStream_Flush_m3434052532 ();
extern "C" void NullStream_Read_m3022202162 ();
extern "C" void NullStream_ReadByte_m2679416287 ();
extern "C" void NullStream_Seek_m2325342734 ();
extern "C" void NullStream_SetLength_m4241737735 ();
extern "C" void NullStream_Write_m2734052681 ();
extern "C" void NullStream_WriteByte_m180574711 ();
extern "C" void Path__cctor_m1182673417 ();
extern "C" void Path_Combine_m3715734842 ();
extern "C" void Path_CleanPath_m587000654 ();
extern "C" void Path_GetDirectoryName_m1793648012 ();
extern "C" void Path_GetFileName_m2078448260 ();
extern "C" void Path_GetFullPath_m2850694796 ();
extern "C" void Path_WindowsDriveAdjustment_m1323197026 ();
extern "C" void Path_InsecureGetFullPath_m2142429469 ();
extern "C" void Path_IsDsc_m4006149363 ();
extern "C" void Path_GetPathRoot_m2257742348 ();
extern "C" void Path_IsPathRooted_m706315654 ();
extern "C" void Path_GetInvalidPathChars_m3949158031 ();
extern "C" void Path_GetServerAndShare_m3189850192 ();
extern "C" void Path_SameRoot_m2719937575 ();
extern "C" void Path_CanonicalizePath_m2252383871 ();
extern "C" void PathTooLongException__ctor_m2875851057 ();
extern "C" void PathTooLongException__ctor_m199774354 ();
extern "C" void PathTooLongException__ctor_m1802317265 ();
extern "C" void SearchPattern__cctor_m1731488231 ();
extern "C" void Stream__ctor_m2595165611 ();
extern "C" void Stream__cctor_m2352701457 ();
extern "C" void Stream_Dispose_m58345995 ();
extern "C" void Stream_Dispose_m1235184734 ();
extern "C" void Stream_Close_m1145425113 ();
extern "C" void Stream_ReadByte_m3089211635 ();
extern "C" void Stream_WriteByte_m2358830811 ();
extern "C" void Stream_BeginRead_m2801101087 ();
extern "C" void Stream_BeginWrite_m576023021 ();
extern "C" void Stream_EndRead_m3875765555 ();
extern "C" void Stream_EndWrite_m2170505350 ();
extern "C" void StreamAsyncResult__ctor_m61719578 ();
extern "C" void StreamAsyncResult_SetComplete_m2436775525 ();
extern "C" void StreamAsyncResult_SetComplete_m4072396035 ();
extern "C" void StreamAsyncResult_get_AsyncState_m805763934 ();
extern "C" void StreamAsyncResult_get_AsyncWaitHandle_m859050593 ();
extern "C" void StreamAsyncResult_get_IsCompleted_m2647936814 ();
extern "C" void StreamAsyncResult_get_Exception_m1408707861 ();
extern "C" void StreamAsyncResult_get_NBytes_m1503908349 ();
extern "C" void StreamAsyncResult_get_Done_m273449559 ();
extern "C" void StreamAsyncResult_set_Done_m3728050232 ();
extern "C" void StreamReader__ctor_m3800634455 ();
extern "C" void StreamReader__ctor_m1497427721 ();
extern "C" void StreamReader__ctor_m564890970 ();
extern "C" void StreamReader__ctor_m1971096640 ();
extern "C" void StreamReader__ctor_m2046924606 ();
extern "C" void StreamReader__cctor_m2686676160 ();
extern "C" void StreamReader_Initialize_m1648093038 ();
extern "C" void StreamReader_Dispose_m1135259915 ();
extern "C" void StreamReader_DoChecks_m3130795215 ();
extern "C" void StreamReader_ReadBuffer_m822987110 ();
extern "C" void StreamReader_Peek_m1418454313 ();
extern "C" void StreamReader_Read_m2817380199 ();
extern "C" void StreamReader_Read_m354217778 ();
extern "C" void StreamReader_FindNextEOL_m75521239 ();
extern "C" void StreamReader_ReadLine_m301472656 ();
extern "C" void StreamReader_ReadToEnd_m2357875299 ();
extern "C" void NullStreamReader__ctor_m606238235 ();
extern "C" void NullStreamReader_Peek_m1178216914 ();
extern "C" void NullStreamReader_Read_m2266751787 ();
extern "C" void NullStreamReader_Read_m1008032484 ();
extern "C" void NullStreamReader_ReadLine_m527468385 ();
extern "C" void NullStreamReader_ReadToEnd_m302770095 ();
extern "C" void StreamWriter__ctor_m124665850 ();
extern "C" void StreamWriter__ctor_m4259096562 ();
extern "C" void StreamWriter__cctor_m2068848624 ();
extern "C" void StreamWriter_Initialize_m3517952154 ();
extern "C" void StreamWriter_set_AutoFlush_m2218912199 ();
extern "C" void StreamWriter_Dispose_m364251551 ();
extern "C" void StreamWriter_Flush_m3873327639 ();
extern "C" void StreamWriter_FlushBytes_m4187352853 ();
extern "C" void StreamWriter_Decode_m2435057951 ();
extern "C" void StreamWriter_Write_m3354196155 ();
extern "C" void StreamWriter_LowLevelWrite_m144202440 ();
extern "C" void StreamWriter_LowLevelWrite_m3922460505 ();
extern "C" void StreamWriter_Write_m3344855415 ();
extern "C" void StreamWriter_Write_m2722904093 ();
extern "C" void StreamWriter_Write_m2124480708 ();
extern "C" void StreamWriter_Close_m3216061938 ();
extern "C" void StreamWriter_Finalize_m4238823298 ();
extern "C" void StringReader__ctor_m2120792881 ();
extern "C" void StringReader_Dispose_m2676840628 ();
extern "C" void StringReader_Peek_m3887889536 ();
extern "C" void StringReader_Read_m1410818423 ();
extern "C" void StringReader_Read_m1914673056 ();
extern "C" void StringReader_ReadLine_m3959855225 ();
extern "C" void StringReader_ReadToEnd_m3512472260 ();
extern "C" void StringReader_CheckObjectDisposedException_m1770092018 ();
extern "C" void SynchronizedReader__ctor_m1030671232 ();
extern "C" void SynchronizedReader_Peek_m619731398 ();
extern "C" void SynchronizedReader_ReadLine_m2317712253 ();
extern "C" void SynchronizedReader_ReadToEnd_m3687710920 ();
extern "C" void SynchronizedReader_Read_m3695306612 ();
extern "C" void SynchronizedReader_Read_m3004765982 ();
extern "C" void SynchronizedWriter__ctor_m656543725 ();
extern "C" void SynchronizedWriter_Close_m2714436712 ();
extern "C" void SynchronizedWriter_Flush_m2386487644 ();
extern "C" void SynchronizedWriter_Write_m653603145 ();
extern "C" void SynchronizedWriter_Write_m2490425531 ();
extern "C" void SynchronizedWriter_Write_m1955696259 ();
extern "C" void SynchronizedWriter_Write_m4177981633 ();
extern "C" void SynchronizedWriter_WriteLine_m3539201113 ();
extern "C" void SynchronizedWriter_WriteLine_m1392051891 ();
extern "C" void TextReader__ctor_m599549953 ();
extern "C" void TextReader__cctor_m1262050920 ();
extern "C" void TextReader_Dispose_m66265068 ();
extern "C" void TextReader_Dispose_m2869876759 ();
extern "C" void TextReader_Peek_m207028174 ();
extern "C" void TextReader_Read_m2964955915 ();
extern "C" void TextReader_Read_m2769771062 ();
extern "C" void TextReader_ReadLine_m1029983807 ();
extern "C" void TextReader_ReadToEnd_m3688262859 ();
extern "C" void TextReader_Synchronized_m2590778601 ();
extern "C" void NullTextReader__ctor_m2827947410 ();
extern "C" void NullTextReader_ReadLine_m3401445917 ();
extern "C" void TextWriter__ctor_m3198288955 ();
extern "C" void TextWriter__cctor_m1164139462 ();
extern "C" void TextWriter_Close_m2431604359 ();
extern "C" void TextWriter_Dispose_m2158707338 ();
extern "C" void TextWriter_Dispose_m1649717177 ();
extern "C" void TextWriter_Flush_m3553256967 ();
extern "C" void TextWriter_Synchronized_m3396118739 ();
extern "C" void TextWriter_Write_m2765732211 ();
extern "C" void TextWriter_Write_m3990727909 ();
extern "C" void TextWriter_Write_m390537503 ();
extern "C" void TextWriter_Write_m1017611963 ();
extern "C" void TextWriter_WriteLine_m3233856660 ();
extern "C" void TextWriter_WriteLine_m1279192657 ();
extern "C" void NullTextWriter__ctor_m1141280443 ();
extern "C" void NullTextWriter_Write_m2013765556 ();
extern "C" void NullTextWriter_Write_m3721300509 ();
extern "C" void NullTextWriter_Write_m2890047477 ();
extern "C" void UnexceptionalStreamReader__ctor_m2400344532 ();
extern "C" void UnexceptionalStreamReader__cctor_m939786749 ();
extern "C" void UnexceptionalStreamReader_Peek_m3198482924 ();
extern "C" void UnexceptionalStreamReader_Read_m2061779030 ();
extern "C" void UnexceptionalStreamReader_Read_m264409809 ();
extern "C" void UnexceptionalStreamReader_CheckEOL_m408300536 ();
extern "C" void UnexceptionalStreamReader_ReadLine_m3933581905 ();
extern "C" void UnexceptionalStreamReader_ReadToEnd_m2904473082 ();
extern "C" void UnexceptionalStreamWriter__ctor_m842043168 ();
extern "C" void UnexceptionalStreamWriter_Flush_m1884199508 ();
extern "C" void UnexceptionalStreamWriter_Write_m2199944806 ();
extern "C" void UnexceptionalStreamWriter_Write_m3279663103 ();
extern "C" void UnexceptionalStreamWriter_Write_m768806348 ();
extern "C" void UnexceptionalStreamWriter_Write_m697134477 ();
extern "C" void UnmanagedMemoryStream_get_CanRead_m1304620089 ();
extern "C" void UnmanagedMemoryStream_get_CanSeek_m3540385675 ();
extern "C" void UnmanagedMemoryStream_get_CanWrite_m2155137361 ();
extern "C" void UnmanagedMemoryStream_get_Length_m4293573839 ();
extern "C" void UnmanagedMemoryStream_get_Position_m1378643060 ();
extern "C" void UnmanagedMemoryStream_set_Position_m143695479 ();
extern "C" void UnmanagedMemoryStream_Read_m2842003147 ();
extern "C" void UnmanagedMemoryStream_ReadByte_m3683539487 ();
extern "C" void UnmanagedMemoryStream_Seek_m737032287 ();
extern "C" void UnmanagedMemoryStream_SetLength_m1082836360 ();
extern "C" void UnmanagedMemoryStream_Flush_m2972825353 ();
extern "C" void UnmanagedMemoryStream_Dispose_m1287975383 ();
extern "C" void UnmanagedMemoryStream_Write_m1342820066 ();
extern "C" void UnmanagedMemoryStream_WriteByte_m3664716057 ();
extern "C" void LocalDataStoreSlot__ctor_m3601079004 ();
extern "C" void LocalDataStoreSlot__cctor_m3219163729 ();
extern "C" void LocalDataStoreSlot_Finalize_m2106500550 ();
extern "C" void MarshalByRefObject__ctor_m2656117921 ();
extern "C" void MarshalByRefObject_get_ObjectIdentity_m3157415857 ();
extern "C" void Math_Abs_m4155529320 ();
extern "C" void Math_Abs_m3490815430 ();
extern "C" void Math_Abs_m2050689009 ();
extern "C" void Math_Floor_m2868312863 ();
extern "C" void Math_Max_m1737240539 ();
extern "C" void Math_Min_m2898138409 ();
extern "C" void Math_Round_m2043849412 ();
extern "C" void Math_Round_m941190684 ();
extern "C" void Math_Pow_m902859463 ();
extern "C" void Math_Sqrt_m2669192963 ();
extern "C" void MemberAccessException__ctor_m1707653143 ();
extern "C" void MemberAccessException__ctor_m2393542836 ();
extern "C" void MemberAccessException__ctor_m2104154496 ();
extern "C" void MethodAccessException__ctor_m541442477 ();
extern "C" void MethodAccessException__ctor_m387096366 ();
extern "C" void MissingFieldException__ctor_m1894240175 ();
extern "C" void MissingFieldException__ctor_m1065923864 ();
extern "C" void MissingFieldException__ctor_m1196397121 ();
extern "C" void MissingFieldException_get_Message_m3790336791 ();
extern "C" void MissingMemberException__ctor_m887262038 ();
extern "C" void MissingMemberException__ctor_m1872643809 ();
extern "C" void MissingMemberException__ctor_m3294640669 ();
extern "C" void MissingMemberException__ctor_m901947305 ();
extern "C" void MissingMemberException_GetObjectData_m3181088585 ();
extern "C" void MissingMemberException_get_Message_m3201407794 ();
extern "C" void MissingMethodException__ctor_m3700049892 ();
extern "C" void MissingMethodException__ctor_m1666152282 ();
extern "C" void MissingMethodException__ctor_m2795898928 ();
extern "C" void MissingMethodException__ctor_m3288422073 ();
extern "C" void MissingMethodException_get_Message_m2284016000 ();
extern "C" void MonoAsyncCall__ctor_m68498696 ();
extern "C" void MonoCustomAttrs__cctor_m4209563544 ();
extern "C" void MonoCustomAttrs_IsUserCattrProvider_m3612979105 ();
extern "C" void MonoCustomAttrs_GetCustomAttributesInternal_m3841876774 ();
extern "C" void MonoCustomAttrs_GetPseudoCustomAttributes_m2838295616 ();
extern "C" void MonoCustomAttrs_GetCustomAttributesBase_m3227454488 ();
extern "C" void MonoCustomAttrs_GetCustomAttribute_m4179188478 ();
extern "C" void MonoCustomAttrs_GetCustomAttributes_m1371831434 ();
extern "C" void MonoCustomAttrs_GetCustomAttributes_m2800682580 ();
extern "C" void MonoCustomAttrs_GetCustomAttributesDataInternal_m2766077647 ();
extern "C" void MonoCustomAttrs_GetCustomAttributesData_m385677270 ();
extern "C" void MonoCustomAttrs_IsDefined_m3898681234 ();
extern "C" void MonoCustomAttrs_IsDefinedInternal_m4148818414 ();
extern "C" void MonoCustomAttrs_GetBasePropertyDefinition_m2982228497 ();
extern "C" void MonoCustomAttrs_GetBase_m3517810493 ();
extern "C" void MonoCustomAttrs_RetrieveAttributeUsage_m2311843294 ();
extern "C" void AttributeInfo__ctor_m1285857649 ();
extern "C" void AttributeInfo_get_Usage_m3451927341 ();
extern "C" void AttributeInfo_get_InheritanceLevel_m2838015478 ();
extern "C" void MonoDocumentationNoteAttribute__ctor_m379452513 ();
extern "C" void MonoEnumInfo__ctor_m3759939735_AdjustorThunk ();
extern "C" void MonoEnumInfo__cctor_m905335985 ();
extern "C" void MonoEnumInfo_get_enum_info_m3635941699 ();
extern "C" void MonoEnumInfo_get_Cache_m1936268453 ();
extern "C" void MonoEnumInfo_GetInfo_m780052133 ();
extern "C" void IntComparer__ctor_m4172929216 ();
extern "C" void IntComparer_Compare_m1795183550 ();
extern "C" void IntComparer_Compare_m1337468578 ();
extern "C" void LongComparer__ctor_m2498885971 ();
extern "C" void LongComparer_Compare_m1369937197 ();
extern "C" void LongComparer_Compare_m2375503760 ();
extern "C" void SByteComparer__ctor_m3472120687 ();
extern "C" void SByteComparer_Compare_m2015588729 ();
extern "C" void SByteComparer_Compare_m3848149989 ();
extern "C" void ShortComparer__ctor_m2177469571 ();
extern "C" void ShortComparer_Compare_m3346626937 ();
extern "C" void ShortComparer_Compare_m2949238292 ();
extern "C" void MonoTODOAttribute__ctor_m2653149720 ();
extern "C" void MonoTODOAttribute__ctor_m956981832 ();
extern "C" void MonoTouchAOTHelper__cctor_m1042324298 ();
extern "C" void MonoType_get_attributes_m2323874482 ();
extern "C" void MonoType_GetDefaultConstructor_m594730275 ();
extern "C" void MonoType_GetAttributeFlagsImpl_m131780615 ();
extern "C" void MonoType_GetConstructorImpl_m1430011647 ();
extern "C" void MonoType_GetConstructors_internal_m489164918 ();
extern "C" void MonoType_GetConstructors_m3120839409 ();
extern "C" void MonoType_InternalGetEvent_m645336830 ();
extern "C" void MonoType_GetEvent_m531418575 ();
extern "C" void MonoType_GetField_m243859047 ();
extern "C" void MonoType_GetFields_internal_m4230754638 ();
extern "C" void MonoType_GetFields_m3131050110 ();
extern "C" void MonoType_GetInterfaces_m20969877 ();
extern "C" void MonoType_GetMethodsByName_m503705917 ();
extern "C" void MonoType_GetMethods_m2896668102 ();
extern "C" void MonoType_GetMethodImpl_m2201018062 ();
extern "C" void MonoType_GetPropertiesByName_m4032150621 ();
extern "C" void MonoType_GetPropertyImpl_m534107472 ();
extern "C" void MonoType_HasElementTypeImpl_m1249231950 ();
extern "C" void MonoType_IsArrayImpl_m2325143669 ();
extern "C" void MonoType_IsByRefImpl_m3718174569 ();
extern "C" void MonoType_IsPointerImpl_m775147452 ();
extern "C" void MonoType_IsPrimitiveImpl_m904878720 ();
extern "C" void MonoType_IsSubclassOf_m2482488910 ();
extern "C" void MonoType_InvokeMember_m821314901 ();
extern "C" void MonoType_GetElementType_m1199886691 ();
extern "C" void MonoType_get_UnderlyingSystemType_m4185992851 ();
extern "C" void MonoType_get_Assembly_m3574224325 ();
extern "C" void MonoType_get_AssemblyQualifiedName_m3302040083 ();
extern "C" void MonoType_getFullName_m4097914536 ();
extern "C" void MonoType_get_BaseType_m1099037884 ();
extern "C" void MonoType_get_FullName_m301492687 ();
extern "C" void MonoType_IsDefined_m4240219457 ();
extern "C" void MonoType_GetCustomAttributes_m686864684 ();
extern "C" void MonoType_GetCustomAttributes_m738241830 ();
extern "C" void MonoType_get_MemberType_m1401244132 ();
extern "C" void MonoType_get_Name_m2741664745 ();
extern "C" void MonoType_get_Namespace_m1830594842 ();
extern "C" void MonoType_get_Module_m2229062923 ();
extern "C" void MonoType_get_DeclaringType_m1218811919 ();
extern "C" void MonoType_get_ReflectedType_m1224953211 ();
extern "C" void MonoType_get_TypeHandle_m2009845375 ();
extern "C" void MonoType_GetObjectData_m3392713679 ();
extern "C" void MonoType_ToString_m1302937548 ();
extern "C" void MonoType_GetGenericArguments_m1363088236 ();
extern "C" void MonoType_get_ContainsGenericParameters_m189307499 ();
extern "C" void MonoType_get_IsGenericParameter_m4210877970 ();
extern "C" void MonoType_GetGenericTypeDefinition_m2954034139 ();
extern "C" void MonoType_CheckMethodSecurity_m804682546 ();
extern "C" void MonoType_ReorderParamArrayArguments_m593941294 ();
extern "C" void MonoTypeInfo__ctor_m854997146 ();
extern "C" void MulticastDelegate_GetObjectData_m3131968880 ();
extern "C" void MulticastDelegate_Equals_m2391386839 ();
extern "C" void MulticastDelegate_GetHashCode_m2058342921 ();
extern "C" void MulticastDelegate_GetInvocationList_m1852279961 ();
extern "C" void MulticastDelegate_CombineImpl_m1072590429 ();
extern "C" void MulticastDelegate_BaseEquals_m823385438 ();
extern "C" void MulticastDelegate_KPM_m2742084548 ();
extern "C" void MulticastDelegate_RemoveImpl_m4247123837 ();
extern "C" void MulticastNotSupportedException__ctor_m2417755598 ();
extern "C" void MulticastNotSupportedException__ctor_m2123402185 ();
extern "C" void MulticastNotSupportedException__ctor_m3670332278 ();
extern "C" void NonSerializedAttribute__ctor_m4871865 ();
extern "C" void NotImplementedException__ctor_m477983135 ();
extern "C" void NotImplementedException__ctor_m1986325158 ();
extern "C" void NotImplementedException__ctor_m2077187522 ();
extern "C" void NotSupportedException__ctor_m2114463680 ();
extern "C" void NotSupportedException__ctor_m52747721 ();
extern "C" void NotSupportedException__ctor_m553951563 ();
extern "C" void NullReferenceException__ctor_m1701905725 ();
extern "C" void NullReferenceException__ctor_m1593493702 ();
extern "C" void NullReferenceException__ctor_m1027837455 ();
extern "C" void NumberFormatter__ctor_m2141086463 ();
extern "C" void NumberFormatter__cctor_m3557929081 ();
extern "C" void NumberFormatter_GetFormatterTables_m1747175642 ();
extern "C" void NumberFormatter_GetTenPowerOf_m3984735441 ();
extern "C" void NumberFormatter_InitDecHexDigits_m3889389778 ();
extern "C" void NumberFormatter_InitDecHexDigits_m2111430985 ();
extern "C" void NumberFormatter_InitDecHexDigits_m311440294 ();
extern "C" void NumberFormatter_FastToDecHex_m2768083532 ();
extern "C" void NumberFormatter_ToDecHex_m3635356694 ();
extern "C" void NumberFormatter_FastDecHexLen_m1915455962 ();
extern "C" void NumberFormatter_DecHexLen_m2832070964 ();
extern "C" void NumberFormatter_DecHexLen_m2991250998 ();
extern "C" void NumberFormatter_ScaleOrder_m1600433103 ();
extern "C" void NumberFormatter_InitialFloatingPrecision_m2143252711 ();
extern "C" void NumberFormatter_ParsePrecision_m2195832396 ();
extern "C" void NumberFormatter_Init_m2127310494 ();
extern "C" void NumberFormatter_InitHex_m342996610 ();
extern "C" void NumberFormatter_Init_m3034217123 ();
extern "C" void NumberFormatter_Init_m3308044450 ();
extern "C" void NumberFormatter_Init_m1573483274 ();
extern "C" void NumberFormatter_Init_m1522536577 ();
extern "C" void NumberFormatter_Init_m3133291034 ();
extern "C" void NumberFormatter_Init_m3692836545 ();
extern "C" void NumberFormatter_ResetCharBuf_m3836151110 ();
extern "C" void NumberFormatter_Resize_m2682803153 ();
extern "C" void NumberFormatter_Append_m2076015538 ();
extern "C" void NumberFormatter_Append_m3734637667 ();
extern "C" void NumberFormatter_Append_m2050012530 ();
extern "C" void NumberFormatter_GetNumberFormatInstance_m4113520079 ();
extern "C" void NumberFormatter_set_CurrentCulture_m457134014 ();
extern "C" void NumberFormatter_get_IntegerDigits_m3979329271 ();
extern "C" void NumberFormatter_get_DecimalDigits_m439285849 ();
extern "C" void NumberFormatter_get_IsFloatingSource_m3207893958 ();
extern "C" void NumberFormatter_get_IsZero_m3359311934 ();
extern "C" void NumberFormatter_get_IsZeroInteger_m3301715141 ();
extern "C" void NumberFormatter_RoundPos_m3370784681 ();
extern "C" void NumberFormatter_RoundDecimal_m3479538926 ();
extern "C" void NumberFormatter_RoundBits_m3941675070 ();
extern "C" void NumberFormatter_RemoveTrailingZeros_m1918889960 ();
extern "C" void NumberFormatter_AddOneToDecHex_m3078903462 ();
extern "C" void NumberFormatter_AddOneToDecHex_m3256818506 ();
extern "C" void NumberFormatter_CountTrailingZeros_m3038126719 ();
extern "C" void NumberFormatter_CountTrailingZeros_m3723111709 ();
extern "C" void NumberFormatter_GetInstance_m2996663744 ();
extern "C" void NumberFormatter_Release_m3167542947 ();
extern "C" void NumberFormatter_SetThreadCurrentCulture_m1560040450 ();
extern "C" void NumberFormatter_NumberToString_m3602657613 ();
extern "C" void NumberFormatter_NumberToString_m2827109763 ();
extern "C" void NumberFormatter_NumberToString_m2035901810 ();
extern "C" void NumberFormatter_NumberToString_m1571641651 ();
extern "C" void NumberFormatter_NumberToString_m1284178353 ();
extern "C" void NumberFormatter_NumberToString_m2823217568 ();
extern "C" void NumberFormatter_NumberToString_m245735860 ();
extern "C" void NumberFormatter_NumberToString_m2831724402 ();
extern "C" void NumberFormatter_NumberToString_m3382855546 ();
extern "C" void NumberFormatter_NumberToString_m4102438340 ();
extern "C" void NumberFormatter_NumberToString_m1020354641 ();
extern "C" void NumberFormatter_NumberToString_m1943835558 ();
extern "C" void NumberFormatter_NumberToString_m3333956848 ();
extern "C" void NumberFormatter_NumberToString_m3638641212 ();
extern "C" void NumberFormatter_NumberToString_m2293810547 ();
extern "C" void NumberFormatter_NumberToString_m203036247 ();
extern "C" void NumberFormatter_NumberToString_m1540346080 ();
extern "C" void NumberFormatter_FastIntegerToString_m1838326482 ();
extern "C" void NumberFormatter_IntegerToString_m4107262335 ();
extern "C" void NumberFormatter_NumberToString_m3666786693 ();
extern "C" void NumberFormatter_FormatCurrency_m3243895876 ();
extern "C" void NumberFormatter_FormatDecimal_m166154075 ();
extern "C" void NumberFormatter_FormatHexadecimal_m2304102207 ();
extern "C" void NumberFormatter_FormatFixedPoint_m220031850 ();
extern "C" void NumberFormatter_FormatRoundtrip_m1272243764 ();
extern "C" void NumberFormatter_FormatRoundtrip_m1316422312 ();
extern "C" void NumberFormatter_FormatGeneral_m2796695385 ();
extern "C" void NumberFormatter_FormatNumber_m4039511018 ();
extern "C" void NumberFormatter_FormatPercent_m4266096735 ();
extern "C" void NumberFormatter_FormatExponential_m2833791326 ();
extern "C" void NumberFormatter_FormatExponential_m2034033465 ();
extern "C" void NumberFormatter_FormatCustom_m3042909951 ();
extern "C" void NumberFormatter_ZeroTrimEnd_m2783222906 ();
extern "C" void NumberFormatter_IsZeroOnly_m2946960116 ();
extern "C" void NumberFormatter_AppendNonNegativeNumber_m2686673915 ();
extern "C" void NumberFormatter_AppendIntegerString_m2282719652 ();
extern "C" void NumberFormatter_AppendIntegerString_m1425281297 ();
extern "C" void NumberFormatter_AppendDecimalString_m1458383674 ();
extern "C" void NumberFormatter_AppendDecimalString_m1348504882 ();
extern "C" void NumberFormatter_AppendIntegerStringWithGroupSeparator_m1458322188 ();
extern "C" void NumberFormatter_AppendExponent_m3408681762 ();
extern "C" void NumberFormatter_AppendOneDigit_m3784616382 ();
extern "C" void NumberFormatter_FastAppendDigits_m2343094226 ();
extern "C" void NumberFormatter_AppendDigits_m2647593189 ();
extern "C" void NumberFormatter_AppendDigits_m827927027 ();
extern "C" void NumberFormatter_Multiply10_m4000997921 ();
extern "C" void NumberFormatter_Divide10_m685560461 ();
extern "C" void NumberFormatter_GetClone_m2058870544 ();
extern "C" void CustomInfo__ctor_m3353878986 ();
extern "C" void CustomInfo_GetActiveSection_m4277983857 ();
extern "C" void CustomInfo_Parse_m3253903869 ();
extern "C" void CustomInfo_Format_m1367832183 ();
extern "C" void Object__ctor_m3570689169 ();
extern "C" void Object_Equals_m1589733813 ();
extern "C" void Object_Equals_m1653553012 ();
extern "C" void Object_Finalize_m3819013302 ();
extern "C" void Object_GetHashCode_m75012116 ();
extern "C" void Object_GetType_m824619215 ();
extern "C" void Object_MemberwiseClone_m1637840242 ();
extern "C" void Object_ToString_m1243246388 ();
extern "C" void Object_ReferenceEquals_m1745896791 ();
extern "C" void Object_InternalGetHashCode_m3239484227 ();
extern "C" void ObjectDisposedException__ctor_m2874627009 ();
extern "C" void ObjectDisposedException__ctor_m2916448319 ();
extern "C" void ObjectDisposedException__ctor_m2830566228 ();
extern "C" void ObjectDisposedException_get_Message_m3020538918 ();
extern "C" void ObjectDisposedException_GetObjectData_m173037097 ();
extern "C" void ObsoleteAttribute__ctor_m2346818104 ();
extern "C" void ObsoleteAttribute__ctor_m3649443664 ();
extern "C" void ObsoleteAttribute__ctor_m74976096 ();
extern "C" void OperatingSystem__ctor_m1938051607 ();
extern "C" void OperatingSystem_get_Platform_m3327222881 ();
extern "C" void OperatingSystem_Clone_m3011752554 ();
extern "C" void OperatingSystem_GetObjectData_m2864715462 ();
extern "C" void OperatingSystem_ToString_m1327952677 ();
extern "C" void OrdinalComparer__ctor_m795122326 ();
extern "C" void OrdinalComparer_Compare_m649554243 ();
extern "C" void OrdinalComparer_Equals_m1349310104 ();
extern "C" void OrdinalComparer_GetHashCode_m2290661839 ();
extern "C" void OutOfMemoryException__ctor_m1205545298 ();
extern "C" void OutOfMemoryException__ctor_m3178126794 ();
extern "C" void OutOfMemoryException__ctor_m3628315802 ();
extern "C" void OverflowException__ctor_m287420521 ();
extern "C" void OverflowException__ctor_m3309379331 ();
extern "C" void OverflowException__ctor_m3967190257 ();
extern "C" void ParamArrayAttribute__ctor_m1476893411 ();
extern "C" void PlatformNotSupportedException__ctor_m2011956139 ();
extern "C" void PlatformNotSupportedException__ctor_m438435675 ();
extern "C" void RankException__ctor_m3047453347 ();
extern "C" void RankException__ctor_m357593887 ();
extern "C" void RankException__ctor_m3181261104 ();
extern "C" void AmbiguousMatchException__ctor_m1650682271 ();
extern "C" void AmbiguousMatchException__ctor_m3363049417 ();
extern "C" void AmbiguousMatchException__ctor_m3268112286 ();
extern "C" void Assembly__ctor_m1129759937 ();
extern "C" void Assembly_get_code_base_m127033788 ();
extern "C" void Assembly_get_fullname_m4270733977 ();
extern "C" void Assembly_get_location_m3770795522 ();
extern "C" void Assembly_GetCodeBase_m6707203 ();
extern "C" void Assembly_get_FullName_m3956258934 ();
extern "C" void Assembly_get_Location_m2676569818 ();
extern "C" void Assembly_IsDefined_m3344635396 ();
extern "C" void Assembly_GetCustomAttributes_m2556799392 ();
extern "C" void Assembly_GetManifestResourceInternal_m664493768 ();
extern "C" void Assembly_GetTypes_m1716081216 ();
extern "C" void Assembly_GetTypes_m2231873833 ();
extern "C" void Assembly_GetType_m2914302819 ();
extern "C" void Assembly_GetType_m2170979294 ();
extern "C" void Assembly_InternalGetType_m1071048114 ();
extern "C" void Assembly_GetType_m3488314699 ();
extern "C" void Assembly_FillName_m778112029 ();
extern "C" void Assembly_GetName_m2496216313 ();
extern "C" void Assembly_GetName_m1496227622 ();
extern "C" void Assembly_UnprotectedGetName_m389720229 ();
extern "C" void Assembly_ToString_m3415840225 ();
extern "C" void Assembly_Load_m3107598193 ();
extern "C" void Assembly_GetModule_m1920455931 ();
extern "C" void Assembly_GetModulesInternal_m3041328967 ();
extern "C" void Assembly_GetModules_m2887076454 ();
extern "C" void Assembly_GetExecutingAssembly_m582814672 ();
extern "C" void ResolveEventHolder__ctor_m607253803 ();
extern "C" void AssemblyCompanyAttribute__ctor_m1961203133 ();
extern "C" void AssemblyCopyrightAttribute__ctor_m2442777966 ();
extern "C" void AssemblyDefaultAliasAttribute__ctor_m1008481974 ();
extern "C" void AssemblyDelaySignAttribute__ctor_m792735968 ();
extern "C" void AssemblyDescriptionAttribute__ctor_m863331373 ();
extern "C" void AssemblyFileVersionAttribute__ctor_m104636996 ();
extern "C" void AssemblyInformationalVersionAttribute__ctor_m2606705742 ();
extern "C" void AssemblyKeyFileAttribute__ctor_m515360797 ();
extern "C" void AssemblyName__ctor_m1606482411 ();
extern "C" void AssemblyName__ctor_m2165385509 ();
extern "C" void AssemblyName_get_Name_m1622178965 ();
extern "C" void AssemblyName_get_Flags_m743173569 ();
extern "C" void AssemblyName_get_FullName_m1324125095 ();
extern "C" void AssemblyName_get_Version_m1348671957 ();
extern "C" void AssemblyName_set_Version_m1402967326 ();
extern "C" void AssemblyName_ToString_m2129407468 ();
extern "C" void AssemblyName_get_IsPublicKeyValid_m3478360955 ();
extern "C" void AssemblyName_InternalGetPublicKeyToken_m4256419726 ();
extern "C" void AssemblyName_ComputePublicKeyToken_m2212213111 ();
extern "C" void AssemblyName_SetPublicKey_m3853417853 ();
extern "C" void AssemblyName_SetPublicKeyToken_m3125749103 ();
extern "C" void AssemblyName_GetObjectData_m4048799064 ();
extern "C" void AssemblyName_Clone_m67236874 ();
extern "C" void AssemblyName_OnDeserialization_m1855099319 ();
extern "C" void AssemblyProductAttribute__ctor_m2179734435 ();
extern "C" void AssemblyTitleAttribute__ctor_m2280157225 ();
extern "C" void Binder__ctor_m2914744643 ();
extern "C" void Binder__cctor_m3419827066 ();
extern "C" void Binder_get_DefaultBinder_m93799448 ();
extern "C" void Binder_ConvertArgs_m3209251020 ();
extern "C" void Binder_GetDerivedLevel_m3080703552 ();
extern "C" void Binder_FindMostDerivedMatch_m321679317 ();
extern "C" void Default__ctor_m2884560628 ();
extern "C" void Default_BindToMethod_m1424112417 ();
extern "C" void Default_ReorderParameters_m932957755 ();
extern "C" void Default_IsArrayAssignable_m690722658 ();
extern "C" void Default_ChangeType_m607399848 ();
extern "C" void Default_ReorderArgumentArray_m1230275780 ();
extern "C" void Default_check_type_m1599279309 ();
extern "C" void Default_check_arguments_m2241121707 ();
extern "C" void Default_SelectMethod_m2203110393 ();
extern "C" void Default_SelectMethod_m2065722860 ();
extern "C" void Default_GetBetterMethod_m2039851047 ();
extern "C" void Default_CompareCloserType_m303877795 ();
extern "C" void Default_SelectProperty_m4180238434 ();
extern "C" void Default_check_arguments_with_score_m2268626604 ();
extern "C" void Default_check_type_with_score_m2837505628 ();
extern "C" void ConstructorInfo__ctor_m33952912 ();
extern "C" void ConstructorInfo__cctor_m2349776223 ();
extern "C" void ConstructorInfo_get_MemberType_m452596585 ();
extern "C" void ConstructorInfo_Invoke_m2121930581 ();
extern "C" void CustomAttributeData__ctor_m4204343487 ();
extern "C" void CustomAttributeData_get_Constructor_m1392415606 ();
extern "C" void CustomAttributeData_get_ConstructorArguments_m3516412943 ();
extern "C" void CustomAttributeData_get_NamedArguments_m3735702561 ();
extern "C" void CustomAttributeData_GetCustomAttributes_m2925805381 ();
extern "C" void CustomAttributeData_GetCustomAttributes_m2504614822 ();
extern "C" void CustomAttributeData_GetCustomAttributes_m1321853079 ();
extern "C" void CustomAttributeData_GetCustomAttributes_m436637582 ();
extern "C" void CustomAttributeData_ToString_m890844682 ();
extern "C" void CustomAttributeData_Equals_m3367973531 ();
extern "C" void CustomAttributeData_GetHashCode_m2200382294 ();
extern "C" void CustomAttributeNamedArgument_ToString_m1730663428_AdjustorThunk ();
extern "C" void CustomAttributeNamedArgument_Equals_m2667330995_AdjustorThunk ();
extern "C" void CustomAttributeNamedArgument_GetHashCode_m451651329_AdjustorThunk ();
extern "C" void CustomAttributeTypedArgument_ToString_m4251600315_AdjustorThunk ();
extern "C" void CustomAttributeTypedArgument_Equals_m3427675425_AdjustorThunk ();
extern "C" void CustomAttributeTypedArgument_GetHashCode_m3252838495_AdjustorThunk ();
extern "C" void DefaultMemberAttribute__ctor_m1668906589 ();
extern "C" void DefaultMemberAttribute_get_MemberName_m1805847907 ();
extern "C" void AssemblyBuilder_get_Location_m731197943 ();
extern "C" void AssemblyBuilder_GetModulesInternal_m2140896078 ();
extern "C" void AssemblyBuilder_GetTypes_m485354545 ();
extern "C" void AssemblyBuilder_get_IsCompilerContext_m4268419819 ();
extern "C" void AssemblyBuilder_not_supported_m1259221233 ();
extern "C" void AssemblyBuilder_UnprotectedGetName_m1954650636 ();
extern "C" void ConstructorBuilder__ctor_m1109760205 ();
extern "C" void ConstructorBuilder_get_CallingConvention_m1485716714 ();
extern "C" void ConstructorBuilder_get_TypeBuilder_m348576299 ();
extern "C" void ConstructorBuilder_GetParameters_m2580118339 ();
extern "C" void ConstructorBuilder_GetParametersInternal_m3427358513 ();
extern "C" void ConstructorBuilder_GetParameterCount_m2491355488 ();
extern "C" void ConstructorBuilder_Invoke_m4267349784 ();
extern "C" void ConstructorBuilder_Invoke_m2950671586 ();
extern "C" void ConstructorBuilder_get_MethodHandle_m3481765851 ();
extern "C" void ConstructorBuilder_get_Attributes_m2180218649 ();
extern "C" void ConstructorBuilder_get_ReflectedType_m83279888 ();
extern "C" void ConstructorBuilder_get_DeclaringType_m913596390 ();
extern "C" void ConstructorBuilder_get_Name_m2197591737 ();
extern "C" void ConstructorBuilder_IsDefined_m1820164848 ();
extern "C" void ConstructorBuilder_GetCustomAttributes_m3924080049 ();
extern "C" void ConstructorBuilder_GetCustomAttributes_m368928065 ();
extern "C" void ConstructorBuilder_GetILGenerator_m4076496357 ();
extern "C" void ConstructorBuilder_GetILGenerator_m4273795898 ();
extern "C" void ConstructorBuilder_GetToken_m1485580701 ();
extern "C" void ConstructorBuilder_get_Module_m3395962136 ();
extern "C" void ConstructorBuilder_ToString_m3882603010 ();
extern "C" void ConstructorBuilder_fixup_m3681136798 ();
extern "C" void ConstructorBuilder_get_next_table_index_m2412271123 ();
extern "C" void ConstructorBuilder_get_IsCompilerContext_m1823032054 ();
extern "C" void ConstructorBuilder_not_supported_m3113087006 ();
extern "C" void ConstructorBuilder_not_created_m2593555328 ();
extern "C" void EnumBuilder_get_Assembly_m355013314 ();
extern "C" void EnumBuilder_get_AssemblyQualifiedName_m2677384494 ();
extern "C" void EnumBuilder_get_BaseType_m1724791672 ();
extern "C" void EnumBuilder_get_DeclaringType_m3414694952 ();
extern "C" void EnumBuilder_get_FullName_m289521373 ();
extern "C" void EnumBuilder_get_Module_m430470637 ();
extern "C" void EnumBuilder_get_Name_m701559818 ();
extern "C" void EnumBuilder_get_Namespace_m2974690056 ();
extern "C" void EnumBuilder_get_ReflectedType_m3363631725 ();
extern "C" void EnumBuilder_get_TypeHandle_m317711653 ();
extern "C" void EnumBuilder_get_UnderlyingSystemType_m119970781 ();
extern "C" void EnumBuilder_GetAttributeFlagsImpl_m606822698 ();
extern "C" void EnumBuilder_GetConstructorImpl_m3945935172 ();
extern "C" void EnumBuilder_GetConstructors_m4236007330 ();
extern "C" void EnumBuilder_GetCustomAttributes_m1145053795 ();
extern "C" void EnumBuilder_GetCustomAttributes_m2952891353 ();
extern "C" void EnumBuilder_GetElementType_m375234762 ();
extern "C" void EnumBuilder_GetEvent_m494472581 ();
extern "C" void EnumBuilder_GetField_m1193459080 ();
extern "C" void EnumBuilder_GetFields_m3875416208 ();
extern "C" void EnumBuilder_GetInterfaces_m2323579277 ();
extern "C" void EnumBuilder_GetMethodImpl_m84945609 ();
extern "C" void EnumBuilder_GetMethods_m2124000878 ();
extern "C" void EnumBuilder_GetPropertyImpl_m3879058494 ();
extern "C" void EnumBuilder_HasElementTypeImpl_m4135987772 ();
extern "C" void EnumBuilder_InvokeMember_m40776934 ();
extern "C" void EnumBuilder_IsArrayImpl_m2829518040 ();
extern "C" void EnumBuilder_IsByRefImpl_m2277826720 ();
extern "C" void EnumBuilder_IsPointerImpl_m1997301688 ();
extern "C" void EnumBuilder_IsPrimitiveImpl_m1814564375 ();
extern "C" void EnumBuilder_IsValueTypeImpl_m3129477556 ();
extern "C" void EnumBuilder_IsDefined_m3982557818 ();
extern "C" void EnumBuilder_CreateNotSupportedException_m1570169503 ();
extern "C" void FieldBuilder_get_Attributes_m2171613738 ();
extern "C" void FieldBuilder_get_DeclaringType_m2499047695 ();
extern "C" void FieldBuilder_get_FieldHandle_m2001735098 ();
extern "C" void FieldBuilder_get_FieldType_m462820209 ();
extern "C" void FieldBuilder_get_Name_m281129090 ();
extern "C" void FieldBuilder_get_ReflectedType_m4186495894 ();
extern "C" void FieldBuilder_GetCustomAttributes_m4061980295 ();
extern "C" void FieldBuilder_GetCustomAttributes_m570688289 ();
extern "C" void FieldBuilder_GetValue_m3811999812 ();
extern "C" void FieldBuilder_IsDefined_m179997776 ();
extern "C" void FieldBuilder_GetFieldOffset_m4153895622 ();
extern "C" void FieldBuilder_SetValue_m3449164453 ();
extern "C" void FieldBuilder_get_UMarshal_m1984011598 ();
extern "C" void FieldBuilder_CreateNotSupportedException_m3232073932 ();
extern "C" void FieldBuilder_get_Module_m1965601633 ();
extern "C" void GenericTypeParameterBuilder_IsSubclassOf_m353142104 ();
extern "C" void GenericTypeParameterBuilder_GetAttributeFlagsImpl_m1839213924 ();
extern "C" void GenericTypeParameterBuilder_GetConstructorImpl_m3636295158 ();
extern "C" void GenericTypeParameterBuilder_GetConstructors_m3284886085 ();
extern "C" void GenericTypeParameterBuilder_GetEvent_m2342415410 ();
extern "C" void GenericTypeParameterBuilder_GetField_m1550196833 ();
extern "C" void GenericTypeParameterBuilder_GetFields_m3294053138 ();
extern "C" void GenericTypeParameterBuilder_GetInterfaces_m104749576 ();
extern "C" void GenericTypeParameterBuilder_GetMethods_m29397225 ();
extern "C" void GenericTypeParameterBuilder_GetMethodImpl_m547015455 ();
extern "C" void GenericTypeParameterBuilder_GetPropertyImpl_m1157110034 ();
extern "C" void GenericTypeParameterBuilder_HasElementTypeImpl_m2616217087 ();
extern "C" void GenericTypeParameterBuilder_IsAssignableFrom_m2851625581 ();
extern "C" void GenericTypeParameterBuilder_IsInstanceOfType_m1660697006 ();
extern "C" void GenericTypeParameterBuilder_IsArrayImpl_m376392290 ();
extern "C" void GenericTypeParameterBuilder_IsByRefImpl_m997941508 ();
extern "C" void GenericTypeParameterBuilder_IsPointerImpl_m3596100288 ();
extern "C" void GenericTypeParameterBuilder_IsPrimitiveImpl_m53642826 ();
extern "C" void GenericTypeParameterBuilder_IsValueTypeImpl_m2839751211 ();
extern "C" void GenericTypeParameterBuilder_InvokeMember_m2129857298 ();
extern "C" void GenericTypeParameterBuilder_GetElementType_m3106765030 ();
extern "C" void GenericTypeParameterBuilder_get_UnderlyingSystemType_m1049760852 ();
extern "C" void GenericTypeParameterBuilder_get_Assembly_m3256314693 ();
extern "C" void GenericTypeParameterBuilder_get_AssemblyQualifiedName_m930142857 ();
extern "C" void GenericTypeParameterBuilder_get_BaseType_m2038220919 ();
extern "C" void GenericTypeParameterBuilder_get_FullName_m113867323 ();
extern "C" void GenericTypeParameterBuilder_IsDefined_m3083113094 ();
extern "C" void GenericTypeParameterBuilder_GetCustomAttributes_m1784509669 ();
extern "C" void GenericTypeParameterBuilder_GetCustomAttributes_m516723103 ();
extern "C" void GenericTypeParameterBuilder_get_Name_m2329592136 ();
extern "C" void GenericTypeParameterBuilder_get_Namespace_m115401056 ();
extern "C" void GenericTypeParameterBuilder_get_Module_m4243919340 ();
extern "C" void GenericTypeParameterBuilder_get_DeclaringType_m4161880422 ();
extern "C" void GenericTypeParameterBuilder_get_ReflectedType_m1498626203 ();
extern "C" void GenericTypeParameterBuilder_get_TypeHandle_m2981587387 ();
extern "C" void GenericTypeParameterBuilder_GetGenericArguments_m1548145364 ();
extern "C" void GenericTypeParameterBuilder_GetGenericTypeDefinition_m2308065503 ();
extern "C" void GenericTypeParameterBuilder_get_ContainsGenericParameters_m29159950 ();
extern "C" void GenericTypeParameterBuilder_get_IsGenericParameter_m3114374385 ();
extern "C" void GenericTypeParameterBuilder_get_IsGenericType_m3781708032 ();
extern "C" void GenericTypeParameterBuilder_get_IsGenericTypeDefinition_m2389046390 ();
extern "C" void GenericTypeParameterBuilder_not_supported_m1731476325 ();
extern "C" void GenericTypeParameterBuilder_ToString_m787137575 ();
extern "C" void GenericTypeParameterBuilder_Equals_m4250412984 ();
extern "C" void GenericTypeParameterBuilder_GetHashCode_m2384437160 ();
extern "C" void GenericTypeParameterBuilder_MakeGenericType_m92865730 ();
extern "C" void ILGenerator__ctor_m3831821068 ();
extern "C" void ILGenerator__cctor_m1016473741 ();
extern "C" void ILGenerator_add_token_fixup_m1724091381 ();
extern "C" void ILGenerator_make_room_m444464353 ();
extern "C" void ILGenerator_emit_int_m2794944108 ();
extern "C" void ILGenerator_ll_emit_m709490707 ();
extern "C" void ILGenerator_Emit_m649449510 ();
extern "C" void ILGenerator_Emit_m1397855461 ();
extern "C" void ILGenerator_label_fixup_m2220310279 ();
extern "C" void ILGenerator_Mono_GetCurrentOffset_m1965052903 ();
extern "C" void MethodBuilder_get_ContainsGenericParameters_m558997801 ();
extern "C" void MethodBuilder_get_MethodHandle_m1478074017 ();
extern "C" void MethodBuilder_get_ReturnType_m1039020030 ();
extern "C" void MethodBuilder_get_ReflectedType_m2006317078 ();
extern "C" void MethodBuilder_get_DeclaringType_m135867346 ();
extern "C" void MethodBuilder_get_Name_m3558084903 ();
extern "C" void MethodBuilder_get_Attributes_m3974070431 ();
extern "C" void MethodBuilder_get_CallingConvention_m3240118774 ();
extern "C" void MethodBuilder_GetBaseDefinition_m2891328059 ();
extern "C" void MethodBuilder_GetParameters_m78256597 ();
extern "C" void MethodBuilder_GetParameterCount_m432668952 ();
extern "C" void MethodBuilder_Invoke_m3372071101 ();
extern "C" void MethodBuilder_IsDefined_m1520062565 ();
extern "C" void MethodBuilder_GetCustomAttributes_m473377132 ();
extern "C" void MethodBuilder_GetCustomAttributes_m3351245388 ();
extern "C" void MethodBuilder_check_override_m2061218982 ();
extern "C" void MethodBuilder_fixup_m1382183758 ();
extern "C" void MethodBuilder_ToString_m3845707716 ();
extern "C" void MethodBuilder_Equals_m2649897076 ();
extern "C" void MethodBuilder_GetHashCode_m2275982589 ();
extern "C" void MethodBuilder_get_next_table_index_m999917900 ();
extern "C" void MethodBuilder_NotSupported_m4035176812 ();
extern "C" void MethodBuilder_MakeGenericMethod_m1194343307 ();
extern "C" void MethodBuilder_get_IsGenericMethodDefinition_m1404273627 ();
extern "C" void MethodBuilder_get_IsGenericMethod_m4027418537 ();
extern "C" void MethodBuilder_GetGenericArguments_m2143170801 ();
extern "C" void MethodBuilder_get_Module_m2723726460 ();
extern "C" void MethodToken__ctor_m4038133375_AdjustorThunk ();
extern "C" void MethodToken__cctor_m768804040 ();
extern "C" void MethodToken_Equals_m3797630749_AdjustorThunk ();
extern "C" void MethodToken_GetHashCode_m2040477620_AdjustorThunk ();
extern "C" void MethodToken_get_Token_m699050427_AdjustorThunk ();
extern "C" void ModuleBuilder__cctor_m2057277080 ();
extern "C" void ModuleBuilder_get_next_table_index_m3753842447 ();
extern "C" void ModuleBuilder_GetTypes_m3938547762 ();
extern "C" void ModuleBuilder_getToken_m959987480 ();
extern "C" void ModuleBuilder_GetToken_m2353291662 ();
extern "C" void ModuleBuilder_RegisterToken_m567790628 ();
extern "C" void ModuleBuilder_GetTokenGenerator_m4097658340 ();
extern "C" void ModuleBuilderTokenGenerator__ctor_m896014926 ();
extern "C" void ModuleBuilderTokenGenerator_GetToken_m1763381870 ();
extern "C" void OpCode__ctor_m3124025053_AdjustorThunk ();
extern "C" void OpCode_GetHashCode_m188093846_AdjustorThunk ();
extern "C" void OpCode_Equals_m3409306657_AdjustorThunk ();
extern "C" void OpCode_ToString_m1642375114_AdjustorThunk ();
extern "C" void OpCode_get_Name_m1352624527_AdjustorThunk ();
extern "C" void OpCode_get_Size_m654700322_AdjustorThunk ();
extern "C" void OpCode_get_StackBehaviourPop_m2319974318_AdjustorThunk ();
extern "C" void OpCode_get_StackBehaviourPush_m2342360980_AdjustorThunk ();
extern "C" void OpCodeNames__cctor_m1379507976 ();
extern "C" void OpCodes__cctor_m2732960412 ();
extern "C" void ParameterBuilder_get_Attributes_m3870211422 ();
extern "C" void ParameterBuilder_get_Name_m2092199752 ();
extern "C" void ParameterBuilder_get_Position_m1847690366 ();
extern "C" void TypeBuilder_GetAttributeFlagsImpl_m2920211965 ();
extern "C" void TypeBuilder_setup_internal_class_m2244704536 ();
extern "C" void TypeBuilder_create_generic_class_m4285558031 ();
extern "C" void TypeBuilder_get_Assembly_m3299514451 ();
extern "C" void TypeBuilder_get_AssemblyQualifiedName_m1412739845 ();
extern "C" void TypeBuilder_get_BaseType_m3817395349 ();
extern "C" void TypeBuilder_get_DeclaringType_m1223871182 ();
extern "C" void TypeBuilder_get_UnderlyingSystemType_m2961106457 ();
extern "C" void TypeBuilder_get_FullName_m3626162747 ();
extern "C" void TypeBuilder_get_Module_m1866101650 ();
extern "C" void TypeBuilder_get_Name_m2090121023 ();
extern "C" void TypeBuilder_get_Namespace_m332380446 ();
extern "C" void TypeBuilder_get_ReflectedType_m767353663 ();
extern "C" void TypeBuilder_GetConstructorImpl_m2746299425 ();
extern "C" void TypeBuilder_IsDefined_m3327317460 ();
extern "C" void TypeBuilder_GetCustomAttributes_m2547225084 ();
extern "C" void TypeBuilder_GetCustomAttributes_m989064033 ();
extern "C" void TypeBuilder_DefineConstructor_m3569992820 ();
extern "C" void TypeBuilder_DefineConstructor_m467803885 ();
extern "C" void TypeBuilder_DefineDefaultConstructor_m1244102928 ();
extern "C" void TypeBuilder_create_runtime_class_m2008555911 ();
extern "C" void TypeBuilder_is_nested_in_m2139302697 ();
extern "C" void TypeBuilder_has_ctor_method_m2846430015 ();
extern "C" void TypeBuilder_CreateType_m3351196612 ();
extern "C" void TypeBuilder_GetConstructors_m3718991123 ();
extern "C" void TypeBuilder_GetConstructorsInternal_m368288422 ();
extern "C" void TypeBuilder_GetElementType_m1570270004 ();
extern "C" void TypeBuilder_GetEvent_m973045957 ();
extern "C" void TypeBuilder_GetField_m2062793076 ();
extern "C" void TypeBuilder_GetFields_m4186988355 ();
extern "C" void TypeBuilder_GetInterfaces_m2536132964 ();
extern "C" void TypeBuilder_GetMethodsByName_m2893159309 ();
extern "C" void TypeBuilder_GetMethods_m2941619924 ();
extern "C" void TypeBuilder_GetMethodImpl_m2363962104 ();
extern "C" void TypeBuilder_GetPropertyImpl_m527397799 ();
extern "C" void TypeBuilder_HasElementTypeImpl_m1352051324 ();
extern "C" void TypeBuilder_InvokeMember_m981872043 ();
extern "C" void TypeBuilder_IsArrayImpl_m3754106921 ();
extern "C" void TypeBuilder_IsByRefImpl_m1688605928 ();
extern "C" void TypeBuilder_IsPointerImpl_m2119945128 ();
extern "C" void TypeBuilder_IsPrimitiveImpl_m1394730752 ();
extern "C" void TypeBuilder_IsValueTypeImpl_m2957956512 ();
extern "C" void TypeBuilder_MakeGenericType_m1825409448 ();
extern "C" void TypeBuilder_get_TypeHandle_m1131290943 ();
extern "C" void TypeBuilder_SetParent_m511590099 ();
extern "C" void TypeBuilder_get_next_table_index_m3795850917 ();
extern "C" void TypeBuilder_get_IsCompilerContext_m380125708 ();
extern "C" void TypeBuilder_get_is_created_m3806364821 ();
extern "C" void TypeBuilder_not_supported_m4035202484 ();
extern "C" void TypeBuilder_check_not_created_m398775119 ();
extern "C" void TypeBuilder_check_created_m768973979 ();
extern "C" void TypeBuilder_ToString_m2453558611 ();
extern "C" void TypeBuilder_IsAssignableFrom_m3041852661 ();
extern "C" void TypeBuilder_IsSubclassOf_m2811257152 ();
extern "C" void TypeBuilder_IsAssignableTo_m1907754253 ();
extern "C" void TypeBuilder_GetGenericArguments_m123452731 ();
extern "C" void TypeBuilder_GetGenericTypeDefinition_m183072622 ();
extern "C" void TypeBuilder_get_ContainsGenericParameters_m2527904564 ();
extern "C" void TypeBuilder_get_IsGenericParameter_m3977989423 ();
extern "C" void TypeBuilder_get_IsGenericTypeDefinition_m4055168744 ();
extern "C" void TypeBuilder_get_IsGenericType_m2048561606 ();
extern "C" void UnmanagedMarshal_ToMarshalAsAttribute_m515448510 ();
extern "C" void EventInfo__ctor_m3830324722 ();
extern "C" void EventInfo_get_EventHandlerType_m2669943566 ();
extern "C" void EventInfo_get_MemberType_m3045779206 ();
extern "C" void AddEventAdapter__ctor_m2936189202 ();
extern "C" void AddEventAdapter_Invoke_m1903394599 ();
extern "C" void AddEventAdapter_BeginInvoke_m4267541168 ();
extern "C" void AddEventAdapter_EndInvoke_m1140548722 ();
extern "C" void FieldInfo__ctor_m3053970987 ();
extern "C" void FieldInfo_get_MemberType_m922465815 ();
extern "C" void FieldInfo_get_IsLiteral_m1190605584 ();
extern "C" void FieldInfo_get_IsStatic_m3509250687 ();
extern "C" void FieldInfo_get_IsNotSerialized_m2193323076 ();
extern "C" void FieldInfo_SetValue_m3184768154 ();
extern "C" void FieldInfo_internal_from_handle_type_m2092753019 ();
extern "C" void FieldInfo_GetFieldFromHandle_m2696435896 ();
extern "C" void FieldInfo_GetFieldOffset_m3612678663 ();
extern "C" void FieldInfo_GetUnmanagedMarshal_m584782143 ();
extern "C" void FieldInfo_get_UMarshal_m1375567641 ();
extern "C" void FieldInfo_GetPseudoCustomAttributes_m56998992 ();
extern "C" void MemberFilter__ctor_m3294589552 ();
extern "C" void MemberFilter_Invoke_m883704118 ();
extern "C" void MemberFilter_BeginInvoke_m719276847 ();
extern "C" void MemberFilter_EndInvoke_m667200611 ();
extern "C" void MemberInfo__ctor_m2895172263 ();
extern "C" void MemberInfo_get_Module_m2318214504 ();
extern "C" void MemberInfoSerializationHolder__ctor_m3584691757 ();
extern "C" void MemberInfoSerializationHolder_Serialize_m1886087251 ();
extern "C" void MemberInfoSerializationHolder_Serialize_m1707562648 ();
extern "C" void MemberInfoSerializationHolder_GetObjectData_m2308673721 ();
extern "C" void MemberInfoSerializationHolder_GetRealObject_m333774208 ();
extern "C" void MethodBase__ctor_m914644895 ();
extern "C" void MethodBase_GetMethodFromHandleNoGenericCheck_m2913373160 ();
extern "C" void MethodBase_GetMethodFromIntPtr_m3175053392 ();
extern "C" void MethodBase_GetMethodFromHandle_m1957760829 ();
extern "C" void MethodBase_GetMethodFromHandleInternalType_m291748205 ();
extern "C" void MethodBase_GetParameterCount_m3721378648 ();
extern "C" void MethodBase_Invoke_m1733031813 ();
extern "C" void MethodBase_get_CallingConvention_m3072461124 ();
extern "C" void MethodBase_get_IsPublic_m1144995937 ();
extern "C" void MethodBase_get_IsStatic_m3254123256 ();
extern "C" void MethodBase_get_IsVirtual_m3405858414 ();
extern "C" void MethodBase_get_IsAbstract_m2894117648 ();
extern "C" void MethodBase_get_next_table_index_m1429744308 ();
extern "C" void MethodBase_GetGenericArguments_m3649313813 ();
extern "C" void MethodBase_get_ContainsGenericParameters_m1058418413 ();
extern "C" void MethodBase_get_IsGenericMethodDefinition_m1322528031 ();
extern "C" void MethodBase_get_IsGenericMethod_m181568085 ();
extern "C" void MethodInfo__ctor_m3355489345 ();
extern "C" void MethodInfo_get_MemberType_m1375837193 ();
extern "C" void MethodInfo_get_ReturnType_m1381443358 ();
extern "C" void MethodInfo_MakeGenericMethod_m386620528 ();
extern "C" void MethodInfo_GetGenericArguments_m3810648776 ();
extern "C" void MethodInfo_get_IsGenericMethod_m921554736 ();
extern "C" void MethodInfo_get_IsGenericMethodDefinition_m3340704956 ();
extern "C" void MethodInfo_get_ContainsGenericParameters_m2598133705 ();
extern "C" void Missing__ctor_m4289576884 ();
extern "C" void Missing__cctor_m2565184059 ();
extern "C" void Missing_System_Runtime_Serialization_ISerializable_GetObjectData_m3892491128 ();
extern "C" void Module__ctor_m3036718125 ();
extern "C" void Module__cctor_m2458341886 ();
extern "C" void Module_get_Assembly_m1122675775 ();
extern "C" void Module_get_ScopeName_m1235275893 ();
extern "C" void Module_GetCustomAttributes_m2263679618 ();
extern "C" void Module_GetObjectData_m2031407505 ();
extern "C" void Module_InternalGetTypes_m1279518627 ();
extern "C" void Module_GetTypes_m1078392553 ();
extern "C" void Module_IsDefined_m699307601 ();
extern "C" void Module_IsResource_m1671226801 ();
extern "C" void Module_ToString_m3206737166 ();
extern "C" void Module_filter_by_type_name_m3362081677 ();
extern "C" void Module_filter_by_type_name_ignore_case_m1377657907 ();
extern "C" void MonoCMethod__ctor_m1368515011 ();
extern "C" void MonoCMethod_GetParameters_m2185608004 ();
extern "C" void MonoCMethod_InternalInvoke_m926685991 ();
extern "C" void MonoCMethod_Invoke_m1176335855 ();
extern "C" void MonoCMethod_Invoke_m1899956600 ();
extern "C" void MonoCMethod_get_MethodHandle_m1426101540 ();
extern "C" void MonoCMethod_get_Attributes_m2031015977 ();
extern "C" void MonoCMethod_get_CallingConvention_m2663884831 ();
extern "C" void MonoCMethod_get_ReflectedType_m359869482 ();
extern "C" void MonoCMethod_get_DeclaringType_m1134080785 ();
extern "C" void MonoCMethod_get_Name_m2549379589 ();
extern "C" void MonoCMethod_IsDefined_m2758653357 ();
extern "C" void MonoCMethod_GetCustomAttributes_m1468537363 ();
extern "C" void MonoCMethod_GetCustomAttributes_m3506054775 ();
extern "C" void MonoCMethod_ToString_m3471500585 ();
extern "C" void MonoCMethod_GetObjectData_m2316862133 ();
extern "C" void MonoEvent__ctor_m2633135540 ();
extern "C" void MonoEvent_get_Attributes_m1918740251 ();
extern "C" void MonoEvent_GetAddMethod_m4281263188 ();
extern "C" void MonoEvent_get_DeclaringType_m3540285216 ();
extern "C" void MonoEvent_get_ReflectedType_m4138508682 ();
extern "C" void MonoEvent_get_Name_m2644209411 ();
extern "C" void MonoEvent_ToString_m93515601 ();
extern "C" void MonoEvent_IsDefined_m1491615391 ();
extern "C" void MonoEvent_GetCustomAttributes_m4167148841 ();
extern "C" void MonoEvent_GetCustomAttributes_m3650299405 ();
extern "C" void MonoEvent_GetObjectData_m584957029 ();
extern "C" void MonoEventInfo_get_event_info_m4045553184 ();
extern "C" void MonoEventInfo_GetEventInfo_m44209219 ();
extern "C" void MonoField__ctor_m3815878254 ();
extern "C" void MonoField_get_Attributes_m4066504495 ();
extern "C" void MonoField_get_FieldHandle_m1267921003 ();
extern "C" void MonoField_get_FieldType_m2857925770 ();
extern "C" void MonoField_GetParentType_m958274503 ();
extern "C" void MonoField_get_ReflectedType_m3574480981 ();
extern "C" void MonoField_get_DeclaringType_m3892021042 ();
extern "C" void MonoField_get_Name_m2743852047 ();
extern "C" void MonoField_IsDefined_m2573678378 ();
extern "C" void MonoField_GetCustomAttributes_m1612478183 ();
extern "C" void MonoField_GetCustomAttributes_m2460206797 ();
extern "C" void MonoField_GetFieldOffset_m151961242 ();
extern "C" void MonoField_GetValueInternal_m775233678 ();
extern "C" void MonoField_GetValue_m1128051181 ();
extern "C" void MonoField_ToString_m1158774068 ();
extern "C" void MonoField_SetValueInternal_m687129371 ();
extern "C" void MonoField_SetValue_m2020324035 ();
extern "C" void MonoField_GetObjectData_m3538855411 ();
extern "C" void MonoField_CheckGeneric_m2176366112 ();
extern "C" void MonoGenericCMethod__ctor_m333579013 ();
extern "C" void MonoGenericCMethod_get_ReflectedType_m621354 ();
extern "C" void MonoGenericMethod__ctor_m108676012 ();
extern "C" void MonoGenericMethod_get_ReflectedType_m1588296328 ();
extern "C" void MonoMethod__ctor_m2394553335 ();
extern "C" void MonoMethod_get_name_m2996022605 ();
extern "C" void MonoMethod_get_base_definition_m3434665674 ();
extern "C" void MonoMethod_GetBaseDefinition_m26679534 ();
extern "C" void MonoMethod_get_ReturnType_m1418708448 ();
extern "C" void MonoMethod_GetParameters_m2049036167 ();
extern "C" void MonoMethod_InternalInvoke_m3495962619 ();
extern "C" void MonoMethod_Invoke_m597221130 ();
extern "C" void MonoMethod_get_MethodHandle_m1665293443 ();
extern "C" void MonoMethod_get_Attributes_m2537532032 ();
extern "C" void MonoMethod_get_CallingConvention_m2809250670 ();
extern "C" void MonoMethod_get_ReflectedType_m3250902944 ();
extern "C" void MonoMethod_get_DeclaringType_m226148929 ();
extern "C" void MonoMethod_get_Name_m3603474228 ();
extern "C" void MonoMethod_IsDefined_m3702183531 ();
extern "C" void MonoMethod_GetCustomAttributes_m2351603402 ();
extern "C" void MonoMethod_GetCustomAttributes_m2457172789 ();
extern "C" void MonoMethod_GetDllImportAttribute_m1901190805 ();
extern "C" void MonoMethod_GetPseudoCustomAttributes_m2692758498 ();
extern "C" void MonoMethod_ShouldPrintFullName_m2935901902 ();
extern "C" void MonoMethod_ToString_m3887950899 ();
extern "C" void MonoMethod_GetObjectData_m441826518 ();
extern "C" void MonoMethod_MakeGenericMethod_m2027759215 ();
extern "C" void MonoMethod_MakeGenericMethod_impl_m608204904 ();
extern "C" void MonoMethod_GetGenericArguments_m3396008493 ();
extern "C" void MonoMethod_get_IsGenericMethodDefinition_m430528877 ();
extern "C" void MonoMethod_get_IsGenericMethod_m2752274537 ();
extern "C" void MonoMethod_get_ContainsGenericParameters_m132612449 ();
extern "C" void MonoMethodInfo_get_method_info_m4041399695 ();
extern "C" void MonoMethodInfo_GetMethodInfo_m1130553512 ();
extern "C" void MonoMethodInfo_GetDeclaringType_m3171456324 ();
extern "C" void MonoMethodInfo_GetReturnType_m4023614880 ();
extern "C" void MonoMethodInfo_GetAttributes_m275559530 ();
extern "C" void MonoMethodInfo_GetCallingConvention_m1539455965 ();
extern "C" void MonoMethodInfo_get_parameter_info_m3207129851 ();
extern "C" void MonoMethodInfo_GetParametersInfo_m2379324589 ();
extern "C" void MonoProperty__ctor_m3749131868 ();
extern "C" void MonoProperty_CachePropertyInfo_m2203593361 ();
extern "C" void MonoProperty_get_Attributes_m788547603 ();
extern "C" void MonoProperty_get_CanRead_m2714628776 ();
extern "C" void MonoProperty_get_CanWrite_m1110418558 ();
extern "C" void MonoProperty_get_PropertyType_m3552246100 ();
extern "C" void MonoProperty_get_ReflectedType_m1569187598 ();
extern "C" void MonoProperty_get_DeclaringType_m3201336604 ();
extern "C" void MonoProperty_get_Name_m4214358520 ();
extern "C" void MonoProperty_GetAccessors_m2636385166 ();
extern "C" void MonoProperty_GetGetMethod_m1200130706 ();
extern "C" void MonoProperty_GetIndexParameters_m1064406362 ();
extern "C" void MonoProperty_GetSetMethod_m2480910565 ();
extern "C" void MonoProperty_IsDefined_m2926514180 ();
extern "C" void MonoProperty_GetCustomAttributes_m2693909456 ();
extern "C" void MonoProperty_GetCustomAttributes_m606671689 ();
extern "C" void MonoProperty_CreateGetterDelegate_m2312737886 ();
extern "C" void MonoProperty_GetValue_m3026733966 ();
extern "C" void MonoProperty_GetValue_m3864069366 ();
extern "C" void MonoProperty_SetValue_m1983498753 ();
extern "C" void MonoProperty_ToString_m82409001 ();
extern "C" void MonoProperty_GetOptionalCustomModifiers_m2078442524 ();
extern "C" void MonoProperty_GetRequiredCustomModifiers_m78783095 ();
extern "C" void MonoProperty_GetObjectData_m2146788892 ();
extern "C" void GetterAdapter__ctor_m1012554090 ();
extern "C" void GetterAdapter_Invoke_m274341202 ();
extern "C" void GetterAdapter_BeginInvoke_m1418105378 ();
extern "C" void GetterAdapter_EndInvoke_m4038673688 ();
extern "C" void MonoPropertyInfo_get_property_info_m2619364300 ();
extern "C" void MonoPropertyInfo_GetTypeModifiers_m3896701535 ();
extern "C" void ParameterInfo__ctor_m1259672684 ();
extern "C" void ParameterInfo__ctor_m4093661503 ();
extern "C" void ParameterInfo__ctor_m1491210204 ();
extern "C" void ParameterInfo_ToString_m657579133 ();
extern "C" void ParameterInfo_get_ParameterType_m1392854300 ();
extern "C" void ParameterInfo_get_Attributes_m4228374328 ();
extern "C" void ParameterInfo_get_IsIn_m3130393014 ();
extern "C" void ParameterInfo_get_IsOptional_m3016593533 ();
extern "C" void ParameterInfo_get_IsOut_m4053388324 ();
extern "C" void ParameterInfo_get_IsRetval_m981319851 ();
extern "C" void ParameterInfo_get_Member_m703771809 ();
extern "C" void ParameterInfo_get_Name_m3844246097 ();
extern "C" void ParameterInfo_get_Position_m1016390727 ();
extern "C" void ParameterInfo_GetCustomAttributes_m2620927559 ();
extern "C" void ParameterInfo_IsDefined_m1898312502 ();
extern "C" void ParameterInfo_GetPseudoCustomAttributes_m3010230487 ();
extern "C" void Pointer__ctor_m3237441921 ();
extern "C" void Pointer_System_Runtime_Serialization_ISerializable_GetObjectData_m1139492117 ();
extern "C" void Pointer_Box_m3312154931 ();
extern "C" void PropertyInfo__ctor_m701561300 ();
extern "C" void PropertyInfo_get_MemberType_m503325555 ();
extern "C" void PropertyInfo_GetValue_m3754113982 ();
extern "C" void PropertyInfo_SetValue_m3700075641 ();
extern "C" void PropertyInfo_GetOptionalCustomModifiers_m1048434156 ();
extern "C" void PropertyInfo_GetRequiredCustomModifiers_m10361816 ();
extern "C" void StrongNameKeyPair__ctor_m32462396 ();
extern "C" void StrongNameKeyPair_System_Runtime_Serialization_ISerializable_GetObjectData_m2820598375 ();
extern "C" void StrongNameKeyPair_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m2070263637 ();
extern "C" void TargetException__ctor_m822694954 ();
extern "C" void TargetException__ctor_m3271977883 ();
extern "C" void TargetException__ctor_m2483985350 ();
extern "C" void TargetInvocationException__ctor_m837454776 ();
extern "C" void TargetInvocationException__ctor_m3194966783 ();
extern "C" void TargetParameterCountException__ctor_m2743742885 ();
extern "C" void TargetParameterCountException__ctor_m124206017 ();
extern "C" void TargetParameterCountException__ctor_m2871128293 ();
extern "C" void TypeFilter__ctor_m299289324 ();
extern "C" void TypeFilter_Invoke_m965484192 ();
extern "C" void TypeFilter_BeginInvoke_m2198754576 ();
extern "C" void TypeFilter_EndInvoke_m122362554 ();
extern "C" void ResolveEventArgs__ctor_m3960362713 ();
extern "C" void ResolveEventHandler__ctor_m3364537882 ();
extern "C" void ResolveEventHandler_Invoke_m2076389584 ();
extern "C" void ResolveEventHandler_BeginInvoke_m4075502633 ();
extern "C" void ResolveEventHandler_EndInvoke_m3596368155 ();
extern "C" void NeutralResourcesLanguageAttribute__ctor_m1705398382 ();
extern "C" void ResourceManager__ctor_m2377996755 ();
extern "C" void ResourceManager__cctor_m3369413866 ();
extern "C" void ResourceReader__ctor_m2992668569 ();
extern "C" void ResourceReader__ctor_m2898836350 ();
extern "C" void ResourceReader_System_Collections_IEnumerable_GetEnumerator_m1273544185 ();
extern "C" void ResourceReader_System_IDisposable_Dispose_m2871216432 ();
extern "C" void ResourceReader_ReadHeaders_m3788459369 ();
extern "C" void ResourceReader_CreateResourceInfo_m2385156689 ();
extern "C" void ResourceReader_Read7BitEncodedInt_m3940796910 ();
extern "C" void ResourceReader_ReadValueVer2_m491773434 ();
extern "C" void ResourceReader_ReadValueVer1_m1712931252 ();
extern "C" void ResourceReader_ReadNonPredefinedValue_m3987838549 ();
extern "C" void ResourceReader_LoadResourceValues_m3900593382 ();
extern "C" void ResourceReader_Close_m2367136949 ();
extern "C" void ResourceReader_GetEnumerator_m674542934 ();
extern "C" void ResourceReader_Dispose_m2330356043 ();
extern "C" void ResourceCacheItem__ctor_m2141503584_AdjustorThunk ();
extern "C" void ResourceEnumerator__ctor_m2161138338 ();
extern "C" void ResourceEnumerator_get_Entry_m2788443893 ();
extern "C" void ResourceEnumerator_get_Key_m3490384347 ();
extern "C" void ResourceEnumerator_get_Value_m690942934 ();
extern "C" void ResourceEnumerator_get_Current_m3599228775 ();
extern "C" void ResourceEnumerator_MoveNext_m3061705329 ();
extern "C" void ResourceEnumerator_Reset_m1094270379 ();
extern "C" void ResourceEnumerator_FillCache_m1461526679 ();
extern "C" void ResourceInfo__ctor_m29313275_AdjustorThunk ();
extern "C" void ResourceSet__ctor_m3064702632 ();
extern "C" void ResourceSet__ctor_m3926974598 ();
extern "C" void ResourceSet__ctor_m2843759256 ();
extern "C" void ResourceSet__ctor_m3716415605 ();
extern "C" void ResourceSet_System_Collections_IEnumerable_GetEnumerator_m3787282306 ();
extern "C" void ResourceSet_Dispose_m997817438 ();
extern "C" void ResourceSet_Dispose_m3909104616 ();
extern "C" void ResourceSet_GetEnumerator_m2056913480 ();
extern "C" void ResourceSet_GetObjectInternal_m3498257566 ();
extern "C" void ResourceSet_GetObject_m1749535546 ();
extern "C" void ResourceSet_GetObject_m800002112 ();
extern "C" void ResourceSet_ReadResources_m1247711666 ();
extern "C" void RuntimeResourceSet__ctor_m2600464097 ();
extern "C" void RuntimeResourceSet__ctor_m3701588765 ();
extern "C" void RuntimeResourceSet__ctor_m663308246 ();
extern "C" void RuntimeResourceSet_GetObject_m1211470855 ();
extern "C" void RuntimeResourceSet_GetObject_m4004481700 ();
extern "C" void RuntimeResourceSet_CloneDisposableObjectIfPossible_m1954735340 ();
extern "C" void SatelliteContractVersionAttribute__ctor_m3848511474 ();
extern "C" void CompilationRelaxationsAttribute__ctor_m3343263694 ();
extern "C" void CompilerGeneratedAttribute__ctor_m1329859730 ();
extern "C" void DecimalConstantAttribute__ctor_m65841775 ();
extern "C" void DefaultDependencyAttribute__ctor_m2434010332 ();
extern "C" void FixedBufferAttribute__ctor_m504397755 ();
extern "C" void FixedBufferAttribute_get_ElementType_m1143901886 ();
extern "C" void FixedBufferAttribute_get_Length_m965624054 ();
extern "C" void InternalsVisibleToAttribute__ctor_m3585987778 ();
extern "C" void RuntimeCompatibilityAttribute__ctor_m1077459611 ();
extern "C" void RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2097818566 ();
extern "C" void RuntimeHelpers_InitializeArray_m1875588582 ();
extern "C" void RuntimeHelpers_InitializeArray_m4208405769 ();
extern "C" void RuntimeHelpers_get_OffsetToStringData_m3635924201 ();
extern "C" void StringFreezingAttribute__ctor_m327960799 ();
extern "C" void CriticalFinalizerObject__ctor_m2030151810 ();
extern "C" void CriticalFinalizerObject_Finalize_m1139807466 ();
extern "C" void ReliabilityContractAttribute__ctor_m1584311890 ();
extern "C" void ClassInterfaceAttribute__ctor_m1041561158 ();
extern "C" void ComDefaultInterfaceAttribute__ctor_m585413508 ();
extern "C" void COMException__ctor_m1724775782 ();
extern "C" void COMException__ctor_m3235920267 ();
extern "C" void COMException_ToString_m1844260211 ();
extern "C" void ComImportAttribute__ctor_m1135573434 ();
extern "C" void ComVisibleAttribute__ctor_m3177107244 ();
extern "C" void DispIdAttribute__ctor_m787871839 ();
extern "C" void DllImportAttribute__ctor_m3240233065 ();
extern "C" void DllImportAttribute_get_Value_m2261338912 ();
extern "C" void ExternalException__ctor_m2503986190 ();
extern "C" void ExternalException__ctor_m463019174 ();
extern "C" void FieldOffsetAttribute__ctor_m1651212589 ();
extern "C" void GCHandle__ctor_m778347281_AdjustorThunk ();
extern "C" void GCHandle_get_IsAllocated_m4178866460_AdjustorThunk ();
extern "C" void GCHandle_get_Target_m1404668502_AdjustorThunk ();
extern "C" void GCHandle_Alloc_m2569753928 ();
extern "C" void GCHandle_Free_m516436441_AdjustorThunk ();
extern "C" void GCHandle_GetTarget_m2486407089 ();
extern "C" void GCHandle_GetTargetHandle_m1314632647 ();
extern "C" void GCHandle_FreeHandle_m3959163090 ();
extern "C" void GCHandle_Equals_m2849443044_AdjustorThunk ();
extern "C" void GCHandle_GetHashCode_m2912917812_AdjustorThunk ();
extern "C" void GuidAttribute__ctor_m2076129958 ();
extern "C" void InAttribute__ctor_m2228312299 ();
extern "C" void InterfaceTypeAttribute__ctor_m458747174 ();
extern "C" void Marshal__cctor_m4104258811 ();
extern "C" void Marshal_copy_from_unmanaged_m2804320864 ();
extern "C" void Marshal_Copy_m2093961536 ();
extern "C" void Marshal_Copy_m2701261851 ();
extern "C" void Marshal_ReadByte_m2604965135 ();
extern "C" void Marshal_WriteByte_m1621362122 ();
extern "C" void MarshalAsAttribute__ctor_m767061736 ();
extern "C" void MarshalDirectiveException__ctor_m1071837358 ();
extern "C" void MarshalDirectiveException__ctor_m1659829488 ();
extern "C" void OptionalAttribute__ctor_m2750181596 ();
extern "C" void OutAttribute__ctor_m3241134633 ();
extern "C" void PreserveSigAttribute__ctor_m2060022429 ();
extern "C" void SafeHandle__ctor_m783613520 ();
extern "C" void SafeHandle_Close_m1681605028 ();
extern "C" void SafeHandle_DangerousAddRef_m1891015601 ();
extern "C" void SafeHandle_DangerousGetHandle_m1375610744 ();
extern "C" void SafeHandle_DangerousRelease_m3378349730 ();
extern "C" void SafeHandle_Dispose_m2973664238 ();
extern "C" void SafeHandle_Dispose_m2534630911 ();
extern "C" void SafeHandle_SetHandle_m662183779 ();
extern "C" void SafeHandle_Finalize_m1085970670 ();
extern "C" void TypeLibImportClassAttribute__ctor_m1625403865 ();
extern "C" void TypeLibVersionAttribute__ctor_m3709773259 ();
extern "C" void UnmanagedFunctionPointerAttribute__ctor_m3384177810 ();
extern "C" void ActivatedClientTypeEntry__ctor_m961700077 ();
extern "C" void ActivatedClientTypeEntry_get_ApplicationUrl_m65674309 ();
extern "C" void ActivatedClientTypeEntry_get_ContextAttributes_m1891553033 ();
extern "C" void ActivatedClientTypeEntry_get_ObjectType_m4210984781 ();
extern "C" void ActivatedClientTypeEntry_ToString_m1615275276 ();
extern "C" void ActivatedServiceTypeEntry__ctor_m2993206676 ();
extern "C" void ActivatedServiceTypeEntry_get_ObjectType_m1427973026 ();
extern "C" void ActivatedServiceTypeEntry_ToString_m843014576 ();
extern "C" void ActivationServices_get_ConstructionActivator_m4240976655 ();
extern "C" void ActivationServices_CreateProxyFromAttributes_m3130040993 ();
extern "C" void ActivationServices_CreateConstructionCall_m1739289852 ();
extern "C" void ActivationServices_AllocateUninitializedClassInstance_m1041577079 ();
extern "C" void ActivationServices_EnableProxyActivation_m3061095704 ();
extern "C" void AppDomainLevelActivator__ctor_m1752711285 ();
extern "C" void ConstructionLevelActivator__ctor_m1866604337 ();
extern "C" void ContextLevelActivator__ctor_m2887329662 ();
extern "C" void UrlAttribute_get_UrlValue_m3695705807 ();
extern "C" void UrlAttribute_Equals_m3242123363 ();
extern "C" void UrlAttribute_GetHashCode_m1126142254 ();
extern "C" void UrlAttribute_GetPropertiesForNewContext_m1689720063 ();
extern "C" void UrlAttribute_IsContextOK_m2408897339 ();
extern "C" void ChannelData__ctor_m3724019093 ();
extern "C" void ChannelData_get_ServerProviders_m2346420728 ();
extern "C" void ChannelData_get_ClientProviders_m2647766900 ();
extern "C" void ChannelData_get_CustomProperties_m3201616328 ();
extern "C" void ChannelData_CopyFrom_m3048959718 ();
extern "C" void ChannelInfo__ctor_m3458956171 ();
extern "C" void ChannelInfo_get_ChannelData_m1721234000 ();
extern "C" void ChannelServices__cctor_m2925605698 ();
extern "C" void ChannelServices_CreateClientChannelSinkChain_m2299002996 ();
extern "C" void ChannelServices_CreateClientChannelSinkChain_m1830317104 ();
extern "C" void ChannelServices_RegisterChannel_m619736505 ();
extern "C" void ChannelServices_RegisterChannel_m3776073786 ();
extern "C" void ChannelServices_RegisterChannelConfig_m620916206 ();
extern "C" void ChannelServices_CreateProvider_m2383308334 ();
extern "C" void ChannelServices_GetCurrentChannelInfo_m2697201746 ();
extern "C" void CrossAppDomainChannel__ctor_m922148798 ();
extern "C" void CrossAppDomainChannel__cctor_m61205201 ();
extern "C" void CrossAppDomainChannel_RegisterCrossAppDomainChannel_m3549328991 ();
extern "C" void CrossAppDomainChannel_get_ChannelName_m1966890542 ();
extern "C" void CrossAppDomainChannel_get_ChannelPriority_m2508057774 ();
extern "C" void CrossAppDomainChannel_get_ChannelData_m2946439121 ();
extern "C" void CrossAppDomainChannel_StartListening_m799869571 ();
extern "C" void CrossAppDomainChannel_CreateMessageSink_m3478549795 ();
extern "C" void CrossAppDomainData__ctor_m3603375222 ();
extern "C" void CrossAppDomainData_get_DomainID_m1381698640 ();
extern "C" void CrossAppDomainData_get_ProcessID_m1025542747 ();
extern "C" void CrossAppDomainSink__ctor_m3221079242 ();
extern "C" void CrossAppDomainSink__cctor_m2829594424 ();
extern "C" void CrossAppDomainSink_GetSink_m223269928 ();
extern "C" void CrossAppDomainSink_get_TargetDomainId_m3142859908 ();
extern "C" void SinkProviderData__ctor_m338897737 ();
extern "C" void SinkProviderData_get_Children_m3566980833 ();
extern "C" void SinkProviderData_get_Properties_m1085815932 ();
extern "C" void ClientActivatedIdentity_GetServerObject_m146141043 ();
extern "C" void ClientIdentity__ctor_m401680993 ();
extern "C" void ClientIdentity_get_ClientProxy_m3707620840 ();
extern "C" void ClientIdentity_set_ClientProxy_m3489345640 ();
extern "C" void ClientIdentity_CreateObjRef_m2812888787 ();
extern "C" void ClientIdentity_get_TargetUri_m2343617238 ();
extern "C" void ConfigHandler__ctor_m2131886541 ();
extern "C" void ConfigHandler_ValidatePath_m3488759860 ();
extern "C" void ConfigHandler_CheckPath_m2765851308 ();
extern "C" void ConfigHandler_OnStartParsing_m2591807998 ();
extern "C" void ConfigHandler_OnProcessingInstruction_m610470747 ();
extern "C" void ConfigHandler_OnIgnorableWhitespace_m1043832771 ();
extern "C" void ConfigHandler_OnStartElement_m3059487790 ();
extern "C" void ConfigHandler_ParseElement_m2853712773 ();
extern "C" void ConfigHandler_OnEndElement_m3555551528 ();
extern "C" void ConfigHandler_ReadCustomProviderData_m2138933965 ();
extern "C" void ConfigHandler_ReadLifetine_m1383959793 ();
extern "C" void ConfigHandler_ParseTime_m915090830 ();
extern "C" void ConfigHandler_ReadChannel_m3087762983 ();
extern "C" void ConfigHandler_ReadProvider_m2756436168 ();
extern "C" void ConfigHandler_ReadClientActivated_m4074147023 ();
extern "C" void ConfigHandler_ReadServiceActivated_m2953899804 ();
extern "C" void ConfigHandler_ReadClientWellKnown_m141186075 ();
extern "C" void ConfigHandler_ReadServiceWellKnown_m1548650707 ();
extern "C" void ConfigHandler_ReadInteropXml_m1706145686 ();
extern "C" void ConfigHandler_ReadPreload_m3645960259 ();
extern "C" void ConfigHandler_GetNotNull_m1929319944 ();
extern "C" void ConfigHandler_ExtractAssembly_m46994864 ();
extern "C" void ConfigHandler_OnChars_m2335751675 ();
extern "C" void ConfigHandler_OnEndParsing_m3955900569 ();
extern "C" void Context__ctor_m3838186117 ();
extern "C" void Context__cctor_m1686361362 ();
extern "C" void Context_Finalize_m2707923909 ();
extern "C" void Context_get_DefaultContext_m1757982623 ();
extern "C" void Context_get_ContextID_m1405591127 ();
extern "C" void Context_get_ContextProperties_m3311229519 ();
extern "C" void Context_get_IsDefaultContext_m3747889133 ();
extern "C" void Context_get_NeedsContextSink_m873051291 ();
extern "C" void Context_RegisterDynamicProperty_m3074051190 ();
extern "C" void Context_UnregisterDynamicProperty_m2338404966 ();
extern "C" void Context_GetDynamicPropertyCollection_m1082450921 ();
extern "C" void Context_NotifyGlobalDynamicSinks_m1914139369 ();
extern "C" void Context_get_HasGlobalDynamicSinks_m1840794589 ();
extern "C" void Context_NotifyDynamicSinks_m4010548312 ();
extern "C" void Context_get_HasDynamicSinks_m876233005 ();
extern "C" void Context_get_HasExitSinks_m2218417582 ();
extern "C" void Context_GetProperty_m1984995929 ();
extern "C" void Context_SetProperty_m232332861 ();
extern "C" void Context_Freeze_m772166489 ();
extern "C" void Context_ToString_m2437055406 ();
extern "C" void Context_GetServerContextSinkChain_m2786094134 ();
extern "C" void Context_GetClientContextSinkChain_m3476566830 ();
extern "C" void Context_CreateServerObjectSinkChain_m731523930 ();
extern "C" void Context_CreateEnvoySink_m2384793104 ();
extern "C" void Context_SwitchToContext_m2435378473 ();
extern "C" void Context_CreateNewContext_m484094750 ();
extern "C" void Context_DoCallBack_m2209911274 ();
extern "C" void Context_AllocateDataSlot_m2895667391 ();
extern "C" void Context_AllocateNamedDataSlot_m2522743541 ();
extern "C" void Context_FreeNamedDataSlot_m3013717957 ();
extern "C" void Context_GetData_m1650081915 ();
extern "C" void Context_GetNamedDataSlot_m2125513560 ();
extern "C" void Context_SetData_m930255550 ();
extern "C" void ContextAttribute__ctor_m1193606705 ();
extern "C" void ContextAttribute_get_Name_m3666631151 ();
extern "C" void ContextAttribute_Equals_m880661481 ();
extern "C" void ContextAttribute_Freeze_m4237110078 ();
extern "C" void ContextAttribute_GetHashCode_m1783548121 ();
extern "C" void ContextAttribute_GetPropertiesForNewContext_m3927899656 ();
extern "C" void ContextAttribute_IsContextOK_m807706287 ();
extern "C" void ContextAttribute_IsNewContextOK_m2437025709 ();
extern "C" void ContextCallbackObject__ctor_m3155241849 ();
extern "C" void ContextCallbackObject_DoCallBack_m2489864602 ();
extern "C" void CrossContextChannel__ctor_m230624169 ();
extern "C" void CrossContextDelegate__ctor_m3150806701 ();
extern "C" void CrossContextDelegate_Invoke_m3346279658 ();
extern "C" void CrossContextDelegate_BeginInvoke_m3506025905 ();
extern "C" void CrossContextDelegate_EndInvoke_m856896361 ();
extern "C" void DynamicPropertyCollection__ctor_m3275052761 ();
extern "C" void DynamicPropertyCollection_get_HasProperties_m564239650 ();
extern "C" void DynamicPropertyCollection_RegisterDynamicProperty_m2990332387 ();
extern "C" void DynamicPropertyCollection_UnregisterDynamicProperty_m1202699648 ();
extern "C" void DynamicPropertyCollection_NotifyMessage_m399106134 ();
extern "C" void DynamicPropertyCollection_FindProperty_m1611935282 ();
extern "C" void DynamicPropertyReg__ctor_m483988335 ();
extern "C" void SynchronizationAttribute__ctor_m754806361 ();
extern "C" void SynchronizationAttribute__ctor_m2850967056 ();
extern "C" void SynchronizationAttribute_set_Locked_m1952643074 ();
extern "C" void SynchronizationAttribute_ReleaseLock_m3429901459 ();
extern "C" void SynchronizationAttribute_GetPropertiesForNewContext_m3510013590 ();
extern "C" void SynchronizationAttribute_GetClientContextSink_m13625270 ();
extern "C" void SynchronizationAttribute_GetServerContextSink_m3935992027 ();
extern "C" void SynchronizationAttribute_IsContextOK_m1799431817 ();
extern "C" void SynchronizationAttribute_ExitContext_m1351064750 ();
extern "C" void SynchronizationAttribute_EnterContext_m1794141384 ();
extern "C" void SynchronizedClientContextSink__ctor_m3074650272 ();
extern "C" void SynchronizedServerContextSink__ctor_m1274353107 ();
extern "C" void EnvoyInfo__ctor_m2138777162 ();
extern "C" void EnvoyInfo_get_EnvoySinks_m3098746731 ();
extern "C" void FormatterData__ctor_m1386663475 ();
extern "C" void Identity__ctor_m557501921 ();
extern "C" void Identity_get_ChannelSink_m3563421219 ();
extern "C" void Identity_set_ChannelSink_m3361282506 ();
extern "C" void Identity_get_ObjectUri_m4198864041 ();
extern "C" void Identity_get_Disposed_m942418569 ();
extern "C" void Identity_set_Disposed_m664277977 ();
extern "C" void Identity_get_ClientDynamicProperties_m1621923289 ();
extern "C" void Identity_get_ServerDynamicProperties_m100764717 ();
extern "C" void InternalRemotingServices__cctor_m1051948496 ();
extern "C" void InternalRemotingServices_GetCachedSoapAttribute_m547594056 ();
extern "C" void LeaseManager__ctor_m4166399689 ();
extern "C" void LeaseManager_SetPollTime_m2692443769 ();
extern "C" void LeaseSink__ctor_m3451823952 ();
extern "C" void LifetimeServices__cctor_m490172128 ();
extern "C" void LifetimeServices_set_LeaseManagerPollTime_m2733098311 ();
extern "C" void LifetimeServices_set_LeaseTime_m4187707445 ();
extern "C" void LifetimeServices_set_RenewOnCallTime_m2572614698 ();
extern "C" void LifetimeServices_set_SponsorshipTimeout_m1926202911 ();
extern "C" void ArgInfo__ctor_m2065871060 ();
extern "C" void ArgInfo_GetInOutArgs_m3466727859 ();
extern "C" void AsyncResult__ctor_m2209868077 ();
extern "C" void AsyncResult_get_AsyncState_m2700488195 ();
extern "C" void AsyncResult_get_AsyncWaitHandle_m2951059697 ();
extern "C" void AsyncResult_get_CompletedSynchronously_m674195806 ();
extern "C" void AsyncResult_get_IsCompleted_m2438030310 ();
extern "C" void AsyncResult_get_EndInvokeCalled_m2941151778 ();
extern "C" void AsyncResult_set_EndInvokeCalled_m829674032 ();
extern "C" void AsyncResult_get_AsyncDelegate_m3530734011 ();
extern "C" void AsyncResult_get_NextSink_m46927345 ();
extern "C" void AsyncResult_AsyncProcessMessage_m22892000 ();
extern "C" void AsyncResult_GetReplyMessage_m2466755290 ();
extern "C" void AsyncResult_SetMessageCtrl_m4280675270 ();
extern "C" void AsyncResult_SetCompletedSynchronously_m825468251 ();
extern "C" void AsyncResult_EndInvoke_m1653541135 ();
extern "C" void AsyncResult_SyncProcessMessage_m3119234226 ();
extern "C" void AsyncResult_get_CallMessage_m3771784926 ();
extern "C" void AsyncResult_set_CallMessage_m216266389 ();
extern "C" void CallContextRemotingData__ctor_m1331046353 ();
extern "C" void CallContextRemotingData_Clone_m2495159650 ();
extern "C" void ClientContextTerminatorSink__ctor_m2539508169 ();
extern "C" void ConstructionCall__ctor_m3466893612 ();
extern "C" void ConstructionCall__ctor_m2142921764 ();
extern "C" void ConstructionCall_InitDictionary_m1651665349 ();
extern "C" void ConstructionCall_set_IsContextOk_m1285431228 ();
extern "C" void ConstructionCall_get_ActivationType_m1377015468 ();
extern "C" void ConstructionCall_get_ActivationTypeName_m3161202982 ();
extern "C" void ConstructionCall_get_Activator_m154943756 ();
extern "C" void ConstructionCall_set_Activator_m1835718599 ();
extern "C" void ConstructionCall_get_CallSiteActivationAttributes_m2238433931 ();
extern "C" void ConstructionCall_SetActivationAttributes_m2199093722 ();
extern "C" void ConstructionCall_get_ContextProperties_m906482931 ();
extern "C" void ConstructionCall_InitMethodProperty_m3108654040 ();
extern "C" void ConstructionCall_GetObjectData_m2015931236 ();
extern "C" void ConstructionCall_get_Properties_m1549127719 ();
extern "C" void ConstructionCallDictionary__ctor_m2492889596 ();
extern "C" void ConstructionCallDictionary__cctor_m3231094952 ();
extern "C" void ConstructionCallDictionary_GetMethodProperty_m690519747 ();
extern "C" void ConstructionCallDictionary_SetMethodProperty_m1713421783 ();
extern "C" void EnvoyTerminatorSink__ctor_m3953491455 ();
extern "C" void EnvoyTerminatorSink__cctor_m701708909 ();
extern "C" void Header__ctor_m3914572230 ();
extern "C" void Header__ctor_m272790498 ();
extern "C" void Header__ctor_m2746884126 ();
extern "C" void HeaderHandler__ctor_m3976795712 ();
extern "C" void HeaderHandler_Invoke_m2831067375 ();
extern "C" void HeaderHandler_BeginInvoke_m2995178583 ();
extern "C" void HeaderHandler_EndInvoke_m968934439 ();
extern "C" void LogicalCallContext__ctor_m1163298286 ();
extern "C" void LogicalCallContext__ctor_m1170822759 ();
extern "C" void LogicalCallContext_GetObjectData_m4052825173 ();
extern "C" void LogicalCallContext_SetData_m1821488439 ();
extern "C" void LogicalCallContext_Clone_m1259859386 ();
extern "C" void MethodCall__ctor_m415036708 ();
extern "C" void MethodCall__ctor_m939263252 ();
extern "C" void MethodCall__ctor_m476029139 ();
extern "C" void MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m3786604827 ();
extern "C" void MethodCall_InitMethodProperty_m1633379551 ();
extern "C" void MethodCall_GetObjectData_m740960429 ();
extern "C" void MethodCall_get_Args_m3959193076 ();
extern "C" void MethodCall_get_LogicalCallContext_m3492300167 ();
extern "C" void MethodCall_get_MethodBase_m4004745274 ();
extern "C" void MethodCall_get_MethodName_m690348348 ();
extern "C" void MethodCall_get_MethodSignature_m3050585430 ();
extern "C" void MethodCall_get_Properties_m1136036514 ();
extern "C" void MethodCall_InitDictionary_m762103735 ();
extern "C" void MethodCall_get_TypeName_m2628791529 ();
extern "C" void MethodCall_get_Uri_m2689236272 ();
extern "C" void MethodCall_set_Uri_m4084674782 ();
extern "C" void MethodCall_Init_m47204717 ();
extern "C" void MethodCall_ResolveMethod_m4086104164 ();
extern "C" void MethodCall_CastTo_m728181532 ();
extern "C" void MethodCall_GetTypeNameFromAssemblyQualifiedName_m273889598 ();
extern "C" void MethodCall_get_GenericArguments_m3852295719 ();
extern "C" void MethodCallDictionary__ctor_m2802526823 ();
extern "C" void MethodCallDictionary__cctor_m2460609733 ();
extern "C" void MethodDictionary__ctor_m1781993430 ();
extern "C" void MethodDictionary_System_Collections_IEnumerable_GetEnumerator_m3562925644 ();
extern "C" void MethodDictionary_set_MethodKeys_m1080197003 ();
extern "C" void MethodDictionary_AllocInternalProperties_m3366171218 ();
extern "C" void MethodDictionary_GetInternalProperties_m4025173702 ();
extern "C" void MethodDictionary_IsOverridenKey_m2159926719 ();
extern "C" void MethodDictionary_get_Item_m959319473 ();
extern "C" void MethodDictionary_set_Item_m203484086 ();
extern "C" void MethodDictionary_GetMethodProperty_m2698644386 ();
extern "C" void MethodDictionary_SetMethodProperty_m2556365533 ();
extern "C" void MethodDictionary_get_Values_m2864171127 ();
extern "C" void MethodDictionary_Add_m3203360238 ();
extern "C" void MethodDictionary_Remove_m571527225 ();
extern "C" void MethodDictionary_get_Count_m2276481542 ();
extern "C" void MethodDictionary_get_SyncRoot_m1665468154 ();
extern "C" void MethodDictionary_CopyTo_m4023794854 ();
extern "C" void MethodDictionary_GetEnumerator_m462316350 ();
extern "C" void DictionaryEnumerator__ctor_m46703506 ();
extern "C" void DictionaryEnumerator_get_Current_m851028571 ();
extern "C" void DictionaryEnumerator_MoveNext_m2917595099 ();
extern "C" void DictionaryEnumerator_Reset_m1324461869 ();
extern "C" void DictionaryEnumerator_get_Entry_m688138041 ();
extern "C" void DictionaryEnumerator_get_Key_m1291444917 ();
extern "C" void DictionaryEnumerator_get_Value_m457270540 ();
extern "C" void MethodReturnDictionary__ctor_m1109184831 ();
extern "C" void MethodReturnDictionary__cctor_m1532423255 ();
extern "C" void MonoMethodMessage_get_Args_m4197779504 ();
extern "C" void MonoMethodMessage_get_LogicalCallContext_m3002289517 ();
extern "C" void MonoMethodMessage_get_MethodBase_m3221508894 ();
extern "C" void MonoMethodMessage_get_MethodName_m3182476596 ();
extern "C" void MonoMethodMessage_get_MethodSignature_m1697153679 ();
extern "C" void MonoMethodMessage_get_TypeName_m1795907018 ();
extern "C" void MonoMethodMessage_get_Uri_m91319704 ();
extern "C" void MonoMethodMessage_set_Uri_m3533759863 ();
extern "C" void MonoMethodMessage_get_Exception_m114422168 ();
extern "C" void MonoMethodMessage_get_OutArgCount_m1777813996 ();
extern "C" void MonoMethodMessage_get_OutArgs_m3309919187 ();
extern "C" void MonoMethodMessage_get_ReturnValue_m654888810 ();
extern "C" void ObjRefSurrogate__ctor_m780691929 ();
extern "C" void ObjRefSurrogate_SetObjectData_m588521599 ();
extern "C" void RemotingSurrogate__ctor_m2070167194 ();
extern "C" void RemotingSurrogate_SetObjectData_m3933222664 ();
extern "C" void RemotingSurrogateSelector__ctor_m2739539366 ();
extern "C" void RemotingSurrogateSelector__cctor_m2479395107 ();
extern "C" void RemotingSurrogateSelector_GetSurrogate_m4075568739 ();
extern "C" void ReturnMessage__ctor_m585853403 ();
extern "C" void ReturnMessage__ctor_m3407677129 ();
extern "C" void ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m4261914537 ();
extern "C" void ReturnMessage_get_Args_m4250458202 ();
extern "C" void ReturnMessage_get_LogicalCallContext_m2795444970 ();
extern "C" void ReturnMessage_get_MethodBase_m3826743104 ();
extern "C" void ReturnMessage_get_MethodName_m3938791954 ();
extern "C" void ReturnMessage_get_MethodSignature_m3174578052 ();
extern "C" void ReturnMessage_get_Properties_m2160042302 ();
extern "C" void ReturnMessage_get_TypeName_m752749841 ();
extern "C" void ReturnMessage_get_Uri_m1271224052 ();
extern "C" void ReturnMessage_set_Uri_m1515029532 ();
extern "C" void ReturnMessage_get_Exception_m1147782502 ();
extern "C" void ReturnMessage_get_OutArgs_m2626479784 ();
extern "C" void ReturnMessage_get_ReturnValue_m337270066 ();
extern "C" void ServerContextTerminatorSink__ctor_m499022319 ();
extern "C" void ServerObjectTerminatorSink__ctor_m1659403710 ();
extern "C" void StackBuilderSink__ctor_m576942155 ();
extern "C" void SoapAttribute__ctor_m1306946280 ();
extern "C" void SoapAttribute_get_UseAttribute_m1300208059 ();
extern "C" void SoapAttribute_get_XmlNamespace_m1520332408 ();
extern "C" void SoapAttribute_SetReflectionObject_m4117039302 ();
extern "C" void SoapFieldAttribute__ctor_m348678892 ();
extern "C" void SoapFieldAttribute_get_XmlElementName_m2947819553 ();
extern "C" void SoapFieldAttribute_IsInteropXmlElement_m4172772882 ();
extern "C" void SoapFieldAttribute_SetReflectionObject_m2500062081 ();
extern "C" void SoapMethodAttribute__ctor_m3606291552 ();
extern "C" void SoapMethodAttribute_get_UseAttribute_m2633944108 ();
extern "C" void SoapMethodAttribute_get_XmlNamespace_m3002077767 ();
extern "C" void SoapMethodAttribute_SetReflectionObject_m734446699 ();
extern "C" void SoapParameterAttribute__ctor_m3166664116 ();
extern "C" void SoapTypeAttribute__ctor_m1748412569 ();
extern "C" void SoapTypeAttribute_get_UseAttribute_m4043801432 ();
extern "C" void SoapTypeAttribute_get_XmlElementName_m3856270789 ();
extern "C" void SoapTypeAttribute_get_XmlNamespace_m3158991572 ();
extern "C" void SoapTypeAttribute_get_XmlTypeName_m3547608960 ();
extern "C" void SoapTypeAttribute_get_XmlTypeNamespace_m2663572758 ();
extern "C" void SoapTypeAttribute_get_IsInteropXmlElement_m4150796203 ();
extern "C" void SoapTypeAttribute_get_IsInteropXmlType_m58579444 ();
extern "C" void SoapTypeAttribute_SetReflectionObject_m3374443417 ();
extern "C" void ObjRef__ctor_m2201506127 ();
extern "C" void ObjRef__ctor_m516056283 ();
extern "C" void ObjRef__cctor_m4053166273 ();
extern "C" void ObjRef_get_IsReferenceToWellKnow_m2899488919 ();
extern "C" void ObjRef_get_ChannelInfo_m2012758559 ();
extern "C" void ObjRef_get_EnvoyInfo_m2369958823 ();
extern "C" void ObjRef_set_EnvoyInfo_m475830191 ();
extern "C" void ObjRef_get_TypeInfo_m2162062585 ();
extern "C" void ObjRef_set_TypeInfo_m2940278911 ();
extern "C" void ObjRef_get_URI_m3161471344 ();
extern "C" void ObjRef_set_URI_m222403039 ();
extern "C" void ObjRef_GetObjectData_m725082537 ();
extern "C" void ObjRef_GetRealObject_m925820486 ();
extern "C" void ObjRef_UpdateChannelInfo_m2391705399 ();
extern "C" void ObjRef_get_ServerType_m56993821 ();
extern "C" void ProviderData__ctor_m3415210490 ();
extern "C" void ProviderData_CopyFrom_m3006936805 ();
extern "C" void ProxyAttribute_CreateInstance_m3346069638 ();
extern "C" void ProxyAttribute_CreateProxy_m2609399614 ();
extern "C" void ProxyAttribute_GetPropertiesForNewContext_m2921967682 ();
extern "C" void ProxyAttribute_IsContextOK_m2900797900 ();
extern "C" void RealProxy__ctor_m4047939971 ();
extern "C" void RealProxy__ctor_m1219875204 ();
extern "C" void RealProxy__ctor_m643728101 ();
extern "C" void RealProxy_InternalGetProxyType_m1757270186 ();
extern "C" void RealProxy_GetProxiedType_m874982819 ();
extern "C" void RealProxy_get_ObjectIdentity_m2464753590 ();
extern "C" void RealProxy_InternalGetTransparentProxy_m3162398806 ();
extern "C" void RealProxy_GetTransparentProxy_m2284490092 ();
extern "C" void RealProxy_SetTargetDomain_m2331264622 ();
extern "C" void RemotingProxy__ctor_m2148441992 ();
extern "C" void RemotingProxy__ctor_m3935036851 ();
extern "C" void RemotingProxy__cctor_m2396862393 ();
extern "C" void RemotingProxy_get_TypeName_m1121862913 ();
extern "C" void RemotingProxy_Finalize_m3734033920 ();
extern "C" void RemotingConfiguration__cctor_m2311209514 ();
extern "C" void RemotingConfiguration_get_ApplicationName_m672944369 ();
extern "C" void RemotingConfiguration_set_ApplicationName_m792542103 ();
extern "C" void RemotingConfiguration_get_ProcessId_m1656665657 ();
extern "C" void RemotingConfiguration_LoadDefaultDelayedChannels_m618815769 ();
extern "C" void RemotingConfiguration_IsRemotelyActivatedClientType_m503546012 ();
extern "C" void RemotingConfiguration_RegisterActivatedClientType_m3041958400 ();
extern "C" void RemotingConfiguration_RegisterActivatedServiceType_m1490903857 ();
extern "C" void RemotingConfiguration_RegisterWellKnownClientType_m2781688209 ();
extern "C" void RemotingConfiguration_RegisterWellKnownServiceType_m1677471129 ();
extern "C" void RemotingConfiguration_RegisterChannelTemplate_m184465224 ();
extern "C" void RemotingConfiguration_RegisterClientProviderTemplate_m2381947447 ();
extern "C" void RemotingConfiguration_RegisterServerProviderTemplate_m3536257028 ();
extern "C" void RemotingConfiguration_RegisterChannels_m261577395 ();
extern "C" void RemotingConfiguration_RegisterTypes_m100450006 ();
extern "C" void RemotingConfiguration_SetCustomErrorsMode_m677597509 ();
extern "C" void RemotingException__ctor_m3721773766 ();
extern "C" void RemotingException__ctor_m707171175 ();
extern "C" void RemotingException__ctor_m3933416140 ();
extern "C" void RemotingException__ctor_m3896880630 ();
extern "C" void RemotingServices__cctor_m3778079804 ();
extern "C" void RemotingServices_GetVirtualMethod_m652022987 ();
extern "C" void RemotingServices_IsTransparentProxy_m279338587 ();
extern "C" void RemotingServices_GetServerTypeForUri_m4277211104 ();
extern "C" void RemotingServices_Unmarshal_m3017263782 ();
extern "C" void RemotingServices_Unmarshal_m3419487221 ();
extern "C" void RemotingServices_GetRealProxy_m280469471 ();
extern "C" void RemotingServices_GetMethodBaseFromMethodMessage_m3573931760 ();
extern "C" void RemotingServices_GetMethodBaseFromName_m621270620 ();
extern "C" void RemotingServices_FindInterfaceMethod_m2755295661 ();
extern "C" void RemotingServices_CreateClientProxy_m3730760804 ();
extern "C" void RemotingServices_CreateClientProxy_m2260470495 ();
extern "C" void RemotingServices_CreateClientProxyForContextBound_m1156816168 ();
extern "C" void RemotingServices_GetIdentityForUri_m1525529537 ();
extern "C" void RemotingServices_RemoveAppNameFromUri_m2783715653 ();
extern "C" void RemotingServices_GetOrCreateClientIdentity_m1811768247 ();
extern "C" void RemotingServices_GetClientChannelSinkChain_m493244133 ();
extern "C" void RemotingServices_CreateWellKnownServerIdentity_m67274966 ();
extern "C" void RemotingServices_RegisterServerIdentity_m3843373474 ();
extern "C" void RemotingServices_GetProxyForRemoteObject_m2032832169 ();
extern "C" void RemotingServices_GetRemoteObject_m401742822 ();
extern "C" void RemotingServices_RegisterInternalChannels_m3328389237 ();
extern "C" void RemotingServices_DisposeIdentity_m2311273193 ();
extern "C" void RemotingServices_GetNormalizedUri_m2695347677 ();
extern "C" void ServerIdentity__ctor_m532254845 ();
extern "C" void ServerIdentity_get_ObjectType_m990614504 ();
extern "C" void ServerIdentity_CreateObjRef_m3549161024 ();
extern "C" void TrackingServices__cctor_m3046150965 ();
extern "C" void TrackingServices_NotifyUnmarshaledObject_m909404297 ();
extern "C" void SingleCallIdentity__ctor_m3629585548 ();
extern "C" void SingletonIdentity__ctor_m641328939 ();
extern "C" void SoapServices__cctor_m3893749875 ();
extern "C" void SoapServices_get_XmlNsForClrTypeWithAssembly_m255710703 ();
extern "C" void SoapServices_get_XmlNsForClrTypeWithNs_m2681437479 ();
extern "C" void SoapServices_get_XmlNsForClrTypeWithNsAndAssembly_m3163592569 ();
extern "C" void SoapServices_CodeXmlNamespaceForClrTypeNamespace_m2713593429 ();
extern "C" void SoapServices_GetNameKey_m1699605387 ();
extern "C" void SoapServices_GetAssemblyName_m3132444504 ();
extern "C" void SoapServices_GetXmlElementForInteropType_m2691027766 ();
extern "C" void SoapServices_GetXmlNamespaceForMethodCall_m3612287677 ();
extern "C" void SoapServices_GetXmlNamespaceForMethodResponse_m2122162288 ();
extern "C" void SoapServices_GetXmlTypeForInteropType_m3922130045 ();
extern "C" void SoapServices_PreLoad_m3096575915 ();
extern "C" void SoapServices_PreLoad_m2963871411 ();
extern "C" void SoapServices_RegisterInteropXmlElement_m3273918327 ();
extern "C" void SoapServices_RegisterInteropXmlType_m3782208866 ();
extern "C" void SoapServices_EncodeNs_m3623626875 ();
extern "C" void TypeInfo__ctor_m749005430 ();
extern "C" void TypeEntry__ctor_m299864581 ();
extern "C" void TypeEntry_get_AssemblyName_m1609650271 ();
extern "C" void TypeEntry_set_AssemblyName_m72117852 ();
extern "C" void TypeEntry_get_TypeName_m846966246 ();
extern "C" void TypeEntry_set_TypeName_m3142650263 ();
extern "C" void TypeInfo__ctor_m1222490081 ();
extern "C" void TypeInfo_get_TypeName_m2953131114 ();
extern "C" void WellKnownClientTypeEntry__ctor_m1247784010 ();
extern "C" void WellKnownClientTypeEntry_get_ApplicationUrl_m3928198598 ();
extern "C" void WellKnownClientTypeEntry_get_ObjectType_m586290458 ();
extern "C" void WellKnownClientTypeEntry_get_ObjectUrl_m431903055 ();
extern "C" void WellKnownClientTypeEntry_ToString_m3134498117 ();
extern "C" void WellKnownServiceTypeEntry__ctor_m2537961663 ();
extern "C" void WellKnownServiceTypeEntry_get_Mode_m724663084 ();
extern "C" void WellKnownServiceTypeEntry_get_ObjectType_m256079547 ();
extern "C" void WellKnownServiceTypeEntry_get_ObjectUri_m1845332693 ();
extern "C" void WellKnownServiceTypeEntry_ToString_m1565416192 ();
extern "C" void ArrayFixupRecord__ctor_m3836393882 ();
extern "C" void ArrayFixupRecord_FixupImpl_m2851003963 ();
extern "C" void BaseFixupRecord__ctor_m2609189912 ();
extern "C" void BaseFixupRecord_DoFixup_m2617577611 ();
extern "C" void DelayedFixupRecord__ctor_m4014918533 ();
extern "C" void DelayedFixupRecord_FixupImpl_m1877769505 ();
extern "C" void FixupRecord__ctor_m1957389285 ();
extern "C" void FixupRecord_FixupImpl_m1620782233 ();
extern "C" void FormatterConverter__ctor_m2135716800 ();
extern "C" void FormatterConverter_Convert_m3684785726 ();
extern "C" void FormatterConverter_ToBoolean_m479120073 ();
extern "C" void FormatterConverter_ToInt16_m3479858435 ();
extern "C" void FormatterConverter_ToInt32_m3722320607 ();
extern "C" void FormatterConverter_ToInt64_m3595075555 ();
extern "C" void FormatterConverter_ToString_m241015643 ();
extern "C" void BinaryCommon__cctor_m3004868178 ();
extern "C" void BinaryCommon_IsPrimitive_m2616910507 ();
extern "C" void BinaryCommon_GetTypeFromCode_m131918506 ();
extern "C" void BinaryCommon_SwapBytes_m2432230699 ();
extern "C" void BinaryFormatter__ctor_m3146562200 ();
extern "C" void BinaryFormatter__ctor_m2851663452 ();
extern "C" void BinaryFormatter_get_DefaultSurrogateSelector_m854521798 ();
extern "C" void BinaryFormatter_set_AssemblyFormat_m1189284053 ();
extern "C" void BinaryFormatter_get_Binder_m2039458805 ();
extern "C" void BinaryFormatter_get_Context_m3731928774 ();
extern "C" void BinaryFormatter_get_SurrogateSelector_m3168333247 ();
extern "C" void BinaryFormatter_get_FilterLevel_m2369297993 ();
extern "C" void BinaryFormatter_Deserialize_m462089466 ();
extern "C" void BinaryFormatter_NoCheckDeserialize_m4098423934 ();
extern "C" void BinaryFormatter_ReadBinaryHeader_m206187517 ();
extern "C" void MessageFormatter_ReadMethodCall_m2321634515 ();
extern "C" void MessageFormatter_ReadMethodResponse_m3085665395 ();
extern "C" void ObjectReader__ctor_m1273001858 ();
extern "C" void ObjectReader_ReadObjectGraph_m3902162721 ();
extern "C" void ObjectReader_ReadObjectGraph_m1685992435 ();
extern "C" void ObjectReader_ReadNextObject_m795245237 ();
extern "C" void ObjectReader_ReadNextObject_m2541422008 ();
extern "C" void ObjectReader_get_CurrentObject_m360305727 ();
extern "C" void ObjectReader_ReadObject_m199288650 ();
extern "C" void ObjectReader_ReadAssembly_m1539730531 ();
extern "C" void ObjectReader_ReadObjectInstance_m2151687868 ();
extern "C" void ObjectReader_ReadRefTypeObjectInstance_m1891840481 ();
extern "C" void ObjectReader_ReadObjectContent_m2317908275 ();
extern "C" void ObjectReader_RegisterObject_m3571110076 ();
extern "C" void ObjectReader_ReadStringIntance_m3521752300 ();
extern "C" void ObjectReader_ReadGenericArray_m3349314585 ();
extern "C" void ObjectReader_ReadBoxedPrimitiveTypeValue_m2878618397 ();
extern "C" void ObjectReader_ReadArrayOfPrimitiveType_m1993495055 ();
extern "C" void ObjectReader_BlockRead_m412730463 ();
extern "C" void ObjectReader_ReadArrayOfObject_m3759609410 ();
extern "C" void ObjectReader_ReadArrayOfString_m2353638103 ();
extern "C" void ObjectReader_ReadSimpleArray_m3777056613 ();
extern "C" void ObjectReader_ReadTypeMetadata_m1403168639 ();
extern "C" void ObjectReader_ReadValue_m411602587 ();
extern "C" void ObjectReader_SetObjectValue_m4161835366 ();
extern "C" void ObjectReader_RecordFixup_m175190372 ();
extern "C" void ObjectReader_GetDeserializationType_m1976087801 ();
extern "C" void ObjectReader_ReadType_m3109025754 ();
extern "C" void ObjectReader_ReadPrimitiveTypeValue_m1847732724 ();
extern "C" void ArrayNullFiller__ctor_m1731819938 ();
extern "C" void TypeMetadata__ctor_m3098590023 ();
extern "C" void FormatterServices_GetUninitializedObject_m4187463930 ();
extern "C" void FormatterServices_GetSafeUninitializedObject_m1378558216 ();
extern "C" void MultiArrayFixupRecord__ctor_m649923862 ();
extern "C" void MultiArrayFixupRecord_FixupImpl_m3758679554 ();
extern "C" void ObjectManager__ctor_m3601834391 ();
extern "C" void ObjectManager_DoFixups_m3290753670 ();
extern "C" void ObjectManager_GetObjectRecord_m3668965817 ();
extern "C" void ObjectManager_GetObject_m3360629357 ();
extern "C" void ObjectManager_RaiseDeserializationEvent_m3355231024 ();
extern "C" void ObjectManager_RaiseOnDeserializingEvent_m1847096661 ();
extern "C" void ObjectManager_RaiseOnDeserializedEvent_m3014513403 ();
extern "C" void ObjectManager_AddFixup_m2279770251 ();
extern "C" void ObjectManager_RecordArrayElementFixup_m2313711327 ();
extern "C" void ObjectManager_RecordArrayElementFixup_m1616535972 ();
extern "C" void ObjectManager_RecordDelayedFixup_m3185204348 ();
extern "C" void ObjectManager_RecordFixup_m228983078 ();
extern "C" void ObjectManager_RegisterObjectInternal_m1854943049 ();
extern "C" void ObjectManager_RegisterObject_m2926210872 ();
extern "C" void ObjectRecord__ctor_m1438414803 ();
extern "C" void ObjectRecord_SetMemberValue_m686143867 ();
extern "C" void ObjectRecord_SetArrayValue_m1820344001 ();
extern "C" void ObjectRecord_SetMemberValue_m2609372451 ();
extern "C" void ObjectRecord_get_IsInstanceReady_m724320986 ();
extern "C" void ObjectRecord_get_IsUnsolvedObjectReference_m841138941 ();
extern "C" void ObjectRecord_get_IsRegistered_m355656857 ();
extern "C" void ObjectRecord_DoFixups_m893086713 ();
extern "C" void ObjectRecord_RemoveFixup_m2186927737 ();
extern "C" void ObjectRecord_UnchainFixup_m1977281516 ();
extern "C" void ObjectRecord_ChainFixup_m2043725430 ();
extern "C" void ObjectRecord_LoadData_m68651069 ();
extern "C" void ObjectRecord_get_HasPendingFixups_m3021207880 ();
extern "C" void SerializationBinder__ctor_m1078952796 ();
extern "C" void SerializationCallbacks__ctor_m3384310389 ();
extern "C" void SerializationCallbacks__cctor_m1813319232 ();
extern "C" void SerializationCallbacks_get_HasDeserializedCallbacks_m1082288191 ();
extern "C" void SerializationCallbacks_GetMethodsByAttribute_m1078102764 ();
extern "C" void SerializationCallbacks_Invoke_m1531280676 ();
extern "C" void SerializationCallbacks_RaiseOnDeserializing_m1542357703 ();
extern "C" void SerializationCallbacks_RaiseOnDeserialized_m1994674013 ();
extern "C" void SerializationCallbacks_GetSerializationCallbacks_m845878201 ();
extern "C" void CallbackHandler__ctor_m1461418459 ();
extern "C" void CallbackHandler_Invoke_m1359829553 ();
extern "C" void CallbackHandler_BeginInvoke_m2676435091 ();
extern "C" void CallbackHandler_EndInvoke_m3197008604 ();
extern "C" void SerializationEntry__ctor_m790429572_AdjustorThunk ();
extern "C" void SerializationEntry_get_Name_m2420372003_AdjustorThunk ();
extern "C" void SerializationEntry_get_Value_m511469057_AdjustorThunk ();
extern "C" void SerializationException__ctor_m2487770392 ();
extern "C" void SerializationException__ctor_m543944324 ();
extern "C" void SerializationException__ctor_m2473528184 ();
extern "C" void SerializationInfo__ctor_m2387200337 ();
extern "C" void SerializationInfo_AddValue_m759493278 ();
extern "C" void SerializationInfo_GetValue_m2154590912 ();
extern "C" void SerializationInfo_SetType_m4250326333 ();
extern "C" void SerializationInfo_GetEnumerator_m2037478279 ();
extern "C" void SerializationInfo_AddValue_m2914747780 ();
extern "C" void SerializationInfo_AddValue_m3600311562 ();
extern "C" void SerializationInfo_AddValue_m1250939204 ();
extern "C" void SerializationInfo_AddValue_m1839889968 ();
extern "C" void SerializationInfo_AddValue_m2293930930 ();
extern "C" void SerializationInfo_AddValue_m1332533654 ();
extern "C" void SerializationInfo_AddValue_m4204157667 ();
extern "C" void SerializationInfo_AddValue_m289879288 ();
extern "C" void SerializationInfo_GetBoolean_m921802057 ();
extern "C" void SerializationInfo_GetInt16_m1776181798 ();
extern "C" void SerializationInfo_GetInt32_m1778692989 ();
extern "C" void SerializationInfo_GetInt64_m1823203327 ();
extern "C" void SerializationInfo_GetString_m4161796836 ();
extern "C" void SerializationInfoEnumerator__ctor_m998457667 ();
extern "C" void SerializationInfoEnumerator_System_Collections_IEnumerator_get_Current_m968813573 ();
extern "C" void SerializationInfoEnumerator_get_Current_m4238443440 ();
extern "C" void SerializationInfoEnumerator_get_Name_m2588889941 ();
extern "C" void SerializationInfoEnumerator_get_Value_m1906390789 ();
extern "C" void SerializationInfoEnumerator_MoveNext_m1785816370 ();
extern "C" void SerializationInfoEnumerator_Reset_m1174885035 ();
extern "C" void StreamingContext__ctor_m3022477990_AdjustorThunk ();
extern "C" void StreamingContext__ctor_m312956436_AdjustorThunk ();
extern "C" void StreamingContext_get_State_m283394087_AdjustorThunk ();
extern "C" void StreamingContext_Equals_m933234336_AdjustorThunk ();
extern "C" void StreamingContext_GetHashCode_m2625011279_AdjustorThunk ();
extern "C" void RuntimeFieldHandle__ctor_m4172087370_AdjustorThunk ();
extern "C" void RuntimeFieldHandle_get_Value_m866086549_AdjustorThunk ();
extern "C" void RuntimeFieldHandle_GetObjectData_m2689093007_AdjustorThunk ();
extern "C" void RuntimeFieldHandle_Equals_m1997721335_AdjustorThunk ();
extern "C" void RuntimeFieldHandle_GetHashCode_m1029854444_AdjustorThunk ();
extern "C" void RuntimeMethodHandle__ctor_m1321128595_AdjustorThunk ();
extern "C" void RuntimeMethodHandle__ctor_m3935743526_AdjustorThunk ();
extern "C" void RuntimeMethodHandle_get_Value_m3451776408_AdjustorThunk ();
extern "C" void RuntimeMethodHandle_GetObjectData_m1453343446_AdjustorThunk ();
extern "C" void RuntimeMethodHandle_Equals_m694043567_AdjustorThunk ();
extern "C" void RuntimeMethodHandle_GetHashCode_m4152426864_AdjustorThunk ();
extern "C" void RuntimeTypeHandle__ctor_m105574446_AdjustorThunk ();
extern "C" void RuntimeTypeHandle_get_Value_m2841980210_AdjustorThunk ();
extern "C" void RuntimeTypeHandle_GetObjectData_m2737299150_AdjustorThunk ();
extern "C" void RuntimeTypeHandle_Equals_m3316377268_AdjustorThunk ();
extern "C" void RuntimeTypeHandle_GetHashCode_m229948238_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToBoolean_m705044034_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToByte_m1875040019_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToChar_m2477566749_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToDateTime_m3268135819_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToDecimal_m3482021937_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToDouble_m2507104885_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToInt16_m297586731_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToInt32_m1408482032_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToInt64_m59703844_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToSByte_m1395714978_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToSingle_m3196659216_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToType_m1425966275_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToUInt16_m1156307957_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToUInt32_m1630092365_AdjustorThunk ();
extern "C" void SByte_System_IConvertible_ToUInt64_m682207648_AdjustorThunk ();
extern "C" void SByte_CompareTo_m2779740121_AdjustorThunk ();
extern "C" void SByte_Equals_m4108147891_AdjustorThunk ();
extern "C" void SByte_GetHashCode_m3795742907_AdjustorThunk ();
extern "C" void SByte_CompareTo_m3951976715_AdjustorThunk ();
extern "C" void SByte_Equals_m2186545988_AdjustorThunk ();
extern "C" void SByte_Parse_m1765018877 ();
extern "C" void SByte_Parse_m970256373 ();
extern "C" void SByte_Parse_m512031140 ();
extern "C" void SByte_TryParse_m2531638266 ();
extern "C" void SByte_ToString_m2281364446_AdjustorThunk ();
extern "C" void SByte_ToString_m906610161_AdjustorThunk ();
extern "C" void SByte_ToString_m3415302163_AdjustorThunk ();
extern "C" void SByte_ToString_m1524252683_AdjustorThunk ();
extern "C" void AllowPartiallyTrustedCallersAttribute__ctor_m3140459627 ();
extern "C" void CodeAccessPermission__ctor_m2433238787 ();
extern "C" void CodeAccessPermission_Equals_m3953672351 ();
extern "C" void CodeAccessPermission_GetHashCode_m539756730 ();
extern "C" void CodeAccessPermission_ToString_m1334089401 ();
extern "C" void CodeAccessPermission_Element_m2627688913 ();
extern "C" void CodeAccessPermission_ThrowInvalidPermission_m3351613238 ();
extern "C" void AsymmetricAlgorithm__ctor_m2287376669 ();
extern "C" void AsymmetricAlgorithm_System_IDisposable_Dispose_m1738211272 ();
extern "C" void AsymmetricAlgorithm_get_KeySize_m2661714387 ();
extern "C" void AsymmetricAlgorithm_set_KeySize_m1791656823 ();
extern "C" void AsymmetricAlgorithm_Clear_m3692737162 ();
extern "C" void AsymmetricAlgorithm_GetNamedParam_m1740130169 ();
extern "C" void AsymmetricKeyExchangeFormatter__ctor_m1023672232 ();
extern "C" void AsymmetricSignatureDeformatter__ctor_m3988664358 ();
extern "C" void AsymmetricSignatureFormatter__ctor_m1640818079 ();
extern "C" void Base64Constants__cctor_m2107127471 ();
extern "C" void CryptoConfig__cctor_m866309163 ();
extern "C" void CryptoConfig_Initialize_m1734067327 ();
extern "C" void CryptoConfig_CreateFromName_m231814076 ();
extern "C" void CryptoConfig_CreateFromName_m3002182116 ();
extern "C" void CryptoConfig_MapNameToOID_m3381960723 ();
extern "C" void CryptoConfig_EncodeOID_m4065586783 ();
extern "C" void CryptoConfig_EncodeLongNumber_m2216895718 ();
extern "C" void CryptographicException__ctor_m2480918178 ();
extern "C" void CryptographicException__ctor_m3631852793 ();
extern "C" void CryptographicException__ctor_m3730179204 ();
extern "C" void CryptographicException__ctor_m1959895321 ();
extern "C" void CryptographicException__ctor_m487633063 ();
extern "C" void CryptographicUnexpectedOperationException__ctor_m3738311784 ();
extern "C" void CryptographicUnexpectedOperationException__ctor_m2082830875 ();
extern "C" void CryptographicUnexpectedOperationException__ctor_m2071918291 ();
extern "C" void CspParameters__ctor_m3702908281 ();
extern "C" void CspParameters__ctor_m277089053 ();
extern "C" void CspParameters__ctor_m289584655 ();
extern "C" void CspParameters__ctor_m3792907619 ();
extern "C" void CspParameters_get_Flags_m3417749665 ();
extern "C" void CspParameters_set_Flags_m836186324 ();
extern "C" void DES__ctor_m4233698758 ();
extern "C" void DES__cctor_m3070684742 ();
extern "C" void DES_Create_m3267808042 ();
extern "C" void DES_Create_m1170661537 ();
extern "C" void DES_IsWeakKey_m2312600013 ();
extern "C" void DES_IsSemiWeakKey_m319738260 ();
extern "C" void DES_get_Key_m268505297 ();
extern "C" void DES_set_Key_m467923446 ();
extern "C" void DESCryptoServiceProvider__ctor_m702944993 ();
extern "C" void DESCryptoServiceProvider_CreateDecryptor_m3209468118 ();
extern "C" void DESCryptoServiceProvider_CreateEncryptor_m3515578811 ();
extern "C" void DESCryptoServiceProvider_GenerateIV_m4241668416 ();
extern "C" void DESCryptoServiceProvider_GenerateKey_m3835533934 ();
extern "C" void DESTransform__ctor_m3332211466 ();
extern "C" void DESTransform__cctor_m2274726065 ();
extern "C" void DESTransform_CipherFunct_m915571017 ();
extern "C" void DESTransform_Permutation_m118653901 ();
extern "C" void DESTransform_BSwap_m3115355213 ();
extern "C" void DESTransform_SetKey_m1904852052 ();
extern "C" void DESTransform_ProcessBlock_m3137656659 ();
extern "C" void DESTransform_ECB_m1707917459 ();
extern "C" void DESTransform_GetStrongKey_m3121830593 ();
extern "C" void DSA__ctor_m536540930 ();
extern "C" void DSA_Create_m2518185329 ();
extern "C" void DSA_Create_m787108845 ();
extern "C" void DSA_ZeroizePrivateKey_m3486340173 ();
extern "C" void DSA_FromXmlString_m972829522 ();
extern "C" void DSA_ToXmlString_m2192751897 ();
extern "C" void DSACryptoServiceProvider__ctor_m1596488375 ();
extern "C" void DSACryptoServiceProvider__ctor_m787349590 ();
extern "C" void DSACryptoServiceProvider__ctor_m1947829840 ();
extern "C" void DSACryptoServiceProvider__cctor_m1275456870 ();
extern "C" void DSACryptoServiceProvider_Finalize_m278584479 ();
extern "C" void DSACryptoServiceProvider_get_KeySize_m4020532355 ();
extern "C" void DSACryptoServiceProvider_get_PublicOnly_m2126730996 ();
extern "C" void DSACryptoServiceProvider_ExportParameters_m2011127564 ();
extern "C" void DSACryptoServiceProvider_ImportParameters_m2807004223 ();
extern "C" void DSACryptoServiceProvider_CreateSignature_m2245336314 ();
extern "C" void DSACryptoServiceProvider_VerifySignature_m2722981406 ();
extern "C" void DSACryptoServiceProvider_Dispose_m3939213751 ();
extern "C" void DSACryptoServiceProvider_OnKeyGenerated_m1298791583 ();
extern "C" void DSASignatureDeformatter__ctor_m1593180206 ();
extern "C" void DSASignatureDeformatter__ctor_m1334927914 ();
extern "C" void DSASignatureDeformatter_SetHashAlgorithm_m2463972379 ();
extern "C" void DSASignatureDeformatter_SetKey_m2536713114 ();
extern "C" void DSASignatureDeformatter_VerifySignature_m2106654280 ();
extern "C" void DSASignatureDescription__ctor_m1909776961 ();
extern "C" void DSASignatureFormatter__ctor_m955073984 ();
extern "C" void DSASignatureFormatter_CreateSignature_m1272540439 ();
extern "C" void DSASignatureFormatter_SetHashAlgorithm_m2407146058 ();
extern "C" void DSASignatureFormatter_SetKey_m3442764047 ();
extern "C" void HashAlgorithm__ctor_m584424507 ();
extern "C" void HashAlgorithm_System_IDisposable_Dispose_m2507530935 ();
extern "C" void HashAlgorithm_get_CanReuseTransform_m1058251057 ();
extern "C" void HashAlgorithm_ComputeHash_m2877966704 ();
extern "C" void HashAlgorithm_ComputeHash_m2249490520 ();
extern "C" void HashAlgorithm_Create_m1468966163 ();
extern "C" void HashAlgorithm_get_Hash_m2483127982 ();
extern "C" void HashAlgorithm_get_HashSize_m2187072066 ();
extern "C" void HashAlgorithm_Dispose_m397531773 ();
extern "C" void HashAlgorithm_TransformBlock_m3993734057 ();
extern "C" void HashAlgorithm_TransformFinalBlock_m1002009535 ();
extern "C" void HMAC__ctor_m2121955378 ();
extern "C" void HMAC_get_BlockSizeValue_m3123162733 ();
extern "C" void HMAC_set_BlockSizeValue_m127665774 ();
extern "C" void HMAC_set_HashName_m2430067301 ();
extern "C" void HMAC_get_Key_m1979367088 ();
extern "C" void HMAC_set_Key_m1846298930 ();
extern "C" void HMAC_get_Block_m1079323359 ();
extern "C" void HMAC_KeySetup_m347660145 ();
extern "C" void HMAC_Dispose_m2279147198 ();
extern "C" void HMAC_HashCore_m3360064661 ();
extern "C" void HMAC_HashFinal_m1409071730 ();
extern "C" void HMAC_Initialize_m3684336309 ();
extern "C" void HMAC_Create_m2565963980 ();
extern "C" void HMAC_Create_m3696050415 ();
extern "C" void HMACMD5__ctor_m894105130 ();
extern "C" void HMACMD5__ctor_m4027363171 ();
extern "C" void HMACRIPEMD160__ctor_m2345098499 ();
extern "C" void HMACRIPEMD160__ctor_m24840140 ();
extern "C" void HMACSHA1__ctor_m1034545673 ();
extern "C" void HMACSHA1__ctor_m4263724133 ();
extern "C" void HMACSHA256__ctor_m3304286696 ();
extern "C" void HMACSHA256__ctor_m32453075 ();
extern "C" void HMACSHA384__ctor_m4041969840 ();
extern "C" void HMACSHA384__ctor_m400753621 ();
extern "C" void HMACSHA384__cctor_m1943010839 ();
extern "C" void HMACSHA384_set_ProduceLegacyHmacValues_m1144342068 ();
extern "C" void HMACSHA512__ctor_m805158160 ();
extern "C" void HMACSHA512__ctor_m343337217 ();
extern "C" void HMACSHA512__cctor_m652861467 ();
extern "C" void HMACSHA512_set_ProduceLegacyHmacValues_m2734681597 ();
extern "C" void KeyedHashAlgorithm__ctor_m2738969915 ();
extern "C" void KeyedHashAlgorithm_Finalize_m1060205184 ();
extern "C" void KeyedHashAlgorithm_get_Key_m3269097206 ();
extern "C" void KeyedHashAlgorithm_set_Key_m1091398052 ();
extern "C" void KeyedHashAlgorithm_Dispose_m3711504753 ();
extern "C" void KeyedHashAlgorithm_ZeroizeKey_m1358463092 ();
extern "C" void KeySizes__ctor_m2363976682 ();
extern "C" void KeySizes_get_MaxSize_m2534537201 ();
extern "C" void KeySizes_get_MinSize_m2751942049 ();
extern "C" void KeySizes_get_SkipSize_m3329564690 ();
extern "C" void KeySizes_IsLegal_m4141793984 ();
extern "C" void KeySizes_IsLegalKeySize_m169156417 ();
extern "C" void MACTripleDES__ctor_m3860786401 ();
extern "C" void MACTripleDES_Setup_m1983097667 ();
extern "C" void MACTripleDES_Finalize_m2823221823 ();
extern "C" void MACTripleDES_Dispose_m3932196328 ();
extern "C" void MACTripleDES_Initialize_m3226985574 ();
extern "C" void MACTripleDES_HashCore_m2634199206 ();
extern "C" void MACTripleDES_HashFinal_m538999467 ();
extern "C" void MD5__ctor_m1323562619 ();
extern "C" void MD5_Create_m2385042514 ();
extern "C" void MD5_Create_m2869875857 ();
extern "C" void MD5CryptoServiceProvider__ctor_m214915886 ();
extern "C" void MD5CryptoServiceProvider__cctor_m1939351890 ();
extern "C" void MD5CryptoServiceProvider_Finalize_m970178194 ();
extern "C" void MD5CryptoServiceProvider_Dispose_m852817958 ();
extern "C" void MD5CryptoServiceProvider_HashCore_m1311421323 ();
extern "C" void MD5CryptoServiceProvider_HashFinal_m2571030067 ();
extern "C" void MD5CryptoServiceProvider_Initialize_m2823586746 ();
extern "C" void MD5CryptoServiceProvider_ProcessBlock_m895304490 ();
extern "C" void MD5CryptoServiceProvider_ProcessFinalBlock_m2821355884 ();
extern "C" void MD5CryptoServiceProvider_AddLength_m512335437 ();
extern "C" void RandomNumberGenerator__ctor_m3939249654 ();
extern "C" void RandomNumberGenerator_Create_m1431169500 ();
extern "C" void RandomNumberGenerator_Create_m3503708628 ();
extern "C" void RC2__ctor_m4204072771 ();
extern "C" void RC2_Create_m4004729600 ();
extern "C" void RC2_Create_m3881730986 ();
extern "C" void RC2_get_EffectiveKeySize_m904204713 ();
extern "C" void RC2_get_KeySize_m1880714395 ();
extern "C" void RC2_set_KeySize_m1090717279 ();
extern "C" void RC2CryptoServiceProvider__ctor_m653119750 ();
extern "C" void RC2CryptoServiceProvider_get_EffectiveKeySize_m650737987 ();
extern "C" void RC2CryptoServiceProvider_CreateDecryptor_m373084290 ();
extern "C" void RC2CryptoServiceProvider_CreateEncryptor_m3935846208 ();
extern "C" void RC2CryptoServiceProvider_GenerateIV_m4256672338 ();
extern "C" void RC2CryptoServiceProvider_GenerateKey_m1091248491 ();
extern "C" void RC2Transform__ctor_m2270872876 ();
extern "C" void RC2Transform__cctor_m3954912500 ();
extern "C" void RC2Transform_ECB_m777958400 ();
extern "C" void Rijndael__ctor_m569547863 ();
extern "C" void Rijndael_Create_m2043577928 ();
extern "C" void Rijndael_Create_m256024357 ();
extern "C" void RijndaelManaged__ctor_m1859549111 ();
extern "C" void RijndaelManaged_GenerateIV_m1123037081 ();
extern "C" void RijndaelManaged_GenerateKey_m423570930 ();
extern "C" void RijndaelManaged_CreateDecryptor_m4215947421 ();
extern "C" void RijndaelManaged_CreateEncryptor_m842685846 ();
extern "C" void RijndaelManagedTransform__ctor_m1161577055 ();
extern "C" void RijndaelManagedTransform_System_IDisposable_Dispose_m3156143058 ();
extern "C" void RijndaelManagedTransform_get_CanReuseTransform_m2765034471 ();
extern "C" void RijndaelManagedTransform_TransformBlock_m3409590100 ();
extern "C" void RijndaelManagedTransform_TransformFinalBlock_m2589306319 ();
extern "C" void RijndaelTransform__ctor_m2159698755 ();
extern "C" void RijndaelTransform__cctor_m4224639698 ();
extern "C" void RijndaelTransform_Clear_m923483040 ();
extern "C" void RijndaelTransform_ECB_m1043320970 ();
extern "C" void RijndaelTransform_SubByte_m379037516 ();
extern "C" void RijndaelTransform_Encrypt128_m193641953 ();
extern "C" void RijndaelTransform_Encrypt192_m2076300861 ();
extern "C" void RijndaelTransform_Encrypt256_m2198473672 ();
extern "C" void RijndaelTransform_Decrypt128_m2752989474 ();
extern "C" void RijndaelTransform_Decrypt192_m3716986189 ();
extern "C" void RijndaelTransform_Decrypt256_m3786109318 ();
extern "C" void RIPEMD160__ctor_m458952317 ();
extern "C" void RIPEMD160Managed__ctor_m4211343806 ();
extern "C" void RIPEMD160Managed_Initialize_m3469028291 ();
extern "C" void RIPEMD160Managed_HashCore_m238041734 ();
extern "C" void RIPEMD160Managed_HashFinal_m1031199659 ();
extern "C" void RIPEMD160Managed_Finalize_m1155918876 ();
extern "C" void RIPEMD160Managed_ProcessBlock_m1882667436 ();
extern "C" void RIPEMD160Managed_Compress_m2045615632 ();
extern "C" void RIPEMD160Managed_CompressFinal_m4170573773 ();
extern "C" void RIPEMD160Managed_ROL_m1090185248 ();
extern "C" void RIPEMD160Managed_F_m1464279206 ();
extern "C" void RIPEMD160Managed_G_m1667672529 ();
extern "C" void RIPEMD160Managed_H_m3299186924 ();
extern "C" void RIPEMD160Managed_I_m1554323262 ();
extern "C" void RIPEMD160Managed_J_m4119682292 ();
extern "C" void RIPEMD160Managed_FF_m994828637 ();
extern "C" void RIPEMD160Managed_GG_m1861900783 ();
extern "C" void RIPEMD160Managed_HH_m346411911 ();
extern "C" void RIPEMD160Managed_II_m2684363707 ();
extern "C" void RIPEMD160Managed_JJ_m2386545611 ();
extern "C" void RIPEMD160Managed_FFF_m2028229179 ();
extern "C" void RIPEMD160Managed_GGG_m137516215 ();
extern "C" void RIPEMD160Managed_HHH_m1723579147 ();
extern "C" void RIPEMD160Managed_III_m2117715712 ();
extern "C" void RIPEMD160Managed_JJJ_m2587022283 ();
extern "C" void RNGCryptoServiceProvider__ctor_m2029700126 ();
extern "C" void RNGCryptoServiceProvider__cctor_m1919301485 ();
extern "C" void RNGCryptoServiceProvider_Check_m552544446 ();
extern "C" void RNGCryptoServiceProvider_RngOpen_m2616908683 ();
extern "C" void RNGCryptoServiceProvider_RngInitialize_m2618561254 ();
extern "C" void RNGCryptoServiceProvider_RngGetBytes_m918087422 ();
extern "C" void RNGCryptoServiceProvider_RngClose_m533018497 ();
extern "C" void RNGCryptoServiceProvider_GetBytes_m2938911782 ();
extern "C" void RNGCryptoServiceProvider_GetNonZeroBytes_m2211806560 ();
extern "C" void RNGCryptoServiceProvider_Finalize_m3612537545 ();
extern "C" void RSA__ctor_m2516576077 ();
extern "C" void RSA_Create_m2098378378 ();
extern "C" void RSA_Create_m2167317622 ();
extern "C" void RSA_ZeroizePrivateKey_m2699768189 ();
extern "C" void RSA_FromXmlString_m3910835382 ();
extern "C" void RSA_ToXmlString_m1368893058 ();
extern "C" void RSACryptoServiceProvider__ctor_m494920222 ();
extern "C" void RSACryptoServiceProvider__ctor_m1834871502 ();
extern "C" void RSACryptoServiceProvider__ctor_m2651361429 ();
extern "C" void RSACryptoServiceProvider__cctor_m1656044272 ();
extern "C" void RSACryptoServiceProvider_Common_m971604078 ();
extern "C" void RSACryptoServiceProvider_Finalize_m581596575 ();
extern "C" void RSACryptoServiceProvider_get_KeySize_m14171628 ();
extern "C" void RSACryptoServiceProvider_get_PublicOnly_m1322291509 ();
extern "C" void RSACryptoServiceProvider_DecryptValue_m494881412 ();
extern "C" void RSACryptoServiceProvider_EncryptValue_m3362633146 ();
extern "C" void RSACryptoServiceProvider_ExportParameters_m2246352314 ();
extern "C" void RSACryptoServiceProvider_ImportParameters_m2588335021 ();
extern "C" void RSACryptoServiceProvider_Dispose_m2107529962 ();
extern "C" void RSACryptoServiceProvider_OnKeyGenerated_m1365285689 ();
extern "C" void RSAPKCS1KeyExchangeFormatter__ctor_m1245335096 ();
extern "C" void RSAPKCS1KeyExchangeFormatter_CreateKeyExchange_m1314284802 ();
extern "C" void RSAPKCS1KeyExchangeFormatter_SetRSAKey_m1965546122 ();
extern "C" void RSAPKCS1SHA1SignatureDescription__ctor_m2106874314 ();
extern "C" void RSAPKCS1SignatureDeformatter__ctor_m1986341172 ();
extern "C" void RSAPKCS1SignatureDeformatter__ctor_m2532782780 ();
extern "C" void RSAPKCS1SignatureDeformatter_SetHashAlgorithm_m1997399751 ();
extern "C" void RSAPKCS1SignatureDeformatter_SetKey_m539761269 ();
extern "C" void RSAPKCS1SignatureDeformatter_VerifySignature_m3268121280 ();
extern "C" void RSAPKCS1SignatureFormatter__ctor_m1986635058 ();
extern "C" void RSAPKCS1SignatureFormatter_CreateSignature_m2607393667 ();
extern "C" void RSAPKCS1SignatureFormatter_SetHashAlgorithm_m2984544991 ();
extern "C" void RSAPKCS1SignatureFormatter_SetKey_m2601050193 ();
extern "C" void SHA1__ctor_m1969536635 ();
extern "C" void SHA1_Create_m3946979285 ();
extern "C" void SHA1_Create_m974371071 ();
extern "C" void SHA1CryptoServiceProvider__ctor_m1967520929 ();
extern "C" void SHA1CryptoServiceProvider_Finalize_m3718267469 ();
extern "C" void SHA1CryptoServiceProvider_Dispose_m105661239 ();
extern "C" void SHA1CryptoServiceProvider_HashCore_m2234117083 ();
extern "C" void SHA1CryptoServiceProvider_HashFinal_m3803579073 ();
extern "C" void SHA1CryptoServiceProvider_Initialize_m2261370112 ();
extern "C" void SHA1Internal__ctor_m2994753244 ();
extern "C" void SHA1Internal_HashCore_m1717092929 ();
extern "C" void SHA1Internal_HashFinal_m1355532083 ();
extern "C" void SHA1Internal_Initialize_m546222499 ();
extern "C" void SHA1Internal_ProcessBlock_m4072397381 ();
extern "C" void SHA1Internal_InitialiseBuff_m2649170437 ();
extern "C" void SHA1Internal_FillBuff_m2630535725 ();
extern "C" void SHA1Internal_ProcessFinalBlock_m2707203005 ();
extern "C" void SHA1Internal_AddLength_m2262981079 ();
extern "C" void SHA1Managed__ctor_m1921984796 ();
extern "C" void SHA1Managed_HashCore_m2837280064 ();
extern "C" void SHA1Managed_HashFinal_m2353453359 ();
extern "C" void SHA1Managed_Initialize_m1342241130 ();
extern "C" void SHA256__ctor_m4240254819 ();
extern "C" void SHA256_Create_m462422102 ();
extern "C" void SHA256_Create_m2238749554 ();
extern "C" void SHA256Managed__ctor_m4106396050 ();
extern "C" void SHA256Managed_HashCore_m3408643825 ();
extern "C" void SHA256Managed_HashFinal_m3933879613 ();
extern "C" void SHA256Managed_Initialize_m204270072 ();
extern "C" void SHA256Managed_ProcessBlock_m753555195 ();
extern "C" void SHA256Managed_ProcessFinalBlock_m1121500207 ();
extern "C" void SHA256Managed_AddLength_m4284553060 ();
extern "C" void SHA384__ctor_m334659379 ();
extern "C" void SHA384_Create_m526495048 ();
extern "C" void SHA384_Create_m4239756223 ();
extern "C" void SHA384Managed__ctor_m3170837026 ();
extern "C" void SHA384Managed_Initialize_m1476192725 ();
extern "C" void SHA384Managed_Initialize_m1847819359 ();
extern "C" void SHA384Managed_HashCore_m4173033847 ();
extern "C" void SHA384Managed_HashFinal_m1753937062 ();
extern "C" void SHA384Managed_update_m1141165968 ();
extern "C" void SHA384Managed_processWord_m2618477847 ();
extern "C" void SHA384Managed_unpackWord_m1957689207 ();
extern "C" void SHA384Managed_adjustByteCounts_m566288436 ();
extern "C" void SHA384Managed_processLength_m658249786 ();
extern "C" void SHA384Managed_processBlock_m684140079 ();
extern "C" void SHA512__ctor_m4036499772 ();
extern "C" void SHA512_Create_m456504481 ();
extern "C" void SHA512_Create_m1101996406 ();
extern "C" void SHA512Managed__ctor_m3022883860 ();
extern "C" void SHA512Managed_Initialize_m3277525724 ();
extern "C" void SHA512Managed_Initialize_m766809252 ();
extern "C" void SHA512Managed_HashCore_m2989249322 ();
extern "C" void SHA512Managed_HashFinal_m2508134175 ();
extern "C" void SHA512Managed_update_m1429757441 ();
extern "C" void SHA512Managed_processWord_m4094117712 ();
extern "C" void SHA512Managed_unpackWord_m3213888570 ();
extern "C" void SHA512Managed_adjustByteCounts_m1398880188 ();
extern "C" void SHA512Managed_processLength_m1576722253 ();
extern "C" void SHA512Managed_processBlock_m2460866755 ();
extern "C" void SHA512Managed_rotateRight_m805706266 ();
extern "C" void SHA512Managed_Ch_m677772777 ();
extern "C" void SHA512Managed_Maj_m423045056 ();
extern "C" void SHA512Managed_Sum0_m502557237 ();
extern "C" void SHA512Managed_Sum1_m3199977649 ();
extern "C" void SHA512Managed_Sigma0_m179912122 ();
extern "C" void SHA512Managed_Sigma1_m842511038 ();
extern "C" void SHAConstants__cctor_m4272201901 ();
extern "C" void SignatureDescription__ctor_m756568113 ();
extern "C" void SignatureDescription_set_DeformatterAlgorithm_m2445338640 ();
extern "C" void SignatureDescription_set_DigestAlgorithm_m4083166638 ();
extern "C" void SignatureDescription_set_FormatterAlgorithm_m2903154629 ();
extern "C" void SignatureDescription_set_KeyAlgorithm_m1930616075 ();
extern "C" void SymmetricAlgorithm__ctor_m3530978002 ();
extern "C" void SymmetricAlgorithm_System_IDisposable_Dispose_m2429136725 ();
extern "C" void SymmetricAlgorithm_Finalize_m475352580 ();
extern "C" void SymmetricAlgorithm_Clear_m4086940160 ();
extern "C" void SymmetricAlgorithm_Dispose_m3284301350 ();
extern "C" void SymmetricAlgorithm_get_BlockSize_m665076769 ();
extern "C" void SymmetricAlgorithm_set_BlockSize_m2683310524 ();
extern "C" void SymmetricAlgorithm_get_FeedbackSize_m480120971 ();
extern "C" void SymmetricAlgorithm_get_IV_m1566235590 ();
extern "C" void SymmetricAlgorithm_set_IV_m283538311 ();
extern "C" void SymmetricAlgorithm_get_Key_m3263732574 ();
extern "C" void SymmetricAlgorithm_set_Key_m2615539943 ();
extern "C" void SymmetricAlgorithm_get_KeySize_m3842476726 ();
extern "C" void SymmetricAlgorithm_set_KeySize_m3692049243 ();
extern "C" void SymmetricAlgorithm_get_LegalKeySizes_m2105996708 ();
extern "C" void SymmetricAlgorithm_get_Mode_m580803141 ();
extern "C" void SymmetricAlgorithm_set_Mode_m1104711670 ();
extern "C" void SymmetricAlgorithm_get_Padding_m540812409 ();
extern "C" void SymmetricAlgorithm_set_Padding_m3038551471 ();
extern "C" void SymmetricAlgorithm_CreateDecryptor_m224668375 ();
extern "C" void SymmetricAlgorithm_CreateEncryptor_m970802849 ();
extern "C" void SymmetricAlgorithm_Create_m2890948765 ();
extern "C" void ToBase64Transform_System_IDisposable_Dispose_m471317583 ();
extern "C" void ToBase64Transform_Finalize_m140506812 ();
extern "C" void ToBase64Transform_get_CanReuseTransform_m3967355810 ();
extern "C" void ToBase64Transform_get_InputBlockSize_m3765814599 ();
extern "C" void ToBase64Transform_get_OutputBlockSize_m3044525699 ();
extern "C" void ToBase64Transform_Dispose_m2612407126 ();
extern "C" void ToBase64Transform_TransformBlock_m1712575818 ();
extern "C" void ToBase64Transform_InternalTransformBlock_m1909386603 ();
extern "C" void ToBase64Transform_TransformFinalBlock_m3042863047 ();
extern "C" void ToBase64Transform_InternalTransformFinalBlock_m1455808496 ();
extern "C" void TripleDES__ctor_m1962223256 ();
extern "C" void TripleDES_get_Key_m3397880201 ();
extern "C" void TripleDES_set_Key_m3691393715 ();
extern "C" void TripleDES_IsWeakKey_m2759836646 ();
extern "C" void TripleDES_Create_m1188329831 ();
extern "C" void TripleDES_Create_m274258073 ();
extern "C" void TripleDESCryptoServiceProvider__ctor_m4290068524 ();
extern "C" void TripleDESCryptoServiceProvider_GenerateIV_m2268505232 ();
extern "C" void TripleDESCryptoServiceProvider_GenerateKey_m3906262374 ();
extern "C" void TripleDESCryptoServiceProvider_CreateDecryptor_m2003987385 ();
extern "C" void TripleDESCryptoServiceProvider_CreateEncryptor_m797239158 ();
extern "C" void TripleDESTransform__ctor_m36363670 ();
extern "C" void TripleDESTransform_ECB_m3111392017 ();
extern "C" void TripleDESTransform_GetStrongKey_m1266123329 ();
extern "C" void X509Certificate__ctor_m3407924276 ();
extern "C" void X509Certificate__ctor_m1548315145 ();
extern "C" void X509Certificate__ctor_m3676038623 ();
extern "C" void X509Certificate__ctor_m2718650002 ();
extern "C" void X509Certificate_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m3612759154 ();
extern "C" void X509Certificate_System_Runtime_Serialization_ISerializable_GetObjectData_m2599848675 ();
extern "C" void X509Certificate_tostr_m2221058328 ();
extern "C" void X509Certificate_Equals_m56391754 ();
extern "C" void X509Certificate_GetCertHash_m836096880 ();
extern "C" void X509Certificate_GetCertHashString_m938235395 ();
extern "C" void X509Certificate_GetEffectiveDateString_m597661879 ();
extern "C" void X509Certificate_GetExpirationDateString_m1031306912 ();
extern "C" void X509Certificate_GetHashCode_m3873304085 ();
extern "C" void X509Certificate_GetIssuerName_m985760924 ();
extern "C" void X509Certificate_GetName_m839418740 ();
extern "C" void X509Certificate_GetPublicKey_m13902926 ();
extern "C" void X509Certificate_GetRawCertData_m139142862 ();
extern "C" void X509Certificate_ToString_m3901050003 ();
extern "C" void X509Certificate_ToString_m2906291789 ();
extern "C" void X509Certificate_get_Issuer_m1004229346 ();
extern "C" void X509Certificate_get_Subject_m2350827574 ();
extern "C" void X509Certificate_Equals_m3424353702 ();
extern "C" void X509Certificate_Import_m2684987799 ();
extern "C" void X509Certificate_Reset_m4105901662 ();
extern "C" void SecurityPermission__ctor_m4197502246 ();
extern "C" void SecurityPermission_set_Flags_m339644 ();
extern "C" void SecurityPermission_IsUnrestricted_m3354178782 ();
extern "C" void SecurityPermission_IsSubsetOf_m566105140 ();
extern "C" void SecurityPermission_ToXml_m1610766876 ();
extern "C" void SecurityPermission_IsEmpty_m698687277 ();
extern "C" void SecurityPermission_Cast_m2977698443 ();
extern "C" void SecurityPermissionAttribute_set_SkipVerification_m3308373995 ();
extern "C" void StrongNamePublicKeyBlob_Equals_m3462806622 ();
extern "C" void StrongNamePublicKeyBlob_GetHashCode_m1621593698 ();
extern "C" void StrongNamePublicKeyBlob_ToString_m3532563419 ();
extern "C" void PermissionSet__ctor_m771135781 ();
extern "C" void PermissionSet__ctor_m230458726 ();
extern "C" void PermissionSet_set_DeclarativeSecurity_m644410636 ();
extern "C" void PermissionSet_CreateFromBinaryFormat_m3580799913 ();
extern "C" void ApplicationTrust__ctor_m3796110394 ();
extern "C" void Evidence__ctor_m226600667 ();
extern "C" void Evidence_get_Count_m3051625439 ();
extern "C" void Evidence_get_SyncRoot_m2744837828 ();
extern "C" void Evidence_get_HostEvidenceList_m3783616253 ();
extern "C" void Evidence_get_AssemblyEvidenceList_m2815161303 ();
extern "C" void Evidence_CopyTo_m1202507747 ();
extern "C" void Evidence_Equals_m3868193673 ();
extern "C" void Evidence_GetEnumerator_m2562761046 ();
extern "C" void Evidence_GetHashCode_m3660855014 ();
extern "C" void EvidenceEnumerator__ctor_m558010460 ();
extern "C" void EvidenceEnumerator_MoveNext_m113582795 ();
extern "C" void EvidenceEnumerator_Reset_m2273931871 ();
extern "C" void EvidenceEnumerator_get_Current_m1416526449 ();
extern "C" void Hash__ctor_m488556517 ();
extern "C" void Hash__ctor_m699072506 ();
extern "C" void Hash_GetObjectData_m3237225528 ();
extern "C" void Hash_ToString_m2275256858 ();
extern "C" void Hash_GetData_m1423422691 ();
extern "C" void StrongName_get_Name_m984799822 ();
extern "C" void StrongName_get_PublicKey_m276363371 ();
extern "C" void StrongName_get_Version_m497732567 ();
extern "C" void StrongName_Equals_m1955316562 ();
extern "C" void StrongName_GetHashCode_m4077531007 ();
extern "C" void StrongName_ToString_m3570293456 ();
extern "C" void WindowsIdentity__ctor_m1811963814 ();
extern "C" void WindowsIdentity__cctor_m4102338034 ();
extern "C" void WindowsIdentity_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1019467441 ();
extern "C" void WindowsIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m1044464041 ();
extern "C" void WindowsIdentity_Dispose_m2729980567 ();
extern "C" void WindowsIdentity_GetCurrentToken_m2751916831 ();
extern "C" void WindowsIdentity_GetTokenName_m2704573011 ();
extern "C" void SecurityContext__ctor_m1611332893 ();
extern "C" void SecurityContext__ctor_m2441641144 ();
extern "C" void SecurityContext_Capture_m2143019511 ();
extern "C" void SecurityContext_get_FlowSuppressed_m4084430719 ();
extern "C" void SecurityContext_get_CompressedStack_m925330154 ();
extern "C" void SecurityCriticalAttribute__ctor_m4283676607 ();
extern "C" void SecurityElement__ctor_m359142113 ();
extern "C" void SecurityElement__ctor_m4136117828 ();
extern "C" void SecurityElement__cctor_m1925771841 ();
extern "C" void SecurityElement_get_Children_m4090366312 ();
extern "C" void SecurityElement_get_Tag_m1217815539 ();
extern "C" void SecurityElement_set_Text_m1068735059 ();
extern "C" void SecurityElement_AddAttribute_m2785847673 ();
extern "C" void SecurityElement_AddChild_m3042363596 ();
extern "C" void SecurityElement_Escape_m314020543 ();
extern "C" void SecurityElement_Unescape_m3061570899 ();
extern "C" void SecurityElement_IsValidAttributeName_m779754135 ();
extern "C" void SecurityElement_IsValidAttributeValue_m1368665728 ();
extern "C" void SecurityElement_IsValidTag_m2084804419 ();
extern "C" void SecurityElement_IsValidText_m3922265080 ();
extern "C" void SecurityElement_SearchForChildByTag_m690528742 ();
extern "C" void SecurityElement_ToString_m1864728802 ();
extern "C" void SecurityElement_ToXml_m3571179917 ();
extern "C" void SecurityElement_GetAttribute_m4050327145 ();
extern "C" void SecurityAttribute__ctor_m453957305 ();
extern "C" void SecurityAttribute_get_Name_m3885903818 ();
extern "C" void SecurityAttribute_get_Value_m1764543067 ();
extern "C" void SecurityException__ctor_m1530694241 ();
extern "C" void SecurityException__ctor_m78750685 ();
extern "C" void SecurityException__ctor_m4201478182 ();
extern "C" void SecurityException_get_Demanded_m3265310211 ();
extern "C" void SecurityException_get_FirstPermissionThatFailed_m1290931100 ();
extern "C" void SecurityException_get_PermissionState_m3093263458 ();
extern "C" void SecurityException_get_PermissionType_m2440776481 ();
extern "C" void SecurityException_get_GrantedSet_m3491710904 ();
extern "C" void SecurityException_get_RefusedSet_m556824700 ();
extern "C" void SecurityException_GetObjectData_m3040244220 ();
extern "C" void SecurityException_ToString_m241756719 ();
extern "C" void SecurityFrame__ctor_m1941352356_AdjustorThunk ();
extern "C" void SecurityFrame__GetSecurityStack_m1571368125 ();
extern "C" void SecurityFrame_InitFromRuntimeFrame_m819564435_AdjustorThunk ();
extern "C" void SecurityFrame_get_Assembly_m630022476_AdjustorThunk ();
extern "C" void SecurityFrame_get_Domain_m2621428839_AdjustorThunk ();
extern "C" void SecurityFrame_ToString_m961788698_AdjustorThunk ();
extern "C" void SecurityFrame_GetStack_m176825473 ();
extern "C" void SecurityManager__cctor_m3229916011 ();
extern "C" void SecurityManager_get_SecurityEnabled_m4152097806 ();
extern "C" void SecurityManager_Decode_m2324823191 ();
extern "C" void SecurityManager_Decode_m1619407822 ();
extern "C" void SecuritySafeCriticalAttribute__ctor_m1104744884 ();
extern "C" void SuppressUnmanagedCodeSecurityAttribute__ctor_m3765472890 ();
extern "C" void UnverifiableCodeAttribute__ctor_m3350723594 ();
extern "C" void SerializableAttribute__ctor_m1148700181 ();
extern "C" void Single_System_IConvertible_ToBoolean_m720126349_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToByte_m2803268345_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToChar_m1561638046_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToDateTime_m3628856099_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToDecimal_m2695673545_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToDouble_m128862438_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToInt16_m818780161_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToInt32_m1944505068_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToInt64_m1593285566_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToSByte_m627657193_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToSingle_m4238518480_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToType_m3289199070_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToUInt16_m3232958982_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToUInt32_m2346289835_AdjustorThunk ();
extern "C" void Single_System_IConvertible_ToUInt64_m2640176904_AdjustorThunk ();
extern "C" void Single_CompareTo_m765087958_AdjustorThunk ();
extern "C" void Single_Equals_m1857255371_AdjustorThunk ();
extern "C" void Single_CompareTo_m910502481_AdjustorThunk ();
extern "C" void Single_Equals_m2717732029_AdjustorThunk ();
extern "C" void Single_GetHashCode_m2476090687_AdjustorThunk ();
extern "C" void Single_IsInfinity_m3098138255 ();
extern "C" void Single_IsNaN_m3455339168 ();
extern "C" void Single_IsNegativeInfinity_m1281133443 ();
extern "C" void Single_IsPositiveInfinity_m570566160 ();
extern "C" void Single_Parse_m3254821835 ();
extern "C" void Single_ToString_m1479228193_AdjustorThunk ();
extern "C" void Single_ToString_m375149042_AdjustorThunk ();
extern "C" void Single_ToString_m519745137_AdjustorThunk ();
extern "C" void StackOverflowException__ctor_m2946028495 ();
extern "C" void StackOverflowException__ctor_m2490333010 ();
extern "C" void StackOverflowException__ctor_m1775831137 ();
extern "C" void String__ctor_m3613415962 ();
extern "C" void String__ctor_m1853482631 ();
extern "C" void String__ctor_m885689136 ();
extern "C" void String__ctor_m1709700635 ();
extern "C" void String__cctor_m1603112650 ();
extern "C" void String_System_IConvertible_ToBoolean_m2672471675 ();
extern "C" void String_System_IConvertible_ToByte_m2760073804 ();
extern "C" void String_System_IConvertible_ToChar_m3263129551 ();
extern "C" void String_System_IConvertible_ToDateTime_m2805257558 ();
extern "C" void String_System_IConvertible_ToDecimal_m2944717908 ();
extern "C" void String_System_IConvertible_ToDouble_m2349890820 ();
extern "C" void String_System_IConvertible_ToInt16_m1847522624 ();
extern "C" void String_System_IConvertible_ToInt32_m3872748217 ();
extern "C" void String_System_IConvertible_ToInt64_m533042989 ();
extern "C" void String_System_IConvertible_ToSByte_m2535500817 ();
extern "C" void String_System_IConvertible_ToSingle_m382301513 ();
extern "C" void String_System_IConvertible_ToType_m862140462 ();
extern "C" void String_System_IConvertible_ToUInt16_m1585851494 ();
extern "C" void String_System_IConvertible_ToUInt32_m2467996462 ();
extern "C" void String_System_IConvertible_ToUInt64_m2032133172 ();
extern "C" void String_System_Collections_Generic_IEnumerableU3CcharU3E_GetEnumerator_m811657719 ();
extern "C" void String_System_Collections_IEnumerable_GetEnumerator_m3147391984 ();
extern "C" void String_Equals_m237333880 ();
extern "C" void String_Equals_m3008033655 ();
extern "C" void String_Equals_m1775812447 ();
extern "C" void String_get_Chars_m1464339204 ();
extern "C" void String_Clone_m2585077494 ();
extern "C" void String_CopyTo_m892774036 ();
extern "C" void String_ToCharArray_m3705451209 ();
extern "C" void String_ToCharArray_m3268618965 ();
extern "C" void String_Split_m1027048911 ();
extern "C" void String_Split_m1944641878 ();
extern "C" void String_Split_m752880514 ();
extern "C" void String_Split_m2170789228 ();
extern "C" void String_Split_m882935073 ();
extern "C" void String_Substring_m1464020713 ();
extern "C" void String_Substring_m226770159 ();
extern "C" void String_SubstringUnchecked_m4096211738 ();
extern "C" void String_Trim_m1844077571 ();
extern "C" void String_Trim_m1892663701 ();
extern "C" void String_TrimStart_m923266555 ();
extern "C" void String_TrimEnd_m1178919651 ();
extern "C" void String_FindNotWhiteSpace_m1711185691 ();
extern "C" void String_FindNotInTable_m2137115857 ();
extern "C" void String_Compare_m2471229855 ();
extern "C" void String_Compare_m4147948046 ();
extern "C" void String_Compare_m261071192 ();
extern "C" void String_Compare_m2230433984 ();
extern "C" void String_CompareTo_m3731283673 ();
extern "C" void String_CompareTo_m2261209686 ();
extern "C" void String_CompareOrdinal_m1991598530 ();
extern "C" void String_CompareOrdinalUnchecked_m461278756 ();
extern "C" void String_CompareOrdinalCaseInsensitiveUnchecked_m3635395240 ();
extern "C" void String_EndsWith_m127493516 ();
extern "C" void String_IndexOfAny_m1706062837 ();
extern "C" void String_IndexOfAny_m134417335 ();
extern "C" void String_IndexOfAny_m2260375589 ();
extern "C" void String_IndexOfAnyUnchecked_m4046918375 ();
extern "C" void String_IndexOf_m479525909 ();
extern "C" void String_IndexOf_m944552323 ();
extern "C" void String_IndexOfOrdinal_m2643824054 ();
extern "C" void String_IndexOfOrdinalUnchecked_m639401954 ();
extern "C" void String_IndexOfOrdinalIgnoreCaseUnchecked_m4077622449 ();
extern "C" void String_IndexOf_m3894111918 ();
extern "C" void String_IndexOf_m782950928 ();
extern "C" void String_IndexOf_m3950528921 ();
extern "C" void String_IndexOfUnchecked_m212985164 ();
extern "C" void String_IndexOf_m2070038370 ();
extern "C" void String_IndexOf_m265181594 ();
extern "C" void String_IndexOf_m2102297132 ();
extern "C" void String_LastIndexOfAny_m1287077974 ();
extern "C" void String_LastIndexOfAnyUnchecked_m2313880315 ();
extern "C" void String_LastIndexOf_m1732390103 ();
extern "C" void String_LastIndexOf_m3891998254 ();
extern "C" void String_LastIndexOf_m3705240145 ();
extern "C" void String_LastIndexOfUnchecked_m1515191963 ();
extern "C" void String_LastIndexOf_m2119563327 ();
extern "C" void String_LastIndexOf_m794187726 ();
extern "C" void String_IsNullOrEmpty_m1029040816 ();
extern "C" void String_PadRight_m650210994 ();
extern "C" void String_StartsWith_m2597381112 ();
extern "C" void String_Replace_m3591414543 ();
extern "C" void String_Replace_m3746132805 ();
extern "C" void String_ReplaceUnchecked_m3373930118 ();
extern "C" void String_ReplaceFallback_m3159344605 ();
extern "C" void String_Remove_m633097816 ();
extern "C" void String_ToLower_m2279212582 ();
extern "C" void String_ToLower_m329058893 ();
extern "C" void String_ToLowerInvariant_m3394568761 ();
extern "C" void String_ToString_m1847718173 ();
extern "C" void String_ToString_m1753332709 ();
extern "C" void String_Format_m3184672671 ();
extern "C" void String_Format_m88592014 ();
extern "C" void String_Format_m3597410483 ();
extern "C" void String_Format_m527561873 ();
extern "C" void String_Format_m949849763 ();
extern "C" void String_FormatHelper_m266143647 ();
extern "C" void String_Concat_m2789586187 ();
extern "C" void String_Concat_m1921247215 ();
extern "C" void String_Concat_m3401430135 ();
extern "C" void String_Concat_m800460250 ();
extern "C" void String_Concat_m2337014626 ();
extern "C" void String_Concat_m406606968 ();
extern "C" void String_Concat_m2284411301 ();
extern "C" void String_ConcatInternal_m776915844 ();
extern "C" void String_Insert_m2831565133 ();
extern "C" void String_Join_m3868188132 ();
extern "C" void String_Join_m3179186149 ();
extern "C" void String_JoinUnchecked_m977872119 ();
extern "C" void String_get_Length_m198470169 ();
extern "C" void String_ParseFormatSpecifier_m2647998464 ();
extern "C" void String_ParseDecimal_m4080306657 ();
extern "C" void String_InternalSetChar_m1298932216 ();
extern "C" void String_InternalSetLength_m31814220 ();
extern "C" void String_GetHashCode_m2446182979 ();
extern "C" void String_GetCaseInsensitiveHashCode_m2544214933 ();
extern "C" void String_CreateString_m2185920425 ();
extern "C" void String_CreateString_m1582414959 ();
extern "C" void String_CreateString_m2675909340 ();
extern "C" void String_CreateString_m1994743835 ();
extern "C" void String_CreateString_m2362463515 ();
extern "C" void String_CreateString_m1821258248 ();
extern "C" void String_CreateString_m3540783044 ();
extern "C" void String_CreateString_m3131114500 ();
extern "C" void String_memcpy4_m4200798455 ();
extern "C" void String_memcpy2_m1208599571 ();
extern "C" void String_memcpy1_m1226925708 ();
extern "C" void String_memcpy_m1488033619 ();
extern "C" void String_CharCopy_m2708895260 ();
extern "C" void String_CharCopyReverse_m3113915607 ();
extern "C" void String_CharCopy_m322526068 ();
extern "C" void String_CharCopy_m2594291286 ();
extern "C" void String_CharCopyReverse_m987294522 ();
extern "C" void String_InternalSplit_m1810656421 ();
extern "C" void String_InternalAllocateStr_m763533588 ();
extern "C" void String_op_Equality_m2935810047 ();
extern "C" void String_op_Inequality_m124341459 ();
extern "C" void StringComparer__ctor_m3312622601 ();
extern "C" void StringComparer__cctor_m799052589 ();
extern "C" void StringComparer_get_InvariantCultureIgnoreCase_m2486156775 ();
extern "C" void StringComparer_Compare_m561823171 ();
extern "C" void StringComparer_Equals_m367569743 ();
extern "C" void StringComparer_GetHashCode_m3001431150 ();
extern "C" void SystemException__ctor_m3110433673 ();
extern "C" void SystemException__ctor_m1383525515 ();
extern "C" void SystemException__ctor_m2606713748 ();
extern "C" void SystemException__ctor_m956841773 ();
extern "C" void ASCIIEncoding__ctor_m2577114027 ();
extern "C" void ASCIIEncoding_GetByteCount_m4032353408 ();
extern "C" void ASCIIEncoding_GetByteCount_m1773219795 ();
extern "C" void ASCIIEncoding_GetBytes_m199792205 ();
extern "C" void ASCIIEncoding_GetBytes_m2887481599 ();
extern "C" void ASCIIEncoding_GetBytes_m4210595265 ();
extern "C" void ASCIIEncoding_GetBytes_m3306760563 ();
extern "C" void ASCIIEncoding_GetCharCount_m3004304767 ();
extern "C" void ASCIIEncoding_GetChars_m1246452100 ();
extern "C" void ASCIIEncoding_GetChars_m4136426329 ();
extern "C" void ASCIIEncoding_GetMaxByteCount_m2751391280 ();
extern "C" void ASCIIEncoding_GetMaxCharCount_m2837964160 ();
extern "C" void ASCIIEncoding_GetString_m2942901871 ();
extern "C" void ASCIIEncoding_GetBytes_m1861174925 ();
extern "C" void ASCIIEncoding_GetByteCount_m1104398450 ();
extern "C" void ASCIIEncoding_GetDecoder_m4195996369 ();
extern "C" void Decoder__ctor_m2119960144 ();
extern "C" void Decoder_set_Fallback_m1774963671 ();
extern "C" void Decoder_get_FallbackBuffer_m3655831519 ();
extern "C" void DecoderExceptionFallback__ctor_m3930142307 ();
extern "C" void DecoderExceptionFallback_CreateFallbackBuffer_m2504774350 ();
extern "C" void DecoderExceptionFallback_Equals_m1611656537 ();
extern "C" void DecoderExceptionFallback_GetHashCode_m1598361681 ();
extern "C" void DecoderExceptionFallbackBuffer__ctor_m498479446 ();
extern "C" void DecoderExceptionFallbackBuffer_get_Remaining_m398593133 ();
extern "C" void DecoderExceptionFallbackBuffer_Fallback_m312317784 ();
extern "C" void DecoderExceptionFallbackBuffer_GetNextChar_m1324206150 ();
extern "C" void DecoderFallback__ctor_m1472523671 ();
extern "C" void DecoderFallback__cctor_m4224747013 ();
extern "C" void DecoderFallback_get_ExceptionFallback_m763182818 ();
extern "C" void DecoderFallback_get_ReplacementFallback_m389680609 ();
extern "C" void DecoderFallback_get_StandardSafeFallback_m1965538229 ();
extern "C" void DecoderFallbackBuffer__ctor_m2657398271 ();
extern "C" void DecoderFallbackBuffer_Reset_m1629595938 ();
extern "C" void DecoderFallbackException__ctor_m4074062987 ();
extern "C" void DecoderFallbackException__ctor_m346326103 ();
extern "C" void DecoderFallbackException__ctor_m4264915677 ();
extern "C" void DecoderReplacementFallback__ctor_m3322239076 ();
extern "C" void DecoderReplacementFallback__ctor_m2067492076 ();
extern "C" void DecoderReplacementFallback_get_DefaultString_m2686184964 ();
extern "C" void DecoderReplacementFallback_CreateFallbackBuffer_m2039931449 ();
extern "C" void DecoderReplacementFallback_Equals_m2356168832 ();
extern "C" void DecoderReplacementFallback_GetHashCode_m4267878740 ();
extern "C" void DecoderReplacementFallbackBuffer__ctor_m2624753494 ();
extern "C" void DecoderReplacementFallbackBuffer_get_Remaining_m211987237 ();
extern "C" void DecoderReplacementFallbackBuffer_Fallback_m1284124031 ();
extern "C" void DecoderReplacementFallbackBuffer_GetNextChar_m2110169965 ();
extern "C" void DecoderReplacementFallbackBuffer_Reset_m1786585707 ();
extern "C" void EncoderExceptionFallback__ctor_m2465653200 ();
extern "C" void EncoderExceptionFallback_CreateFallbackBuffer_m2873066032 ();
extern "C" void EncoderExceptionFallback_Equals_m3426853426 ();
extern "C" void EncoderExceptionFallback_GetHashCode_m1526303002 ();
extern "C" void EncoderExceptionFallbackBuffer__ctor_m3193891897 ();
extern "C" void EncoderExceptionFallbackBuffer_get_Remaining_m588064435 ();
extern "C" void EncoderExceptionFallbackBuffer_Fallback_m1188975563 ();
extern "C" void EncoderExceptionFallbackBuffer_Fallback_m777326293 ();
extern "C" void EncoderExceptionFallbackBuffer_GetNextChar_m2105462580 ();
extern "C" void EncoderFallback__ctor_m948719623 ();
extern "C" void EncoderFallback__cctor_m4128339685 ();
extern "C" void EncoderFallback_get_ExceptionFallback_m2915221018 ();
extern "C" void EncoderFallback_get_ReplacementFallback_m1381460304 ();
extern "C" void EncoderFallback_get_StandardSafeFallback_m1287253668 ();
extern "C" void EncoderFallbackBuffer__ctor_m3828467897 ();
extern "C" void EncoderFallbackException__ctor_m1749718132 ();
extern "C" void EncoderFallbackException__ctor_m155720722 ();
extern "C" void EncoderFallbackException__ctor_m1528160091 ();
extern "C" void EncoderFallbackException__ctor_m2270281761 ();
extern "C" void EncoderReplacementFallback__ctor_m2945244117 ();
extern "C" void EncoderReplacementFallback__ctor_m3250070966 ();
extern "C" void EncoderReplacementFallback_get_DefaultString_m4191062785 ();
extern "C" void EncoderReplacementFallback_CreateFallbackBuffer_m1127069765 ();
extern "C" void EncoderReplacementFallback_Equals_m1390013825 ();
extern "C" void EncoderReplacementFallback_GetHashCode_m1615456044 ();
extern "C" void EncoderReplacementFallbackBuffer__ctor_m958381355 ();
extern "C" void EncoderReplacementFallbackBuffer_get_Remaining_m3977844014 ();
extern "C" void EncoderReplacementFallbackBuffer_Fallback_m501992528 ();
extern "C" void EncoderReplacementFallbackBuffer_Fallback_m3466722301 ();
extern "C" void EncoderReplacementFallbackBuffer_Fallback_m599858352 ();
extern "C" void EncoderReplacementFallbackBuffer_GetNextChar_m3453233277 ();
extern "C" void Encoding__ctor_m4008410528 ();
extern "C" void Encoding__ctor_m2875911424 ();
extern "C" void Encoding__cctor_m3484296081 ();
extern "C" void Encoding___m1793497461 ();
extern "C" void Encoding_get_IsReadOnly_m2121072446 ();
extern "C" void Encoding_get_DecoderFallback_m3065083615 ();
extern "C" void Encoding_set_DecoderFallback_m4267870351 ();
extern "C" void Encoding_get_EncoderFallback_m3188170455 ();
extern "C" void Encoding_SetFallbackInternal_m2442298156 ();
extern "C" void Encoding_Equals_m3288962300 ();
extern "C" void Encoding_GetByteCount_m3135173168 ();
extern "C" void Encoding_GetByteCount_m2922393167 ();
extern "C" void Encoding_GetBytes_m1236628218 ();
extern "C" void Encoding_GetBytes_m2340210978 ();
extern "C" void Encoding_GetBytes_m3931697097 ();
extern "C" void Encoding_GetBytes_m249472607 ();
extern "C" void Encoding_GetChars_m1532679131 ();
extern "C" void Encoding_GetDecoder_m3502379790 ();
extern "C" void Encoding_InvokeI18N_m2682327131 ();
extern "C" void Encoding_GetEncoding_m2298077044 ();
extern "C" void Encoding_Clone_m4233455263 ();
extern "C" void Encoding_GetEncoding_m3290780891 ();
extern "C" void Encoding_GetHashCode_m212417971 ();
extern "C" void Encoding_GetPreamble_m867157703 ();
extern "C" void Encoding_GetString_m1125439182 ();
extern "C" void Encoding_GetString_m4093922631 ();
extern "C" void Encoding_get_ASCII_m2724255296 ();
extern "C" void Encoding_get_BigEndianUnicode_m149122260 ();
extern "C" void Encoding_InternalCodePage_m2712836197 ();
extern "C" void Encoding_get_Default_m2372458680 ();
extern "C" void Encoding_get_ISOLatin1_m1300345248 ();
extern "C" void Encoding_get_UTF7_m2280152873 ();
extern "C" void Encoding_get_UTF8_m70465880 ();
extern "C" void Encoding_get_UTF8Unmarked_m1499185185 ();
extern "C" void Encoding_get_UTF8UnmarkedUnsafe_m497255164 ();
extern "C" void Encoding_get_Unicode_m2398772331 ();
extern "C" void Encoding_get_UTF32_m623218688 ();
extern "C" void Encoding_get_BigEndianUTF32_m2377347238 ();
extern "C" void Encoding_GetByteCount_m4183085963 ();
extern "C" void Encoding_GetBytes_m1474736915 ();
extern "C" void ForwardingDecoder__ctor_m1247364898 ();
extern "C" void ForwardingDecoder_GetChars_m1850329998 ();
extern "C" void Latin1Encoding__ctor_m589232024 ();
extern "C" void Latin1Encoding_GetByteCount_m13660016 ();
extern "C" void Latin1Encoding_GetByteCount_m3376283681 ();
extern "C" void Latin1Encoding_GetBytes_m647929659 ();
extern "C" void Latin1Encoding_GetBytes_m1052678065 ();
extern "C" void Latin1Encoding_GetBytes_m3050336403 ();
extern "C" void Latin1Encoding_GetBytes_m2000467629 ();
extern "C" void Latin1Encoding_GetCharCount_m1964788892 ();
extern "C" void Latin1Encoding_GetChars_m3531591516 ();
extern "C" void Latin1Encoding_GetMaxByteCount_m393329894 ();
extern "C" void Latin1Encoding_GetMaxCharCount_m2844776601 ();
extern "C" void Latin1Encoding_GetString_m3077621880 ();
extern "C" void Latin1Encoding_GetString_m2890245530 ();
extern "C" void StringBuilder__ctor_m1428493168 ();
extern "C" void StringBuilder__ctor_m2740731313 ();
extern "C" void StringBuilder__ctor_m175499341 ();
extern "C" void StringBuilder__ctor_m3845806063 ();
extern "C" void StringBuilder__ctor_m3798948217 ();
extern "C" void StringBuilder__ctor_m371641165 ();
extern "C" void StringBuilder__ctor_m773507880 ();
extern "C" void StringBuilder_System_Runtime_Serialization_ISerializable_GetObjectData_m2272161868 ();
extern "C" void StringBuilder_get_Capacity_m3453158625 ();
extern "C" void StringBuilder_set_Capacity_m1732372483 ();
extern "C" void StringBuilder_get_Length_m3907963072 ();
extern "C" void StringBuilder_set_Length_m1315149044 ();
extern "C" void StringBuilder_get_Chars_m3047187487 ();
extern "C" void StringBuilder_set_Chars_m2127440972 ();
extern "C" void StringBuilder_ToString_m244373136 ();
extern "C" void StringBuilder_ToString_m2073934015 ();
extern "C" void StringBuilder_Remove_m3905712325 ();
extern "C" void StringBuilder_Replace_m4020735041 ();
extern "C" void StringBuilder_Replace_m1009576108 ();
extern "C" void StringBuilder_Append_m2543471079 ();
extern "C" void StringBuilder_Append_m2359038886 ();
extern "C" void StringBuilder_Append_m3506914505 ();
extern "C" void StringBuilder_Append_m2521391494 ();
extern "C" void StringBuilder_Append_m2785502290 ();
extern "C" void StringBuilder_Append_m3779698721 ();
extern "C" void StringBuilder_Append_m3734755781 ();
extern "C" void StringBuilder_Append_m1756495403 ();
extern "C" void StringBuilder_AppendFormat_m265867772 ();
extern "C" void StringBuilder_AppendFormat_m170141315 ();
extern "C" void StringBuilder_AppendFormat_m122939010 ();
extern "C" void StringBuilder_AppendFormat_m4167342996 ();
extern "C" void StringBuilder_AppendFormat_m1638161108 ();
extern "C" void StringBuilder_Insert_m1379433688 ();
extern "C" void StringBuilder_Insert_m3210412127 ();
extern "C" void StringBuilder_Insert_m10459946 ();
extern "C" void StringBuilder_InternalEnsureCapacity_m482675063 ();
extern "C" void UnicodeEncoding__ctor_m3228903610 ();
extern "C" void UnicodeEncoding__ctor_m877433414 ();
extern "C" void UnicodeEncoding__ctor_m2462857434 ();
extern "C" void UnicodeEncoding_GetByteCount_m4119381810 ();
extern "C" void UnicodeEncoding_GetByteCount_m1935692450 ();
extern "C" void UnicodeEncoding_GetByteCount_m2385439378 ();
extern "C" void UnicodeEncoding_GetBytes_m692370369 ();
extern "C" void UnicodeEncoding_GetBytes_m3218310618 ();
extern "C" void UnicodeEncoding_GetBytes_m1035720983 ();
extern "C" void UnicodeEncoding_GetBytesInternal_m3562693430 ();
extern "C" void UnicodeEncoding_GetCharCount_m3091704602 ();
extern "C" void UnicodeEncoding_GetChars_m2365064659 ();
extern "C" void UnicodeEncoding_GetString_m2415827372 ();
extern "C" void UnicodeEncoding_GetCharsInternal_m2415901033 ();
extern "C" void UnicodeEncoding_GetMaxByteCount_m3203971272 ();
extern "C" void UnicodeEncoding_GetMaxCharCount_m2832727484 ();
extern "C" void UnicodeEncoding_GetDecoder_m1125098288 ();
extern "C" void UnicodeEncoding_GetPreamble_m4076903843 ();
extern "C" void UnicodeEncoding_Equals_m2221663842 ();
extern "C" void UnicodeEncoding_GetHashCode_m2539936009 ();
extern "C" void UnicodeEncoding_CopyChars_m445859045 ();
extern "C" void UnicodeDecoder__ctor_m3792125802 ();
extern "C" void UnicodeDecoder_GetChars_m1438681656 ();
extern "C" void UTF32Encoding__ctor_m3014186082 ();
extern "C" void UTF32Encoding__ctor_m1633634927 ();
extern "C" void UTF32Encoding__ctor_m3886255025 ();
extern "C" void UTF32Encoding_GetByteCount_m4237185367 ();
extern "C" void UTF32Encoding_GetBytes_m2455949945 ();
extern "C" void UTF32Encoding_GetCharCount_m1134574960 ();
extern "C" void UTF32Encoding_GetChars_m924416857 ();
extern "C" void UTF32Encoding_GetMaxByteCount_m2787654479 ();
extern "C" void UTF32Encoding_GetMaxCharCount_m2910971801 ();
extern "C" void UTF32Encoding_GetDecoder_m2857835937 ();
extern "C" void UTF32Encoding_GetPreamble_m596913816 ();
extern "C" void UTF32Encoding_Equals_m1691988153 ();
extern "C" void UTF32Encoding_GetHashCode_m2641139996 ();
extern "C" void UTF32Encoding_GetByteCount_m1376079431 ();
extern "C" void UTF32Encoding_GetByteCount_m1642432044 ();
extern "C" void UTF32Encoding_GetBytes_m3225718289 ();
extern "C" void UTF32Encoding_GetBytes_m2920443696 ();
extern "C" void UTF32Encoding_GetString_m1938510386 ();
extern "C" void UTF32Decoder__ctor_m1404655395 ();
extern "C" void UTF32Decoder_GetChars_m2487850939 ();
extern "C" void UTF7Encoding__ctor_m2625031550 ();
extern "C" void UTF7Encoding__ctor_m3655267641 ();
extern "C" void UTF7Encoding__cctor_m3748824209 ();
extern "C" void UTF7Encoding_GetHashCode_m2812161639 ();
extern "C" void UTF7Encoding_Equals_m1452874225 ();
extern "C" void UTF7Encoding_InternalGetByteCount_m215089974 ();
extern "C" void UTF7Encoding_GetByteCount_m2061781832 ();
extern "C" void UTF7Encoding_InternalGetBytes_m4089630742 ();
extern "C" void UTF7Encoding_GetBytes_m2080970182 ();
extern "C" void UTF7Encoding_InternalGetCharCount_m1686735135 ();
extern "C" void UTF7Encoding_GetCharCount_m3625731790 ();
extern "C" void UTF7Encoding_InternalGetChars_m1945515060 ();
extern "C" void UTF7Encoding_GetChars_m2884036738 ();
extern "C" void UTF7Encoding_GetMaxByteCount_m314080301 ();
extern "C" void UTF7Encoding_GetMaxCharCount_m3939861284 ();
extern "C" void UTF7Encoding_GetDecoder_m1285919430 ();
extern "C" void UTF7Encoding_GetByteCount_m2506376274 ();
extern "C" void UTF7Encoding_GetByteCount_m339441067 ();
extern "C" void UTF7Encoding_GetBytes_m2044879498 ();
extern "C" void UTF7Encoding_GetBytes_m578527611 ();
extern "C" void UTF7Encoding_GetString_m3450959021 ();
extern "C" void UTF7Decoder__ctor_m3816516457 ();
extern "C" void UTF7Decoder_GetChars_m216473671 ();
extern "C" void UTF8Encoding__ctor_m3506809644 ();
extern "C" void UTF8Encoding__ctor_m3141913478 ();
extern "C" void UTF8Encoding__ctor_m1562634020 ();
extern "C" void UTF8Encoding_InternalGetByteCount_m1956688264 ();
extern "C" void UTF8Encoding_InternalGetByteCount_m3481093678 ();
extern "C" void UTF8Encoding_GetByteCount_m650098797 ();
extern "C" void UTF8Encoding_GetByteCount_m2335716119 ();
extern "C" void UTF8Encoding_InternalGetBytes_m3469452628 ();
extern "C" void UTF8Encoding_InternalGetBytes_m539594093 ();
extern "C" void UTF8Encoding_GetBytes_m2979318900 ();
extern "C" void UTF8Encoding_GetBytes_m752272482 ();
extern "C" void UTF8Encoding_GetBytes_m1516677235 ();
extern "C" void UTF8Encoding_InternalGetCharCount_m163506631 ();
extern "C" void UTF8Encoding_InternalGetCharCount_m1220056757 ();
extern "C" void UTF8Encoding_Fallback_m1083879228 ();
extern "C" void UTF8Encoding_Fallback_m2344474189 ();
extern "C" void UTF8Encoding_GetCharCount_m1230578939 ();
extern "C" void UTF8Encoding_InternalGetChars_m2496291495 ();
extern "C" void UTF8Encoding_InternalGetChars_m972795790 ();
extern "C" void UTF8Encoding_GetChars_m2428255045 ();
extern "C" void UTF8Encoding_GetMaxByteCount_m501722113 ();
extern "C" void UTF8Encoding_GetMaxCharCount_m2175098764 ();
extern "C" void UTF8Encoding_GetDecoder_m3138288894 ();
extern "C" void UTF8Encoding_GetPreamble_m1886809218 ();
extern "C" void UTF8Encoding_Equals_m885845848 ();
extern "C" void UTF8Encoding_GetHashCode_m3782708233 ();
extern "C" void UTF8Encoding_GetByteCount_m1704160248 ();
extern "C" void UTF8Encoding_GetString_m658301774 ();
extern "C" void UTF8Decoder__ctor_m24980077 ();
extern "C" void UTF8Decoder_GetChars_m2736415519 ();
extern "C" void CompressedStack__ctor_m2532168140 ();
extern "C" void CompressedStack__ctor_m447154863 ();
extern "C" void CompressedStack_CreateCopy_m3982422829 ();
extern "C" void CompressedStack_Capture_m768931220 ();
extern "C" void CompressedStack_GetObjectData_m690500011 ();
extern "C" void CompressedStack_IsEmpty_m683992633 ();
extern "C" void EventWaitHandle__ctor_m2932705097 ();
extern "C" void EventWaitHandle_IsManualReset_m2534496093 ();
extern "C" void EventWaitHandle_Reset_m4122309515 ();
extern "C" void EventWaitHandle_Set_m1926926539 ();
extern "C" void ExecutionContext__ctor_m3696050508 ();
extern "C" void ExecutionContext__ctor_m1439213123 ();
extern "C" void ExecutionContext__ctor_m832962155 ();
extern "C" void ExecutionContext_Capture_m3410755285 ();
extern "C" void ExecutionContext_GetObjectData_m1523482666 ();
extern "C" void ExecutionContext_get_SecurityContext_m2985052274 ();
extern "C" void ExecutionContext_set_SecurityContext_m3668312566 ();
extern "C" void ExecutionContext_get_FlowSuppressed_m1317252817 ();
extern "C" void ExecutionContext_IsFlowSuppressed_m2418975955 ();
extern "C" void Interlocked_CompareExchange_m2836937338 ();
extern "C" void Interlocked_CompareExchange_m867509969 ();
extern "C" void ManualResetEvent__ctor_m3272063800 ();
extern "C" void Monitor_Enter_m38452667 ();
extern "C" void Monitor_Exit_m1806149589 ();
extern "C" void Monitor_Monitor_pulse_m238331246 ();
extern "C" void Monitor_Monitor_test_synchronised_m2220174918 ();
extern "C" void Monitor_Pulse_m2889454142 ();
extern "C" void Monitor_Monitor_wait_m3905904418 ();
extern "C" void Monitor_Wait_m856719031 ();
extern "C" void Mutex__ctor_m1301030505 ();
extern "C" void Mutex_CreateMutex_internal_m2160126498 ();
extern "C" void Mutex_ReleaseMutex_internal_m1378384868 ();
extern "C" void Mutex_ReleaseMutex_m4091486119 ();
extern "C" void NativeEventCalls_CreateEvent_internal_m889177616 ();
extern "C" void NativeEventCalls_SetEvent_internal_m2190178706 ();
extern "C" void NativeEventCalls_ResetEvent_internal_m2582641831 ();
extern "C" void NativeEventCalls_CloseEvent_internal_m602630379 ();
extern "C" void SendOrPostCallback__ctor_m4095383272 ();
extern "C" void SendOrPostCallback_Invoke_m1796811407 ();
extern "C" void SendOrPostCallback_BeginInvoke_m2593995799 ();
extern "C" void SendOrPostCallback_EndInvoke_m618896138 ();
extern "C" void SynchronizationContext__ctor_m3662476266 ();
extern "C" void SynchronizationContext_get_Current_m840992411 ();
extern "C" void SynchronizationContext_SetSynchronizationContext_m3503083165 ();
extern "C" void SynchronizationLockException__ctor_m3938079360 ();
extern "C" void SynchronizationLockException__ctor_m2888689672 ();
extern "C" void SynchronizationLockException__ctor_m3039052602 ();
extern "C" void Thread__ctor_m2961764056 ();
extern "C" void Thread__cctor_m658133795 ();
extern "C" void Thread_get_CurrentContext_m2749902502 ();
extern "C" void Thread_CurrentThread_internal_m261912641 ();
extern "C" void Thread_get_CurrentThread_m2728607849 ();
extern "C" void Thread_FreeLocalSlotValues_m623529402 ();
extern "C" void Thread_GetDomainID_m1184134661 ();
extern "C" void Thread_Thread_internal_m3767251588 ();
extern "C" void Thread_Thread_init_m3177124217 ();
extern "C" void Thread_GetCachedCurrentCulture_m2245605137 ();
extern "C" void Thread_GetSerializedCurrentCulture_m3677779835 ();
extern "C" void Thread_SetCachedCurrentCulture_m1966227962 ();
extern "C" void Thread_GetCachedCurrentUICulture_m2995853991 ();
extern "C" void Thread_GetSerializedCurrentUICulture_m766002516 ();
extern "C" void Thread_SetCachedCurrentUICulture_m922720501 ();
extern "C" void Thread_get_CurrentCulture_m522769991 ();
extern "C" void Thread_get_CurrentUICulture_m1331814557 ();
extern "C" void Thread_set_IsBackground_m3770057700 ();
extern "C" void Thread_SetName_internal_m117264428 ();
extern "C" void Thread_set_Name_m3115102052 ();
extern "C" void Thread_Start_m2879827094 ();
extern "C" void Thread_Thread_free_internal_m1301564801 ();
extern "C" void Thread_Finalize_m1654384812 ();
extern "C" void Thread_SetState_m2929757911 ();
extern "C" void Thread_ClrState_m2152224579 ();
extern "C" void Thread_GetNewManagedId_m3558386045 ();
extern "C" void Thread_GetNewManagedId_internal_m733821386 ();
extern "C" void Thread_get_ExecutionContext_m1768813807 ();
extern "C" void Thread_get_ManagedThreadId_m2611241199 ();
extern "C" void Thread_GetHashCode_m2708003321 ();
extern "C" void Thread_GetCompressedStack_m1386275719 ();
extern "C" void ThreadAbortException__ctor_m2121087087 ();
extern "C" void ThreadAbortException__ctor_m1262341537 ();
extern "C" void ThreadInterruptedException__ctor_m4112071000 ();
extern "C" void ThreadInterruptedException__ctor_m3943542634 ();
extern "C" void ThreadPool_QueueUserWorkItem_m1429580738 ();
extern "C" void ThreadStart__ctor_m764849218 ();
extern "C" void ThreadStart_Invoke_m1770126731 ();
extern "C" void ThreadStart_BeginInvoke_m325667963 ();
extern "C" void ThreadStart_EndInvoke_m1958419553 ();
extern "C" void ThreadStateException__ctor_m697746599 ();
extern "C" void ThreadStateException__ctor_m3084835994 ();
extern "C" void Timer__cctor_m3635255388 ();
extern "C" void Timer_Change_m3280661692 ();
extern "C" void Timer_Dispose_m2272806547 ();
extern "C" void Timer_Change_m4053603748 ();
extern "C" void Scheduler__ctor_m3579330397 ();
extern "C" void Scheduler__cctor_m3021403185 ();
extern "C" void Scheduler_get_Instance_m2737017557 ();
extern "C" void Scheduler_Remove_m99311860 ();
extern "C" void Scheduler_Change_m538608898 ();
extern "C" void Scheduler_Add_m3781962737 ();
extern "C" void Scheduler_InternalRemove_m1021644107 ();
extern "C" void Scheduler_SchedulerThread_m380140393 ();
extern "C" void Scheduler_ShrinkIfNeeded_m1969639564 ();
extern "C" void TimerComparer__ctor_m3165162825 ();
extern "C" void TimerComparer_Compare_m2906216700 ();
extern "C" void TimerCallback__ctor_m1469419909 ();
extern "C" void TimerCallback_Invoke_m1696482865 ();
extern "C" void TimerCallback_BeginInvoke_m2975344911 ();
extern "C" void TimerCallback_EndInvoke_m2367493485 ();
extern "C" void WaitCallback__ctor_m2152232241 ();
extern "C" void WaitCallback_Invoke_m3326833418 ();
extern "C" void WaitCallback_BeginInvoke_m2024194814 ();
extern "C" void WaitCallback_EndInvoke_m3586669057 ();
extern "C" void WaitHandle__ctor_m503027900 ();
extern "C" void WaitHandle__cctor_m1653924360 ();
extern "C" void WaitHandle_System_IDisposable_Dispose_m4272735226 ();
extern "C" void WaitHandle_get_Handle_m2420807871 ();
extern "C" void WaitHandle_set_Handle_m336908879 ();
extern "C" void WaitHandle_WaitOne_internal_m3661738743 ();
extern "C" void WaitHandle_Dispose_m3526411156 ();
extern "C" void WaitHandle_WaitOne_m4034199657 ();
extern "C" void WaitHandle_WaitOne_m1473965123 ();
extern "C" void WaitHandle_CheckDisposed_m3085686943 ();
extern "C" void WaitHandle_Finalize_m2135410771 ();
extern "C" void ThreadStaticAttribute__ctor_m406231037 ();
extern "C" void TimeSpan__ctor_m870041458_AdjustorThunk ();
extern "C" void TimeSpan__ctor_m2251893089_AdjustorThunk ();
extern "C" void TimeSpan__ctor_m200249364_AdjustorThunk ();
extern "C" void TimeSpan__cctor_m3387775234 ();
extern "C" void TimeSpan_CalculateTicks_m3000279770 ();
extern "C" void TimeSpan_get_Days_m1072484364_AdjustorThunk ();
extern "C" void TimeSpan_get_Hours_m317922503_AdjustorThunk ();
extern "C" void TimeSpan_get_Milliseconds_m3309834420_AdjustorThunk ();
extern "C" void TimeSpan_get_Minutes_m3625111541_AdjustorThunk ();
extern "C" void TimeSpan_get_Seconds_m2421464030_AdjustorThunk ();
extern "C" void TimeSpan_get_Ticks_m4068363378_AdjustorThunk ();
extern "C" void TimeSpan_get_TotalDays_m1715978830_AdjustorThunk ();
extern "C" void TimeSpan_get_TotalHours_m1351619258_AdjustorThunk ();
extern "C" void TimeSpan_get_TotalMilliseconds_m3880263801_AdjustorThunk ();
extern "C" void TimeSpan_get_TotalMinutes_m3144648976_AdjustorThunk ();
extern "C" void TimeSpan_get_TotalSeconds_m3729239458_AdjustorThunk ();
extern "C" void TimeSpan_Add_m904898194_AdjustorThunk ();
extern "C" void TimeSpan_Compare_m2033428183 ();
extern "C" void TimeSpan_CompareTo_m3351405754_AdjustorThunk ();
extern "C" void TimeSpan_CompareTo_m291689286_AdjustorThunk ();
extern "C" void TimeSpan_Equals_m646882242_AdjustorThunk ();
extern "C" void TimeSpan_Duration_m1524814460_AdjustorThunk ();
extern "C" void TimeSpan_Equals_m2055998824_AdjustorThunk ();
extern "C" void TimeSpan_FromDays_m4000964373 ();
extern "C" void TimeSpan_FromHours_m2014759844 ();
extern "C" void TimeSpan_FromMinutes_m216571269 ();
extern "C" void TimeSpan_FromSeconds_m2832576765 ();
extern "C" void TimeSpan_FromMilliseconds_m3065244797 ();
extern "C" void TimeSpan_From_m246185944 ();
extern "C" void TimeSpan_GetHashCode_m823626829_AdjustorThunk ();
extern "C" void TimeSpan_Negate_m3839207271_AdjustorThunk ();
extern "C" void TimeSpan_Subtract_m4139361392_AdjustorThunk ();
extern "C" void TimeSpan_ToString_m919987235_AdjustorThunk ();
extern "C" void TimeSpan_op_Addition_m1693936150 ();
extern "C" void TimeSpan_op_Equality_m3495453946 ();
extern "C" void TimeSpan_op_GreaterThan_m916935962 ();
extern "C" void TimeSpan_op_GreaterThanOrEqual_m1019326098 ();
extern "C" void TimeSpan_op_Inequality_m68078519 ();
extern "C" void TimeSpan_op_LessThan_m1028668437 ();
extern "C" void TimeSpan_op_LessThanOrEqual_m3885187140 ();
extern "C" void TimeSpan_op_Subtraction_m42918648 ();
extern "C" void TimeZone__ctor_m2450978757 ();
extern "C" void TimeZone__cctor_m3115066945 ();
extern "C" void TimeZone_get_CurrentTimeZone_m891519357 ();
extern "C" void TimeZone_IsDaylightSavingTime_m1272116738 ();
extern "C" void TimeZone_IsDaylightSavingTime_m1403338817 ();
extern "C" void TimeZone_ToLocalTime_m4197877126 ();
extern "C" void TimeZone_ToUniversalTime_m2004835404 ();
extern "C" void TimeZone_GetLocalTimeDiff_m431191048 ();
extern "C" void TimeZone_GetLocalTimeDiff_m1410256051 ();
extern "C" void Type__ctor_m3514625664 ();
extern "C" void Type__cctor_m427325584 ();
extern "C" void Type_FilterName_impl_m102860822 ();
extern "C" void Type_FilterNameIgnoreCase_impl_m2584364550 ();
extern "C" void Type_FilterAttribute_impl_m2244337626 ();
extern "C" void Type_get_Attributes_m3445770387 ();
extern "C" void Type_get_DeclaringType_m3957938188 ();
extern "C" void Type_get_HasElementType_m1982409910 ();
extern "C" void Type_get_IsAbstract_m2706022722 ();
extern "C" void Type_get_IsArray_m1869780647 ();
extern "C" void Type_get_IsByRef_m2632653652 ();
extern "C" void Type_get_IsClass_m2562810909 ();
extern "C" void Type_get_IsContextful_m3345788469 ();
extern "C" void Type_get_IsEnum_m3216654447 ();
extern "C" void Type_get_IsExplicitLayout_m3091686209 ();
extern "C" void Type_get_IsInterface_m810115707 ();
extern "C" void Type_get_IsMarshalByRef_m4289809468 ();
extern "C" void Type_get_IsPointer_m2822765025 ();
extern "C" void Type_get_IsPrimitive_m873255927 ();
extern "C" void Type_get_IsSealed_m593857244 ();
extern "C" void Type_get_IsSerializable_m3983305930 ();
extern "C" void Type_get_IsValueType_m1599902602 ();
extern "C" void Type_get_MemberType_m2285707662 ();
extern "C" void Type_get_ReflectedType_m2518019791 ();
extern "C" void Type_get_TypeHandle_m2853570791 ();
extern "C" void Type_Equals_m1777835199 ();
extern "C" void Type_Equals_m558412655 ();
extern "C" void Type_EqualsInternal_m621957517 ();
extern "C" void Type_internal_from_handle_m322157645 ();
extern "C" void Type_internal_from_name_m3961128735 ();
extern "C" void Type_GetType_m1880105665 ();
extern "C" void Type_GetType_m495616535 ();
extern "C" void Type_GetTypeCodeInternal_m887661258 ();
extern "C" void Type_GetTypeCode_m3372530953 ();
extern "C" void Type_GetTypeFromHandle_m2295595423 ();
extern "C" void Type_GetTypeHandle_m1532429232 ();
extern "C" void Type_type_is_subtype_of_m1951411367 ();
extern "C" void Type_type_is_assignable_from_m2104149404 ();
extern "C" void Type_IsSubclassOf_m3030212525 ();
extern "C" void Type_IsAssignableFrom_m1556173396 ();
extern "C" void Type_IsInstanceOfType_m2917238988 ();
extern "C" void Type_GetField_m969861738 ();
extern "C" void Type_GetHashCode_m2868298710 ();
extern "C" void Type_GetMethod_m229901197 ();
extern "C" void Type_GetMethod_m1087717536 ();
extern "C" void Type_GetMethod_m788657706 ();
extern "C" void Type_GetMethod_m1268634691 ();
extern "C" void Type_GetProperty_m4192268900 ();
extern "C" void Type_GetProperty_m3593981547 ();
extern "C" void Type_GetProperty_m217098125 ();
extern "C" void Type_GetProperty_m2905030504 ();
extern "C" void Type_GetProperty_m504012450 ();
extern "C" void Type_IsArrayImpl_m1401706624 ();
extern "C" void Type_IsValueTypeImpl_m2680682106 ();
extern "C" void Type_IsContextfulImpl_m2184405446 ();
extern "C" void Type_IsMarshalByRefImpl_m751776591 ();
extern "C" void Type_GetConstructor_m3166019052 ();
extern "C" void Type_GetConstructor_m3093596752 ();
extern "C" void Type_GetConstructor_m888409261 ();
extern "C" void Type_ToString_m1098933952 ();
extern "C" void Type_get_IsSystemType_m3689670840 ();
extern "C" void Type_GetGenericArguments_m2670134621 ();
extern "C" void Type_get_ContainsGenericParameters_m1440526760 ();
extern "C" void Type_get_IsGenericTypeDefinition_m4270534531 ();
extern "C" void Type_GetGenericTypeDefinition_impl_m3084830526 ();
extern "C" void Type_GetGenericTypeDefinition_m1391916486 ();
extern "C" void Type_get_IsGenericType_m1725685497 ();
extern "C" void Type_MakeGenericType_m3657355304 ();
extern "C" void Type_MakeGenericType_m2741335421 ();
extern "C" void Type_get_IsGenericParameter_m3982329739 ();
extern "C" void Type_get_IsNested_m1784827734 ();
extern "C" void Type_GetPseudoCustomAttributes_m1095221136 ();
extern "C" void TypedReference_Equals_m1534014288_AdjustorThunk ();
extern "C" void TypedReference_GetHashCode_m1281515118_AdjustorThunk ();
extern "C" void TypeInitializationException__ctor_m1767161251 ();
extern "C" void TypeInitializationException_GetObjectData_m761223089 ();
extern "C" void TypeLoadException__ctor_m605554810 ();
extern "C" void TypeLoadException__ctor_m2127875797 ();
extern "C" void TypeLoadException__ctor_m2902952148 ();
extern "C" void TypeLoadException__ctor_m1861445896 ();
extern "C" void TypeLoadException_get_Message_m2911451104 ();
extern "C" void TypeLoadException_GetObjectData_m1445642080 ();
extern "C" void UInt16_System_IConvertible_ToBoolean_m2938174643_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToByte_m2026142984_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToChar_m2076998351_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToDateTime_m4012943687_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToDecimal_m1895855844_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToDouble_m3636128198_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToInt16_m4163098757_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToInt32_m3570854327_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToInt64_m1753308647_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToSByte_m3408172411_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToSingle_m2826102608_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToType_m3909179681_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToUInt16_m1317600763_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToUInt32_m4054634694_AdjustorThunk ();
extern "C" void UInt16_System_IConvertible_ToUInt64_m2663253018_AdjustorThunk ();
extern "C" void UInt16_CompareTo_m598717551_AdjustorThunk ();
extern "C" void UInt16_Equals_m391233801_AdjustorThunk ();
extern "C" void UInt16_GetHashCode_m2287554426_AdjustorThunk ();
extern "C" void UInt16_CompareTo_m4063616443_AdjustorThunk ();
extern "C" void UInt16_Equals_m3955712414_AdjustorThunk ();
extern "C" void UInt16_Parse_m821794179 ();
extern "C" void UInt16_Parse_m1827209548 ();
extern "C" void UInt16_TryParse_m2161302458 ();
extern "C" void UInt16_TryParse_m4175666418 ();
extern "C" void UInt16_ToString_m3822407517_AdjustorThunk ();
extern "C" void UInt16_ToString_m30405293_AdjustorThunk ();
extern "C" void UInt16_ToString_m45506489_AdjustorThunk ();
extern "C" void UInt16_ToString_m3807504599_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToBoolean_m3340090418_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToByte_m2481938937_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToChar_m322114797_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToDateTime_m1448117779_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToDecimal_m1499107649_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToDouble_m415718190_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToInt16_m4220398773_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToInt32_m2565310438_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToInt64_m3977292974_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToSByte_m1504578294_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToSingle_m1896300003_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToType_m3185309404_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToUInt16_m3929246764_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToUInt32_m3211145308_AdjustorThunk ();
extern "C" void UInt32_System_IConvertible_ToUInt64_m3755722643_AdjustorThunk ();
extern "C" void UInt32_CompareTo_m1385037073_AdjustorThunk ();
extern "C" void UInt32_Equals_m2504152169_AdjustorThunk ();
extern "C" void UInt32_GetHashCode_m1074555290_AdjustorThunk ();
extern "C" void UInt32_CompareTo_m3135376739_AdjustorThunk ();
extern "C" void UInt32_Equals_m2164242329_AdjustorThunk ();
extern "C" void UInt32_Parse_m2570147847 ();
extern "C" void UInt32_Parse_m1028925636 ();
extern "C" void UInt32_Parse_m602751418 ();
extern "C" void UInt32_Parse_m1560553326 ();
extern "C" void UInt32_TryParse_m872480584 ();
extern "C" void UInt32_TryParse_m2781189100 ();
extern "C" void UInt32_ToString_m1044369565_AdjustorThunk ();
extern "C" void UInt32_ToString_m466102405_AdjustorThunk ();
extern "C" void UInt32_ToString_m2873034864_AdjustorThunk ();
extern "C" void UInt32_ToString_m1785453081_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToBoolean_m940072003_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToByte_m3349692439_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToChar_m4077346663_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToDateTime_m825240115_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToDecimal_m573006315_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToDouble_m234291922_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToInt16_m4190108701_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToInt32_m2065607744_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToInt64_m1438551110_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToSByte_m3762118253_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToSingle_m342787973_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToType_m3046026539_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToUInt16_m982389634_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToUInt32_m1482915438_AdjustorThunk ();
extern "C" void UInt64_System_IConvertible_ToUInt64_m559076774_AdjustorThunk ();
extern "C" void UInt64_CompareTo_m3064838862_AdjustorThunk ();
extern "C" void UInt64_Equals_m3307238183_AdjustorThunk ();
extern "C" void UInt64_GetHashCode_m1170046557_AdjustorThunk ();
extern "C" void UInt64_CompareTo_m2050311960_AdjustorThunk ();
extern "C" void UInt64_Equals_m559271450_AdjustorThunk ();
extern "C" void UInt64_Parse_m2837505384 ();
extern "C" void UInt64_Parse_m1564256210 ();
extern "C" void UInt64_Parse_m1838157675 ();
extern "C" void UInt64_TryParse_m1875351864 ();
extern "C" void UInt64_ToString_m3813799023_AdjustorThunk ();
extern "C" void UInt64_ToString_m1174253044_AdjustorThunk ();
extern "C" void UInt64_ToString_m601668999_AdjustorThunk ();
extern "C" void UInt64_ToString_m2220742856_AdjustorThunk ();
extern "C" void UIntPtr__ctor_m3478500531_AdjustorThunk ();
extern "C" void UIntPtr__ctor_m4105922456_AdjustorThunk ();
extern "C" void UIntPtr__ctor_m890287867_AdjustorThunk ();
extern "C" void UIntPtr__cctor_m3098084730 ();
extern "C" void UIntPtr_System_Runtime_Serialization_ISerializable_GetObjectData_m2261738681_AdjustorThunk ();
extern "C" void UIntPtr_Equals_m2565501201_AdjustorThunk ();
extern "C" void UIntPtr_GetHashCode_m3117809595_AdjustorThunk ();
extern "C" void UIntPtr_ToUInt32_m1488255549_AdjustorThunk ();
extern "C" void UIntPtr_ToUInt64_m1446044739_AdjustorThunk ();
extern "C" void UIntPtr_ToPointer_m2330649849_AdjustorThunk ();
extern "C" void UIntPtr_ToString_m2349799160_AdjustorThunk ();
extern "C" void UIntPtr_get_Size_m4091950724 ();
extern "C" void UIntPtr_op_Equality_m1590355935 ();
extern "C" void UIntPtr_op_Inequality_m376990495 ();
extern "C" void UIntPtr_op_Explicit_m3590246742 ();
extern "C" void UIntPtr_op_Explicit_m3099530842 ();
extern "C" void UIntPtr_op_Explicit_m2779336468 ();
extern "C" void UIntPtr_op_Explicit_m4118586544 ();
extern "C" void UIntPtr_op_Explicit_m1761774754 ();
extern "C" void UIntPtr_op_Explicit_m1534923483 ();
extern "C" void UnauthorizedAccessException__ctor_m3689916169 ();
extern "C" void UnauthorizedAccessException__ctor_m300962893 ();
extern "C" void UnauthorizedAccessException__ctor_m2339700578 ();
extern "C" void UnhandledExceptionEventArgs__ctor_m29960797 ();
extern "C" void UnhandledExceptionEventArgs_get_ExceptionObject_m4275923656 ();
extern "C" void UnhandledExceptionEventArgs_get_IsTerminating_m3714614171 ();
extern "C" void UnhandledExceptionEventHandler__ctor_m2199922652 ();
extern "C" void UnhandledExceptionEventHandler_Invoke_m4186886379 ();
extern "C" void UnhandledExceptionEventHandler_BeginInvoke_m1399476456 ();
extern "C" void UnhandledExceptionEventHandler_EndInvoke_m1298953255 ();
extern "C" void UnitySerializationHolder__ctor_m1034045059 ();
extern "C" void UnitySerializationHolder_GetTypeData_m316232846 ();
extern "C" void UnitySerializationHolder_GetDBNullData_m4272190497 ();
extern "C" void UnitySerializationHolder_GetModuleData_m2344463278 ();
extern "C" void UnitySerializationHolder_GetObjectData_m4063397316 ();
extern "C" void UnitySerializationHolder_GetRealObject_m1459969038 ();
extern "C" void ValueType__ctor_m2756058136 ();
extern "C" void ValueType_InternalEquals_m1159190307 ();
extern "C" void ValueType_DefaultEquals_m3478451992 ();
extern "C" void ValueType_Equals_m239602267 ();
extern "C" void ValueType_InternalGetHashCode_m3183595565 ();
extern "C" void ValueType_GetHashCode_m2115687125 ();
extern "C" void ValueType_ToString_m1086036397 ();
extern "C" void Version__ctor_m3000072641 ();
extern "C" void Version__ctor_m4079040315 ();
extern "C" void Version__ctor_m2777383737 ();
extern "C" void Version__ctor_m852799842 ();
extern "C" void Version__ctor_m3884932599 ();
extern "C" void Version_CheckedSet_m111653027 ();
extern "C" void Version_get_Build_m2354003600 ();
extern "C" void Version_get_Major_m2328730053 ();
extern "C" void Version_get_Minor_m2929997196 ();
extern "C" void Version_get_Revision_m608992238 ();
extern "C" void Version_Clone_m3183706130 ();
extern "C" void Version_CompareTo_m1235128625 ();
extern "C" void Version_Equals_m4160560067 ();
extern "C" void Version_CompareTo_m3125023153 ();
extern "C" void Version_Equals_m3860247383 ();
extern "C" void Version_GetHashCode_m3395513008 ();
extern "C" void Version_ToString_m926326786 ();
extern "C" void Version_CreateFromString_m3672463384 ();
extern "C" void Version_op_Equality_m443314940 ();
extern "C" void Version_op_Inequality_m2806992777 ();
extern "C" void WeakReference__ctor_m773162140 ();
extern "C" void WeakReference__ctor_m2124974099 ();
extern "C" void WeakReference__ctor_m398759899 ();
extern "C" void WeakReference__ctor_m2153339938 ();
extern "C" void WeakReference_AllocateHandle_m1110798685 ();
extern "C" void WeakReference_get_IsAlive_m2440580473 ();
extern "C" void WeakReference_get_Target_m926440970 ();
extern "C" void WeakReference_get_TrackResurrection_m91962753 ();
extern "C" void WeakReference_Finalize_m2384180804 ();
extern "C" void WeakReference_GetObjectData_m4174671114 ();
extern "C" void Locale_GetText_m1647632488 ();
extern "C" void Locale_GetText_m3231868817 ();
extern "C" void HybridDictionary__ctor_m3653045782 ();
extern "C" void HybridDictionary__ctor_m2147156402 ();
extern "C" void HybridDictionary_System_Collections_IEnumerable_GetEnumerator_m926841030 ();
extern "C" void HybridDictionary_get_inner_m4173737539 ();
extern "C" void HybridDictionary_get_Count_m1847902913 ();
extern "C" void HybridDictionary_get_Item_m791179778 ();
extern "C" void HybridDictionary_set_Item_m1547193035 ();
extern "C" void HybridDictionary_get_SyncRoot_m1441637939 ();
extern "C" void HybridDictionary_Add_m3601456474 ();
extern "C" void HybridDictionary_CopyTo_m2014314495 ();
extern "C" void HybridDictionary_GetEnumerator_m3316769784 ();
extern "C" void HybridDictionary_Remove_m3466274522 ();
extern "C" void HybridDictionary_Switch_m3582035830 ();
extern "C" void ListDictionary__ctor_m4252876715 ();
extern "C" void ListDictionary__ctor_m576138091 ();
extern "C" void ListDictionary_System_Collections_IEnumerable_GetEnumerator_m1131156923 ();
extern "C" void ListDictionary_FindEntry_m1708015721 ();
extern "C" void ListDictionary_FindEntry_m2871472386 ();
extern "C" void ListDictionary_AddImpl_m1078813873 ();
extern "C" void ListDictionary_get_Count_m654515562 ();
extern "C" void ListDictionary_get_SyncRoot_m1057056687 ();
extern "C" void ListDictionary_CopyTo_m1376306415 ();
extern "C" void ListDictionary_get_Item_m682334219 ();
extern "C" void ListDictionary_set_Item_m3311570113 ();
extern "C" void ListDictionary_Add_m2512092114 ();
extern "C" void ListDictionary_Clear_m2772407903 ();
extern "C" void ListDictionary_GetEnumerator_m1192837366 ();
extern "C" void ListDictionary_Remove_m1866677954 ();
extern "C" void DictionaryNode__ctor_m3583809050 ();
extern "C" void DictionaryNodeEnumerator__ctor_m3308198089 ();
extern "C" void DictionaryNodeEnumerator_FailFast_m2080867333 ();
extern "C" void DictionaryNodeEnumerator_MoveNext_m3257976381 ();
extern "C" void DictionaryNodeEnumerator_Reset_m2537649624 ();
extern "C" void DictionaryNodeEnumerator_get_Current_m2851874498 ();
extern "C" void DictionaryNodeEnumerator_get_DictionaryNode_m1494027982 ();
extern "C" void DictionaryNodeEnumerator_get_Entry_m1719842113 ();
extern "C" void DictionaryNodeEnumerator_get_Key_m2349419451 ();
extern "C" void DictionaryNodeEnumerator_get_Value_m3813667679 ();
extern "C" void NameObjectCollectionBase__ctor_m1305041123 ();
extern "C" void NameObjectCollectionBase__ctor_m27591930 ();
extern "C" void NameObjectCollectionBase_System_Collections_ICollection_get_SyncRoot_m4022549244 ();
extern "C" void NameObjectCollectionBase_System_Collections_ICollection_CopyTo_m189238480 ();
extern "C" void NameObjectCollectionBase_Init_m3689157985 ();
extern "C" void NameObjectCollectionBase_get_Keys_m1338563883 ();
extern "C" void NameObjectCollectionBase_GetEnumerator_m2920527064 ();
extern "C" void NameObjectCollectionBase_GetObjectData_m3062537340 ();
extern "C" void NameObjectCollectionBase_get_Count_m2167539385 ();
extern "C" void NameObjectCollectionBase_OnDeserialization_m399028257 ();
extern "C" void NameObjectCollectionBase_get_IsReadOnly_m2917149711 ();
extern "C" void NameObjectCollectionBase_BaseAdd_m2613686807 ();
extern "C" void NameObjectCollectionBase_BaseGet_m1017030273 ();
extern "C" void NameObjectCollectionBase_BaseGet_m1564870035 ();
extern "C" void NameObjectCollectionBase_BaseGetKey_m2496215546 ();
extern "C" void NameObjectCollectionBase_FindFirstMatchedItem_m2785248297 ();
extern "C" void _Item__ctor_m4107454056 ();
extern "C" void _KeysEnumerator__ctor_m515115223 ();
extern "C" void _KeysEnumerator_get_Current_m2321820747 ();
extern "C" void _KeysEnumerator_MoveNext_m506294014 ();
extern "C" void _KeysEnumerator_Reset_m1803042365 ();
extern "C" void KeysCollection__ctor_m2173697011 ();
extern "C" void KeysCollection_System_Collections_ICollection_CopyTo_m1072205791 ();
extern "C" void KeysCollection_System_Collections_ICollection_get_SyncRoot_m684690045 ();
extern "C" void KeysCollection_get_Count_m2006320711 ();
extern "C" void KeysCollection_GetEnumerator_m1640177526 ();
extern "C" void NameValueCollection__ctor_m2278028677 ();
extern "C" void NameValueCollection__ctor_m1373236513 ();
extern "C" void NameValueCollection_Add_m1155069069 ();
extern "C" void NameValueCollection_Get_m257741685 ();
extern "C" void NameValueCollection_AsSingleString_m4102959917 ();
extern "C" void NameValueCollection_GetKey_m2719855662 ();
extern "C" void NameValueCollection_InvalidateCachedArrays_m1895956073 ();
extern "C" void EditorBrowsableAttribute__ctor_m2659158224 ();
extern "C" void EditorBrowsableAttribute_get_State_m3042163749 ();
extern "C" void EditorBrowsableAttribute_Equals_m3235731104 ();
extern "C" void EditorBrowsableAttribute_GetHashCode_m1104320344 ();
extern "C" void TypeConverterAttribute__ctor_m565780092 ();
extern "C" void TypeConverterAttribute__ctor_m2251610938 ();
extern "C" void TypeConverterAttribute__cctor_m63856178 ();
extern "C" void TypeConverterAttribute_Equals_m619429225 ();
extern "C" void TypeConverterAttribute_GetHashCode_m3929170352 ();
extern "C" void TypeConverterAttribute_get_ConverterTypeName_m908500315 ();
extern "C" void DefaultUriParser__ctor_m4218342554 ();
extern "C" void DefaultUriParser__ctor_m3423160560 ();
extern "C" void MonoTODOAttribute__ctor_m937077758 ();
extern "C" void MonoTODOAttribute__ctor_m741414698 ();
extern "C" void DefaultCertificatePolicy__ctor_m2926301288 ();
extern "C" void DefaultCertificatePolicy_CheckValidationResult_m675248107 ();
extern "C" void FileWebRequest__ctor_m328140929 ();
extern "C" void FileWebRequest__ctor_m331710361 ();
extern "C" void FileWebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m1090276256 ();
extern "C" void FileWebRequest_GetObjectData_m3786272976 ();
extern "C" void FileWebRequestCreator__ctor_m3382062713 ();
extern "C" void FileWebRequestCreator_Create_m3235750503 ();
extern "C" void FtpRequestCreator__ctor_m1504958891 ();
extern "C" void FtpRequestCreator_Create_m1210584353 ();
extern "C" void FtpWebRequest__ctor_m1716432029 ();
extern "C" void FtpWebRequest__cctor_m614165506 ();
extern "C" void FtpWebRequest_U3CcallbackU3Em__B_m3498702001 ();
extern "C" void GlobalProxySelection_get_Select_m2157273934 ();
extern "C" void HttpRequestCreator__ctor_m3328396086 ();
extern "C" void HttpRequestCreator_Create_m2394659706 ();
extern "C" void HttpVersion__cctor_m3103263600 ();
extern "C" void HttpWebRequest__ctor_m434731781 ();
extern "C" void HttpWebRequest__ctor_m2901044332 ();
extern "C" void HttpWebRequest__cctor_m2685482861 ();
extern "C" void HttpWebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m3676360574 ();
extern "C" void HttpWebRequest_get_Address_m7309902 ();
extern "C" void HttpWebRequest_get_ServicePoint_m720606461 ();
extern "C" void HttpWebRequest_GetServicePoint_m4013005630 ();
extern "C" void HttpWebRequest_GetObjectData_m3141098937 ();
extern "C" void IPAddress__ctor_m2425901205 ();
extern "C" void IPAddress__ctor_m3327862736 ();
extern "C" void IPAddress__cctor_m660017201 ();
extern "C" void IPAddress_SwapShort_m2393026236 ();
extern "C" void IPAddress_HostToNetworkOrder_m1077450846 ();
extern "C" void IPAddress_NetworkToHostOrder_m675703911 ();
extern "C" void IPAddress_Parse_m3574716329 ();
extern "C" void IPAddress_TryParse_m3599578258 ();
extern "C" void IPAddress_ParseIPV4_m2302493237 ();
extern "C" void IPAddress_ParseIPV6_m1754153831 ();
extern "C" void IPAddress_get_InternalIPv4Address_m450045632 ();
extern "C" void IPAddress_get_ScopeId_m3054422697 ();
extern "C" void IPAddress_get_AddressFamily_m3244967048 ();
extern "C" void IPAddress_IsLoopback_m761081390 ();
extern "C" void IPAddress_ToString_m2511897936 ();
extern "C" void IPAddress_ToString_m3324380514 ();
extern "C" void IPAddress_Equals_m1887710285 ();
extern "C" void IPAddress_GetHashCode_m17845621 ();
extern "C" void IPAddress_Hash_m3259784001 ();
extern "C" void IPv6Address__ctor_m3248518714 ();
extern "C" void IPv6Address__ctor_m2257874333 ();
extern "C" void IPv6Address__ctor_m74903806 ();
extern "C" void IPv6Address__cctor_m2752111042 ();
extern "C" void IPv6Address_Parse_m3201407685 ();
extern "C" void IPv6Address_Fill_m4090713947 ();
extern "C" void IPv6Address_TryParse_m1927408658 ();
extern "C" void IPv6Address_TryParse_m3203198026 ();
extern "C" void IPv6Address_get_Address_m3386592422 ();
extern "C" void IPv6Address_get_ScopeId_m1217333468 ();
extern "C" void IPv6Address_set_ScopeId_m319634826 ();
extern "C" void IPv6Address_IsLoopback_m2938267155 ();
extern "C" void IPv6Address_SwapUShort_m2157039462 ();
extern "C" void IPv6Address_AsIPv4Int_m3230172872 ();
extern "C" void IPv6Address_IsIPv4Compatible_m1460932075 ();
extern "C" void IPv6Address_IsIPv4Mapped_m3768654363 ();
extern "C" void IPv6Address_ToString_m2749627050 ();
extern "C" void IPv6Address_ToString_m1655328954 ();
extern "C" void IPv6Address_Equals_m2918345306 ();
extern "C" void IPv6Address_GetHashCode_m65255023 ();
extern "C" void IPv6Address_Hash_m709643461 ();
extern "C" void RemoteCertificateValidationCallback__ctor_m1528111085 ();
extern "C" void RemoteCertificateValidationCallback_Invoke_m522374110 ();
extern "C" void RemoteCertificateValidationCallback_BeginInvoke_m3285627105 ();
extern "C" void RemoteCertificateValidationCallback_EndInvoke_m4104187126 ();
extern "C" void ServicePoint__ctor_m3556548504 ();
extern "C" void ServicePoint_get_Address_m3793322199 ();
extern "C" void ServicePoint_get_CurrentConnections_m1981947194 ();
extern "C" void ServicePoint_get_IdleSince_m739666800 ();
extern "C" void ServicePoint_set_IdleSince_m2595005045 ();
extern "C" void ServicePoint_set_Expect100Continue_m2505370509 ();
extern "C" void ServicePoint_set_UseNagleAlgorithm_m3162047792 ();
extern "C" void ServicePoint_set_SendContinue_m1181690970 ();
extern "C" void ServicePoint_set_UsesProxy_m3283909725 ();
extern "C" void ServicePoint_set_UseConnect_m504286873 ();
extern "C" void ServicePoint_get_AvailableForRecycling_m425308459 ();
extern "C" void ServicePointManager__cctor_m3138212209 ();
extern "C" void ServicePointManager_get_CertificatePolicy_m3822685417 ();
extern "C" void ServicePointManager_get_CheckCertificateRevocationList_m2512216872 ();
extern "C" void ServicePointManager_get_SecurityProtocol_m1618197087 ();
extern "C" void ServicePointManager_get_ServerCertificateValidationCallback_m3949280906 ();
extern "C" void ServicePointManager_FindServicePoint_m1125235358 ();
extern "C" void ServicePointManager_RecycleServicePoints_m2752261321 ();
extern "C" void SPKey__ctor_m732745578 ();
extern "C" void SPKey_GetHashCode_m1429544805 ();
extern "C" void SPKey_Equals_m219844906 ();
extern "C" void WebHeaderCollection__ctor_m3619487727 ();
extern "C" void WebHeaderCollection__ctor_m1059550187 ();
extern "C" void WebHeaderCollection__ctor_m989548309 ();
extern "C" void WebHeaderCollection__cctor_m1613442010 ();
extern "C" void WebHeaderCollection_System_Runtime_Serialization_ISerializable_GetObjectData_m8944261 ();
extern "C" void WebHeaderCollection_Add_m1264164693 ();
extern "C" void WebHeaderCollection_AddWithoutValidate_m606007058 ();
extern "C" void WebHeaderCollection_IsRestricted_m3869734646 ();
extern "C" void WebHeaderCollection_OnDeserialization_m3270564415 ();
extern "C" void WebHeaderCollection_ToString_m391855276 ();
extern "C" void WebHeaderCollection_GetObjectData_m594675392 ();
extern "C" void WebHeaderCollection_get_Count_m2668601130 ();
extern "C" void WebHeaderCollection_get_Keys_m188155367 ();
extern "C" void WebHeaderCollection_Get_m2188960424 ();
extern "C" void WebHeaderCollection_GetKey_m3346270839 ();
extern "C" void WebHeaderCollection_GetEnumerator_m3936804387 ();
extern "C" void WebHeaderCollection_IsHeaderValue_m1333711411 ();
extern "C" void WebHeaderCollection_IsHeaderName_m3456245027 ();
extern "C" void WebProxy__ctor_m748551541 ();
extern "C" void WebProxy__ctor_m4040032087 ();
extern "C" void WebProxy__ctor_m1388018577 ();
extern "C" void WebProxy_System_Runtime_Serialization_ISerializable_GetObjectData_m1601589441 ();
extern "C" void WebProxy_get_UseDefaultCredentials_m3972272783 ();
extern "C" void WebProxy_GetProxy_m2250017237 ();
extern "C" void WebProxy_IsBypassed_m2540390668 ();
extern "C" void WebProxy_GetObjectData_m4048881970 ();
extern "C" void WebProxy_CheckBypassList_m1167118873 ();
extern "C" void WebRequest__ctor_m3085130597 ();
extern "C" void WebRequest__ctor_m3421329469 ();
extern "C" void WebRequest__cctor_m92070379 ();
extern "C" void WebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m1656636354 ();
extern "C" void WebRequest_AddDynamicPrefix_m689243842 ();
extern "C" void WebRequest_GetMustImplement_m395385750 ();
extern "C" void WebRequest_get_DefaultWebProxy_m1862724228 ();
extern "C" void WebRequest_GetDefaultWebProxy_m2436480977 ();
extern "C" void WebRequest_GetObjectData_m1843151265 ();
extern "C" void WebRequest_AddPrefix_m68233748 ();
extern "C" void AsnEncodedData__ctor_m2384778664 ();
extern "C" void AsnEncodedData__ctor_m3737559252 ();
extern "C" void AsnEncodedData__ctor_m3478274676 ();
extern "C" void AsnEncodedData_get_Oid_m1755202606 ();
extern "C" void AsnEncodedData_set_Oid_m428546322 ();
extern "C" void AsnEncodedData_get_RawData_m1941753742 ();
extern "C" void AsnEncodedData_set_RawData_m999695041 ();
extern "C" void AsnEncodedData_CopyFrom_m4129437351 ();
extern "C" void AsnEncodedData_ToString_m3184123992 ();
extern "C" void AsnEncodedData_Default_m2232941155 ();
extern "C" void AsnEncodedData_BasicConstraintsExtension_m3764584996 ();
extern "C" void AsnEncodedData_EnhancedKeyUsageExtension_m3609456747 ();
extern "C" void AsnEncodedData_KeyUsageExtension_m2665418060 ();
extern "C" void AsnEncodedData_SubjectKeyIdentifierExtension_m2350885142 ();
extern "C" void AsnEncodedData_SubjectAltName_m2746612239 ();
extern "C" void AsnEncodedData_NetscapeCertType_m4258108562 ();
extern "C" void Oid__ctor_m1845559200 ();
extern "C" void Oid__ctor_m2872646922 ();
extern "C" void Oid__ctor_m3316546995 ();
extern "C" void Oid__ctor_m3596594614 ();
extern "C" void Oid_get_FriendlyName_m3124218941 ();
extern "C" void Oid_get_Value_m3061680761 ();
extern "C" void Oid_GetName_m3146123539 ();
extern "C" void OidCollection__ctor_m1418041579 ();
extern "C" void OidCollection_System_Collections_ICollection_CopyTo_m1818992363 ();
extern "C" void OidCollection_System_Collections_IEnumerable_GetEnumerator_m2282912456 ();
extern "C" void OidCollection_get_Count_m3550869606 ();
extern "C" void OidCollection_get_Item_m2370418372 ();
extern "C" void OidCollection_get_SyncRoot_m1436628185 ();
extern "C" void OidCollection_Add_m2772445532 ();
extern "C" void OidEnumerator__ctor_m3914047703 ();
extern "C" void OidEnumerator_System_Collections_IEnumerator_get_Current_m3083832048 ();
extern "C" void OidEnumerator_MoveNext_m1204098737 ();
extern "C" void OidEnumerator_Reset_m2338305976 ();
extern "C" void PublicKey__ctor_m3018451802 ();
extern "C" void PublicKey_get_EncodedKeyValue_m839105348 ();
extern "C" void PublicKey_get_EncodedParameters_m221039915 ();
extern "C" void PublicKey_get_Key_m1228042147 ();
extern "C" void PublicKey_get_Oid_m2482011906 ();
extern "C" void PublicKey_GetUnsignedBigInteger_m4097116804 ();
extern "C" void PublicKey_DecodeDSA_m474144981 ();
extern "C" void PublicKey_DecodeRSA_m3080821993 ();
extern "C" void X500DistinguishedName__ctor_m4189237902 ();
extern "C" void X500DistinguishedName_Decode_m3269481422 ();
extern "C" void X500DistinguishedName_GetSeparator_m199732345 ();
extern "C" void X500DistinguishedName_DecodeRawData_m4274092901 ();
extern "C" void X500DistinguishedName_Canonize_m2715628542 ();
extern "C" void X500DistinguishedName_AreEqual_m3439065037 ();
extern "C" void X509BasicConstraintsExtension__ctor_m3473898820 ();
extern "C" void X509BasicConstraintsExtension__ctor_m2800340189 ();
extern "C" void X509BasicConstraintsExtension__ctor_m4111597117 ();
extern "C" void X509BasicConstraintsExtension_get_CertificateAuthority_m4263835909 ();
extern "C" void X509BasicConstraintsExtension_get_HasPathLengthConstraint_m1542188903 ();
extern "C" void X509BasicConstraintsExtension_get_PathLengthConstraint_m573505714 ();
extern "C" void X509BasicConstraintsExtension_CopyFrom_m964409699 ();
extern "C" void X509BasicConstraintsExtension_Decode_m2148167021 ();
extern "C" void X509BasicConstraintsExtension_Encode_m1342427522 ();
extern "C" void X509BasicConstraintsExtension_ToString_m4228051348 ();
extern "C" void X509Certificate2__ctor_m2926745132 ();
extern "C" void X509Certificate2__cctor_m4102588900 ();
extern "C" void X509Certificate2_get_Extensions_m3136800204 ();
extern "C" void X509Certificate2_get_IssuerName_m1608133231 ();
extern "C" void X509Certificate2_get_NotAfter_m1462478161 ();
extern "C" void X509Certificate2_get_NotBefore_m461384883 ();
extern "C" void X509Certificate2_get_PrivateKey_m796288645 ();
extern "C" void X509Certificate2_get_PublicKey_m4121486856 ();
extern "C" void X509Certificate2_get_SerialNumber_m3617614289 ();
extern "C" void X509Certificate2_get_SignatureAlgorithm_m3895449782 ();
extern "C" void X509Certificate2_get_SubjectName_m2101884752 ();
extern "C" void X509Certificate2_get_Thumbprint_m3213978850 ();
extern "C" void X509Certificate2_get_Version_m3742682081 ();
extern "C" void X509Certificate2_GetNameInfo_m808913113 ();
extern "C" void X509Certificate2_Find_m2628184362 ();
extern "C" void X509Certificate2_GetValueAsString_m1803200042 ();
extern "C" void X509Certificate2_ImportPkcs12_m3301136225 ();
extern "C" void X509Certificate2_Import_m3534696989 ();
extern "C" void X509Certificate2_Reset_m1544400693 ();
extern "C" void X509Certificate2_ToString_m1172523465 ();
extern "C" void X509Certificate2_ToString_m932704669 ();
extern "C" void X509Certificate2_AppendBuffer_m4266606259 ();
extern "C" void X509Certificate2_Verify_m284365349 ();
extern "C" void X509Certificate2_get_MonoCertificate_m2373788936 ();
extern "C" void X509Certificate2Collection__ctor_m3365711536 ();
extern "C" void X509Certificate2Collection__ctor_m3624708096 ();
extern "C" void X509Certificate2Collection_get_Item_m3631099683 ();
extern "C" void X509Certificate2Collection_Add_m3021876451 ();
extern "C" void X509Certificate2Collection_AddRange_m3857728710 ();
extern "C" void X509Certificate2Collection_Contains_m67155110 ();
extern "C" void X509Certificate2Collection_Find_m2757621005 ();
extern "C" void X509Certificate2Collection_GetEnumerator_m1569313327 ();
extern "C" void X509Certificate2Enumerator__ctor_m603220320 ();
extern "C" void X509Certificate2Enumerator_System_Collections_IEnumerator_get_Current_m1285802559 ();
extern "C" void X509Certificate2Enumerator_System_Collections_IEnumerator_MoveNext_m1046457630 ();
extern "C" void X509Certificate2Enumerator_System_Collections_IEnumerator_Reset_m1381206356 ();
extern "C" void X509Certificate2Enumerator_get_Current_m312763933 ();
extern "C" void X509Certificate2Enumerator_MoveNext_m4204177854 ();
extern "C" void X509Certificate2Enumerator_Reset_m1366892457 ();
extern "C" void X509CertificateCollection__ctor_m1456408456 ();
extern "C" void X509CertificateCollection__ctor_m3900377825 ();
extern "C" void X509CertificateCollection_get_Item_m3671308570 ();
extern "C" void X509CertificateCollection_AddRange_m2387664531 ();
extern "C" void X509CertificateCollection_GetEnumerator_m3762497105 ();
extern "C" void X509CertificateCollection_GetHashCode_m2514557430 ();
extern "C" void X509CertificateEnumerator__ctor_m481851256 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m3673524984 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m137447140 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m1922725236 ();
extern "C" void X509CertificateEnumerator_get_Current_m2224343874 ();
extern "C" void X509CertificateEnumerator_MoveNext_m3348388573 ();
extern "C" void X509CertificateEnumerator_Reset_m4255168805 ();
extern "C" void X509Chain__ctor_m583237922 ();
extern "C" void X509Chain__ctor_m2382375899 ();
extern "C" void X509Chain__cctor_m1233248096 ();
extern "C" void X509Chain_get_ChainPolicy_m2937769194 ();
extern "C" void X509Chain_Build_m1000713326 ();
extern "C" void X509Chain_Reset_m4098829074 ();
extern "C" void X509Chain_get_Roots_m2087621631 ();
extern "C" void X509Chain_get_CertificateAuthorities_m2477380737 ();
extern "C" void X509Chain_get_CertificateCollection_m2115847340 ();
extern "C" void X509Chain_BuildChainFrom_m3124143205 ();
extern "C" void X509Chain_SelectBestFromCollection_m3351987027 ();
extern "C" void X509Chain_FindParent_m3698810595 ();
extern "C" void X509Chain_IsChainComplete_m703687826 ();
extern "C" void X509Chain_IsSelfIssued_m3689374980 ();
extern "C" void X509Chain_ValidateChain_m2800009862 ();
extern "C" void X509Chain_Process_m283031606 ();
extern "C" void X509Chain_PrepareForNextCertificate_m1627882308 ();
extern "C" void X509Chain_WrapUp_m1733160488 ();
extern "C" void X509Chain_ProcessCertificateExtensions_m4144749770 ();
extern "C" void X509Chain_IsSignedWith_m3777092682 ();
extern "C" void X509Chain_GetSubjectKeyIdentifier_m1066335808 ();
extern "C" void X509Chain_GetAuthorityKeyIdentifier_m2900205621 ();
extern "C" void X509Chain_GetAuthorityKeyIdentifier_m917151907 ();
extern "C" void X509Chain_GetAuthorityKeyIdentifier_m2685749841 ();
extern "C" void X509Chain_CheckRevocationOnChain_m74590067 ();
extern "C" void X509Chain_CheckRevocation_m2066152658 ();
extern "C" void X509Chain_CheckRevocation_m1531381360 ();
extern "C" void X509Chain_FindCrl_m2309199168 ();
extern "C" void X509Chain_ProcessCrlExtensions_m1320700338 ();
extern "C" void X509Chain_ProcessCrlEntryExtensions_m1432454835 ();
extern "C" void X509ChainElement__ctor_m1880580410 ();
extern "C" void X509ChainElement_get_Certificate_m3241871595 ();
extern "C" void X509ChainElement_get_ChainElementStatus_m587278778 ();
extern "C" void X509ChainElement_get_StatusFlags_m229459722 ();
extern "C" void X509ChainElement_set_StatusFlags_m536621046 ();
extern "C" void X509ChainElement_Count_m879236329 ();
extern "C" void X509ChainElement_Set_m3136156342 ();
extern "C" void X509ChainElement_UncompressFlags_m4160750824 ();
extern "C" void X509ChainElementCollection__ctor_m1837933552 ();
extern "C" void X509ChainElementCollection_System_Collections_ICollection_CopyTo_m3057694626 ();
extern "C" void X509ChainElementCollection_System_Collections_IEnumerable_GetEnumerator_m109510445 ();
extern "C" void X509ChainElementCollection_get_Count_m2869759041 ();
extern "C" void X509ChainElementCollection_get_Item_m1081301532 ();
extern "C" void X509ChainElementCollection_get_SyncRoot_m2227897855 ();
extern "C" void X509ChainElementCollection_GetEnumerator_m3169469758 ();
extern "C" void X509ChainElementCollection_Add_m4163208859 ();
extern "C" void X509ChainElementCollection_Clear_m2370058916 ();
extern "C" void X509ChainElementCollection_Contains_m3678300766 ();
extern "C" void X509ChainElementEnumerator__ctor_m3655165220 ();
extern "C" void X509ChainElementEnumerator_System_Collections_IEnumerator_get_Current_m4276540009 ();
extern "C" void X509ChainElementEnumerator_get_Current_m2079232385 ();
extern "C" void X509ChainElementEnumerator_MoveNext_m279597569 ();
extern "C" void X509ChainElementEnumerator_Reset_m1754904740 ();
extern "C" void X509ChainPolicy__ctor_m1621131493 ();
extern "C" void X509ChainPolicy_get_ExtraStore_m3798730679 ();
extern "C" void X509ChainPolicy_get_RevocationFlag_m2578342906 ();
extern "C" void X509ChainPolicy_get_RevocationMode_m108590087 ();
extern "C" void X509ChainPolicy_get_VerificationFlags_m1416596346 ();
extern "C" void X509ChainPolicy_get_VerificationTime_m2471432300 ();
extern "C" void X509ChainPolicy_Reset_m1836143270 ();
extern "C" void X509ChainStatus__ctor_m3018128567_AdjustorThunk ();
extern "C" void X509ChainStatus_get_Status_m2150926311_AdjustorThunk ();
extern "C" void X509ChainStatus_set_Status_m1692295910_AdjustorThunk ();
extern "C" void X509ChainStatus_set_StatusInformation_m1702484074_AdjustorThunk ();
extern "C" void X509ChainStatus_GetInformation_m2234207597 ();
extern "C" void X509EnhancedKeyUsageExtension__ctor_m3260908215 ();
extern "C" void X509EnhancedKeyUsageExtension_CopyFrom_m3929728340 ();
extern "C" void X509EnhancedKeyUsageExtension_Decode_m2745773589 ();
extern "C" void X509EnhancedKeyUsageExtension_ToString_m3220087219 ();
extern "C" void X509Extension__ctor_m2391813590 ();
extern "C" void X509Extension__ctor_m2891239361 ();
extern "C" void X509Extension_get_Critical_m975012775 ();
extern "C" void X509Extension_set_Critical_m3714286755 ();
extern "C" void X509Extension_CopyFrom_m3727910601 ();
extern "C" void X509Extension_FormatUnkownData_m2636613681 ();
extern "C" void X509ExtensionCollection__ctor_m618270890 ();
extern "C" void X509ExtensionCollection_System_Collections_ICollection_CopyTo_m3060354564 ();
extern "C" void X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m384132609 ();
extern "C" void X509ExtensionCollection_get_Count_m1857330339 ();
extern "C" void X509ExtensionCollection_get_SyncRoot_m2596941851 ();
extern "C" void X509ExtensionCollection_get_Item_m3318656216 ();
extern "C" void X509ExtensionCollection_GetEnumerator_m1416980249 ();
extern "C" void X509ExtensionEnumerator__ctor_m48655285 ();
extern "C" void X509ExtensionEnumerator_System_Collections_IEnumerator_get_Current_m1945278316 ();
extern "C" void X509ExtensionEnumerator_get_Current_m4078292627 ();
extern "C" void X509ExtensionEnumerator_MoveNext_m2429627246 ();
extern "C" void X509ExtensionEnumerator_Reset_m3734752993 ();
extern "C" void X509KeyUsageExtension__ctor_m4101631676 ();
extern "C" void X509KeyUsageExtension__ctor_m4002560134 ();
extern "C" void X509KeyUsageExtension__ctor_m942910524 ();
extern "C" void X509KeyUsageExtension_get_KeyUsages_m3406415185 ();
extern "C" void X509KeyUsageExtension_CopyFrom_m1527234626 ();
extern "C" void X509KeyUsageExtension_GetValidFlags_m3365957747 ();
extern "C" void X509KeyUsageExtension_Decode_m2890215189 ();
extern "C" void X509KeyUsageExtension_Encode_m3258780823 ();
extern "C" void X509KeyUsageExtension_ToString_m3524737243 ();
extern "C" void X509Store__ctor_m2254016317 ();
extern "C" void X509Store_get_Certificates_m4064399406 ();
extern "C" void X509Store_get_Factory_m3038371408 ();
extern "C" void X509Store_get_Store_m1972390865 ();
extern "C" void X509Store_Close_m369655280 ();
extern "C" void X509Store_Open_m2021193476 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m3821445495 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m1007866642 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m2481719515 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m2876160692 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m1550638166 ();
extern "C" void X509SubjectKeyIdentifierExtension__ctor_m2033331363 ();
extern "C" void X509SubjectKeyIdentifierExtension_get_SubjectKeyIdentifier_m2217507528 ();
extern "C" void X509SubjectKeyIdentifierExtension_CopyFrom_m2942703343 ();
extern "C" void X509SubjectKeyIdentifierExtension_FromHexChar_m2113243667 ();
extern "C" void X509SubjectKeyIdentifierExtension_FromHexChars_m1282499442 ();
extern "C" void X509SubjectKeyIdentifierExtension_FromHex_m3075151455 ();
extern "C" void X509SubjectKeyIdentifierExtension_Decode_m813371828 ();
extern "C" void X509SubjectKeyIdentifierExtension_Encode_m558430525 ();
extern "C" void X509SubjectKeyIdentifierExtension_ToString_m3894933131 ();
extern "C" void BaseMachine__ctor_m4084020858 ();
extern "C" void BaseMachine_Scan_m3268312916 ();
extern "C" void Capture__ctor_m3641620806 ();
extern "C" void Capture__ctor_m1068818810 ();
extern "C" void Capture_get_Index_m338765806 ();
extern "C" void Capture_get_Length_m2890330190 ();
extern "C" void Capture_get_Value_m4065226265 ();
extern "C" void Capture_ToString_m1617592058 ();
extern "C" void Capture_get_Text_m999705200 ();
extern "C" void CaptureCollection__ctor_m2434469797 ();
extern "C" void CaptureCollection_get_Count_m2620041631 ();
extern "C" void CaptureCollection_SetValue_m3580350314 ();
extern "C" void CaptureCollection_get_SyncRoot_m1235288200 ();
extern "C" void CaptureCollection_CopyTo_m476172626 ();
extern "C" void CaptureCollection_GetEnumerator_m2751155309 ();
extern "C" void CategoryUtils_CategoryFromName_m3454984674 ();
extern "C" void CategoryUtils_IsCategory_m1954085905 ();
extern "C" void CategoryUtils_IsCategory_m1631542215 ();
extern "C" void FactoryCache__ctor_m3110918728 ();
extern "C" void FactoryCache_Add_m333224650 ();
extern "C" void FactoryCache_Cleanup_m2321743382 ();
extern "C" void FactoryCache_Lookup_m1107376873 ();
extern "C" void Key__ctor_m3271912660 ();
extern "C" void Key_GetHashCode_m4029769586 ();
extern "C" void Key_Equals_m2944673701 ();
extern "C" void Key_ToString_m1916919406 ();
extern "C" void Group__ctor_m1581832311 ();
extern "C" void Group__ctor_m1380117201 ();
extern "C" void Group__ctor_m974563356 ();
extern "C" void Group__cctor_m745321436 ();
extern "C" void Group_get_Captures_m3811459642 ();
extern "C" void Group_get_Success_m2194759106 ();
extern "C" void GroupCollection__ctor_m3960019923 ();
extern "C" void GroupCollection_get_Count_m1310531683 ();
extern "C" void GroupCollection_get_Item_m1153500950 ();
extern "C" void GroupCollection_SetValue_m3255312432 ();
extern "C" void GroupCollection_get_SyncRoot_m2726667879 ();
extern "C" void GroupCollection_CopyTo_m4209509466 ();
extern "C" void GroupCollection_GetEnumerator_m2022831241 ();
extern "C" void Interpreter__ctor_m804634620 ();
extern "C" void Interpreter_ReadProgramCount_m1005652950 ();
extern "C" void Interpreter_Scan_m2287197984 ();
extern "C" void Interpreter_Reset_m1045573326 ();
extern "C" void Interpreter_Eval_m1396764476 ();
extern "C" void Interpreter_EvalChar_m3505508938 ();
extern "C" void Interpreter_TryMatch_m3206370614 ();
extern "C" void Interpreter_IsPosition_m2416589926 ();
extern "C" void Interpreter_IsWordChar_m1078367919 ();
extern "C" void Interpreter_GetString_m1446051119 ();
extern "C" void Interpreter_Open_m2367898279 ();
extern "C" void Interpreter_Close_m3231684097 ();
extern "C" void Interpreter_Balance_m1823429025 ();
extern "C" void Interpreter_Checkpoint_m484310107 ();
extern "C" void Interpreter_Backtrack_m4289283913 ();
extern "C" void Interpreter_ResetGroups_m4240955779 ();
extern "C" void Interpreter_GetLastDefined_m452748063 ();
extern "C" void Interpreter_CreateMark_m2754475756 ();
extern "C" void Interpreter_GetGroupInfo_m615692711 ();
extern "C" void Interpreter_PopulateGroup_m4206034385 ();
extern "C" void Interpreter_GenerateMatch_m2660368459 ();
extern "C" void IntStack_Pop_m3722683769_AdjustorThunk ();
extern "C" void IntStack_Push_m1635691781_AdjustorThunk ();
extern "C" void IntStack_get_Count_m3039047661_AdjustorThunk ();
extern "C" void IntStack_set_Count_m2003476785_AdjustorThunk ();
extern "C" void RepeatContext__ctor_m2229900814 ();
extern "C" void RepeatContext_get_Count_m2181802077 ();
extern "C" void RepeatContext_set_Count_m2572177685 ();
extern "C" void RepeatContext_get_Start_m1293738790 ();
extern "C" void RepeatContext_set_Start_m990883173 ();
extern "C" void RepeatContext_get_IsMinimum_m1953926463 ();
extern "C" void RepeatContext_get_IsMaximum_m1324672030 ();
extern "C" void RepeatContext_get_IsLazy_m2930525391 ();
extern "C" void RepeatContext_get_Expression_m3316144173 ();
extern "C" void RepeatContext_get_Previous_m1045665069 ();
extern "C" void InterpreterFactory__ctor_m3863904418 ();
extern "C" void InterpreterFactory_NewInstance_m2528127587 ();
extern "C" void InterpreterFactory_get_GroupCount_m98333284 ();
extern "C" void InterpreterFactory_get_Gap_m2707604386 ();
extern "C" void InterpreterFactory_set_Gap_m3151466641 ();
extern "C" void InterpreterFactory_get_Mapping_m3535354017 ();
extern "C" void InterpreterFactory_set_Mapping_m166844383 ();
extern "C" void InterpreterFactory_get_NamesMapping_m2772135229 ();
extern "C" void InterpreterFactory_set_NamesMapping_m3924398020 ();
extern "C" void Interval__ctor_m56080377_AdjustorThunk ();
extern "C" void Interval_get_Empty_m243986300 ();
extern "C" void Interval_get_IsDiscontiguous_m801604911_AdjustorThunk ();
extern "C" void Interval_get_IsSingleton_m4216198275_AdjustorThunk ();
extern "C" void Interval_get_IsEmpty_m994480924_AdjustorThunk ();
extern "C" void Interval_get_Size_m608071487_AdjustorThunk ();
extern "C" void Interval_IsDisjoint_m2524723846_AdjustorThunk ();
extern "C" void Interval_IsAdjacent_m2556513672_AdjustorThunk ();
extern "C" void Interval_Contains_m1571606611_AdjustorThunk ();
extern "C" void Interval_Contains_m3342353116_AdjustorThunk ();
extern "C" void Interval_Intersects_m3216855994_AdjustorThunk ();
extern "C" void Interval_Merge_m2946312130_AdjustorThunk ();
extern "C" void Interval_CompareTo_m3815929644_AdjustorThunk ();
extern "C" void IntervalCollection__ctor_m1313218258 ();
extern "C" void IntervalCollection_get_Item_m2537028855 ();
extern "C" void IntervalCollection_Add_m1622943099 ();
extern "C" void IntervalCollection_Normalize_m3628515323 ();
extern "C" void IntervalCollection_GetMetaCollection_m1648565138 ();
extern "C" void IntervalCollection_Optimize_m2102410078 ();
extern "C" void IntervalCollection_get_Count_m1214350167 ();
extern "C" void IntervalCollection_get_SyncRoot_m2297894933 ();
extern "C" void IntervalCollection_CopyTo_m2391624220 ();
extern "C" void IntervalCollection_GetEnumerator_m1462566 ();
extern "C" void CostDelegate__ctor_m1641520847 ();
extern "C" void CostDelegate_Invoke_m2352390745 ();
extern "C" void CostDelegate_BeginInvoke_m4143628807 ();
extern "C" void CostDelegate_EndInvoke_m2898868193 ();
extern "C" void Enumerator__ctor_m731076298 ();
extern "C" void Enumerator_get_Current_m400005700 ();
extern "C" void Enumerator_MoveNext_m621925305 ();
extern "C" void Enumerator_Reset_m1187950456 ();
extern "C" void LinkRef__ctor_m115717970 ();
extern "C" void LinkStack__ctor_m3590709140 ();
extern "C" void LinkStack_Push_m1643249603 ();
extern "C" void LinkStack_Pop_m2631501487 ();
extern "C" void Mark_get_IsDefined_m3052049299_AdjustorThunk ();
extern "C" void Mark_get_Index_m3778528825_AdjustorThunk ();
extern "C" void Mark_get_Length_m1936833463_AdjustorThunk ();
extern "C" void Match__ctor_m4138167299 ();
extern "C" void Match__ctor_m1230053901 ();
extern "C" void Match__ctor_m4092008910 ();
extern "C" void Match__cctor_m950904057 ();
extern "C" void Match_get_Empty_m2989863553 ();
extern "C" void Match_get_Groups_m2472995486 ();
extern "C" void Match_NextMatch_m2724645654 ();
extern "C" void Match_get_Regex_m3430681050 ();
extern "C" void MatchCollection__ctor_m3291470240 ();
extern "C" void MatchCollection_get_Count_m1252685359 ();
extern "C" void MatchCollection_get_Item_m1236870324 ();
extern "C" void MatchCollection_get_SyncRoot_m4141550550 ();
extern "C" void MatchCollection_CopyTo_m3356170189 ();
extern "C" void MatchCollection_GetEnumerator_m42466798 ();
extern "C" void MatchCollection_TryToGet_m1484228680 ();
extern "C" void MatchCollection_get_FullList_m501322905 ();
extern "C" void Enumerator__ctor_m4142914143 ();
extern "C" void Enumerator_System_Collections_IEnumerator_Reset_m41729423 ();
extern "C" void Enumerator_System_Collections_IEnumerator_get_Current_m3948877931 ();
extern "C" void Enumerator_System_Collections_IEnumerator_MoveNext_m2284117019 ();
extern "C" void MRUList__ctor_m1781461164 ();
extern "C" void MRUList_Use_m1901538896 ();
extern "C" void MRUList_Evict_m1764791586 ();
extern "C" void Node__ctor_m2776986241 ();
extern "C" void PatternCompiler__ctor_m410115436 ();
extern "C" void PatternCompiler_EncodeOp_m2901316554 ();
extern "C" void PatternCompiler_GetMachineFactory_m2648131593 ();
extern "C" void PatternCompiler_EmitFalse_m2640584393 ();
extern "C" void PatternCompiler_EmitTrue_m1022795498 ();
extern "C" void PatternCompiler_EmitCount_m3294248707 ();
extern "C" void PatternCompiler_EmitCharacter_m2653938343 ();
extern "C" void PatternCompiler_EmitCategory_m2518950337 ();
extern "C" void PatternCompiler_EmitNotCategory_m1071501134 ();
extern "C" void PatternCompiler_EmitRange_m2459956573 ();
extern "C" void PatternCompiler_EmitSet_m1062023712 ();
extern "C" void PatternCompiler_EmitString_m1185175630 ();
extern "C" void PatternCompiler_EmitPosition_m1696976247 ();
extern "C" void PatternCompiler_EmitOpen_m592558635 ();
extern "C" void PatternCompiler_EmitClose_m1170569105 ();
extern "C" void PatternCompiler_EmitBalanceStart_m2601415548 ();
extern "C" void PatternCompiler_EmitBalance_m4112245197 ();
extern "C" void PatternCompiler_EmitReference_m3950472736 ();
extern "C" void PatternCompiler_EmitIfDefined_m3742773374 ();
extern "C" void PatternCompiler_EmitSub_m1489955558 ();
extern "C" void PatternCompiler_EmitTest_m2939752100 ();
extern "C" void PatternCompiler_EmitBranch_m943585207 ();
extern "C" void PatternCompiler_EmitJump_m3344301169 ();
extern "C" void PatternCompiler_EmitRepeat_m1500105114 ();
extern "C" void PatternCompiler_EmitUntil_m2024071189 ();
extern "C" void PatternCompiler_EmitFastRepeat_m3606913334 ();
extern "C" void PatternCompiler_EmitIn_m3864996455 ();
extern "C" void PatternCompiler_EmitAnchor_m2942110370 ();
extern "C" void PatternCompiler_EmitInfo_m2366746382 ();
extern "C" void PatternCompiler_NewLink_m647017702 ();
extern "C" void PatternCompiler_ResolveLink_m1268480421 ();
extern "C" void PatternCompiler_EmitBranchEnd_m1675597919 ();
extern "C" void PatternCompiler_EmitAlternationEnd_m3445383137 ();
extern "C" void PatternCompiler_MakeFlags_m4079825653 ();
extern "C" void PatternCompiler_Emit_m1702133176 ();
extern "C" void PatternCompiler_Emit_m3786016948 ();
extern "C" void PatternCompiler_Emit_m970277532 ();
extern "C" void PatternCompiler_get_CurrentAddress_m1636342801 ();
extern "C" void PatternCompiler_BeginLink_m3756888575 ();
extern "C" void PatternCompiler_EmitLink_m668125758 ();
extern "C" void PatternLinkStack__ctor_m3478661650 ();
extern "C" void PatternLinkStack_set_BaseAddress_m2740867805 ();
extern "C" void PatternLinkStack_get_OffsetAddress_m2597479309 ();
extern "C" void PatternLinkStack_set_OffsetAddress_m843732842 ();
extern "C" void PatternLinkStack_GetOffset_m3240753922 ();
extern "C" void PatternLinkStack_GetCurrent_m3801736097 ();
extern "C" void PatternLinkStack_SetCurrent_m1220160224 ();
extern "C" void QuickSearch__ctor_m4059767917 ();
extern "C" void QuickSearch__cctor_m2344235813 ();
extern "C" void QuickSearch_get_Length_m399794991 ();
extern "C" void QuickSearch_Search_m515408899 ();
extern "C" void QuickSearch_SetupShiftTable_m858007187 ();
extern "C" void QuickSearch_GetShiftDistance_m12615168 ();
extern "C" void QuickSearch_GetChar_m4230039001 ();
extern "C" void Regex__ctor_m2152913977 ();
extern "C" void Regex__ctor_m1710967937 ();
extern "C" void Regex__ctor_m3286392212 ();
extern "C" void Regex__ctor_m349172803 ();
extern "C" void Regex__cctor_m297163374 ();
extern "C" void Regex_System_Runtime_Serialization_ISerializable_GetObjectData_m4270565887 ();
extern "C" void Regex_validate_options_m3934692030 ();
extern "C" void Regex_Init_m2144493458 ();
extern "C" void Regex_InitNewRegex_m778207142 ();
extern "C" void Regex_CreateMachineFactory_m3188339410 ();
extern "C" void Regex_get_Options_m2702568210 ();
extern "C" void Regex_get_RightToLeft_m391807453 ();
extern "C" void Regex_GetGroupIndex_m1445574727 ();
extern "C" void Regex_default_startat_m3082441407 ();
extern "C" void Regex_IsMatch_m2092521843 ();
extern "C" void Regex_IsMatch_m3684892322 ();
extern "C" void Regex_Match_m1845182378 ();
extern "C" void Regex_Matches_m145108686 ();
extern "C" void Regex_Matches_m2227589686 ();
extern "C" void Regex_ToString_m1187978950 ();
extern "C" void Regex_get_Gap_m3479581456 ();
extern "C" void Regex_CreateMachine_m1313339656 ();
extern "C" void Regex_GetGroupNamesArray_m1682668965 ();
extern "C" void Regex_get_GroupNumbers_m770788777 ();
extern "C" void Alternation__ctor_m1928818157 ();
extern "C" void Alternation_get_Alternatives_m1120962893 ();
extern "C" void Alternation_AddAlternative_m1617589135 ();
extern "C" void Alternation_Compile_m20073373 ();
extern "C" void Alternation_GetWidth_m1207664397 ();
extern "C" void AnchorInfo__ctor_m824858336 ();
extern "C" void AnchorInfo__ctor_m2851148696 ();
extern "C" void AnchorInfo__ctor_m1473803883 ();
extern "C" void AnchorInfo_get_Offset_m1319987204 ();
extern "C" void AnchorInfo_get_Width_m493853670 ();
extern "C" void AnchorInfo_get_Length_m1465965650 ();
extern "C" void AnchorInfo_get_IsUnknownWidth_m662726343 ();
extern "C" void AnchorInfo_get_IsComplete_m1743357072 ();
extern "C" void AnchorInfo_get_Substring_m1684539014 ();
extern "C" void AnchorInfo_get_IgnoreCase_m437969666 ();
extern "C" void AnchorInfo_get_Position_m3190094805 ();
extern "C" void AnchorInfo_get_IsSubstring_m4002693124 ();
extern "C" void AnchorInfo_get_IsPosition_m3021919887 ();
extern "C" void AnchorInfo_GetInterval_m2655761101 ();
extern "C" void Assertion__ctor_m398595606 ();
extern "C" void Assertion_get_TrueExpression_m2259873105 ();
extern "C" void Assertion_set_TrueExpression_m1985969396 ();
extern "C" void Assertion_get_FalseExpression_m330764519 ();
extern "C" void Assertion_set_FalseExpression_m3409248562 ();
extern "C" void Assertion_GetWidth_m1502322795 ();
extern "C" void BackslashNumber__ctor_m3447276269 ();
extern "C" void BackslashNumber_ResolveReference_m3158307001 ();
extern "C" void BackslashNumber_Compile_m984574971 ();
extern "C" void BalancingGroup__ctor_m2831526052 ();
extern "C" void BalancingGroup_set_Balance_m1137491036 ();
extern "C" void BalancingGroup_Compile_m722938181 ();
extern "C" void CaptureAssertion__ctor_m3123794115 ();
extern "C" void CaptureAssertion_set_CapturingGroup_m973632836 ();
extern "C" void CaptureAssertion_Compile_m2292386304 ();
extern "C" void CaptureAssertion_IsComplex_m859291764 ();
extern "C" void CaptureAssertion_get_Alternate_m3292690552 ();
extern "C" void CapturingGroup__ctor_m1629266381 ();
extern "C" void CapturingGroup_get_Index_m106793448 ();
extern "C" void CapturingGroup_set_Index_m1742842172 ();
extern "C" void CapturingGroup_get_Name_m363976611 ();
extern "C" void CapturingGroup_set_Name_m2976480153 ();
extern "C" void CapturingGroup_get_IsNamed_m3740804414 ();
extern "C" void CapturingGroup_Compile_m2827666078 ();
extern "C" void CapturingGroup_IsComplex_m1142236473 ();
extern "C" void CapturingGroup_CompareTo_m1522854790 ();
extern "C" void CharacterClass__ctor_m887051867 ();
extern "C" void CharacterClass__ctor_m2813845994 ();
extern "C" void CharacterClass__cctor_m395790389 ();
extern "C" void CharacterClass_AddCategory_m3684686996 ();
extern "C" void CharacterClass_AddCharacter_m3247269656 ();
extern "C" void CharacterClass_AddRange_m305568238 ();
extern "C" void CharacterClass_Compile_m1290198257 ();
extern "C" void CharacterClass_GetWidth_m656030323 ();
extern "C" void CharacterClass_IsComplex_m3098294588 ();
extern "C" void CharacterClass_GetIntervalCost_m2101477823 ();
extern "C" void CompositeExpression__ctor_m1934809119 ();
extern "C" void CompositeExpression_get_Expressions_m49895278 ();
extern "C" void CompositeExpression_GetWidth_m1995740879 ();
extern "C" void CompositeExpression_IsComplex_m1142190359 ();
extern "C" void Expression__ctor_m2833584603 ();
extern "C" void Expression_GetFixedWidth_m1958842952 ();
extern "C" void Expression_GetAnchorInfo_m2896655711 ();
extern "C" void ExpressionAssertion__ctor_m3257347577 ();
extern "C" void ExpressionAssertion_set_Reverse_m518904159 ();
extern "C" void ExpressionAssertion_set_Negate_m2956012353 ();
extern "C" void ExpressionAssertion_get_TestExpression_m1394104218 ();
extern "C" void ExpressionAssertion_set_TestExpression_m3171393795 ();
extern "C" void ExpressionAssertion_Compile_m2065362775 ();
extern "C" void ExpressionAssertion_IsComplex_m4133577483 ();
extern "C" void ExpressionCollection__ctor_m1397747210 ();
extern "C" void ExpressionCollection_Add_m1497088939 ();
extern "C" void ExpressionCollection_get_Item_m3015047122 ();
extern "C" void ExpressionCollection_set_Item_m899574536 ();
extern "C" void ExpressionCollection_OnValidate_m834765135 ();
extern "C" void Group__ctor_m3448404732 ();
extern "C" void Group_AppendExpression_m755733818 ();
extern "C" void Group_Compile_m534411174 ();
extern "C" void Group_GetWidth_m511968788 ();
extern "C" void Group_GetAnchorInfo_m3709280256 ();
extern "C" void Literal__ctor_m3783101682 ();
extern "C" void Literal_CompileLiteral_m467234476 ();
extern "C" void Literal_Compile_m3984565343 ();
extern "C" void Literal_GetWidth_m4116851574 ();
extern "C" void Literal_GetAnchorInfo_m3654853643 ();
extern "C" void Literal_IsComplex_m1701526983 ();
extern "C" void NonBacktrackingGroup__ctor_m1434515617 ();
extern "C" void NonBacktrackingGroup_Compile_m15580587 ();
extern "C" void NonBacktrackingGroup_IsComplex_m3028987305 ();
extern "C" void Parser__ctor_m1624682398 ();
extern "C" void Parser_ParseDecimal_m2165142223 ();
extern "C" void Parser_ParseOctal_m1575012645 ();
extern "C" void Parser_ParseHex_m537456312 ();
extern "C" void Parser_ParseNumber_m3552252646 ();
extern "C" void Parser_ParseName_m3162581411 ();
extern "C" void Parser_ParseRegularExpression_m1535595762 ();
extern "C" void Parser_GetMapping_m3031693366 ();
extern "C" void Parser_ParseGroup_m3055023692 ();
extern "C" void Parser_ParseGroupingConstruct_m3582473049 ();
extern "C" void Parser_ParseAssertionType_m3369870575 ();
extern "C" void Parser_ParseOptions_m1380880684 ();
extern "C" void Parser_ParseCharacterClass_m94403723 ();
extern "C" void Parser_ParseRepetitionBounds_m310221816 ();
extern "C" void Parser_ParseUnicodeCategory_m3196734900 ();
extern "C" void Parser_ParseSpecial_m841116392 ();
extern "C" void Parser_ParseEscape_m857679945 ();
extern "C" void Parser_ParseName_m2170905461 ();
extern "C" void Parser_IsNameChar_m2317119264 ();
extern "C" void Parser_ParseNumber_m655594974 ();
extern "C" void Parser_ParseDigit_m3652462519 ();
extern "C" void Parser_ConsumeWhitespace_m508757941 ();
extern "C" void Parser_ResolveReferences_m2213940638 ();
extern "C" void Parser_HandleExplicitNumericGroups_m3519363816 ();
extern "C" void Parser_IsIgnoreCase_m304301899 ();
extern "C" void Parser_IsMultiline_m3866250345 ();
extern "C" void Parser_IsExplicitCapture_m1338376295 ();
extern "C" void Parser_IsSingleline_m1052655427 ();
extern "C" void Parser_IsIgnorePatternWhitespace_m3572327486 ();
extern "C" void Parser_IsECMAScript_m1081327743 ();
extern "C" void Parser_NewParseException_m1848723036 ();
extern "C" void PositionAssertion__ctor_m2403739134 ();
extern "C" void PositionAssertion_Compile_m1316517346 ();
extern "C" void PositionAssertion_GetWidth_m3342085669 ();
extern "C" void PositionAssertion_IsComplex_m709315024 ();
extern "C" void PositionAssertion_GetAnchorInfo_m2632727543 ();
extern "C" void Reference__ctor_m1535544569 ();
extern "C" void Reference_get_CapturingGroup_m1229793376 ();
extern "C" void Reference_set_CapturingGroup_m2320303589 ();
extern "C" void Reference_get_IgnoreCase_m1970330033 ();
extern "C" void Reference_Compile_m1360992492 ();
extern "C" void Reference_GetWidth_m3585605624 ();
extern "C" void Reference_IsComplex_m3217857356 ();
extern "C" void RegularExpression__ctor_m4104829235 ();
extern "C" void RegularExpression_set_GroupCount_m257952646 ();
extern "C" void RegularExpression_Compile_m3503254582 ();
extern "C" void Repetition__ctor_m894351731 ();
extern "C" void Repetition_get_Expression_m3416660833 ();
extern "C" void Repetition_set_Expression_m1682832613 ();
extern "C" void Repetition_get_Minimum_m3382307448 ();
extern "C" void Repetition_Compile_m3524912164 ();
extern "C" void Repetition_GetWidth_m1885879497 ();
extern "C" void Repetition_GetAnchorInfo_m1246107493 ();
extern "C" void Uri__ctor_m3348164601 ();
extern "C" void Uri__ctor_m3232901013 ();
extern "C" void Uri__ctor_m1296127773 ();
extern "C" void Uri__ctor_m1252356203 ();
extern "C" void Uri__ctor_m3676275920 ();
extern "C" void Uri__cctor_m670386229 ();
extern "C" void Uri_System_Runtime_Serialization_ISerializable_GetObjectData_m1787623764 ();
extern "C" void Uri_Merge_m3329659150 ();
extern "C" void Uri_get_AbsoluteUri_m2013121997 ();
extern "C" void Uri_get_Authority_m2303303812 ();
extern "C" void Uri_get_Host_m2432049313 ();
extern "C" void Uri_get_IsFile_m3505615125 ();
extern "C" void Uri_get_IsLoopback_m4019510841 ();
extern "C" void Uri_get_IsUnc_m3264105637 ();
extern "C" void Uri_get_Scheme_m3469071689 ();
extern "C" void Uri_get_IsAbsoluteUri_m139224931 ();
extern "C" void Uri_get_OriginalString_m3905916304 ();
extern "C" void Uri_CheckHostName_m858702357 ();
extern "C" void Uri_IsIPv4Address_m3276606606 ();
extern "C" void Uri_IsDomainAddress_m1246829380 ();
extern "C" void Uri_CheckSchemeName_m4037918197 ();
extern "C" void Uri_IsAlpha_m1200488333 ();
extern "C" void Uri_Equals_m2284165007 ();
extern "C" void Uri_InternalEquals_m3302240146 ();
extern "C" void Uri_GetHashCode_m1596773147 ();
extern "C" void Uri_GetLeftPart_m86636703 ();
extern "C" void Uri_FromHex_m3563680093 ();
extern "C" void Uri_HexEscape_m3670676588 ();
extern "C" void Uri_IsHexDigit_m4143014970 ();
extern "C" void Uri_IsHexEncoding_m846496275 ();
extern "C" void Uri_AppendQueryAndFragment_m770779446 ();
extern "C" void Uri_ToString_m3161250604 ();
extern "C" void Uri_EscapeString_m3040128922 ();
extern "C" void Uri_EscapeString_m2069814481 ();
extern "C" void Uri_ParseUri_m2241113980 ();
extern "C" void Uri_Unescape_m772995138 ();
extern "C" void Uri_Unescape_m247455015 ();
extern "C" void Uri_ParseAsWindowsUNC_m4171604414 ();
extern "C" void Uri_ParseAsWindowsAbsoluteFilePath_m239351627 ();
extern "C" void Uri_ParseAsUnixAbsoluteFilePath_m685806022 ();
extern "C" void Uri_Parse_m1835669794 ();
extern "C" void Uri_ParseNoExceptions_m939127859 ();
extern "C" void Uri_CompactEscaped_m1802822627 ();
extern "C" void Uri_Reduce_m2274440801 ();
extern "C" void Uri_HexUnescapeMultiByte_m1299350805 ();
extern "C" void Uri_GetSchemeDelimiter_m1906926383 ();
extern "C" void Uri_GetDefaultPort_m1490273727 ();
extern "C" void Uri_GetOpaqueWiseSchemeDelimiter_m695787016 ();
extern "C" void Uri_IsPredefinedScheme_m1610104302 ();
extern "C" void Uri_get_Parser_m4049015381 ();
extern "C" void Uri_EnsureAbsoluteUri_m3222131342 ();
extern "C" void Uri_op_Equality_m2744738567 ();
extern "C" void UriScheme__ctor_m490875041_AdjustorThunk ();
extern "C" void UriFormatException__ctor_m1696921716 ();
extern "C" void UriFormatException__ctor_m24411027 ();
extern "C" void UriFormatException__ctor_m814282742 ();
extern "C" void UriFormatException_System_Runtime_Serialization_ISerializable_GetObjectData_m2999057613 ();
extern "C" void UriParser__ctor_m1773679871 ();
extern "C" void UriParser__cctor_m1593326550 ();
extern "C" void UriParser_InitializeAndValidate_m1248295043 ();
extern "C" void UriParser_OnRegister_m3840206273 ();
extern "C" void UriParser_set_SchemeName_m3234468530 ();
extern "C" void UriParser_get_DefaultPort_m1674135503 ();
extern "C" void UriParser_set_DefaultPort_m1715738360 ();
extern "C" void UriParser_CreateDefaults_m2561524976 ();
extern "C" void UriParser_InternalRegister_m3668852610 ();
extern "C" void UriParser_GetParser_m2093785923 ();
extern "C" void Locale_GetText_m942401560 ();
extern "C" void BigInteger__ctor_m3040047200 ();
extern "C" void BigInteger__ctor_m4290790657 ();
extern "C" void BigInteger__ctor_m3107529596 ();
extern "C" void BigInteger__ctor_m2655203050 ();
extern "C" void BigInteger__ctor_m2947591044 ();
extern "C" void BigInteger__cctor_m925432748 ();
extern "C" void BigInteger_get_Rng_m1252581024 ();
extern "C" void BigInteger_GenerateRandom_m238978006 ();
extern "C" void BigInteger_GenerateRandom_m2624136324 ();
extern "C" void BigInteger_BitCount_m4273960697 ();
extern "C" void BigInteger_TestBit_m3127499382 ();
extern "C" void BigInteger_SetBit_m1548788441 ();
extern "C" void BigInteger_SetBit_m2995356053 ();
extern "C" void BigInteger_LowestSetBit_m1562554553 ();
extern "C" void BigInteger_GetBytes_m828519052 ();
extern "C" void BigInteger_ToString_m974324122 ();
extern "C" void BigInteger_ToString_m2613494688 ();
extern "C" void BigInteger_Normalize_m1168693604 ();
extern "C" void BigInteger_Clear_m1006056064 ();
extern "C" void BigInteger_GetHashCode_m2499559039 ();
extern "C" void BigInteger_ToString_m1423031679 ();
extern "C" void BigInteger_Equals_m1747576300 ();
extern "C" void BigInteger_ModInverse_m2074417766 ();
extern "C" void BigInteger_ModPow_m2422803179 ();
extern "C" void BigInteger_GeneratePseudoPrime_m3903026346 ();
extern "C" void BigInteger_Incr2_m2993801397 ();
extern "C" void BigInteger_op_Implicit_m1053202820 ();
extern "C" void BigInteger_op_Implicit_m2599149503 ();
extern "C" void BigInteger_op_Addition_m4246822083 ();
extern "C" void BigInteger_op_Subtraction_m2921645157 ();
extern "C" void BigInteger_op_Modulus_m1699883937 ();
extern "C" void BigInteger_op_Modulus_m2023755691 ();
extern "C" void BigInteger_op_Division_m1613931499 ();
extern "C" void BigInteger_op_Multiply_m714911343 ();
extern "C" void BigInteger_op_LeftShift_m4103973491 ();
extern "C" void BigInteger_op_RightShift_m3299250634 ();
extern "C" void BigInteger_op_Equality_m294921050 ();
extern "C" void BigInteger_op_Inequality_m1285189855 ();
extern "C" void BigInteger_op_Equality_m850722513 ();
extern "C" void BigInteger_op_Inequality_m4114052575 ();
extern "C" void BigInteger_op_GreaterThan_m81356145 ();
extern "C" void BigInteger_op_LessThan_m646428307 ();
extern "C" void BigInteger_op_GreaterThanOrEqual_m3156148447 ();
extern "C" void BigInteger_op_LessThanOrEqual_m3140405012 ();
extern "C" void Kernel_AddSameSign_m2969372982 ();
extern "C" void Kernel_Subtract_m1106059469 ();
extern "C" void Kernel_MinusEq_m3085426594 ();
extern "C" void Kernel_PlusEq_m3851100234 ();
extern "C" void Kernel_Compare_m334500803 ();
extern "C" void Kernel_SingleByteDivideInPlace_m1500186441 ();
extern "C" void Kernel_DwordMod_m4269311808 ();
extern "C" void Kernel_DwordDivMod_m4023601570 ();
extern "C" void Kernel_multiByteDivide_m760606649 ();
extern "C" void Kernel_LeftShift_m1732871444 ();
extern "C" void Kernel_RightShift_m4142931590 ();
extern "C" void Kernel_Multiply_m1928927344 ();
extern "C" void Kernel_MultiplyMod2p32pmod_m2454258067 ();
extern "C" void Kernel_modInverse_m1415510529 ();
extern "C" void Kernel_modInverse_m3659691283 ();
extern "C" void ModulusRing__ctor_m786617357 ();
extern "C" void ModulusRing_BarrettReduction_m1658994967 ();
extern "C" void ModulusRing_Multiply_m1279044268 ();
extern "C" void ModulusRing_Difference_m1148123159 ();
extern "C" void ModulusRing_Pow_m3336321534 ();
extern "C" void ModulusRing_Pow_m4156652970 ();
extern "C" void PrimeGeneratorBase__ctor_m2461768112 ();
extern "C" void PrimeGeneratorBase_get_Confidence_m430559964 ();
extern "C" void PrimeGeneratorBase_get_PrimalityTest_m1500128059 ();
extern "C" void PrimeGeneratorBase_get_TrialDivisionBounds_m2021639477 ();
extern "C" void SequentialSearchPrimeGeneratorBase__ctor_m1926266009 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateSearchBase_m1640156251 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m616189243 ();
extern "C" void SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m1410289324 ();
extern "C" void SequentialSearchPrimeGeneratorBase_IsPrimeAcceptable_m4283101715 ();
extern "C" void PrimalityTest__ctor_m1649143675 ();
extern "C" void PrimalityTest_Invoke_m2505690669 ();
extern "C" void PrimalityTest_BeginInvoke_m4252933746 ();
extern "C" void PrimalityTest_EndInvoke_m2207734714 ();
extern "C" void PrimalityTests_GetSPPRounds_m3858806831 ();
extern "C" void PrimalityTests_RabinMillerTest_m3372622796 ();
extern "C" void ASN1__ctor_m1530949167 ();
extern "C" void ASN1__ctor_m2207550225 ();
extern "C" void ASN1__ctor_m663943558 ();
extern "C" void ASN1_get_Count_m3514133667 ();
extern "C" void ASN1_get_Tag_m671763313 ();
extern "C" void ASN1_get_Length_m3357792533 ();
extern "C" void ASN1_get_Value_m1563037521 ();
extern "C" void ASN1_set_Value_m3219014527 ();
extern "C" void ASN1_CompareArray_m601385103 ();
extern "C" void ASN1_CompareValue_m2380040405 ();
extern "C" void ASN1_Add_m2935298555 ();
extern "C" void ASN1_GetBytes_m1347548052 ();
extern "C" void ASN1_Decode_m421083504 ();
extern "C" void ASN1_DecodeTLV_m3033110137 ();
extern "C" void ASN1_get_Item_m1219168070 ();
extern "C" void ASN1_Element_m914257385 ();
extern "C" void ASN1_ToString_m4000515052 ();
extern "C" void ASN1Convert_FromInt32_m2200170205 ();
extern "C" void ASN1Convert_FromOid_m934152182 ();
extern "C" void ASN1Convert_ToInt32_m2352803718 ();
extern "C" void ASN1Convert_ToOid_m1258403924 ();
extern "C" void ASN1Convert_ToDateTime_m1328396727 ();
extern "C" void BitConverterLE_GetUIntBytes_m1384569885 ();
extern "C" void BitConverterLE_GetBytes_m2412841700 ();
extern "C" void ARC4Managed__ctor_m2574020285 ();
extern "C" void ARC4Managed_Finalize_m2148772049 ();
extern "C" void ARC4Managed_Dispose_m2710895473 ();
extern "C" void ARC4Managed_get_Key_m895766196 ();
extern "C" void ARC4Managed_set_Key_m1143489015 ();
extern "C" void ARC4Managed_get_CanReuseTransform_m3551629669 ();
extern "C" void ARC4Managed_CreateEncryptor_m614861295 ();
extern "C" void ARC4Managed_CreateDecryptor_m3676499029 ();
extern "C" void ARC4Managed_GenerateIV_m2848265659 ();
extern "C" void ARC4Managed_GenerateKey_m1412660680 ();
extern "C" void ARC4Managed_KeySetup_m2603934730 ();
extern "C" void ARC4Managed_CheckInput_m3888795245 ();
extern "C" void ARC4Managed_TransformBlock_m249171651 ();
extern "C" void ARC4Managed_InternalTransformBlock_m702959129 ();
extern "C" void ARC4Managed_TransformFinalBlock_m85404601 ();
extern "C" void CryptoConvert_ToHex_m2874115614 ();
extern "C" void HMAC__ctor_m2350580409 ();
extern "C" void HMAC_get_Key_m2145604251 ();
extern "C" void HMAC_set_Key_m49633678 ();
extern "C" void HMAC_Initialize_m2128632358 ();
extern "C" void HMAC_HashFinal_m302978610 ();
extern "C" void HMAC_HashCore_m902726834 ();
extern "C" void HMAC_initializePad_m104781443 ();
extern "C" void KeyBuilder_get_Rng_m390497396 ();
extern "C" void KeyBuilder_Key_m1555863487 ();
extern "C" void MD2__ctor_m1551032726 ();
extern "C" void MD2_Create_m3228747869 ();
extern "C" void MD2_Create_m320237521 ();
extern "C" void MD2Managed__ctor_m3399753397 ();
extern "C" void MD2Managed__cctor_m3778632564 ();
extern "C" void MD2Managed_Padding_m2385175461 ();
extern "C" void MD2Managed_Initialize_m1809936405 ();
extern "C" void MD2Managed_HashCore_m783128322 ();
extern "C" void MD2Managed_HashFinal_m1157314737 ();
extern "C" void MD2Managed_MD2Transform_m3020703703 ();
extern "C" void MD4__ctor_m3027213364 ();
extern "C" void MD4_Create_m3258860119 ();
extern "C" void MD4_Create_m3923361414 ();
extern "C" void MD4Managed__ctor_m3926348398 ();
extern "C" void MD4Managed_Initialize_m537126806 ();
extern "C" void MD4Managed_HashCore_m3698561284 ();
extern "C" void MD4Managed_HashFinal_m236989277 ();
extern "C" void MD4Managed_Padding_m1030210229 ();
extern "C" void MD4Managed_F_m4014378268 ();
extern "C" void MD4Managed_G_m1583243911 ();
extern "C" void MD4Managed_H_m213622522 ();
extern "C" void MD4Managed_ROL_m4179454275 ();
extern "C" void MD4Managed_FF_m3540939855 ();
extern "C" void MD4Managed_GG_m4200015153 ();
extern "C" void MD4Managed_HH_m3395074399 ();
extern "C" void MD4Managed_Encode_m3938310465 ();
extern "C" void MD4Managed_Decode_m3755082395 ();
extern "C" void MD4Managed_MD4Transform_m2381702939 ();
extern "C" void MD5SHA1__ctor_m2795497798 ();
extern "C" void MD5SHA1_Initialize_m667354197 ();
extern "C" void MD5SHA1_HashFinal_m1774759575 ();
extern "C" void MD5SHA1_HashCore_m723438337 ();
extern "C" void MD5SHA1_CreateSignature_m386328975 ();
extern "C" void MD5SHA1_VerifySignature_m2021453399 ();
extern "C" void PKCS1__cctor_m1181663908 ();
extern "C" void PKCS1_Compare_m1604695389 ();
extern "C" void PKCS1_I2OSP_m1521391326 ();
extern "C" void PKCS1_OS2IP_m1998787336 ();
extern "C" void PKCS1_RSASP1_m1693518040 ();
extern "C" void PKCS1_RSAVP1_m2152666711 ();
extern "C" void PKCS1_Sign_v15_m309973407 ();
extern "C" void PKCS1_Verify_v15_m4288865952 ();
extern "C" void PKCS1_Verify_v15_m1929947392 ();
extern "C" void PKCS1_Encode_v15_m2755555715 ();
extern "C" void EncryptedPrivateKeyInfo__ctor_m3590714673 ();
extern "C" void EncryptedPrivateKeyInfo__ctor_m1843255414 ();
extern "C" void EncryptedPrivateKeyInfo_get_Algorithm_m1079349399 ();
extern "C" void EncryptedPrivateKeyInfo_get_EncryptedData_m2030517224 ();
extern "C" void EncryptedPrivateKeyInfo_get_Salt_m1846754638 ();
extern "C" void EncryptedPrivateKeyInfo_get_IterationCount_m4284424872 ();
extern "C" void EncryptedPrivateKeyInfo_Decode_m3601396636 ();
extern "C" void PrivateKeyInfo__ctor_m1237589692 ();
extern "C" void PrivateKeyInfo__ctor_m4219676801 ();
extern "C" void PrivateKeyInfo_get_PrivateKey_m3262798750 ();
extern "C" void PrivateKeyInfo_Decode_m2276932701 ();
extern "C" void PrivateKeyInfo_RemoveLeadingZero_m3182739459 ();
extern "C" void PrivateKeyInfo_Normalize_m2035008135 ();
extern "C" void PrivateKeyInfo_DecodeRSA_m1537516818 ();
extern "C" void PrivateKeyInfo_DecodeDSA_m550432302 ();
extern "C" void RC4__ctor_m4271839561 ();
extern "C" void RC4__cctor_m1937931724 ();
extern "C" void RC4_get_IV_m396864526 ();
extern "C" void RC4_set_IV_m1338082778 ();
extern "C" void RSAManaged__ctor_m2505588350 ();
extern "C" void RSAManaged__ctor_m4060578812 ();
extern "C" void RSAManaged_Finalize_m1973406382 ();
extern "C" void RSAManaged_GenerateKeyPair_m210133981 ();
extern "C" void RSAManaged_get_KeySize_m1513772531 ();
extern "C" void RSAManaged_get_PublicOnly_m1997870060 ();
extern "C" void RSAManaged_DecryptValue_m377747502 ();
extern "C" void RSAManaged_EncryptValue_m3224637528 ();
extern "C" void RSAManaged_ExportParameters_m4220341555 ();
extern "C" void RSAManaged_ImportParameters_m116434100 ();
extern "C" void RSAManaged_Dispose_m440951713 ();
extern "C" void RSAManaged_ToXmlString_m3830541597 ();
extern "C" void RSAManaged_GetPaddedValue_m3038337403 ();
extern "C" void KeyGeneratedEventHandler__ctor_m591696252 ();
extern "C" void KeyGeneratedEventHandler_Invoke_m2823279036 ();
extern "C" void KeyGeneratedEventHandler_BeginInvoke_m229179016 ();
extern "C" void KeyGeneratedEventHandler_EndInvoke_m3115686752 ();
extern "C" void ContentInfo__ctor_m3422405402 ();
extern "C" void ContentInfo__ctor_m2765343486 ();
extern "C" void ContentInfo__ctor_m3211573373 ();
extern "C" void ContentInfo__ctor_m434478412 ();
extern "C" void ContentInfo_get_ASN1_m1578251455 ();
extern "C" void ContentInfo_get_Content_m3252263860 ();
extern "C" void ContentInfo_set_Content_m1482307621 ();
extern "C" void ContentInfo_get_ContentType_m3232672236 ();
extern "C" void ContentInfo_set_ContentType_m1498463555 ();
extern "C" void ContentInfo_GetASN1_m1022320466 ();
extern "C" void EncryptedData__ctor_m1197706297 ();
extern "C" void EncryptedData__ctor_m2094635316 ();
extern "C" void EncryptedData_get_EncryptionAlgorithm_m4107847107 ();
extern "C" void EncryptedData_get_EncryptedContent_m1500872137 ();
extern "C" void Alert__ctor_m3960313528 ();
extern "C" void Alert__ctor_m2259743940 ();
extern "C" void Alert_get_Level_m1211567354 ();
extern "C" void Alert_get_Description_m3184731798 ();
extern "C" void Alert_get_IsWarning_m196889914 ();
extern "C" void Alert_get_IsCloseNotify_m644254786 ();
extern "C" void Alert_inferAlertLevel_m4212996167 ();
extern "C" void Alert_GetAlertMessage_m745264909 ();
extern "C" void CertificateSelectionCallback__ctor_m1037063776 ();
extern "C" void CertificateSelectionCallback_Invoke_m845045433 ();
extern "C" void CertificateSelectionCallback_BeginInvoke_m386427038 ();
extern "C" void CertificateSelectionCallback_EndInvoke_m1729707519 ();
extern "C" void CertificateValidationCallback__ctor_m531022621 ();
extern "C" void CertificateValidationCallback_Invoke_m3326233986 ();
extern "C" void CertificateValidationCallback_BeginInvoke_m2551305279 ();
extern "C" void CertificateValidationCallback_EndInvoke_m68592148 ();
extern "C" void CertificateValidationCallback2__ctor_m1348748949 ();
extern "C" void CertificateValidationCallback2_Invoke_m3750848618 ();
extern "C" void CertificateValidationCallback2_BeginInvoke_m1026766960 ();
extern "C" void CertificateValidationCallback2_EndInvoke_m2103952377 ();
extern "C" void CipherSuite__ctor_m3238057673 ();
extern "C" void CipherSuite__cctor_m2886247321 ();
extern "C" void CipherSuite_get_EncryptionCipher_m3907182089 ();
extern "C" void CipherSuite_get_DecryptionCipher_m1728914303 ();
extern "C" void CipherSuite_get_ClientHMAC_m545977915 ();
extern "C" void CipherSuite_get_ServerHMAC_m4179848733 ();
extern "C" void CipherSuite_get_CipherAlgorithmType_m1369943773 ();
extern "C" void CipherSuite_get_HashAlgorithmName_m2441595063 ();
extern "C" void CipherSuite_get_HashAlgorithmType_m63516961 ();
extern "C" void CipherSuite_get_HashSize_m3493484425 ();
extern "C" void CipherSuite_get_ExchangeAlgorithmType_m2191904983 ();
extern "C" void CipherSuite_get_CipherMode_m722281993 ();
extern "C" void CipherSuite_get_Code_m3233650270 ();
extern "C" void CipherSuite_get_Name_m146691250 ();
extern "C" void CipherSuite_get_IsExportable_m3752663011 ();
extern "C" void CipherSuite_get_KeyMaterialSize_m2547888576 ();
extern "C" void CipherSuite_get_KeyBlockSize_m858464013 ();
extern "C" void CipherSuite_get_ExpandedKeyMaterialSize_m2832732491 ();
extern "C" void CipherSuite_get_EffectiveKeyBits_m1229195912 ();
extern "C" void CipherSuite_get_IvSize_m3368985968 ();
extern "C" void CipherSuite_get_Context_m2736770064 ();
extern "C" void CipherSuite_set_Context_m2064029995 ();
extern "C" void CipherSuite_Write_m676636739 ();
extern "C" void CipherSuite_Write_m3889367699 ();
extern "C" void CipherSuite_InitializeCipher_m33195514 ();
extern "C" void CipherSuite_EncryptRecord_m3304923834 ();
extern "C" void CipherSuite_DecryptRecord_m3624678067 ();
extern "C" void CipherSuite_CreatePremasterSecret_m3240677517 ();
extern "C" void CipherSuite_PRF_m224011433 ();
extern "C" void CipherSuite_Expand_m124298141 ();
extern "C" void CipherSuite_createEncryptionCipher_m1872228627 ();
extern "C" void CipherSuite_createDecryptionCipher_m974093277 ();
extern "C" void CipherSuiteCollection__ctor_m2912717739 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_get_Item_m1307094960 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_set_Item_m392670202 ();
extern "C" void CipherSuiteCollection_System_Collections_ICollection_get_SyncRoot_m2380123721 ();
extern "C" void CipherSuiteCollection_System_Collections_IEnumerable_GetEnumerator_m3457794598 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_Contains_m2253368777 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_IndexOf_m373506972 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_Insert_m2934430661 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_Remove_m1818202553 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_RemoveAt_m1577796664 ();
extern "C" void CipherSuiteCollection_System_Collections_IList_Add_m1343552861 ();
extern "C" void CipherSuiteCollection_get_Item_m1951170518 ();
extern "C" void CipherSuiteCollection_get_Item_m3024799401 ();
extern "C" void CipherSuiteCollection_set_Item_m1243143140 ();
extern "C" void CipherSuiteCollection_get_Item_m1448468422 ();
extern "C" void CipherSuiteCollection_get_Count_m2326692355 ();
extern "C" void CipherSuiteCollection_CopyTo_m2265539659 ();
extern "C" void CipherSuiteCollection_Clear_m194062517 ();
extern "C" void CipherSuiteCollection_IndexOf_m2804224314 ();
extern "C" void CipherSuiteCollection_IndexOf_m3646000520 ();
extern "C" void CipherSuiteCollection_Add_m1162497026 ();
extern "C" void CipherSuiteCollection_add_m1386009775 ();
extern "C" void CipherSuiteCollection_add_m2193951846 ();
extern "C" void CipherSuiteCollection_cultureAwareCompare_m1656419337 ();
extern "C" void CipherSuiteFactory_GetSupportedCiphers_m3100505535 ();
extern "C" void CipherSuiteFactory_GetTls1SupportedCiphers_m2307500680 ();
extern "C" void CipherSuiteFactory_GetSsl3SupportedCiphers_m3037057534 ();
extern "C" void ClientContext__ctor_m4206399174 ();
extern "C" void ClientContext_get_SslStream_m3280236306 ();
extern "C" void ClientContext_get_ClientHelloProtocol_m549457804 ();
extern "C" void ClientContext_set_ClientHelloProtocol_m3002521062 ();
extern "C" void ClientContext_Clear_m3011543115 ();
extern "C" void ClientRecordProtocol__ctor_m2014520355 ();
extern "C" void ClientRecordProtocol_GetMessage_m1005146182 ();
extern "C" void ClientRecordProtocol_ProcessHandshakeMessage_m3835877856 ();
extern "C" void ClientRecordProtocol_createClientHandshakeMessage_m517870575 ();
extern "C" void ClientRecordProtocol_createServerHandshakeMessage_m4244780190 ();
extern "C" void ClientSessionCache__cctor_m2017799205 ();
extern "C" void ClientSessionCache_Add_m2763750836 ();
extern "C" void ClientSessionCache_FromHost_m837030325 ();
extern "C" void ClientSessionCache_FromContext_m196666535 ();
extern "C" void ClientSessionCache_SetContextInCache_m3731615989 ();
extern "C" void ClientSessionCache_SetContextFromCache_m4127032905 ();
extern "C" void ClientSessionInfo__ctor_m3448346647 ();
extern "C" void ClientSessionInfo__cctor_m4029916257 ();
extern "C" void ClientSessionInfo_Finalize_m1903692174 ();
extern "C" void ClientSessionInfo_get_HostName_m1813423510 ();
extern "C" void ClientSessionInfo_get_Id_m1861651764 ();
extern "C" void ClientSessionInfo_get_Valid_m108361290 ();
extern "C" void ClientSessionInfo_GetContext_m2374376354 ();
extern "C" void ClientSessionInfo_SetContext_m3996633527 ();
extern "C" void ClientSessionInfo_KeepAlive_m1428910606 ();
extern "C" void ClientSessionInfo_Dispose_m3364663612 ();
extern "C" void ClientSessionInfo_Dispose_m2740391058 ();
extern "C" void ClientSessionInfo_CheckDisposed_m3131695358 ();
extern "C" void Context__ctor_m3487143758 ();
extern "C" void Context_get_AbbreviatedHandshake_m2669858019 ();
extern "C" void Context_set_AbbreviatedHandshake_m2710710445 ();
extern "C" void Context_get_ProtocolNegotiated_m789604084 ();
extern "C" void Context_set_ProtocolNegotiated_m3756570868 ();
extern "C" void Context_get_SecurityProtocol_m2757912658 ();
extern "C" void Context_set_SecurityProtocol_m3317356583 ();
extern "C" void Context_get_SecurityProtocolFlags_m3524319652 ();
extern "C" void Context_get_Protocol_m1042868808 ();
extern "C" void Context_get_SessionId_m2455183004 ();
extern "C" void Context_set_SessionId_m123662079 ();
extern "C" void Context_get_CompressionMethod_m3396244842 ();
extern "C" void Context_set_CompressionMethod_m3409746309 ();
extern "C" void Context_get_ServerSettings_m665092935 ();
extern "C" void Context_get_ClientSettings_m3639013314 ();
extern "C" void Context_get_LastHandshakeMsg_m2955711067 ();
extern "C" void Context_set_LastHandshakeMsg_m2090546789 ();
extern "C" void Context_get_HandshakeState_m2458679945 ();
extern "C" void Context_set_HandshakeState_m3386485285 ();
extern "C" void Context_get_ReceivedConnectionEnd_m3128583971 ();
extern "C" void Context_set_ReceivedConnectionEnd_m1451919546 ();
extern "C" void Context_get_SentConnectionEnd_m700150566 ();
extern "C" void Context_set_SentConnectionEnd_m3449731688 ();
extern "C" void Context_get_SupportedCiphers_m1355455486 ();
extern "C" void Context_set_SupportedCiphers_m1363192622 ();
extern "C" void Context_get_HandshakeMessages_m1050441678 ();
extern "C" void Context_get_WriteSequenceNumber_m3416479008 ();
extern "C" void Context_set_WriteSequenceNumber_m963357767 ();
extern "C" void Context_get_ReadSequenceNumber_m2387323861 ();
extern "C" void Context_set_ReadSequenceNumber_m2845416021 ();
extern "C" void Context_get_ClientRandom_m2305500516 ();
extern "C" void Context_set_ClientRandom_m3044497698 ();
extern "C" void Context_get_ServerRandom_m2613499485 ();
extern "C" void Context_set_ServerRandom_m3928200091 ();
extern "C" void Context_get_RandomCS_m2660362496 ();
extern "C" void Context_set_RandomCS_m1286521761 ();
extern "C" void Context_get_RandomSC_m3120784806 ();
extern "C" void Context_set_RandomSC_m672398920 ();
extern "C" void Context_get_MasterSecret_m441975730 ();
extern "C" void Context_set_MasterSecret_m2764130687 ();
extern "C" void Context_get_ClientWriteKey_m1688510987 ();
extern "C" void Context_set_ClientWriteKey_m1144722876 ();
extern "C" void Context_get_ServerWriteKey_m97178656 ();
extern "C" void Context_set_ServerWriteKey_m3796044638 ();
extern "C" void Context_get_ClientWriteIV_m4054803469 ();
extern "C" void Context_set_ClientWriteIV_m3047460563 ();
extern "C" void Context_get_ServerWriteIV_m258231173 ();
extern "C" void Context_set_ServerWriteIV_m172124322 ();
extern "C" void Context_get_RecordProtocol_m2454746427 ();
extern "C" void Context_set_RecordProtocol_m1453028534 ();
extern "C" void Context_GetUnixTime_m3476999680 ();
extern "C" void Context_GetSecureRandomBytes_m1050390791 ();
extern "C" void Context_Clear_m262551141 ();
extern "C" void Context_ClearKeyInfo_m969907945 ();
extern "C" void Context_DecodeProtocolCode_m4015438900 ();
extern "C" void Context_ChangeProtocol_m2610365909 ();
extern "C" void Context_get_Current_m3638905943 ();
extern "C" void Context_get_Negotiating_m739161972 ();
extern "C" void Context_get_Read_m1345235724 ();
extern "C" void Context_get_Write_m3526842162 ();
extern "C" void Context_StartSwitchingSecurityParameters_m2793916331 ();
extern "C" void Context_EndSwitchingSecurityParameters_m1888801424 ();
extern "C" void TlsClientCertificate__ctor_m4188345127 ();
extern "C" void TlsClientCertificate_get_ClientCertificate_m2162810393 ();
extern "C" void TlsClientCertificate_Update_m3893752988 ();
extern "C" void TlsClientCertificate_GetClientCertificate_m3885367635 ();
extern "C" void TlsClientCertificate_SendCertificates_m2667924708 ();
extern "C" void TlsClientCertificate_ProcessAsSsl3_m1200484296 ();
extern "C" void TlsClientCertificate_ProcessAsTls1_m2788357699 ();
extern "C" void TlsClientCertificate_FindParentCertificate_m3532186312 ();
extern "C" void TlsClientCertificateVerify__ctor_m338572956 ();
extern "C" void TlsClientCertificateVerify_Update_m2511791151 ();
extern "C" void TlsClientCertificateVerify_ProcessAsSsl3_m2765492448 ();
extern "C" void TlsClientCertificateVerify_ProcessAsTls1_m2753986979 ();
extern "C" void TlsClientCertificateVerify_getClientCertRSA_m3730379553 ();
extern "C" void TlsClientCertificateVerify_getUnsignedBigInteger_m1458425385 ();
extern "C" void TlsClientFinished__ctor_m516655734 ();
extern "C" void TlsClientFinished__cctor_m1143607366 ();
extern "C" void TlsClientFinished_Update_m3939044555 ();
extern "C" void TlsClientFinished_ProcessAsSsl3_m4156123412 ();
extern "C" void TlsClientFinished_ProcessAsTls1_m2479980324 ();
extern "C" void TlsClientHello__ctor_m2277964250 ();
extern "C" void TlsClientHello_Update_m2275537526 ();
extern "C" void TlsClientHello_ProcessAsSsl3_m1637487823 ();
extern "C" void TlsClientHello_ProcessAsTls1_m1595447014 ();
extern "C" void TlsClientKeyExchange__ctor_m2822701268 ();
extern "C" void TlsClientKeyExchange_ProcessAsSsl3_m2739916873 ();
extern "C" void TlsClientKeyExchange_ProcessAsTls1_m602401587 ();
extern "C" void TlsClientKeyExchange_ProcessCommon_m682895191 ();
extern "C" void TlsServerCertificate__ctor_m282941458 ();
extern "C" void TlsServerCertificate_Update_m1900628844 ();
extern "C" void TlsServerCertificate_ProcessAsSsl3_m3278094808 ();
extern "C" void TlsServerCertificate_ProcessAsTls1_m562387507 ();
extern "C" void TlsServerCertificate_checkCertificateUsage_m4181540579 ();
extern "C" void TlsServerCertificate_validateCertificates_m1126938502 ();
extern "C" void TlsServerCertificate_checkServerIdentity_m2133010983 ();
extern "C" void TlsServerCertificate_checkDomainName_m3213917459 ();
extern "C" void TlsServerCertificate_Match_m3405733548 ();
extern "C" void TlsServerCertificateRequest__ctor_m2645105734 ();
extern "C" void TlsServerCertificateRequest_Update_m2630970912 ();
extern "C" void TlsServerCertificateRequest_ProcessAsSsl3_m3911069156 ();
extern "C" void TlsServerCertificateRequest_ProcessAsTls1_m4269715970 ();
extern "C" void TlsServerFinished__ctor_m3230261975 ();
extern "C" void TlsServerFinished__cctor_m1633508801 ();
extern "C" void TlsServerFinished_Update_m1771319351 ();
extern "C" void TlsServerFinished_ProcessAsSsl3_m2165526924 ();
extern "C" void TlsServerFinished_ProcessAsTls1_m3714237769 ();
extern "C" void TlsServerHello__ctor_m444591022 ();
extern "C" void TlsServerHello_Update_m2629871195 ();
extern "C" void TlsServerHello_ProcessAsSsl3_m393375042 ();
extern "C" void TlsServerHello_ProcessAsTls1_m3486984712 ();
extern "C" void TlsServerHello_processProtocol_m3391908470 ();
extern "C" void TlsServerHelloDone__ctor_m3361320814 ();
extern "C" void TlsServerHelloDone_ProcessAsSsl3_m857276614 ();
extern "C" void TlsServerHelloDone_ProcessAsTls1_m951443237 ();
extern "C" void TlsServerKeyExchange__ctor_m266967171 ();
extern "C" void TlsServerKeyExchange_Update_m412825504 ();
extern "C" void TlsServerKeyExchange_ProcessAsSsl3_m2599813925 ();
extern "C" void TlsServerKeyExchange_ProcessAsTls1_m3396398902 ();
extern "C" void TlsServerKeyExchange_verifySignature_m1928629356 ();
extern "C" void HandshakeMessage__ctor_m187395287 ();
extern "C" void HandshakeMessage__ctor_m2680747516 ();
extern "C" void HandshakeMessage__ctor_m582056598 ();
extern "C" void HandshakeMessage_get_Context_m1083485348 ();
extern "C" void HandshakeMessage_get_HandshakeType_m2133048855 ();
extern "C" void HandshakeMessage_get_ContentType_m914521830 ();
extern "C" void HandshakeMessage_Process_m1991805942 ();
extern "C" void HandshakeMessage_Update_m3717551506 ();
extern "C" void HandshakeMessage_EncodeMessage_m320082085 ();
extern "C" void HandshakeMessage_Compare_m1908730859 ();
extern "C" void HttpsClientStream__ctor_m1064104888 ();
extern "C" void HttpsClientStream_get_TrustFailure_m2709743809 ();
extern "C" void HttpsClientStream_RaiseServerCertificateValidation_m3897092030 ();
extern "C" void HttpsClientStream_U3CHttpsClientStreamU3Em__0_m2170627081 ();
extern "C" void HttpsClientStream_U3CHttpsClientStreamU3Em__1_m1135820886 ();
extern "C" void PrivateKeySelectionCallback__ctor_m3337344772 ();
extern "C" void PrivateKeySelectionCallback_Invoke_m2047935261 ();
extern "C" void PrivateKeySelectionCallback_BeginInvoke_m3340292590 ();
extern "C" void PrivateKeySelectionCallback_EndInvoke_m2685876631 ();
extern "C" void RecordProtocol__ctor_m2040317979 ();
extern "C" void RecordProtocol__cctor_m4109051570 ();
extern "C" void RecordProtocol_get_Context_m3495648327 ();
extern "C" void RecordProtocol_SendRecord_m3856809599 ();
extern "C" void RecordProtocol_ProcessChangeCipherSpec_m2460141099 ();
extern "C" void RecordProtocol_GetMessage_m4076299694 ();
extern "C" void RecordProtocol_BeginReceiveRecord_m1962336162 ();
extern "C" void RecordProtocol_InternalReceiveRecordCallback_m93368051 ();
extern "C" void RecordProtocol_EndReceiveRecord_m402307927 ();
extern "C" void RecordProtocol_ReceiveRecord_m3686709362 ();
extern "C" void RecordProtocol_ReadRecordBuffer_m2213213812 ();
extern "C" void RecordProtocol_ReadClientHelloV2_m752890893 ();
extern "C" void RecordProtocol_ReadStandardRecordBuffer_m1267363110 ();
extern "C" void RecordProtocol_ProcessAlert_m294723356 ();
extern "C" void RecordProtocol_SendAlert_m2958143399 ();
extern "C" void RecordProtocol_SendAlert_m4165963710 ();
extern "C" void RecordProtocol_SendAlert_m2052764902 ();
extern "C" void RecordProtocol_SendChangeCipherSpec_m2587651596 ();
extern "C" void RecordProtocol_BeginSendRecord_m1123863227 ();
extern "C" void RecordProtocol_InternalSendRecordCallback_m3634123222 ();
extern "C" void RecordProtocol_BeginSendRecord_m1393516835 ();
extern "C" void RecordProtocol_EndSendRecord_m1123729343 ();
extern "C" void RecordProtocol_SendRecord_m280973384 ();
extern "C" void RecordProtocol_EncodeRecord_m878781190 ();
extern "C" void RecordProtocol_EncodeRecord_m1965588201 ();
extern "C" void RecordProtocol_encryptRecordFragment_m3505542538 ();
extern "C" void RecordProtocol_decryptRecordFragment_m3121017180 ();
extern "C" void RecordProtocol_Compare_m540163432 ();
extern "C" void RecordProtocol_ProcessCipherSpecV2Buffer_m83749199 ();
extern "C" void RecordProtocol_MapV2CipherCode_m3080704908 ();
extern "C" void ReceiveRecordAsyncResult__ctor_m1757831986 ();
extern "C" void ReceiveRecordAsyncResult_get_Record_m4281416090 ();
extern "C" void ReceiveRecordAsyncResult_get_ResultingBuffer_m2327738099 ();
extern "C" void ReceiveRecordAsyncResult_get_InitialBuffer_m2745225686 ();
extern "C" void ReceiveRecordAsyncResult_get_AsyncState_m3875465955 ();
extern "C" void ReceiveRecordAsyncResult_get_AsyncException_m1293664692 ();
extern "C" void ReceiveRecordAsyncResult_get_CompletedWithError_m1130061612 ();
extern "C" void ReceiveRecordAsyncResult_get_AsyncWaitHandle_m795523398 ();
extern "C" void ReceiveRecordAsyncResult_get_IsCompleted_m1477966073 ();
extern "C" void ReceiveRecordAsyncResult_SetComplete_m2761699087 ();
extern "C" void ReceiveRecordAsyncResult_SetComplete_m3052701818 ();
extern "C" void ReceiveRecordAsyncResult_SetComplete_m2322563145 ();
extern "C" void SendRecordAsyncResult__ctor_m3939881511 ();
extern "C" void SendRecordAsyncResult_get_Message_m2693739483 ();
extern "C" void SendRecordAsyncResult_get_AsyncState_m2735412790 ();
extern "C" void SendRecordAsyncResult_get_AsyncException_m629429291 ();
extern "C" void SendRecordAsyncResult_get_CompletedWithError_m1424077404 ();
extern "C" void SendRecordAsyncResult_get_AsyncWaitHandle_m3444932567 ();
extern "C" void SendRecordAsyncResult_get_IsCompleted_m1978447102 ();
extern "C" void SendRecordAsyncResult_SetComplete_m3767973408 ();
extern "C" void SendRecordAsyncResult_SetComplete_m407898290 ();
extern "C" void RSASslSignatureDeformatter__ctor_m485749795 ();
extern "C" void RSASslSignatureDeformatter_VerifySignature_m2745594033 ();
extern "C" void RSASslSignatureDeformatter_SetHashAlgorithm_m3833261103 ();
extern "C" void RSASslSignatureDeformatter_SetKey_m3863158732 ();
extern "C" void RSASslSignatureFormatter__ctor_m1000501437 ();
extern "C" void RSASslSignatureFormatter_CreateSignature_m1971677772 ();
extern "C" void RSASslSignatureFormatter_SetHashAlgorithm_m2496272067 ();
extern "C" void RSASslSignatureFormatter_SetKey_m3623953786 ();
extern "C" void SecurityParameters__ctor_m181771869 ();
extern "C" void SecurityParameters_get_Cipher_m3930246943 ();
extern "C" void SecurityParameters_set_Cipher_m1901519968 ();
extern "C" void SecurityParameters_get_ClientWriteMAC_m350260151 ();
extern "C" void SecurityParameters_set_ClientWriteMAC_m1663908222 ();
extern "C" void SecurityParameters_get_ServerWriteMAC_m3828576339 ();
extern "C" void SecurityParameters_set_ServerWriteMAC_m1009765799 ();
extern "C" void SecurityParameters_Clear_m1749827366 ();
extern "C" void SslCipherSuite__ctor_m968100862 ();
extern "C" void SslCipherSuite_ComputeServerRecordMAC_m1999477721 ();
extern "C" void SslCipherSuite_ComputeClientRecordMAC_m1337486433 ();
extern "C" void SslCipherSuite_ComputeMasterSecret_m2033082143 ();
extern "C" void SslCipherSuite_ComputeKeys_m3698646511 ();
extern "C" void SslCipherSuite_prf_m2590711611 ();
extern "C" void SslClientStream__ctor_m1433461746 ();
extern "C" void SslClientStream__ctor_m2633889984 ();
extern "C" void SslClientStream__ctor_m712711730 ();
extern "C" void SslClientStream__ctor_m3514916655 ();
extern "C" void SslClientStream__ctor_m2510462250 ();
extern "C" void SslClientStream_add_ServerCertValidation_m1523778381 ();
extern "C" void SslClientStream_remove_ServerCertValidation_m1297189878 ();
extern "C" void SslClientStream_add_ClientCertSelection_m452774312 ();
extern "C" void SslClientStream_remove_ClientCertSelection_m3667337044 ();
extern "C" void SslClientStream_add_PrivateKeySelection_m2824039476 ();
extern "C" void SslClientStream_remove_PrivateKeySelection_m3103873688 ();
extern "C" void SslClientStream_add_ServerCertValidation2_m3028641733 ();
extern "C" void SslClientStream_remove_ServerCertValidation2_m1700046162 ();
extern "C" void SslClientStream_get_InputBuffer_m1646783146 ();
extern "C" void SslClientStream_get_ClientCertificates_m2009517140 ();
extern "C" void SslClientStream_get_SelectedClientCertificate_m924322606 ();
extern "C" void SslClientStream_get_ServerCertValidationDelegate_m3612901859 ();
extern "C" void SslClientStream_set_ServerCertValidationDelegate_m73621411 ();
extern "C" void SslClientStream_get_ClientCertSelectionDelegate_m477769626 ();
extern "C" void SslClientStream_set_ClientCertSelectionDelegate_m3631584828 ();
extern "C" void SslClientStream_get_PrivateKeyCertSelectionDelegate_m288458638 ();
extern "C" void SslClientStream_set_PrivateKeyCertSelectionDelegate_m2185355211 ();
extern "C" void SslClientStream_Finalize_m3204804972 ();
extern "C" void SslClientStream_Dispose_m2742423009 ();
extern "C" void SslClientStream_OnBeginNegotiateHandshake_m3521994229 ();
extern "C" void SslClientStream_SafeReceiveRecord_m970773830 ();
extern "C" void SslClientStream_OnNegotiateHandshakeCallback_m346876372 ();
extern "C" void SslClientStream_OnLocalCertificateSelection_m2419470968 ();
extern "C" void SslClientStream_get_HaveRemoteValidation2Callback_m2400940629 ();
extern "C" void SslClientStream_OnRemoteCertificateValidation2_m3541905573 ();
extern "C" void SslClientStream_OnRemoteCertificateValidation_m189215702 ();
extern "C" void SslClientStream_RaiseServerCertificateValidation_m4005846852 ();
extern "C" void SslClientStream_RaiseServerCertificateValidation2_m2753141552 ();
extern "C" void SslClientStream_RaiseClientCertificateSelection_m156904178 ();
extern "C" void SslClientStream_OnLocalPrivateKeySelection_m2716108951 ();
extern "C" void SslClientStream_RaisePrivateKeySelection_m489845487 ();
extern "C" void SslHandshakeHash__ctor_m756898996 ();
extern "C" void SslHandshakeHash_Initialize_m1791132127 ();
extern "C" void SslHandshakeHash_HashFinal_m1701169298 ();
extern "C" void SslHandshakeHash_HashCore_m3933865887 ();
extern "C" void SslHandshakeHash_CreateSignature_m1939494048 ();
extern "C" void SslHandshakeHash_initializePad_m250387769 ();
extern "C" void SslStreamBase__ctor_m741205528 ();
extern "C" void SslStreamBase__cctor_m3014705422 ();
extern "C" void SslStreamBase_AsyncHandshakeCallback_m3294599590 ();
extern "C" void SslStreamBase_get_MightNeedHandshake_m1992121943 ();
extern "C" void SslStreamBase_NegotiateHandshake_m573491502 ();
extern "C" void SslStreamBase_RaiseLocalCertificateSelection_m1433227057 ();
extern "C" void SslStreamBase_RaiseRemoteCertificateValidation_m3341524304 ();
extern "C" void SslStreamBase_RaiseRemoteCertificateValidation2_m4029917716 ();
extern "C" void SslStreamBase_RaiseLocalPrivateKeySelection_m2735161685 ();
extern "C" void SslStreamBase_get_CheckCertRevocationStatus_m77642209 ();
extern "C" void SslStreamBase_set_CheckCertRevocationStatus_m4261866224 ();
extern "C" void SslStreamBase_get_CipherAlgorithm_m3666529430 ();
extern "C" void SslStreamBase_get_CipherStrength_m1580212736 ();
extern "C" void SslStreamBase_get_HashAlgorithm_m1079516308 ();
extern "C" void SslStreamBase_get_HashStrength_m2478322151 ();
extern "C" void SslStreamBase_get_KeyExchangeStrength_m1541427818 ();
extern "C" void SslStreamBase_get_KeyExchangeAlgorithm_m2863204591 ();
extern "C" void SslStreamBase_get_SecurityProtocol_m2618450503 ();
extern "C" void SslStreamBase_get_ServerCertificate_m2145681234 ();
extern "C" void SslStreamBase_get_ServerCertificates_m939421281 ();
extern "C" void SslStreamBase_BeginNegotiateHandshake_m547336995 ();
extern "C" void SslStreamBase_EndNegotiateHandshake_m397829249 ();
extern "C" void SslStreamBase_BeginRead_m2809800024 ();
extern "C" void SslStreamBase_InternalBeginRead_m963539731 ();
extern "C" void SslStreamBase_InternalReadCallback_m1305227365 ();
extern "C" void SslStreamBase_InternalBeginWrite_m3598790627 ();
extern "C" void SslStreamBase_InternalWriteCallback_m3296769839 ();
extern "C" void SslStreamBase_BeginWrite_m2564053213 ();
extern "C" void SslStreamBase_EndRead_m437026192 ();
extern "C" void SslStreamBase_EndWrite_m2714332870 ();
extern "C" void SslStreamBase_Close_m3709519320 ();
extern "C" void SslStreamBase_Flush_m3658498653 ();
extern "C" void SslStreamBase_Read_m2195290049 ();
extern "C" void SslStreamBase_Read_m3643263392 ();
extern "C" void SslStreamBase_Seek_m2054533330 ();
extern "C" void SslStreamBase_SetLength_m1638416063 ();
extern "C" void SslStreamBase_Write_m2025580464 ();
extern "C" void SslStreamBase_Write_m2240111151 ();
extern "C" void SslStreamBase_get_CanRead_m1991562813 ();
extern "C" void SslStreamBase_get_CanSeek_m812627421 ();
extern "C" void SslStreamBase_get_CanWrite_m1968128100 ();
extern "C" void SslStreamBase_get_Length_m272340880 ();
extern "C" void SslStreamBase_get_Position_m1000100995 ();
extern "C" void SslStreamBase_set_Position_m1857423747 ();
extern "C" void SslStreamBase_Finalize_m356284376 ();
extern "C" void SslStreamBase_Dispose_m3739772543 ();
extern "C" void SslStreamBase_resetBuffer_m3181034709 ();
extern "C" void SslStreamBase_checkDisposed_m2906118924 ();
extern "C" void InternalAsyncResult__ctor_m2214225954 ();
extern "C" void InternalAsyncResult_get_ProceedAfterHandshake_m853048591 ();
extern "C" void InternalAsyncResult_get_FromWrite_m218776078 ();
extern "C" void InternalAsyncResult_get_Buffer_m2215177245 ();
extern "C" void InternalAsyncResult_get_Offset_m769058131 ();
extern "C" void InternalAsyncResult_get_Count_m1900339478 ();
extern "C" void InternalAsyncResult_get_BytesRead_m1934347442 ();
extern "C" void InternalAsyncResult_get_AsyncState_m1834753740 ();
extern "C" void InternalAsyncResult_get_AsyncException_m4277553429 ();
extern "C" void InternalAsyncResult_get_CompletedWithError_m692720727 ();
extern "C" void InternalAsyncResult_get_AsyncWaitHandle_m2827246684 ();
extern "C" void InternalAsyncResult_get_IsCompleted_m1809305310 ();
extern "C" void InternalAsyncResult_SetComplete_m2954631375 ();
extern "C" void InternalAsyncResult_SetComplete_m3383011526 ();
extern "C" void InternalAsyncResult_SetComplete_m1311950338 ();
extern "C" void InternalAsyncResult_SetComplete_m794196429 ();
extern "C" void TlsCipherSuite__ctor_m694841098 ();
extern "C" void TlsCipherSuite_ComputeServerRecordMAC_m2466325416 ();
extern "C" void TlsCipherSuite_ComputeClientRecordMAC_m479855312 ();
extern "C" void TlsCipherSuite_ComputeMasterSecret_m223547806 ();
extern "C" void TlsCipherSuite_ComputeKeys_m2573681292 ();
extern "C" void TlsClientSettings__ctor_m1606665757 ();
extern "C" void TlsClientSettings_get_TargetHost_m3723711163 ();
extern "C" void TlsClientSettings_set_TargetHost_m3968834781 ();
extern "C" void TlsClientSettings_get_Certificates_m1566007174 ();
extern "C" void TlsClientSettings_set_Certificates_m3957959786 ();
extern "C" void TlsClientSettings_get_ClientCertificate_m3506843448 ();
extern "C" void TlsClientSettings_set_ClientCertificate_m539682578 ();
extern "C" void TlsClientSettings_UpdateCertificateRSA_m3858486671 ();
extern "C" void TlsException__ctor_m3560232972 ();
extern "C" void TlsException__ctor_m1727714823 ();
extern "C" void TlsException__ctor_m2050029036 ();
extern "C" void TlsException__ctor_m767832443 ();
extern "C" void TlsException__ctor_m277556507 ();
extern "C" void TlsException__ctor_m6896144 ();
extern "C" void TlsException_get_Alert_m2866791725 ();
extern "C" void TlsServerSettings__ctor_m1778605416 ();
extern "C" void TlsServerSettings_get_ServerKeyExchange_m2147121151 ();
extern "C" void TlsServerSettings_set_ServerKeyExchange_m542234116 ();
extern "C" void TlsServerSettings_get_Certificates_m3650847764 ();
extern "C" void TlsServerSettings_set_Certificates_m982364535 ();
extern "C" void TlsServerSettings_get_CertificateRSA_m1034068925 ();
extern "C" void TlsServerSettings_get_RsaParameters_m1572348672 ();
extern "C" void TlsServerSettings_set_RsaParameters_m490478177 ();
extern "C" void TlsServerSettings_set_SignedParams_m3377624622 ();
extern "C" void TlsServerSettings_get_CertificateRequest_m90880896 ();
extern "C" void TlsServerSettings_set_CertificateRequest_m976590898 ();
extern "C" void TlsServerSettings_set_CertificateTypes_m3407305606 ();
extern "C" void TlsServerSettings_set_DistinguisedNames_m1980717977 ();
extern "C" void TlsServerSettings_UpdateCertificateRSA_m3191619471 ();
extern "C" void TlsStream__ctor_m748448940 ();
extern "C" void TlsStream__ctor_m3756011759 ();
extern "C" void TlsStream_get_EOF_m340757178 ();
extern "C" void TlsStream_get_CanWrite_m167831487 ();
extern "C" void TlsStream_get_CanRead_m3288349133 ();
extern "C" void TlsStream_get_CanSeek_m3944248432 ();
extern "C" void TlsStream_get_Position_m2542488461 ();
extern "C" void TlsStream_set_Position_m2207048000 ();
extern "C" void TlsStream_get_Length_m3807077833 ();
extern "C" void TlsStream_ReadSmallValue_m1022298559 ();
extern "C" void TlsStream_ReadByte_m777518142 ();
extern "C" void TlsStream_ReadInt16_m485537606 ();
extern "C" void TlsStream_ReadInt24_m3090987673 ();
extern "C" void TlsStream_ReadBytes_m378502065 ();
extern "C" void TlsStream_Write_m2411452691 ();
extern "C" void TlsStream_Write_m1006871602 ();
extern "C" void TlsStream_WriteInt24_m1187607382 ();
extern "C" void TlsStream_Write_m1457234136 ();
extern "C" void TlsStream_Write_m2768379738 ();
extern "C" void TlsStream_Reset_m2365541461 ();
extern "C" void TlsStream_ToArray_m3134746106 ();
extern "C" void TlsStream_Flush_m3962898263 ();
extern "C" void TlsStream_SetLength_m3711323663 ();
extern "C" void TlsStream_Seek_m145155004 ();
extern "C" void TlsStream_Read_m1722448457 ();
extern "C" void TlsStream_Write_m3440017277 ();
extern "C" void ValidationResult_get_Trusted_m1345068309 ();
extern "C" void ValidationResult_get_ErrorCode_m304391632 ();
extern "C" void AuthorityKeyIdentifierExtension__ctor_m219033161 ();
extern "C" void AuthorityKeyIdentifierExtension_Decode_m710183725 ();
extern "C" void AuthorityKeyIdentifierExtension_get_Identifier_m209684292 ();
extern "C" void AuthorityKeyIdentifierExtension_ToString_m2353194001 ();
extern "C" void BasicConstraintsExtension__ctor_m1669247165 ();
extern "C" void BasicConstraintsExtension_Decode_m2558178225 ();
extern "C" void BasicConstraintsExtension_Encode_m3247810661 ();
extern "C" void BasicConstraintsExtension_get_CertificateAuthority_m821405121 ();
extern "C" void BasicConstraintsExtension_ToString_m3236584636 ();
extern "C" void ExtendedKeyUsageExtension__ctor_m2334921451 ();
extern "C" void ExtendedKeyUsageExtension_Decode_m3019927506 ();
extern "C" void ExtendedKeyUsageExtension_Encode_m4180241165 ();
extern "C" void ExtendedKeyUsageExtension_get_KeyPurpose_m861952333 ();
extern "C" void ExtendedKeyUsageExtension_ToString_m385154138 ();
extern "C" void GeneralNames__ctor_m342736606 ();
extern "C" void GeneralNames_get_DNSNames_m175359186 ();
extern "C" void GeneralNames_get_IPAddresses_m3029857601 ();
extern "C" void GeneralNames_ToString_m2803221720 ();
extern "C" void KeyUsageExtension__ctor_m1050328440 ();
extern "C" void KeyUsageExtension_Decode_m694564864 ();
extern "C" void KeyUsageExtension_Encode_m4206639500 ();
extern "C" void KeyUsageExtension_Support_m4075266157 ();
extern "C" void KeyUsageExtension_ToString_m1242530744 ();
extern "C" void NetscapeCertTypeExtension__ctor_m3394330620 ();
extern "C" void NetscapeCertTypeExtension_Decode_m39242487 ();
extern "C" void NetscapeCertTypeExtension_Support_m1227706244 ();
extern "C" void NetscapeCertTypeExtension_ToString_m112697774 ();
extern "C" void SubjectAltNameExtension__ctor_m789892295 ();
extern "C" void SubjectAltNameExtension_Decode_m3172834871 ();
extern "C" void SubjectAltNameExtension_get_DNSNames_m1804554775 ();
extern "C" void SubjectAltNameExtension_get_IPAddresses_m2089654521 ();
extern "C" void SubjectAltNameExtension_ToString_m2914767436 ();
extern "C" void PKCS12__ctor_m1777426012 ();
extern "C" void PKCS12__ctor_m3659970847 ();
extern "C" void PKCS12__ctor_m1656806803 ();
extern "C" void PKCS12__cctor_m2775773295 ();
extern "C" void PKCS12_Decode_m3317588035 ();
extern "C" void PKCS12_Finalize_m2317608358 ();
extern "C" void PKCS12_set_Password_m2427294934 ();
extern "C" void PKCS12_get_IterationCount_m2087403858 ();
extern "C" void PKCS12_set_IterationCount_m1788721540 ();
extern "C" void PKCS12_get_Keys_m2167805586 ();
extern "C" void PKCS12_get_Certificates_m240716806 ();
extern "C" void PKCS12_get_RNG_m2558654591 ();
extern "C" void PKCS12_Compare_m696746212 ();
extern "C" void PKCS12_GetSymmetricAlgorithm_m1596743709 ();
extern "C" void PKCS12_Decrypt_m1609151980 ();
extern "C" void PKCS12_Decrypt_m2965366899 ();
extern "C" void PKCS12_Encrypt_m3741127000 ();
extern "C" void PKCS12_GetExistingParameters_m3068163633 ();
extern "C" void PKCS12_AddPrivateKey_m1660821157 ();
extern "C" void PKCS12_ReadSafeBag_m1793596352 ();
extern "C" void PKCS12_CertificateSafeBag_m2039847126 ();
extern "C" void PKCS12_MAC_m3906451347 ();
extern "C" void PKCS12_GetBytes_m3278149050 ();
extern "C" void PKCS12_EncryptedContentInfo_m1491957736 ();
extern "C" void PKCS12_AddCertificate_m454954748 ();
extern "C" void PKCS12_AddCertificate_m1974489930 ();
extern "C" void PKCS12_RemoveCertificate_m1542146527 ();
extern "C" void PKCS12_RemoveCertificate_m1500639714 ();
extern "C" void PKCS12_Clone_m1234389164 ();
extern "C" void PKCS12_get_MaximumPasswordLength_m883214155 ();
extern "C" void DeriveBytes__ctor_m435594913 ();
extern "C" void DeriveBytes__cctor_m2512241514 ();
extern "C" void DeriveBytes_set_HashName_m1312849937 ();
extern "C" void DeriveBytes_set_IterationCount_m375614940 ();
extern "C" void DeriveBytes_set_Password_m1207022898 ();
extern "C" void DeriveBytes_set_Salt_m1226625054 ();
extern "C" void DeriveBytes_Adjust_m2230275790 ();
extern "C" void DeriveBytes_Derive_m2164396782 ();
extern "C" void DeriveBytes_DeriveKey_m2264034637 ();
extern "C" void DeriveBytes_DeriveIV_m156619505 ();
extern "C" void DeriveBytes_DeriveMAC_m2308622817 ();
extern "C" void SafeBag__ctor_m149225940 ();
extern "C" void SafeBag_get_BagOID_m2140085721 ();
extern "C" void SafeBag_get_ASN1_m4116908763 ();
extern "C" void X501__cctor_m215262883 ();
extern "C" void X501_ToString_m1572535881 ();
extern "C" void X501_ToString_m2425160069 ();
extern "C" void X501_AppendEntry_m2829401085 ();
extern "C" void X509Certificate__ctor_m2595420781 ();
extern "C" void X509Certificate__cctor_m3387216631 ();
extern "C" void X509Certificate_Parse_m2434019838 ();
extern "C" void X509Certificate_GetUnsignedBigInteger_m3421969019 ();
extern "C" void X509Certificate_get_DSA_m3900335029 ();
extern "C" void X509Certificate_set_DSA_m2466949906 ();
extern "C" void X509Certificate_get_Extensions_m168359828 ();
extern "C" void X509Certificate_get_Hash_m4070304576 ();
extern "C" void X509Certificate_get_IssuerName_m3125413837 ();
extern "C" void X509Certificate_get_KeyAlgorithm_m1954217732 ();
extern "C" void X509Certificate_get_KeyAlgorithmParameters_m3826010966 ();
extern "C" void X509Certificate_set_KeyAlgorithmParameters_m1678336073 ();
extern "C" void X509Certificate_get_PublicKey_m2789532076 ();
extern "C" void X509Certificate_get_RSA_m444241086 ();
extern "C" void X509Certificate_set_RSA_m2230677437 ();
extern "C" void X509Certificate_get_RawData_m4264811715 ();
extern "C" void X509Certificate_get_SerialNumber_m4150013632 ();
extern "C" void X509Certificate_get_Signature_m1258977383 ();
extern "C" void X509Certificate_get_SignatureAlgorithm_m134784522 ();
extern "C" void X509Certificate_get_SubjectName_m1800094717 ();
extern "C" void X509Certificate_get_ValidFrom_m1616190780 ();
extern "C" void X509Certificate_get_ValidUntil_m3380278620 ();
extern "C" void X509Certificate_get_Version_m2368604753 ();
extern "C" void X509Certificate_get_IsCurrent_m3640852168 ();
extern "C" void X509Certificate_WasCurrent_m917225642 ();
extern "C" void X509Certificate_VerifySignature_m999087952 ();
extern "C" void X509Certificate_VerifySignature_m3586768459 ();
extern "C" void X509Certificate_VerifySignature_m1063367374 ();
extern "C" void X509Certificate_get_IsSelfSigned_m2899197692 ();
extern "C" void X509Certificate_GetIssuerName_m2725382997 ();
extern "C" void X509Certificate_GetSubjectName_m3415136325 ();
extern "C" void X509Certificate_GetObjectData_m477010876 ();
extern "C" void X509Certificate_PEM_m893460658 ();
extern "C" void X509CertificateCollection__ctor_m3814102197 ();
extern "C" void X509CertificateCollection__ctor_m2831022880 ();
extern "C" void X509CertificateCollection_System_Collections_IEnumerable_GetEnumerator_m2203928887 ();
extern "C" void X509CertificateCollection_get_Item_m1037513158 ();
extern "C" void X509CertificateCollection_Add_m3583025647 ();
extern "C" void X509CertificateCollection_AddRange_m3947922443 ();
extern "C" void X509CertificateCollection_Contains_m2689777087 ();
extern "C" void X509CertificateCollection_GetEnumerator_m1488475952 ();
extern "C" void X509CertificateCollection_GetHashCode_m3234395587 ();
extern "C" void X509CertificateCollection_IndexOf_m1510539209 ();
extern "C" void X509CertificateCollection_Remove_m953811859 ();
extern "C" void X509CertificateCollection_Compare_m3326865369 ();
extern "C" void X509CertificateEnumerator__ctor_m3390678879 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m3624737776 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m4129821546 ();
extern "C" void X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m66253660 ();
extern "C" void X509CertificateEnumerator_get_Current_m1278820965 ();
extern "C" void X509CertificateEnumerator_MoveNext_m2399536456 ();
extern "C" void X509CertificateEnumerator_Reset_m2618066962 ();
extern "C" void X509Chain__ctor_m1855707435 ();
extern "C" void X509Chain__ctor_m3929816338 ();
extern "C" void X509Chain_get_Status_m3187776484 ();
extern "C" void X509Chain_get_TrustAnchors_m3647194859 ();
extern "C" void X509Chain_Build_m3816057649 ();
extern "C" void X509Chain_IsValid_m3320576976 ();
extern "C" void X509Chain_FindCertificateParent_m3084039956 ();
extern "C" void X509Chain_FindCertificateRoot_m1594113095 ();
extern "C" void X509Chain_IsTrusted_m4069065425 ();
extern "C" void X509Chain_IsParent_m3921705034 ();
extern "C" void X509Crl__ctor_m1405190782 ();
extern "C" void X509Crl_Parse_m3443588132 ();
extern "C" void X509Crl_get_Extensions_m3563247159 ();
extern "C" void X509Crl_get_Hash_m3316606702 ();
extern "C" void X509Crl_get_IssuerName_m2231565103 ();
extern "C" void X509Crl_get_NextUpdate_m1955410512 ();
extern "C" void X509Crl_Compare_m2769836244 ();
extern "C" void X509Crl_GetCrlEntry_m2770982370 ();
extern "C" void X509Crl_GetCrlEntry_m3898926927 ();
extern "C" void X509Crl_GetHashName_m4172463918 ();
extern "C" void X509Crl_VerifySignature_m1759125724 ();
extern "C" void X509Crl_VerifySignature_m3654385869 ();
extern "C" void X509Crl_VerifySignature_m1470503056 ();
extern "C" void X509CrlEntry__ctor_m3292061466 ();
extern "C" void X509CrlEntry_get_SerialNumber_m3129165863 ();
extern "C" void X509CrlEntry_get_RevocationDate_m1741259245 ();
extern "C" void X509CrlEntry_get_Extensions_m1273042024 ();
extern "C" void X509Extension__ctor_m2037261217 ();
extern "C" void X509Extension__ctor_m1596098138 ();
extern "C" void X509Extension_Decode_m3688445819 ();
extern "C" void X509Extension_Encode_m829172182 ();
extern "C" void X509Extension_get_Oid_m362207092 ();
extern "C" void X509Extension_get_Critical_m1041250559 ();
extern "C" void X509Extension_get_Value_m1107597234 ();
extern "C" void X509Extension_Equals_m430339191 ();
extern "C" void X509Extension_GetHashCode_m1844371398 ();
extern "C" void X509Extension_WriteLine_m3492795937 ();
extern "C" void X509Extension_ToString_m2151664661 ();
extern "C" void X509ExtensionCollection__ctor_m3456583624 ();
extern "C" void X509ExtensionCollection__ctor_m4124179550 ();
extern "C" void X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m3440118309 ();
extern "C" void X509ExtensionCollection_IndexOf_m3436077092 ();
extern "C" void X509ExtensionCollection_get_Item_m2499993247 ();
extern "C" void X509Store__ctor_m2147993305 ();
extern "C" void X509Store_get_Certificates_m3680783951 ();
extern "C" void X509Store_get_Crls_m1033339264 ();
extern "C" void X509Store_Load_m419224682 ();
extern "C" void X509Store_LoadCertificate_m1545801903 ();
extern "C" void X509Store_LoadCrl_m350580848 ();
extern "C" void X509Store_CheckStore_m3326322670 ();
extern "C" void X509Store_BuildCertificatesCollection_m888443411 ();
extern "C" void X509Store_BuildCrlsCollection_m1230599691 ();
extern "C" void X509StoreManager_get_CurrentUser_m3250790281 ();
extern "C" void X509StoreManager_get_LocalMachine_m3513347572 ();
extern "C" void X509StoreManager_get_TrustedRootCertificates_m1474110803 ();
extern "C" void X509Stores__ctor_m265972325 ();
extern "C" void X509Stores_get_TrustedRoot_m125247548 ();
extern "C" void X509Stores_Open_m3469237229 ();
extern "C" void Locale_GetText_m3061672467 ();
extern "C" void Locale_GetText_m2212416198 ();
extern "C" void KeyBuilder_get_Rng_m3489060129 ();
extern "C" void KeyBuilder_Key_m1483187862 ();
extern "C" void KeyBuilder_IV_m3594476528 ();
extern "C" void SymmetricTransform__ctor_m479938328 ();
extern "C" void SymmetricTransform_System_IDisposable_Dispose_m3467570388 ();
extern "C" void SymmetricTransform_Finalize_m3831333474 ();
extern "C" void SymmetricTransform_Dispose_m4199210298 ();
extern "C" void SymmetricTransform_get_CanReuseTransform_m3198136831 ();
extern "C" void SymmetricTransform_Transform_m1783309410 ();
extern "C" void SymmetricTransform_CBC_m3108280695 ();
extern "C" void SymmetricTransform_CFB_m913756151 ();
extern "C" void SymmetricTransform_OFB_m3448407975 ();
extern "C" void SymmetricTransform_CTS_m3137243433 ();
extern "C" void SymmetricTransform_CheckInput_m889492017 ();
extern "C" void SymmetricTransform_TransformBlock_m1133208178 ();
extern "C" void SymmetricTransform_get_KeepLastBlock_m278696008 ();
extern "C" void SymmetricTransform_InternalTransformBlock_m2757264515 ();
extern "C" void SymmetricTransform_Random_m234530533 ();
extern "C" void SymmetricTransform_ThrowBadPaddingException_m2239569074 ();
extern "C" void SymmetricTransform_FinalEncrypt_m3511270614 ();
extern "C" void SymmetricTransform_FinalDecrypt_m288191860 ();
extern "C" void SymmetricTransform_TransformFinalBlock_m150874865 ();
extern "C" void Action__ctor_m2628370505 ();
extern "C" void Action_Invoke_m461827263 ();
extern "C" void Action_BeginInvoke_m3723509046 ();
extern "C" void Action_EndInvoke_m1255458958 ();
extern "C" void Check_Source_m116682380 ();
extern "C" void Check_SourceAndPredicate_m1967256554 ();
extern "C" void ExtensionAttribute__ctor_m4086378263 ();
extern "C" void Aes__ctor_m1953100512 ();
extern "C" void AesManaged__ctor_m3652913943 ();
extern "C" void AesManaged_GenerateIV_m1752581687 ();
extern "C" void AesManaged_GenerateKey_m1663893024 ();
extern "C" void AesManaged_CreateDecryptor_m1783063797 ();
extern "C" void AesManaged_CreateEncryptor_m542327683 ();
extern "C" void AesManaged_get_IV_m445337811 ();
extern "C" void AesManaged_set_IV_m154541751 ();
extern "C" void AesManaged_get_Key_m2188581155 ();
extern "C" void AesManaged_set_Key_m1204862624 ();
extern "C" void AesManaged_get_KeySize_m4026780749 ();
extern "C" void AesManaged_set_KeySize_m2877665950 ();
extern "C" void AesManaged_CreateDecryptor_m705463674 ();
extern "C" void AesManaged_CreateEncryptor_m3828710756 ();
extern "C" void AesManaged_Dispose_m2494358036 ();
extern "C" void AesTransform__ctor_m3423405142 ();
extern "C" void AesTransform__cctor_m59472272 ();
extern "C" void AesTransform_ECB_m2941917479 ();
extern "C" void AesTransform_SubByte_m1840584220 ();
extern "C" void AesTransform_Encrypt128_m4225624107 ();
extern "C" void AesTransform_Decrypt128_m2599523323 ();
extern "C" void AddComponentMenu__ctor_m3547895745 ();
extern "C" void Analytics_GetUnityAnalyticsHandler_m672127306 ();
extern "C" void Analytics_CustomEvent_m2816162597 ();
extern "C" void CustomEventData__ctor_m3827668383 ();
extern "C" void CustomEventData_Finalize_m3487810534 ();
extern "C" void CustomEventData_Dispose_m3383975513 ();
extern "C" void CustomEventData_Add_m255379884 ();
extern "C" void CustomEventData_Add_m4065400 ();
extern "C" void CustomEventData_Add_m1177082793 ();
extern "C" void CustomEventData_Add_m20789608 ();
extern "C" void CustomEventData_Add_m1322416340 ();
extern "C" void CustomEventData_Add_m3098094110 ();
extern "C" void CustomEventData_Add_m1790469430 ();
extern "C" void CustomEventData_Add_m427502212 ();
extern "C" void CustomEventData_Add_m74255895 ();
extern "C" void CustomEventData_Add_m2047600962 ();
extern "C" void CustomEventData_Add_m1265658328 ();
extern "C" void CustomEventData_Add_m3195527203 ();
extern "C" void CustomEventData_Add_m4269902579 ();
extern "C" void CustomEventData_Add_m2852648701 ();
extern "C" void CustomEventData_Add_m716525696 ();
extern "C" void CustomEventData_InternalCreate_m880206285 ();
extern "C" void CustomEventData_InternalDestroy_m2519008968 ();
extern "C" void CustomEventData_AddString_m659451336 ();
extern "C" void CustomEventData_AddBool_m398788015 ();
extern "C" void CustomEventData_AddChar_m319900760 ();
extern "C" void CustomEventData_AddByte_m3717748694 ();
extern "C" void CustomEventData_AddSByte_m3340687799 ();
extern "C" void CustomEventData_AddInt16_m1608076704 ();
extern "C" void CustomEventData_AddUInt16_m204323820 ();
extern "C" void CustomEventData_AddInt32_m779198032 ();
extern "C" void CustomEventData_AddUInt32_m2154319333 ();
extern "C" void CustomEventData_AddInt64_m3524891666 ();
extern "C" void CustomEventData_AddUInt64_m2735082319 ();
extern "C" void CustomEventData_AddDouble_m1124663272 ();
extern "C" void UnityAnalyticsHandler__ctor_m4061513566 ();
extern "C" void UnityAnalyticsHandler_InternalCreate_m2671862836 ();
extern "C" void UnityAnalyticsHandler_InternalDestroy_m304093635 ();
extern "C" void UnityAnalyticsHandler_Finalize_m4007199557 ();
extern "C" void UnityAnalyticsHandler_Dispose_m803102421 ();
extern "C" void UnityAnalyticsHandler_CustomEvent_m2596088521 ();
extern "C" void UnityAnalyticsHandler_CustomEvent_m4076413237 ();
extern "C" void UnityAnalyticsHandler_SendCustomEventName_m3481945465 ();
extern "C" void UnityAnalyticsHandler_SendCustomEvent_m3074734922 ();
extern "C" void AnimationCurve__ctor_m1256678767 ();
extern "C" void AnimationCurve__ctor_m3546708367 ();
extern "C" void AnimationCurve_Cleanup_m870304867 ();
extern "C" void AnimationCurve_Finalize_m1957706335 ();
extern "C" void AnimationCurve_Init_m2288700569 ();
extern "C" void Application_CallLowMemory_m950526118 ();
extern "C" void Application_CallLogCallback_m1230073937 ();
extern "C" void Application_InvokeOnBeforeRender_m367288211 ();
extern "C" void LogCallback__ctor_m1474797444 ();
extern "C" void LogCallback_Invoke_m1074473487 ();
extern "C" void LogCallback_BeginInvoke_m1847524231 ();
extern "C" void LogCallback_EndInvoke_m2170626810 ();
extern "C" void LowMemoryCallback__ctor_m3261191279 ();
extern "C" void LowMemoryCallback_Invoke_m531625589 ();
extern "C" void LowMemoryCallback_BeginInvoke_m2392861162 ();
extern "C" void LowMemoryCallback_EndInvoke_m1446466716 ();
extern "C" void AssemblyIsEditorAssembly__ctor_m2630421681 ();
extern "C" void AssetBundleCreateRequest__ctor_m3026219756 ();
extern "C" void AssetBundleCreateRequest_get_assetBundle_m1127086494 ();
extern "C" void AssetBundleCreateRequest_DisableCompatibilityChecks_m1123061109 ();
extern "C" void AssetBundleRequest__ctor_m23332438 ();
extern "C" void AssetBundleRequest_get_asset_m1618802054 ();
extern "C" void AssetBundleRequest_get_allAssets_m4077343547 ();
extern "C" void AsyncOperation__ctor_m4206607396 ();
extern "C" void AsyncOperation_InternalDestroy_m989121897 ();
extern "C" void AsyncOperation_Finalize_m1982367396 ();
extern "C" void AsyncOperation_get_isDone_m2130057835 ();
extern "C" void AsyncOperation_get_progress_m132026404 ();
extern "C" void AsyncOperation_get_priority_m3349967333 ();
extern "C" void AsyncOperation_set_priority_m2349794837 ();
extern "C" void AsyncOperation_get_allowSceneActivation_m3755262598 ();
extern "C" void AsyncOperation_set_allowSceneActivation_m384018621 ();
extern "C" void AttributeHelperEngine_GetParentTypeDisallowingMultipleInclusion_m4119152402 ();
extern "C" void AttributeHelperEngine_GetRequiredComponents_m942683377 ();
extern "C" void AttributeHelperEngine_CheckIsEditorScript_m4061418281 ();
extern "C" void AttributeHelperEngine_GetDefaultExecutionOrderFor_m3266095226 ();
extern "C" void AttributeHelperEngine__cctor_m3478232574 ();
extern "C" void AudioClipPlayable__ctor_m2695288751_AdjustorThunk ();
extern "C" void AudioClipPlayable_Create_m29077272 ();
extern "C" void AudioClipPlayable_CreateHandle_m931567265 ();
extern "C" void AudioClipPlayable_GetHandle_m943133440_AdjustorThunk ();
extern "C" void AudioClipPlayable_op_Implicit_m2314945005 ();
extern "C" void AudioClipPlayable_op_Explicit_m3538157942 ();
extern "C" void AudioClipPlayable_Equals_m3313539839_AdjustorThunk ();
extern "C" void AudioClipPlayable_GetClip_m2661793626_AdjustorThunk ();
extern "C" void AudioClipPlayable_GetClip_m2699613590_AdjustorThunk ();
extern "C" void AudioClipPlayable_GetClipInternal_m4242826736 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_GetClipInternal_m317731256 ();
extern "C" void AudioClipPlayable_SetClipInternal_m3963613185 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_SetClipInternal_m1813683739 ();
extern "C" void AudioClipPlayable_GetLooped_m794925563_AdjustorThunk ();
extern "C" void AudioClipPlayable_SetLooped_m3574008031_AdjustorThunk ();
extern "C" void AudioClipPlayable_GetLoopedInternal_m1212413764 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_GetLoopedInternal_m3132985087 ();
extern "C" void AudioClipPlayable_SetLoopedInternal_m3850217231 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_SetLoopedInternal_m3163919323 ();
extern "C" void AudioClipPlayable_IsPlaying_m3949290847_AdjustorThunk ();
extern "C" void AudioClipPlayable_GetIsPlayingInternal_m3277395055 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_GetIsPlayingInternal_m3248130146 ();
extern "C" void AudioClipPlayable_GetStartDelay_m2786469541_AdjustorThunk ();
extern "C" void AudioClipPlayable_SetStartDelay_m2489117208_AdjustorThunk ();
extern "C" void AudioClipPlayable_GetStartDelayInternal_m3603302465 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_GetStartDelayInternal_m1864145844 ();
extern "C" void AudioClipPlayable_SetStartDelayInternal_m4184808028 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_SetStartDelayInternal_m3452625175 ();
extern "C" void AudioClipPlayable_GetPauseDelay_m638109021_AdjustorThunk ();
extern "C" void AudioClipPlayable_GetPauseDelay_m663773613_AdjustorThunk ();
extern "C" void AudioClipPlayable_GetPauseDelayInternal_m1384934761 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_GetPauseDelayInternal_m4032398432 ();
extern "C" void AudioClipPlayable_SetPauseDelayInternal_m477818377 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_SetPauseDelayInternal_m234566193 ();
extern "C" void AudioClipPlayable_InternalCreateAudioClipPlayable_m314302546 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_InternalCreateAudioClipPlayable_m496825388 ();
extern "C" void AudioClipPlayable_ValidateType_m3846561236 ();
extern "C" void AudioClipPlayable_INTERNAL_CALL_ValidateType_m2412648730 ();
extern "C" void AudioClipPlayable_Seek_m1537206734_AdjustorThunk ();
extern "C" void AudioClipPlayable_Seek_m743928150_AdjustorThunk ();
extern "C" void AudioClipPlayable_ValidateStartDelayInternal_m2686481105_AdjustorThunk ();
extern "C" void AudioMixerPlayable__ctor_m1764792452_AdjustorThunk ();
extern "C" void AudioMixerPlayable_Create_m3148698328 ();
extern "C" void AudioMixerPlayable_CreateHandle_m4263003578 ();
extern "C" void AudioMixerPlayable_GetHandle_m615245243_AdjustorThunk ();
extern "C" void AudioMixerPlayable_op_Implicit_m2197344530 ();
extern "C" void AudioMixerPlayable_op_Explicit_m231265208 ();
extern "C" void AudioMixerPlayable_Equals_m348392712_AdjustorThunk ();
extern "C" void AudioMixerPlayable_GetAutoNormalizeVolumes_m4252571978_AdjustorThunk ();
extern "C" void AudioMixerPlayable_GetAutoNormalizeVolumes_m2835896126_AdjustorThunk ();
extern "C" void AudioMixerPlayable_GetAutoNormalizeInternal_m3913872939 ();
extern "C" void AudioMixerPlayable_INTERNAL_CALL_GetAutoNormalizeInternal_m2057364040 ();
extern "C" void AudioMixerPlayable_SetAutoNormalizeInternal_m3888761556 ();
extern "C" void AudioMixerPlayable_INTERNAL_CALL_SetAutoNormalizeInternal_m987980948 ();
extern "C" void AudioMixerPlayable_CreateAudioMixerPlayableInternal_m4213450386 ();
extern "C" void AudioMixerPlayable_INTERNAL_CALL_CreateAudioMixerPlayableInternal_m290331118 ();
extern "C" void AudioPlayableOutput__ctor_m1534356330_AdjustorThunk ();
extern "C" void AudioPlayableOutput_Create_m500163179 ();
extern "C" void AudioPlayableOutput_get_Null_m2678190817 ();
extern "C" void AudioPlayableOutput_GetHandle_m22607570_AdjustorThunk ();
extern "C" void AudioPlayableOutput_op_Implicit_m8343428 ();
extern "C" void AudioPlayableOutput_op_Explicit_m2685709622 ();
extern "C" void AudioPlayableOutput_GetTarget_m3546842241_AdjustorThunk ();
extern "C" void AudioPlayableOutput_SetTarget_m1484744610_AdjustorThunk ();
extern "C" void AudioPlayableOutput_InternalGetTarget_m2773003990 ();
extern "C" void AudioPlayableOutput_INTERNAL_CALL_InternalGetTarget_m3249422738 ();
extern "C" void AudioPlayableOutput_InternalSetTarget_m3993687925 ();
extern "C" void AudioPlayableOutput_INTERNAL_CALL_InternalSetTarget_m3185628123 ();
extern "C" void AudioClip_get_length_m2904044266 ();
extern "C" void AudioClip_InvokePCMReaderCallback_Internal_m3969674143 ();
extern "C" void AudioClip_InvokePCMSetPositionCallback_Internal_m4230058079 ();
extern "C" void PCMReaderCallback__ctor_m2058237872 ();
extern "C" void PCMReaderCallback_Invoke_m2813506989 ();
extern "C" void PCMReaderCallback_BeginInvoke_m1187826492 ();
extern "C" void PCMReaderCallback_EndInvoke_m3621326709 ();
extern "C" void PCMSetPositionCallback__ctor_m393872308 ();
extern "C" void PCMSetPositionCallback_Invoke_m1472347517 ();
extern "C" void PCMSetPositionCallback_BeginInvoke_m2213357131 ();
extern "C" void PCMSetPositionCallback_EndInvoke_m92441568 ();
extern "C" void AudioSettings_InvokeOnAudioConfigurationChanged_m61046006 ();
extern "C" void AudioConfigurationChangeHandler__ctor_m1448713277 ();
extern "C" void AudioConfigurationChangeHandler_Invoke_m2768044174 ();
extern "C" void AudioConfigurationChangeHandler_BeginInvoke_m3819714530 ();
extern "C" void AudioConfigurationChangeHandler_EndInvoke_m1284988426 ();
extern "C" void Behaviour__ctor_m645850146 ();
extern "C" void Bounds_GetHashCode_m1439875941_AdjustorThunk ();
extern "C" void Bounds_Equals_m3721596139_AdjustorThunk ();
extern "C" void Bounds_get_center_m1258209247_AdjustorThunk ();
extern "C" void Bounds_get_extents_m3684240117_AdjustorThunk ();
extern "C" void Bounds_ToString_m3832647372_AdjustorThunk ();
extern "C" void BoxCollider__ctor_m597659220 ();
extern "C" void BoxCollider_get_center_m2246712330 ();
extern "C" void BoxCollider_set_center_m1938453905 ();
extern "C" void BoxCollider_INTERNAL_get_center_m2108458525 ();
extern "C" void BoxCollider_INTERNAL_set_center_m1608300232 ();
extern "C" void BoxCollider_get_size_m1661589754 ();
extern "C" void BoxCollider_set_size_m3117771882 ();
extern "C" void BoxCollider_INTERNAL_get_size_m2915107625 ();
extern "C" void BoxCollider_INTERNAL_set_size_m1069292286 ();
extern "C" void BoxCollider_get_extents_m3203461350 ();
extern "C" void BoxCollider_set_extents_m3715940525 ();
extern "C" void Camera_get_nearClipPlane_m595687364 ();
extern "C" void Camera_get_farClipPlane_m672532137 ();
extern "C" void Camera_get_cullingMask_m1829245964 ();
extern "C" void Camera_get_eventMask_m192041623 ();
extern "C" void Camera_get_pixelRect_m2287979086 ();
extern "C" void Camera_INTERNAL_get_pixelRect_m3579949699 ();
extern "C" void Camera_get_targetTexture_m2343817798 ();
extern "C" void Camera_get_clearFlags_m4107941227 ();
extern "C" void Camera_ScreenPointToRay_m2037804860 ();
extern "C" void Camera_INTERNAL_CALL_ScreenPointToRay_m1092094677 ();
extern "C" void Camera_get_allCamerasCount_m202689974 ();
extern "C" void Camera_GetAllCameras_m14780124 ();
extern "C" void Camera_FireOnPreCull_m2833190726 ();
extern "C" void Camera_FireOnPreRender_m3227173956 ();
extern "C" void Camera_FireOnPostRender_m169492450 ();
extern "C" void Camera_RaycastTry_m3445740383 ();
extern "C" void Camera_INTERNAL_CALL_RaycastTry_m3176538179 ();
extern "C" void Camera_RaycastTry2D_m2685151565 ();
extern "C" void Camera_INTERNAL_CALL_RaycastTry2D_m1805928838 ();
extern "C" void CameraCallback__ctor_m2934755836 ();
extern "C" void CameraCallback_Invoke_m3818674482 ();
extern "C" void CameraCallback_BeginInvoke_m996806004 ();
extern "C" void CameraCallback_EndInvoke_m2209671123 ();
extern "C" void CapsuleCollider__ctor_m2230392579 ();
extern "C" void CapsuleCollider_get_center_m3903044238 ();
extern "C" void CapsuleCollider_set_center_m2104777635 ();
extern "C" void CapsuleCollider_INTERNAL_get_center_m343696755 ();
extern "C" void CapsuleCollider_INTERNAL_set_center_m2335165673 ();
extern "C" void CapsuleCollider_get_radius_m4172507562 ();
extern "C" void CapsuleCollider_set_radius_m762145652 ();
extern "C" void CapsuleCollider_get_height_m3662458997 ();
extern "C" void CapsuleCollider_set_height_m2754457501 ();
extern "C" void CapsuleCollider_get_direction_m2169980597 ();
extern "C" void CapsuleCollider_set_direction_m3664861627 ();
extern "C" void CharacterController_Move_m900161214 ();
extern "C" void CharacterController_INTERNAL_CALL_Move_m2501923996 ();
extern "C" void CharacterController_get_isGrounded_m3015943198 ();
extern "C" void ClassLibraryInitializer_Init_m678390546 ();
extern "C" void DeallocateOnJobCompletionAttribute__ctor_m447098597 ();
extern "C" void NativeContainerAttribute__ctor_m119517009 ();
extern "C" void NativeContainerSupportsAtomicWriteAttribute__ctor_m3977352624 ();
extern "C" void NativeContainerSupportsMinMaxWriteRestrictionAttribute__ctor_m1692409002 ();
extern "C" void ReadOnlyAttribute__ctor_m1624519052 ();
extern "C" void ReadWriteAttribute__ctor_m68368940 ();
extern "C" void WriteOnlyAttribute__ctor_m3959797925 ();
extern "C" void Collider__ctor_m170727096 ();
extern "C" void Collider_get_enabled_m1012249734 ();
extern "C" void Collider_set_enabled_m3023772319 ();
extern "C" void Collider_get_attachedRigidbody_m1223649037 ();
extern "C" void Collider_get_isTrigger_m3411014092 ();
extern "C" void Collider_set_isTrigger_m3915953166 ();
extern "C" void Collider_get_contactOffset_m2439063487 ();
extern "C" void Collider_set_contactOffset_m683432949 ();
extern "C" void Collider_get_material_m1577688535 ();
extern "C" void Collider_set_material_m1981090199 ();
extern "C" void Collider_ClosestPointOnBounds_m408573294 ();
extern "C" void Collider_INTERNAL_CALL_ClosestPointOnBounds_m983298871 ();
extern "C" void Collider_ClosestPoint_m1034747586 ();
extern "C" void Collider_INTERNAL_CALL_ClosestPoint_m1905885810 ();
extern "C" void Collider_get_sharedMaterial_m3186711189 ();
extern "C" void Collider_set_sharedMaterial_m378738133 ();
extern "C" void Collider_get_bounds_m1843897070 ();
extern "C" void Collider_INTERNAL_get_bounds_m924372968 ();
extern "C" void Collider_Internal_Raycast_m3210677020 ();
extern "C" void Collider_INTERNAL_CALL_Internal_Raycast_m935082044 ();
extern "C" void Collider_Raycast_m1173729534 ();
extern "C" void Collision__ctor_m2172552466 ();
extern "C" void Collision_get_relativeVelocity_m1709376896 ();
extern "C" void Collision_get_rigidbody_m3834349960 ();
extern "C" void Collision_get_collider_m2199260191 ();
extern "C" void Collision_get_transform_m2373443247 ();
extern "C" void Collision_get_gameObject_m3532016414 ();
extern "C" void Collision_get_contacts_m1067831838 ();
extern "C" void Collision_GetEnumerator_m3074386304 ();
extern "C" void Collision_get_impulse_m306856219 ();
extern "C" void Collision_get_impactForceSum_m3470397102 ();
extern "C" void Collision_get_frictionForceSum_m3332842272 ();
extern "C" void Collision_get_other_m986277678 ();
extern "C" void Component__ctor_m2987636441 ();
extern "C" void Component_get_transform_m1991721595 ();
extern "C" void Component_get_gameObject_m44324674 ();
extern "C" void Component_GetComponent_m4065514490 ();
extern "C" void Component_GetComponentFastPath_m2526947697 ();
extern "C" void Component_GetComponent_m3003597536 ();
extern "C" void Component_GetComponentInChildren_m174763428 ();
extern "C" void Component_GetComponentInChildren_m916963883 ();
extern "C" void Component_GetComponentsInChildren_m3617139144 ();
extern "C" void Component_GetComponentsInChildren_m155792327 ();
extern "C" void Component_GetComponentInParent_m3868731529 ();
extern "C" void Component_GetComponentsInParent_m218516534 ();
extern "C" void Component_GetComponentsInParent_m1469804712 ();
extern "C" void Component_GetComponents_m2744603723 ();
extern "C" void Component_GetComponentsForListInternal_m2222527641 ();
extern "C" void Component_GetComponents_m1300823959 ();
extern "C" void Component_get_tag_m3859973365 ();
extern "C" void Component_set_tag_m1136149524 ();
extern "C" void Component_CompareTag_m95749719 ();
extern "C" void Component_SendMessageUpwards_m2783812412 ();
extern "C" void Component_SendMessageUpwards_m2173372724 ();
extern "C" void Component_SendMessageUpwards_m3268518138 ();
extern "C" void Component_SendMessageUpwards_m3496715621 ();
extern "C" void Component_SendMessage_m4289933507 ();
extern "C" void Component_SendMessage_m3305852972 ();
extern "C" void Component_SendMessage_m872975486 ();
extern "C" void Component_SendMessage_m1196789683 ();
extern "C" void Component_BroadcastMessage_m3258471174 ();
extern "C" void Component_BroadcastMessage_m2127138074 ();
extern "C" void Component_BroadcastMessage_m1539754661 ();
extern "C" void Component_BroadcastMessage_m730653188 ();
extern "C" void ContextMenu__ctor_m3700823191 ();
extern "C" void ContextMenu__ctor_m333661367 ();
extern "C" void ContextMenu__ctor_m1599691754 ();
extern "C" void ControllerColliderHit__ctor_m2011202600 ();
extern "C" void ControllerColliderHit_get_controller_m3364905897 ();
extern "C" void ControllerColliderHit_get_collider_m2056607443 ();
extern "C" void ControllerColliderHit_get_rigidbody_m1353039703 ();
extern "C" void ControllerColliderHit_get_gameObject_m39384490 ();
extern "C" void ControllerColliderHit_get_transform_m2298294070 ();
extern "C" void ControllerColliderHit_get_point_m2077037566 ();
extern "C" void ControllerColliderHit_get_normal_m3810580689 ();
extern "C" void ControllerColliderHit_get_moveDirection_m1063174902 ();
extern "C" void ControllerColliderHit_get_moveLength_m828560915 ();
extern "C" void ControllerColliderHit_get_push_m815657938 ();
extern "C" void ControllerColliderHit_set_push_m243530137 ();
extern "C" void Coroutine__ctor_m2590443731 ();
extern "C" void Coroutine_ReleaseCoroutine_m3781988635 ();
extern "C" void Coroutine_Finalize_m1923989986 ();
extern "C" void CSSMeasureFunc__ctor_m3533652191 ();
extern "C" void CSSMeasureFunc_Invoke_m1154676219 ();
extern "C" void CSSMeasureFunc_BeginInvoke_m2103229683 ();
extern "C" void CSSMeasureFunc_EndInvoke_m2492587638 ();
extern "C" void Native_CSSNodeGetMeasureFunc_m2687424442 ();
extern "C" void Native_CSSNodeMeasureInvoke_m215891493 ();
extern "C" void Native__cctor_m13459289 ();
extern "C" void CullingGroup_Finalize_m1608050186 ();
extern "C" void CullingGroup_Dispose_m1171631894 ();
extern "C" void CullingGroup_SendEvents_m2564931990 ();
extern "C" void CullingGroup_FinalizerFailure_m2017674841 ();
extern "C" void StateChanged__ctor_m2918878156 ();
extern "C" void StateChanged_Invoke_m1198352690 ();
extern "C" void StateChanged_BeginInvoke_m2117606739 ();
extern "C" void StateChanged_EndInvoke_m2248028175 ();
extern "C" void Debug_get_unityLogger_m2347626683 ();
extern "C" void Debug_Log_m612504508 ();
extern "C" void Debug_LogError_m1111084917 ();
extern "C" void Debug_LogWarning_m55671213 ();
extern "C" void Debug__cctor_m1016060880 ();
extern "C" void DebugLogHandler__ctor_m904623223 ();
extern "C" void DebugLogHandler_Internal_Log_m2703551542 ();
extern "C" void DebugLogHandler_LogFormat_m4019243538 ();
extern "C" void DefaultExecutionOrder_get_order_m3764018895 ();
extern "C" void Display__ctor_m2759347064 ();
extern "C" void Display__ctor_m1477480308 ();
extern "C" void Display_RecreateDisplayList_m1233426626 ();
extern "C" void Display_FireDisplaysUpdated_m2028285549 ();
extern "C" void Display__cctor_m3680899297 ();
extern "C" void DisplaysUpdatedDelegate__ctor_m1617523608 ();
extern "C" void DisplaysUpdatedDelegate_Invoke_m2649345203 ();
extern "C" void DisplaysUpdatedDelegate_BeginInvoke_m3935524471 ();
extern "C" void DisplaysUpdatedDelegate_EndInvoke_m341404626 ();
extern "C" void ArgumentCache__ctor_m978772768 ();
extern "C" void ArgumentCache_get_unityObjectArgument_m2085186913 ();
extern "C" void ArgumentCache_get_unityObjectArgumentAssemblyTypeName_m3754631060 ();
extern "C" void ArgumentCache_get_intArgument_m1138448651 ();
extern "C" void ArgumentCache_get_floatArgument_m2018826893 ();
extern "C" void ArgumentCache_get_stringArgument_m2246831120 ();
extern "C" void ArgumentCache_get_boolArgument_m2101152089 ();
extern "C" void ArgumentCache_TidyAssemblyTypeName_m3705917044 ();
extern "C" void ArgumentCache_OnBeforeSerialize_m821915120 ();
extern "C" void ArgumentCache_OnAfterDeserialize_m767341272 ();
extern "C" void BaseInvokableCall__ctor_m3658191802 ();
extern "C" void BaseInvokableCall_AllowInvoke_m472262968 ();
extern "C" void InvokableCall__ctor_m3996529049 ();
extern "C" void InvokableCall_add_Delegate_m2438976025 ();
extern "C" void InvokableCall_remove_Delegate_m3721333387 ();
extern "C" void InvokableCall_Invoke_m1289604502 ();
extern "C" void InvokableCallList__ctor_m1888224612 ();
extern "C" void InvokableCallList_AddPersistentInvokableCall_m2704573799 ();
extern "C" void InvokableCallList_ClearPersistent_m2631436529 ();
extern "C" void InvokableCallList_Invoke_m1328600370 ();
extern "C" void PersistentCall__ctor_m756985338 ();
extern "C" void PersistentCall_get_target_m2727150134 ();
extern "C" void PersistentCall_get_methodName_m30496994 ();
extern "C" void PersistentCall_get_mode_m3619043292 ();
extern "C" void PersistentCall_get_arguments_m4221462882 ();
extern "C" void PersistentCall_IsValid_m224654533 ();
extern "C" void PersistentCall_GetRuntimeCall_m353611327 ();
extern "C" void PersistentCall_GetObjectCall_m2089564283 ();
extern "C" void PersistentCallGroup__ctor_m2284274197 ();
extern "C" void PersistentCallGroup_Initialize_m1460089847 ();
extern "C" void UnityAction__ctor_m3295801254 ();
extern "C" void UnityAction_Invoke_m4258657167 ();
extern "C" void UnityAction_BeginInvoke_m3553174952 ();
extern "C" void UnityAction_EndInvoke_m879801910 ();
extern "C" void UnityEvent__ctor_m709418737 ();
extern "C" void UnityEvent_FindMethod_Impl_m1632288100 ();
extern "C" void UnityEvent_GetDelegate_m254459601 ();
extern "C" void UnityEventBase__ctor_m952299846 ();
extern "C" void UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m3971120570 ();
extern "C" void UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m647175948 ();
extern "C" void UnityEventBase_FindMethod_m1865515850 ();
extern "C" void UnityEventBase_FindMethod_m237643499 ();
extern "C" void UnityEventBase_DirtyPersistentCalls_m2995072991 ();
extern "C" void UnityEventBase_RebuildPersistentCallsIfNeeded_m3255273588 ();
extern "C" void UnityEventBase_Invoke_m434153928 ();
extern "C" void UnityEventBase_ToString_m3093412050 ();
extern "C" void UnityEventBase_GetValidMethodInfo_m3311978107 ();
extern "C" void RenderPipelineManager_get_currentPipeline_m3200673172 ();
extern "C" void RenderPipelineManager_set_currentPipeline_m1673100204 ();
extern "C" void RenderPipelineManager_CleanupRenderPipeline_m3163400220 ();
extern "C" void RenderPipelineManager_DoRenderLoop_Internal_m2060351888 ();
extern "C" void RenderPipelineManager_PrepareRenderPipeline_m2230027504 ();
extern "C" void ScriptableRenderContext__ctor_m2560532740_AdjustorThunk ();
extern "C" void FailedToLoadScriptObject__ctor_m3446975753 ();
extern "C" void Font_InvokeTextureRebuilt_Internal_m3404887950 ();
extern "C" void FontTextureRebuildCallback__ctor_m2739639569 ();
extern "C" void FontTextureRebuildCallback_Invoke_m647222893 ();
extern "C" void FontTextureRebuildCallback_BeginInvoke_m1136377575 ();
extern "C" void FontTextureRebuildCallback_EndInvoke_m3293464560 ();
extern "C" void GameObject_GetComponent_m2381985773 ();
extern "C" void GameObject_GetComponentInChildren_m1168178952 ();
extern "C" void GameObject_GetComponentInParent_m576974860 ();
extern "C" void GameObject_GetComponents_m133749314 ();
extern "C" void GameObject_GetComponentsInChildren_m544289345 ();
extern "C" void GameObject_GetComponentsInParent_m3716665394 ();
extern "C" void GameObject_GetComponentsInternal_m3558330862 ();
extern "C" void GameObject_get_transform_m3351892996 ();
extern "C" void GameObject_SetActive_m924703582 ();
extern "C" void GameObject_get_tag_m3253026982 ();
extern "C" void GameObject_set_tag_m2601144065 ();
extern "C" void GameObject_CompareTag_m4047912073 ();
extern "C" void GameObject_FindGameObjectWithTag_m3016707382 ();
extern "C" void GameObject_SendMessage_m1793137815 ();
extern "C" void GameObject_Find_m357843493 ();
extern "C" void GameObject_get_gameObject_m1404374750 ();
extern "C" void Gradient__ctor_m3449608876 ();
extern "C" void Gradient_Init_m665431756 ();
extern "C" void Gradient_Cleanup_m3762357176 ();
extern "C" void Gradient_Finalize_m3282868344 ();
extern "C" void GUILayer_HitTest_m675486399 ();
extern "C" void GUILayer_INTERNAL_CALL_HitTest_m169839011 ();
extern "C" void Input_GetKeyDownInt_m634892559 ();
extern "C" void Input_GetAxis_m1666418521 ();
extern "C" void Input_GetKeyDown_m1509524102 ();
extern "C" void Input_GetMouseButton_m3485621271 ();
extern "C" void Input_GetMouseButtonDown_m3468031552 ();
extern "C" void Input_get_mousePosition_m1929519408 ();
extern "C" void Input_INTERNAL_get_mousePosition_m2607797593 ();
extern "C" void Input__cctor_m1276431848 ();
extern "C" void DefaultValueAttribute__ctor_m1493972517 ();
extern "C" void DefaultValueAttribute_get_Value_m1750514521 ();
extern "C" void DefaultValueAttribute_Equals_m28642653 ();
extern "C" void DefaultValueAttribute_GetHashCode_m3039019552 ();
extern "C" void ExcludeFromDocsAttribute__ctor_m1396943425 ();
extern "C" void Keyframe__ctor_m3375943797_AdjustorThunk ();
extern "C" void Keyframe__ctor_m621010815_AdjustorThunk ();
extern "C" void Keyframe_get_time_m3515509166_AdjustorThunk ();
extern "C" void Keyframe_set_time_m4108362711_AdjustorThunk ();
extern "C" void Keyframe_get_value_m3983510015_AdjustorThunk ();
extern "C" void Keyframe_set_value_m3659278961_AdjustorThunk ();
extern "C" void Keyframe_get_inTangent_m867801259_AdjustorThunk ();
extern "C" void Keyframe_set_inTangent_m2022606981_AdjustorThunk ();
extern "C" void Keyframe_get_outTangent_m862308822_AdjustorThunk ();
extern "C" void Keyframe_set_outTangent_m5132678_AdjustorThunk ();
extern "C" void Keyframe_get_tangentMode_m4035898618_AdjustorThunk ();
extern "C" void Keyframe_set_tangentMode_m847764452_AdjustorThunk ();
extern "C" void Logger__ctor_m1843464247 ();
extern "C" void Logger_get_logHandler_m1001975644 ();
extern "C" void Logger_set_logHandler_m4221272157 ();
extern "C" void Logger_get_logEnabled_m1878659891 ();
extern "C" void Logger_set_logEnabled_m771198447 ();
extern "C" void Logger_get_filterLogType_m3099848982 ();
extern "C" void Logger_set_filterLogType_m602084239 ();
extern "C" void Logger_IsLogTypeAllowed_m1927143829 ();
extern "C" void Logger_GetString_m2607591468 ();
extern "C" void Logger_Log_m3814276168 ();
extern "C" void Logger_LogFormat_m2728955062 ();
extern "C" void Mathf_Abs_m4037208640 ();
extern "C" void Mathf_Max_m943320266 ();
extern "C" void Mathf_Approximately_m952241212 ();
extern "C" void Mathf__cctor_m3833489122 ();
extern "C" void MeshCollider__ctor_m83612706 ();
extern "C" void MeshCollider_get_sharedMesh_m3981733887 ();
extern "C" void MeshCollider_set_sharedMesh_m1749649964 ();
extern "C" void MeshCollider_get_convex_m3624458602 ();
extern "C" void MeshCollider_set_convex_m3852711973 ();
extern "C" void MeshCollider_get_inflateMesh_m3117051985 ();
extern "C" void MeshCollider_set_inflateMesh_m3536367144 ();
extern "C" void MeshCollider_get_skinWidth_m4113017802 ();
extern "C" void MeshCollider_set_skinWidth_m480533321 ();
extern "C" void MeshCollider_get_smoothSphereCollisions_m4022807522 ();
extern "C" void MeshCollider_set_smoothSphereCollisions_m3702800312 ();
extern "C" void MonoBehaviour__ctor_m1236242179 ();
extern "C" void MonoBehaviour_Internal_CancelInvokeAll_m134567439 ();
extern "C" void MonoBehaviour_Internal_IsInvokingAll_m2498687012 ();
extern "C" void MonoBehaviour_Invoke_m1445658415 ();
extern "C" void MonoBehaviour_InvokeRepeating_m1711920500 ();
extern "C" void MonoBehaviour_CancelInvoke_m2492398622 ();
extern "C" void MonoBehaviour_CancelInvoke_m3804726668 ();
extern "C" void MonoBehaviour_IsInvoking_m878787515 ();
extern "C" void MonoBehaviour_IsInvoking_m3111854111 ();
extern "C" void MonoBehaviour_StartCoroutine_m987154008 ();
extern "C" void MonoBehaviour_StartCoroutine_Auto_m597942758 ();
extern "C" void MonoBehaviour_StartCoroutine_Auto_Internal_m1203968900 ();
extern "C" void MonoBehaviour_StartCoroutine_m1532927778 ();
extern "C" void MonoBehaviour_StartCoroutine_m2151747079 ();
extern "C" void MonoBehaviour_StopCoroutine_m2372275704 ();
extern "C" void MonoBehaviour_StopCoroutine_m1079755942 ();
extern "C" void MonoBehaviour_StopCoroutine_m2707859735 ();
extern "C" void MonoBehaviour_StopCoroutineViaEnumerator_Auto_m2517862605 ();
extern "C" void MonoBehaviour_StopCoroutine_Auto_m1706763131 ();
extern "C" void MonoBehaviour_StopAllCoroutines_m3012207369 ();
extern "C" void MonoBehaviour_print_m134029734 ();
extern "C" void MonoBehaviour_get_useGUILayout_m14506679 ();
extern "C" void MonoBehaviour_set_useGUILayout_m3498661562 ();
extern "C" void MonoBehaviour_GetScriptClassName_m574979679 ();
extern "C" void NativeClassAttribute__ctor_m130061132 ();
extern "C" void NativeClassAttribute_set_QualifiedNativeName_m293935591 ();
extern "C" void MessageEventArgs__ctor_m1335534639 ();
extern "C" void PlayerConnection__ctor_m3750197023 ();
extern "C" void PlayerConnection_get_instance_m2181360178 ();
extern "C" void PlayerConnection_CreateInstance_m3079562849 ();
extern "C" void PlayerConnection_MessageCallbackInternal_m2888194805 ();
extern "C" void PlayerConnection_ConnectedCallbackInternal_m989124288 ();
extern "C" void PlayerConnection_DisconnectedCallback_m571541410 ();
extern "C" void PlayerEditorConnectionEvents__ctor_m3505813805 ();
extern "C" void PlayerEditorConnectionEvents_InvokeMessageIdSubscribers_m2164178597 ();
extern "C" void U3CInvokeMessageIdSubscribersU3Ec__AnonStorey0__ctor_m2842646309 ();
extern "C" void U3CInvokeMessageIdSubscribersU3Ec__AnonStorey0_U3CU3Em__0_m534577330 ();
extern "C" void ConnectionChangeEvent__ctor_m3284882777 ();
extern "C" void MessageEvent__ctor_m3747138721 ();
extern "C" void MessageTypeSubscribers__ctor_m2191380784 ();
extern "C" void MessageTypeSubscribers_get_MessageTypeId_m3512502684 ();
extern "C" void Object__ctor_m753889125 ();
extern "C" void Object_Internal_CloneSingle_m1112466195 ();
extern "C" void Object_Internal_CloneSingleWithParent_m1578544937 ();
extern "C" void Object_Internal_InstantiateSingle_m2703482481 ();
extern "C" void Object_INTERNAL_CALL_Internal_InstantiateSingle_m2354361480 ();
extern "C" void Object_Internal_InstantiateSingleWithParent_m253669687 ();
extern "C" void Object_INTERNAL_CALL_Internal_InstantiateSingleWithParent_m3351340621 ();
extern "C" void Object_GetOffsetOfInstanceIDInCPlusPlusObject_m2289052263 ();
extern "C" void Object_EnsureRunningOnMainThread_m2181426889 ();
extern "C" void Object_Destroy_m763870395 ();
extern "C" void Object_Destroy_m2578737452 ();
extern "C" void Object_DestroyImmediate_m3667352557 ();
extern "C" void Object_DestroyImmediate_m3664569503 ();
extern "C" void Object_FindObjectsOfType_m4065607311 ();
extern "C" void Object_get_name_m4131808298 ();
extern "C" void Object_set_name_m1574609734 ();
extern "C" void Object_DontDestroyOnLoad_m3006908952 ();
extern "C" void Object_get_hideFlags_m606243072 ();
extern "C" void Object_set_hideFlags_m1764873955 ();
extern "C" void Object_DestroyObject_m3415511966 ();
extern "C" void Object_DestroyObject_m4157767402 ();
extern "C" void Object_FindSceneObjectsOfType_m1789838274 ();
extern "C" void Object_FindObjectsOfTypeIncludingAssets_m2898151650 ();
extern "C" void Object_ToString_m1543712694 ();
extern "C" void Object_DoesObjectWithInstanceIDExist_m249218142 ();
extern "C" void Object_GetInstanceID_m2901521971 ();
extern "C" void Object_GetHashCode_m3929092075 ();
extern "C" void Object_Equals_m3089707722 ();
extern "C" void Object_op_Implicit_m1617934672 ();
extern "C" void Object_CompareBaseObjects_m2495735120 ();
extern "C" void Object_IsNativeObjectAlive_m2398424896 ();
extern "C" void Object_GetCachedPtr_m183934072 ();
extern "C" void Object_Instantiate_m3626274236 ();
extern "C" void Object_Instantiate_m499133587 ();
extern "C" void Object_Instantiate_m2255325978 ();
extern "C" void Object_Instantiate_m1560403475 ();
extern "C" void Object_Instantiate_m2568982308 ();
extern "C" void Object_CheckNullArgument_m3394949661 ();
extern "C" void Object_FindObjectOfType_m1934888875 ();
extern "C" void Object_op_Equality_m1841232993 ();
extern "C" void Object_op_Inequality_m807138295 ();
extern "C" void Object__cctor_m1330512343 ();
extern "C" void Physics_Raycast_m3719768030 ();
extern "C" void Physics_Raycast_m2350840452 ();
extern "C" void Physics_Raycast_m913384994 ();
extern "C" void Physics_Raycast_m3873687999 ();
extern "C" void Physics_Raycast_m3877441014 ();
extern "C" void Physics_Raycast_m3826659266 ();
extern "C" void Physics_Raycast_m2170746783 ();
extern "C" void Physics_Raycast_m2445896246 ();
extern "C" void Physics_Raycast_m2802259901 ();
extern "C" void Physics_Raycast_m2419782515 ();
extern "C" void Physics_Raycast_m3871305434 ();
extern "C" void Physics_Raycast_m3013423287 ();
extern "C" void Physics_Raycast_m3076132749 ();
extern "C" void Physics_Raycast_m1510999213 ();
extern "C" void Physics_Raycast_m54040585 ();
extern "C" void Physics_Raycast_m3887300606 ();
extern "C" void Physics_RaycastAll_m3686607343 ();
extern "C" void Physics_RaycastAll_m2500737461 ();
extern "C" void Physics_RaycastAll_m4120885497 ();
extern "C" void Physics_RaycastAll_m1735216570 ();
extern "C" void Physics_RaycastAll_m2296021024 ();
extern "C" void Physics_RaycastAll_m1144311404 ();
extern "C" void Physics_RaycastAll_m98091116 ();
extern "C" void Physics_RaycastAll_m1515184189 ();
extern "C" void Physics_INTERNAL_CALL_RaycastAll_m3201440179 ();
extern "C" void Physics_Internal_Raycast_m370680247 ();
extern "C" void Physics_INTERNAL_CALL_Internal_Raycast_m2853825113 ();
extern "C" void Physics_Internal_RaycastTest_m3350079960 ();
extern "C" void Physics_INTERNAL_CALL_Internal_RaycastTest_m3339338234 ();
extern "C" void AudioPlayableGraphExtensions_InternalCreateAudioOutput_m2760089805 ();
extern "C" void AudioPlayableGraphExtensions_INTERNAL_CALL_InternalCreateAudioOutput_m2119112406 ();
extern "C" void Playable__ctor_m3869525416_AdjustorThunk ();
extern "C" void Playable_get_Null_m1880508074 ();
extern "C" void Playable_Create_m3130309429 ();
extern "C" void Playable_GetHandle_m1873049269_AdjustorThunk ();
extern "C" void Playable_GetPlayableType_m1010025280_AdjustorThunk ();
extern "C" void Playable_Equals_m2026210489_AdjustorThunk ();
extern "C" void Playable__cctor_m2415123826 ();
extern "C" void PlayableAsset__ctor_m2498857636 ();
extern "C" void PlayableAsset_get_duration_m273148557 ();
extern "C" void PlayableAsset_Internal_CreatePlayable_m3902392072 ();
extern "C" void PlayableAsset_Internal_GetPlayableAssetDuration_m614503739 ();
extern "C" void PlayableBehaviour__ctor_m1533023592 ();
extern "C" void PlayableBehaviour_OnGraphStart_m3751382941 ();
extern "C" void PlayableBehaviour_OnGraphStop_m807125375 ();
extern "C" void PlayableBehaviour_OnPlayableCreate_m2568009617 ();
extern "C" void PlayableBehaviour_OnPlayableDestroy_m3890844663 ();
extern "C" void PlayableBehaviour_OnBehaviourPlay_m2743359125 ();
extern "C" void PlayableBehaviour_OnBehaviourPause_m3831040736 ();
extern "C" void PlayableBehaviour_PrepareFrame_m3099946399 ();
extern "C" void PlayableBehaviour_ProcessFrame_m3633324633 ();
extern "C" void PlayableBehaviour_Clone_m3611151540 ();
extern "C" void PlayableBinding__cctor_m2720713679 ();
extern "C" void PlayableGraph_CreateScriptOutputInternal_m2484796455 ();
extern "C" void PlayableGraph_INTERNAL_CALL_CreateScriptOutputInternal_m2263530833 ();
extern "C" void PlayableGraph_CreatePlayableHandle_m2762512469_AdjustorThunk ();
extern "C" void PlayableGraph_CreatePlayableHandleInternal_m2343702139 ();
extern "C" void PlayableGraph_INTERNAL_CALL_CreatePlayableHandleInternal_m848171998 ();
extern "C" void PlayableHandle_IsValid_m2443557981_AdjustorThunk ();
extern "C" void PlayableHandle_IsValidInternal_m4090848785 ();
extern "C" void PlayableHandle_INTERNAL_CALL_IsValidInternal_m2904663435 ();
extern "C" void PlayableHandle_GetPlayableTypeOf_m872040087 ();
extern "C" void PlayableHandle_INTERNAL_CALL_GetPlayableTypeOf_m1882865113 ();
extern "C" void PlayableHandle_GetPlayableType_m2542186169_AdjustorThunk ();
extern "C" void PlayableHandle_get_Null_m2427385690 ();
extern "C" void PlayableHandle_SetInputCount_m56214378_AdjustorThunk ();
extern "C" void PlayableHandle_GetPlayState_m1627799370_AdjustorThunk ();
extern "C" void PlayableHandle_SetPlayState_m3741862175_AdjustorThunk ();
extern "C" void PlayableHandle_SetTime_m4155031655_AdjustorThunk ();
extern "C" void PlayableHandle_GetPlayStateInternal_m1805454215 ();
extern "C" void PlayableHandle_INTERNAL_CALL_GetPlayStateInternal_m79066241 ();
extern "C" void PlayableHandle_SetPlayStateInternal_m1980428610 ();
extern "C" void PlayableHandle_INTERNAL_CALL_SetPlayStateInternal_m3501090634 ();
extern "C" void PlayableHandle_SetTimeInternal_m2135663238 ();
extern "C" void PlayableHandle_INTERNAL_CALL_SetTimeInternal_m207615318 ();
extern "C" void PlayableHandle_SetDuration_m2271770484_AdjustorThunk ();
extern "C" void PlayableHandle_SetDurationInternal_m1685957906 ();
extern "C" void PlayableHandle_INTERNAL_CALL_SetDurationInternal_m2581365362 ();
extern "C" void PlayableHandle_SetInputCountInternal_m3252640859 ();
extern "C" void PlayableHandle_INTERNAL_CALL_SetInputCountInternal_m4151268303 ();
extern "C" void PlayableHandle_op_Equality_m2909715220 ();
extern "C" void PlayableHandle_Equals_m576441965_AdjustorThunk ();
extern "C" void PlayableHandle_GetHashCode_m2709720462_AdjustorThunk ();
extern "C" void PlayableHandle_CompareVersion_m4054145532 ();
extern "C" void PlayableOutput__ctor_m3062526119_AdjustorThunk ();
extern "C" void PlayableOutput_get_Null_m3698924701 ();
extern "C" void PlayableOutput_GetHandle_m3642647841_AdjustorThunk ();
extern "C" void PlayableOutput_GetPlayableOutputType_m2773985409_AdjustorThunk ();
extern "C" void PlayableOutput_Equals_m3613042663_AdjustorThunk ();
extern "C" void PlayableOutput__cctor_m4075004488 ();
extern "C" void PlayableOutputHandle_IsValid_m3916326617_AdjustorThunk ();
extern "C" void PlayableOutputHandle_IsValidInternal_m122093935 ();
extern "C" void PlayableOutputHandle_INTERNAL_CALL_IsValidInternal_m2309803248 ();
extern "C" void PlayableOutputHandle_get_Null_m3448815846 ();
extern "C" void PlayableOutputHandle_GetPlayableOutputTypeOf_m1406648156 ();
extern "C" void PlayableOutputHandle_INTERNAL_CALL_GetPlayableOutputTypeOf_m4071527298 ();
extern "C" void PlayableOutputHandle_GetHashCode_m1652241056_AdjustorThunk ();
extern "C" void PlayableOutputHandle_op_Equality_m3525409465 ();
extern "C" void PlayableOutputHandle_Equals_m807675596_AdjustorThunk ();
extern "C" void PlayableOutputHandle_CompareVersion_m1863899043 ();
extern "C" void ScriptPlayableOutput__ctor_m286455169_AdjustorThunk ();
extern "C" void ScriptPlayableOutput_Create_m3744637025 ();
extern "C" void ScriptPlayableOutput_get_Null_m3074915722 ();
extern "C" void ScriptPlayableOutput_GetHandle_m3375046477_AdjustorThunk ();
extern "C" void ScriptPlayableOutput_op_Implicit_m2701921693 ();
extern "C" void ScriptPlayableOutput_op_Explicit_m2632156067 ();
extern "C" void PreferBinarySerialization__ctor_m1138231225 ();
extern "C" void Quaternion__ctor_m131034559_AdjustorThunk ();
extern "C" void Quaternion_Inverse_m944315417 ();
extern "C" void Quaternion_INTERNAL_CALL_Inverse_m2122284289 ();
extern "C" void Quaternion_set_eulerAngles_m1585488089_AdjustorThunk ();
extern "C" void Quaternion_Euler_m523267498 ();
extern "C" void Quaternion_Internal_FromEulerRad_m1804366691 ();
extern "C" void Quaternion_INTERNAL_CALL_Internal_FromEulerRad_m1158394978 ();
extern "C" void Quaternion_op_Multiply_m1893531635 ();
extern "C" void Quaternion_GetHashCode_m135706246_AdjustorThunk ();
extern "C" void Quaternion_Equals_m303852547_AdjustorThunk ();
extern "C" void Quaternion_ToString_m521349143_AdjustorThunk ();
extern "C" void Quaternion__cctor_m3007313557 ();
extern "C" void Ray_get_origin_m3751020661_AdjustorThunk ();
extern "C" void Ray_get_direction_m86554809_AdjustorThunk ();
extern "C" void Ray_ToString_m2023220715_AdjustorThunk ();
extern "C" void Rect_get_x_m1287081870_AdjustorThunk ();
extern "C" void Rect_get_y_m3638505275_AdjustorThunk ();
extern "C" void Rect_get_width_m2698079399_AdjustorThunk ();
extern "C" void Rect_get_height_m1296734715_AdjustorThunk ();
extern "C" void Rect_get_xMin_m4187551037_AdjustorThunk ();
extern "C" void Rect_get_yMin_m3526403013_AdjustorThunk ();
extern "C" void Rect_get_xMax_m1296688675_AdjustorThunk ();
extern "C" void Rect_get_yMax_m3195629982_AdjustorThunk ();
extern "C" void Rect_Contains_m387453500_AdjustorThunk ();
extern "C" void Rect_GetHashCode_m1396616131_AdjustorThunk ();
extern "C" void Rect_Equals_m3608516552_AdjustorThunk ();
extern "C" void Rect_ToString_m3206280085_AdjustorThunk ();
extern "C" void RectTransform_SendReapplyDrivenProperties_m1673235392 ();
extern "C" void ReapplyDrivenProperties__ctor_m2556620373 ();
extern "C" void ReapplyDrivenProperties_Invoke_m3966453462 ();
extern "C" void ReapplyDrivenProperties_BeginInvoke_m3938025644 ();
extern "C" void ReapplyDrivenProperties_EndInvoke_m2126455265 ();
extern "C" void RemoteSettings_CallOnUpdate_m3230028317 ();
extern "C" void UpdatedEventHandler__ctor_m2546761048 ();
extern "C" void UpdatedEventHandler_Invoke_m2210614729 ();
extern "C" void UpdatedEventHandler_BeginInvoke_m2860243907 ();
extern "C" void UpdatedEventHandler_EndInvoke_m3311727003 ();
extern "C" void RequireComponent__ctor_m715180030 ();
extern "C" void ResourceRequest__ctor_m2395305398 ();
extern "C" void ResourceRequest_get_asset_m3601521397 ();
extern "C" void Resources_Load_m3111310461 ();
extern "C" void Rigidbody_set_velocity_m44238466 ();
extern "C" void Rigidbody_INTERNAL_set_velocity_m36759112 ();
extern "C" void Rigidbody_get_isKinematic_m3289074417 ();
extern "C" void Rigidbody_set_isKinematic_m3808468253 ();
extern "C" void Rigidbody_set_constraints_m1675396742 ();
extern "C" void Scene_get_handle_m2450444867_AdjustorThunk ();
extern "C" void Scene_GetHashCode_m3462008335_AdjustorThunk ();
extern "C" void Scene_Equals_m1417674842_AdjustorThunk ();
extern "C" void SceneManager_Internal_SceneLoaded_m4213089961 ();
extern "C" void SceneManager_Internal_SceneUnloaded_m4274988325 ();
extern "C" void SceneManager_Internal_ActiveSceneChanged_m237859709 ();
extern "C" void ScriptableObject__ctor_m831057273 ();
extern "C" void ScriptableObject_Internal_CreateScriptableObject_m497791512 ();
extern "C" void ScriptableObject_CreateInstance_m1184682349 ();
extern "C" void ScriptableObject_CreateInstance_m2572500432 ();
extern "C" void ScriptableObject_CreateInstanceFromType_m1377228085 ();
extern "C" void GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088 ();
extern "C" void RequiredByNativeCodeAttribute__ctor_m3712479437 ();
extern "C" void UsedByNativeCodeAttribute__ctor_m2169491047 ();
extern "C" void SendMouseEvents_SetMouseMoved_m1615166369 ();
extern "C" void SendMouseEvents_DoSendMouseEvents_m1673877171 ();
extern "C" void SendMouseEvents_SendEvents_m895636432 ();
extern "C" void SendMouseEvents__cctor_m1585552520 ();
extern "C" void HitInfo_SendMessage_m1210191586_AdjustorThunk ();
extern "C" void HitInfo_op_Implicit_m2445466641 ();
extern "C" void HitInfo_Compare_m921880542 ();
extern "C" void FormerlySerializedAsAttribute__ctor_m2819130373 ();
extern "C" void FormerlySerializedAsAttribute_get_oldName_m708849870 ();
extern "C" void SerializeField__ctor_m3105624160 ();
extern "C" void SerializePrivateVariables__ctor_m1720211868 ();
extern "C" void SetupCoroutine_InvokeMoveNext_m2573614623 ();
extern "C" void SetupCoroutine_InvokeMember_m3217874590 ();
extern "C" void SphereCollider__ctor_m1465852125 ();
extern "C" void SphereCollider_get_center_m1650807351 ();
extern "C" void SphereCollider_set_center_m2457717084 ();
extern "C" void SphereCollider_INTERNAL_get_center_m3462447041 ();
extern "C" void SphereCollider_INTERNAL_set_center_m3242641947 ();
extern "C" void SphereCollider_get_radius_m1946668759 ();
extern "C" void SphereCollider_set_radius_m2008006599 ();
extern "C" void StackTraceUtility_SetProjectFolder_m2868605785 ();
extern "C" void StackTraceUtility_ExtractStackTrace_m1508434409 ();
extern "C" void StackTraceUtility_IsSystemStacktraceType_m1940444886 ();
extern "C" void StackTraceUtility_ExtractStringFromExceptionInternal_m3206191879 ();
extern "C" void StackTraceUtility_PostprocessStacktrace_m8392584 ();
extern "C" void StackTraceUtility_ExtractFormattedStackTrace_m2968975606 ();
extern "C" void StackTraceUtility__cctor_m1266974634 ();
extern "C" void ThreadAndSerializationSafeAttribute__ctor_m14339559 ();
extern "C" void Time_get_deltaTime_m3885432000 ();
extern "C" void Transform_get_position_m711175457 ();
extern "C" void Transform_set_position_m3893147833 ();
extern "C" void Transform_INTERNAL_get_position_m2271944548 ();
extern "C" void Transform_INTERNAL_set_position_m2678488908 ();
extern "C" void Transform_get_rotation_m1446247215 ();
extern "C" void Transform_set_rotation_m3616398901 ();
extern "C" void Transform_INTERNAL_get_rotation_m3993959474 ();
extern "C" void Transform_INTERNAL_set_rotation_m3387907152 ();
extern "C" void Transform_get_localRotation_m829296482 ();
extern "C" void Transform_set_localRotation_m3913585663 ();
extern "C" void Transform_INTERNAL_get_localRotation_m420822815 ();
extern "C" void Transform_INTERNAL_set_localRotation_m365960821 ();
extern "C" void Transform_Rotate_m2953437478 ();
extern "C" void Transform_Rotate_m1099066500 ();
extern "C" void Transform_Rotate_m678397658 ();
extern "C" void Transform_get_childCount_m4116705935 ();
extern "C" void Transform_GetEnumerator_m454680747 ();
extern "C" void Transform_GetChild_m1662106098 ();
extern "C" void Enumerator__ctor_m2577253463 ();
extern "C" void Enumerator_get_Current_m2830446975 ();
extern "C" void Enumerator_MoveNext_m3000436454 ();
extern "C" void Enumerator_Reset_m2399314265 ();
extern "C" void SpriteAtlasManager_RequestAtlas_m351979735 ();
extern "C" void SpriteAtlasManager_Register_m3968478932 ();
extern "C" void SpriteAtlasManager__cctor_m633847741 ();
extern "C" void RequestAtlasCallback__ctor_m1940397596 ();
extern "C" void RequestAtlasCallback_Invoke_m2260126922 ();
extern "C" void RequestAtlasCallback_BeginInvoke_m2546690022 ();
extern "C" void RequestAtlasCallback_EndInvoke_m4227810528 ();
extern "C" void UnityException__ctor_m1555052860 ();
extern "C" void UnityException__ctor_m3766139554 ();
extern "C" void UnityException__ctor_m3034370437 ();
extern "C" void UnityString_Format_m2073054251 ();
extern "C" void UnitySynchronizationContext__ctor_m229789324 ();
extern "C" void UnitySynchronizationContext_Exec_m3516798445 ();
extern "C" void UnitySynchronizationContext_InitializeSynchronizationContext_m3655849499 ();
extern "C" void UnitySynchronizationContext_ExecuteTasks_m691963302 ();
extern "C" void WorkRequest_Invoke_m2250752811_AdjustorThunk ();
extern "C" void Vector2__ctor_m1379939419_AdjustorThunk ();
extern "C" void Vector2_ToString_m2249113751_AdjustorThunk ();
extern "C" void Vector2_GetHashCode_m3354548468_AdjustorThunk ();
extern "C" void Vector2_Equals_m730962973_AdjustorThunk ();
extern "C" void Vector2__cctor_m1950777118 ();
extern "C" void Vector3__ctor_m4052953749_AdjustorThunk ();
extern "C" void Vector3_GetHashCode_m3133414896_AdjustorThunk ();
extern "C" void Vector3_Equals_m964850638_AdjustorThunk ();
extern "C" void Vector3_get_zero_m2204703071 ();
extern "C" void Vector3_op_Addition_m1168168007 ();
extern "C" void Vector3_op_Subtraction_m107949794 ();
extern "C" void Vector3_op_Multiply_m1972684293 ();
extern "C" void Vector3_op_Multiply_m3725125284 ();
extern "C" void Vector3_ToString_m2214970796_AdjustorThunk ();
extern "C" void Vector3__cctor_m1893743815 ();
extern "C" void WaitForEndOfFrame__ctor_m2543048271 ();
extern "C" void WaitForFixedUpdate__ctor_m384654351 ();
extern "C" void WaitForSeconds__ctor_m353700436 ();
extern "C" void WritableAttribute__ctor_m2889669273 ();
extern "C" void YieldInstruction__ctor_m4142490385 ();
extern "C" void MathfInternal__cctor_m29666380 ();
extern "C" void NetFxCoreExtensions_CreateDelegate_m1280007241 ();
extern "C" void TypeInferenceRuleAttribute__ctor_m273865400 ();
extern "C" void TypeInferenceRuleAttribute__ctor_m2633202458 ();
extern "C" void TypeInferenceRuleAttribute_ToString_m2239167322 ();
extern "C" void WebRequestUtils_RedirectTo_m1519057860 ();
extern "C" void WebRequestUtils__cctor_m1127827934 ();
extern "C" void AnalyticsTracker__ctor_m4036703947 ();
extern "C" void AnalyticsTracker_get_eventName_m545508370 ();
extern "C" void AnalyticsTracker_set_eventName_m2753990119 ();
extern "C" void AnalyticsTracker_get_TP_m1357043539 ();
extern "C" void AnalyticsTracker_set_TP_m895689910 ();
extern "C" void AnalyticsTracker_Awake_m3429851212 ();
extern "C" void AnalyticsTracker_Start_m3303986160 ();
extern "C" void AnalyticsTracker_OnEnable_m48702781 ();
extern "C" void AnalyticsTracker_OnDisable_m4191761106 ();
extern "C" void AnalyticsTracker_OnApplicationPause_m3716850000 ();
extern "C" void AnalyticsTracker_OnDestroy_m2511155376 ();
extern "C" void AnalyticsTracker_TriggerEvent_m1510154244 ();
extern "C" void AnalyticsTracker_SendEvent_m2472808613 ();
extern "C" void AnalyticsTracker_BuildParameters_m1739240218 ();
extern "C" void TrackableProperty__ctor_m2933150026 ();
extern "C" void TrackableProperty_get_fields_m1105770405 ();
extern "C" void TrackableProperty_set_fields_m279267918 ();
extern "C" void TrackableProperty_GetHashCode_m2535425558 ();
extern "C" void FieldWithTarget__ctor_m2879209876 ();
extern "C" void FieldWithTarget_get_paramName_m787538260 ();
extern "C" void FieldWithTarget_set_paramName_m167468789 ();
extern "C" void FieldWithTarget_get_target_m2983307788 ();
extern "C" void FieldWithTarget_set_target_m769246785 ();
extern "C" void FieldWithTarget_get_fieldPath_m51400754 ();
extern "C" void FieldWithTarget_set_fieldPath_m3902225503 ();
extern "C" void FieldWithTarget_get_typeString_m3284553539 ();
extern "C" void FieldWithTarget_set_typeString_m3894963277 ();
extern "C" void FieldWithTarget_get_doStatic_m1887875852 ();
extern "C" void FieldWithTarget_set_doStatic_m3503446641 ();
extern "C" void FieldWithTarget_get_staticString_m2740384771 ();
extern "C" void FieldWithTarget_set_staticString_m3960315724 ();
extern "C" void FieldWithTarget_GetValue_m1351827778 ();
extern "C" void BoxTrigger__ctor_m910405003 ();
extern "C" void BoxTrigger_Start_m1361771495 ();
extern "C" void BoxTrigger_OnTriggerEnter_m1134727060 ();
extern "C" void BoxTrigger_OnTriggerExit_m1026518603 ();
extern "C" void CameraScript__ctor_m2074972760 ();
extern "C" void CameraScript_Start_m70798908 ();
extern "C" void CameraScript_LateUpdate_m3780720276 ();
extern "C" void FlipCharacter__ctor_m2323846137 ();
extern "C" void FlipCharacter_Start_m1352720864 ();
extern "C" void FlipCharacter_Flip_m936201690 ();
extern "C" void LedgeTrigger__ctor_m3541567390 ();
extern "C" void LedgeTrigger_Start_m3492426325 ();
extern "C" void LedgeTrigger_OnTriggerEnter_m4103365985 ();
extern "C" void MoveCharacter__ctor_m940492633 ();
extern "C" void MoveCharacter_Start_m3159237758 ();
extern "C" void MoveCharacter_Move_m3498876582 ();
extern "C" void MoveCharacter_Jump_m768547604 ();
extern "C" void MoveObject__ctor_m403285747 ();
extern "C" void MoveObject_OnControllerColliderHit_m4083205808 ();
extern "C" void PlatformTrigger__ctor_m684306013 ();
extern "C" void PlatformTrigger_Start_m434823051 ();
extern "C" void PlatformTrigger_OnTriggerEnter_m1123801430 ();
extern "C" void PlayerInput__ctor_m634196471 ();
extern "C" void PlayerInput_Update_m1542141274 ();
extern "C" void PushObject__ctor_m3866911932 ();
extern "C" void PushObject_OnControllerColliderHit_m3319051333 ();
extern "C" void PushObject_test_m2222389076 ();
extern "C" void PushObject__cctor_m933835445 ();
extern const Il2CppMethodPointer g_MethodPointers[8183] = 
{
	Locale_GetText_m1265146595,
	Locale_GetText_m17960088,
	SafeHandleZeroOrMinusOneIsInvalid__ctor_m1494848290,
	SafeHandleZeroOrMinusOneIsInvalid_get_IsInvalid_m82959384,
	SafeWaitHandle__ctor_m1749943790,
	SafeWaitHandle_ReleaseHandle_m4165000905,
	CodePointIndexer__ctor_m2188730405,
	CodePointIndexer_ToIndex_m4068374705,
	TableRange__ctor_m4223564055_AdjustorThunk,
	Contraction__ctor_m2980607259,
	ContractionComparer__ctor_m1040251622,
	ContractionComparer__cctor_m2446220411,
	ContractionComparer_Compare_m1742180961,
	Level2Map__ctor_m1597067058,
	Level2MapComparer__ctor_m1190930255,
	Level2MapComparer__cctor_m1746154148,
	Level2MapComparer_Compare_m2901646138,
	MSCompatUnicodeTable__cctor_m3713475796,
	MSCompatUnicodeTable_GetTailoringInfo_m3078878392,
	MSCompatUnicodeTable_BuildTailoringTables_m62717087,
	MSCompatUnicodeTable_SetCJKReferences_m1405448475,
	MSCompatUnicodeTable_Category_m3334123752,
	MSCompatUnicodeTable_Level1_m1651883004,
	MSCompatUnicodeTable_Level2_m3282328441,
	MSCompatUnicodeTable_Level3_m1965057036,
	MSCompatUnicodeTable_IsIgnorable_m498011888,
	MSCompatUnicodeTable_IsIgnorableNonSpacing_m2195028588,
	MSCompatUnicodeTable_ToKanaTypeInsensitive_m2905559152,
	MSCompatUnicodeTable_ToWidthCompat_m3468994605,
	MSCompatUnicodeTable_HasSpecialWeight_m2586706208,
	MSCompatUnicodeTable_IsHalfWidthKana_m1890435412,
	MSCompatUnicodeTable_IsHiragana_m68825819,
	MSCompatUnicodeTable_IsJapaneseSmallLetter_m3471584530,
	MSCompatUnicodeTable_get_IsReady_m2610718509,
	MSCompatUnicodeTable_GetResource_m4210200220,
	MSCompatUnicodeTable_UInt32FromBytePtr_m598979490,
	MSCompatUnicodeTable_FillCJK_m3611444464,
	MSCompatUnicodeTable_FillCJKCore_m2706440031,
	MSCompatUnicodeTableUtil__cctor_m3741964204,
	SimpleCollator__ctor_m2134046065,
	SimpleCollator__cctor_m3499935719,
	SimpleCollator_SetCJKTable_m2489383572,
	SimpleCollator_GetNeutralCulture_m2904101762,
	SimpleCollator_Category_m529974984,
	SimpleCollator_Level1_m2496649243,
	SimpleCollator_Level2_m676254063,
	SimpleCollator_IsHalfKana_m3397869166,
	SimpleCollator_GetContraction_m1878785680,
	SimpleCollator_GetContraction_m3880760887,
	SimpleCollator_GetTailContraction_m1591628111,
	SimpleCollator_GetTailContraction_m2196500563,
	SimpleCollator_FilterOptions_m2372795395,
	SimpleCollator_GetExtenderType_m2671644325,
	SimpleCollator_ToDashTypeValue_m2698099990,
	SimpleCollator_FilterExtender_m975810900,
	SimpleCollator_IsIgnorable_m2431316413,
	SimpleCollator_IsSafe_m3146679031,
	SimpleCollator_GetSortKey_m2448976682,
	SimpleCollator_GetSortKey_m3673552269,
	SimpleCollator_GetSortKey_m795125130,
	SimpleCollator_FillSortKeyRaw_m2400297059,
	SimpleCollator_FillSurrogateSortKeyRaw_m506828680,
	SimpleCollator_CompareOrdinal_m4131903739,
	SimpleCollator_CompareQuick_m1382920344,
	SimpleCollator_CompareOrdinalIgnoreCase_m2004027341,
	SimpleCollator_Compare_m585522997,
	SimpleCollator_ClearBuffer_m670263399,
	SimpleCollator_QuickCheckPossible_m3949857928,
	SimpleCollator_CompareInternal_m4192545282,
	SimpleCollator_CompareFlagPair_m2916215989,
	SimpleCollator_IsPrefix_m411737590,
	SimpleCollator_IsPrefix_m1716959922,
	SimpleCollator_IsPrefix_m3370175993,
	SimpleCollator_IsSuffix_m2087245658,
	SimpleCollator_IsSuffix_m114126246,
	SimpleCollator_QuickIndexOf_m2371624288,
	SimpleCollator_IndexOf_m1611014549,
	SimpleCollator_IndexOfOrdinal_m3462019578,
	SimpleCollator_IndexOfOrdinalIgnoreCase_m490462133,
	SimpleCollator_IndexOfSortKey_m281127086,
	SimpleCollator_IndexOf_m2414080135,
	SimpleCollator_LastIndexOf_m112368596,
	SimpleCollator_LastIndexOfOrdinal_m1965663055,
	SimpleCollator_LastIndexOfOrdinalIgnoreCase_m625315705,
	SimpleCollator_LastIndexOfSortKey_m431080072,
	SimpleCollator_LastIndexOf_m923630408,
	SimpleCollator_MatchesForward_m2731549659,
	SimpleCollator_MatchesForwardCore_m4057978367,
	SimpleCollator_MatchesPrimitive_m626887649,
	SimpleCollator_MatchesBackward_m3319999137,
	SimpleCollator_MatchesBackwardCore_m3781926410,
	Context__ctor_m285010020_AdjustorThunk,
	PreviousInfo__ctor_m363904324_AdjustorThunk,
	SortKeyBuffer__ctor_m4023860722,
	SortKeyBuffer_Reset_m4192375915,
	SortKeyBuffer_Initialize_m4052992156,
	SortKeyBuffer_AppendCJKExtension_m2400234299,
	SortKeyBuffer_AppendKana_m2514523172,
	SortKeyBuffer_AppendNormal_m1830981725,
	SortKeyBuffer_AppendLevel5_m849136411,
	SortKeyBuffer_AppendBufferPrimitive_m381964935,
	SortKeyBuffer_GetResultAndReset_m4161461551,
	SortKeyBuffer_GetOptimizedLength_m1064586387,
	SortKeyBuffer_GetResult_m3316895793,
	TailoringInfo__ctor_m1019043692,
	BigInteger__ctor_m749285921,
	BigInteger__ctor_m1548060905,
	BigInteger__ctor_m359944000,
	BigInteger__ctor_m1361740461,
	BigInteger__ctor_m739268725,
	BigInteger__cctor_m687928097,
	BigInteger_get_Rng_m4192306485,
	BigInteger_GenerateRandom_m2236311969,
	BigInteger_GenerateRandom_m3914896300,
	BigInteger_Randomize_m1582361938,
	BigInteger_Randomize_m2254548478,
	BigInteger_BitCount_m418591107,
	BigInteger_TestBit_m1331180400,
	BigInteger_TestBit_m4046385986,
	BigInteger_SetBit_m425458138,
	BigInteger_SetBit_m2097412955,
	BigInteger_LowestSetBit_m3166892152,
	BigInteger_GetBytes_m639480215,
	BigInteger_ToString_m4080627353,
	BigInteger_ToString_m2837278763,
	BigInteger_Normalize_m128016676,
	BigInteger_Clear_m628128920,
	BigInteger_GetHashCode_m2553221631,
	BigInteger_ToString_m4176690768,
	BigInteger_Equals_m543243295,
	BigInteger_ModInverse_m275294484,
	BigInteger_ModPow_m2545909939,
	BigInteger_IsProbablePrime_m3566037144,
	BigInteger_GeneratePseudoPrime_m2194202988,
	BigInteger_Incr2_m2242053949,
	BigInteger_op_Implicit_m2646846758,
	BigInteger_op_Implicit_m2269995082,
	BigInteger_op_Addition_m1710113902,
	BigInteger_op_Subtraction_m4293640053,
	BigInteger_op_Modulus_m3315194349,
	BigInteger_op_Modulus_m1676214227,
	BigInteger_op_Division_m2202532690,
	BigInteger_op_Multiply_m2577593846,
	BigInteger_op_Multiply_m1311148295,
	BigInteger_op_LeftShift_m1642370140,
	BigInteger_op_RightShift_m1121795638,
	BigInteger_op_Equality_m2075306021,
	BigInteger_op_Inequality_m130367573,
	BigInteger_op_Equality_m4205992796,
	BigInteger_op_Inequality_m4211291346,
	BigInteger_op_GreaterThan_m1868107497,
	BigInteger_op_LessThan_m2363164644,
	BigInteger_op_GreaterThanOrEqual_m2819743712,
	BigInteger_op_LessThanOrEqual_m1501457970,
	Kernel_AddSameSign_m1710157416,
	Kernel_Subtract_m3200698040,
	Kernel_MinusEq_m3453643272,
	Kernel_PlusEq_m2076902192,
	Kernel_Compare_m2772920044,
	Kernel_SingleByteDivideInPlace_m3969322353,
	Kernel_DwordMod_m538231209,
	Kernel_DwordDivMod_m638557122,
	Kernel_multiByteDivide_m2557810668,
	Kernel_LeftShift_m3419189056,
	Kernel_RightShift_m707895963,
	Kernel_MultiplyByDword_m3417453857,
	Kernel_Multiply_m2696208436,
	Kernel_MultiplyMod2p32pmod_m3089237537,
	Kernel_modInverse_m3924577278,
	Kernel_modInverse_m478118115,
	ModulusRing__ctor_m3459439119,
	ModulusRing_BarrettReduction_m953332471,
	ModulusRing_Multiply_m2306156272,
	ModulusRing_Difference_m3165112467,
	ModulusRing_Pow_m3903062554,
	ModulusRing_Pow_m3028377471,
	PrimeGeneratorBase__ctor_m3810842403,
	PrimeGeneratorBase_get_Confidence_m2751166709,
	PrimeGeneratorBase_get_PrimalityTest_m653630235,
	PrimeGeneratorBase_get_TrialDivisionBounds_m3141706556,
	SequentialSearchPrimeGeneratorBase__ctor_m3036742961,
	SequentialSearchPrimeGeneratorBase_GenerateSearchBase_m397757294,
	SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m3422829138,
	SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m409742484,
	SequentialSearchPrimeGeneratorBase_IsPrimeAcceptable_m509833446,
	PrimalityTest__ctor_m1741929263,
	PrimalityTest_Invoke_m734476009,
	PrimalityTest_BeginInvoke_m780686148,
	PrimalityTest_EndInvoke_m3513513734,
	PrimalityTests_GetSPPRounds_m1356488336,
	PrimalityTests_Test_m2404702103,
	PrimalityTests_RabinMillerTest_m1209091924,
	PrimalityTests_SmallPrimeSppTest_m712000020,
	Runtime_GetDisplayName_m2543745802,
	ASN1__ctor_m3516316147,
	ASN1__ctor_m900389283,
	ASN1__ctor_m3702032794,
	ASN1_get_Count_m3480232352,
	ASN1_get_Tag_m3464757002,
	ASN1_get_Length_m1225159393,
	ASN1_get_Value_m3871082636,
	ASN1_set_Value_m1466677899,
	ASN1_CompareArray_m3660389124,
	ASN1_CompareValue_m1304964968,
	ASN1_Add_m1182244447,
	ASN1_GetBytes_m3669971745,
	ASN1_Decode_m907784624,
	ASN1_DecodeTLV_m673487284,
	ASN1_get_Item_m2436150169,
	ASN1_Element_m4122926611,
	ASN1_ToString_m1043110734,
	ASN1Convert_FromInt32_m2998434422,
	ASN1Convert_FromOid_m1489798743,
	ASN1Convert_ToInt32_m354484360,
	ASN1Convert_ToOid_m3096819508,
	ASN1Convert_ToDateTime_m2361833227,
	BitConverterLE_GetUIntBytes_m1730778039,
	BitConverterLE_GetBytes_m2148648680,
	BitConverterLE_UShortFromBytes_m980213359,
	BitConverterLE_UIntFromBytes_m3407605456,
	BitConverterLE_ULongFromBytes_m1264961194,
	BitConverterLE_ToInt16_m3333209264,
	BitConverterLE_ToInt32_m2015589102,
	BitConverterLE_ToSingle_m1256583513,
	BitConverterLE_ToDouble_m3434335877,
	BlockProcessor__ctor_m1542591421,
	BlockProcessor_Finalize_m2193875010,
	BlockProcessor_Initialize_m1617464021,
	BlockProcessor_Core_m1467748329,
	BlockProcessor_Core_m1163585696,
	BlockProcessor_Final_m466767243,
	CryptoConvert_ToInt32LE_m2881796413,
	CryptoConvert_ToUInt32LE_m3826477295,
	CryptoConvert_GetBytesLE_m1542846119,
	CryptoConvert_ToCapiPrivateKeyBlob_m700900379,
	CryptoConvert_FromCapiPublicKeyBlob_m1029150686,
	CryptoConvert_FromCapiPublicKeyBlob_m3664124753,
	CryptoConvert_ToCapiPublicKeyBlob_m127107459,
	CryptoConvert_ToCapiKeyBlob_m2703135777,
	DSAManaged__ctor_m2239731715,
	DSAManaged_add_KeyGenerated_m617634834,
	DSAManaged_remove_KeyGenerated_m4203967072,
	DSAManaged_Finalize_m658091490,
	DSAManaged_Generate_m2213327800,
	DSAManaged_GenerateKeyPair_m3676828895,
	DSAManaged_add_m2563244335,
	DSAManaged_GenerateParams_m893203057,
	DSAManaged_get_Random_m1552973763,
	DSAManaged_get_KeySize_m195244546,
	DSAManaged_get_PublicOnly_m937331592,
	DSAManaged_NormalizeArray_m3031469125,
	DSAManaged_ExportParameters_m129436677,
	DSAManaged_ImportParameters_m674300461,
	DSAManaged_CreateSignature_m112797504,
	DSAManaged_VerifySignature_m1409117526,
	DSAManaged_Dispose_m3559808758,
	KeyGeneratedEventHandler__ctor_m3350971851,
	KeyGeneratedEventHandler_Invoke_m3584036176,
	KeyGeneratedEventHandler_BeginInvoke_m949536046,
	KeyGeneratedEventHandler_EndInvoke_m4180032083,
	KeyBuilder_get_Rng_m1520795798,
	KeyBuilder_Key_m1913521515,
	KeyBuilder_IV_m3397957894,
	KeyPairPersistence__ctor_m2118809332,
	KeyPairPersistence__ctor_m1640484989,
	KeyPairPersistence__cctor_m2075445627,
	KeyPairPersistence_get_Filename_m4173945282,
	KeyPairPersistence_get_KeyValue_m91066153,
	KeyPairPersistence_set_KeyValue_m2107494925,
	KeyPairPersistence_Load_m4121548623,
	KeyPairPersistence_Save_m1521804892,
	KeyPairPersistence_Remove_m40363756,
	KeyPairPersistence_get_UserPath_m53187470,
	KeyPairPersistence_get_MachinePath_m2891279717,
	KeyPairPersistence__CanSecure_m3650261141,
	KeyPairPersistence__ProtectUser_m2853364577,
	KeyPairPersistence__ProtectMachine_m241429997,
	KeyPairPersistence__IsUserProtected_m1693323233,
	KeyPairPersistence__IsMachineProtected_m2948499064,
	KeyPairPersistence_CanSecure_m2985875540,
	KeyPairPersistence_ProtectUser_m2970823568,
	KeyPairPersistence_ProtectMachine_m4187282752,
	KeyPairPersistence_IsUserProtected_m895119154,
	KeyPairPersistence_IsMachineProtected_m2274466442,
	KeyPairPersistence_get_CanChange_m3024654040,
	KeyPairPersistence_get_UseDefaultKeyContainer_m2357983573,
	KeyPairPersistence_get_UseMachineKeyStore_m1620036962,
	KeyPairPersistence_get_ContainerName_m1066794494,
	KeyPairPersistence_Copy_m2963737075,
	KeyPairPersistence_FromXml_m2913457645,
	KeyPairPersistence_ToXml_m452787328,
	MACAlgorithm__ctor_m2285878648,
	MACAlgorithm_Initialize_m4293111044,
	MACAlgorithm_Core_m3245577984,
	MACAlgorithm_Final_m170881330,
	PKCS1__cctor_m52301062,
	PKCS1_Compare_m2586713663,
	PKCS1_I2OSP_m4089279014,
	PKCS1_OS2IP_m1652482794,
	PKCS1_RSAEP_m4204322655,
	PKCS1_RSASP1_m1153951364,
	PKCS1_RSAVP1_m3043513750,
	PKCS1_Encrypt_v15_m2483357299,
	PKCS1_Sign_v15_m3799722850,
	PKCS1_Verify_v15_m3628112885,
	PKCS1_Verify_v15_m1698944143,
	PKCS1_Encode_v15_m1278782954,
	EncryptedPrivateKeyInfo__ctor_m1728384237,
	EncryptedPrivateKeyInfo__ctor_m255380445,
	EncryptedPrivateKeyInfo_get_Algorithm_m3572697726,
	EncryptedPrivateKeyInfo_get_EncryptedData_m1951388053,
	EncryptedPrivateKeyInfo_get_Salt_m3047726094,
	EncryptedPrivateKeyInfo_get_IterationCount_m567960696,
	EncryptedPrivateKeyInfo_Decode_m2698506670,
	PrivateKeyInfo__ctor_m2373384519,
	PrivateKeyInfo__ctor_m2058598109,
	PrivateKeyInfo_get_PrivateKey_m1774610424,
	PrivateKeyInfo_Decode_m1597257289,
	PrivateKeyInfo_RemoveLeadingZero_m1745558997,
	PrivateKeyInfo_Normalize_m3535728914,
	PrivateKeyInfo_DecodeRSA_m1088370069,
	PrivateKeyInfo_DecodeDSA_m341342618,
	RSAManaged__ctor_m108813814,
	RSAManaged_add_KeyGenerated_m2026269581,
	RSAManaged_remove_KeyGenerated_m452081817,
	RSAManaged_Finalize_m3127602112,
	RSAManaged_GenerateKeyPair_m4239154883,
	RSAManaged_get_KeySize_m1415201630,
	RSAManaged_get_PublicOnly_m3761587738,
	RSAManaged_DecryptValue_m761789094,
	RSAManaged_EncryptValue_m891368688,
	RSAManaged_ExportParameters_m2802579325,
	RSAManaged_ImportParameters_m1700317438,
	RSAManaged_Dispose_m3115457227,
	RSAManaged_ToXmlString_m1925737693,
	RSAManaged_get_IsCrtPossible_m2378749780,
	RSAManaged_GetPaddedValue_m3978405718,
	KeyGeneratedEventHandler__ctor_m593853528,
	KeyGeneratedEventHandler_Invoke_m2062799578,
	KeyGeneratedEventHandler_BeginInvoke_m2450128886,
	KeyGeneratedEventHandler_EndInvoke_m1662721951,
	SymmetricTransform__ctor_m853900815,
	SymmetricTransform_System_IDisposable_Dispose_m3767183876,
	SymmetricTransform_Finalize_m2106608140,
	SymmetricTransform_Dispose_m894001198,
	SymmetricTransform_get_CanReuseTransform_m1766410615,
	SymmetricTransform_Transform_m2228531694,
	SymmetricTransform_CBC_m745169718,
	SymmetricTransform_CFB_m3470641285,
	SymmetricTransform_OFB_m3231919770,
	SymmetricTransform_CTS_m3003575812,
	SymmetricTransform_CheckInput_m3581390890,
	SymmetricTransform_TransformBlock_m3148898394,
	SymmetricTransform_get_KeepLastBlock_m220816450,
	SymmetricTransform_InternalTransformBlock_m2736239174,
	SymmetricTransform_Random_m914001586,
	SymmetricTransform_ThrowBadPaddingException_m2057381031,
	SymmetricTransform_FinalEncrypt_m1005064906,
	SymmetricTransform_FinalDecrypt_m3448120181,
	SymmetricTransform_TransformFinalBlock_m265074875,
	ContentInfo__ctor_m1832218908,
	ContentInfo__ctor_m1779824867,
	ContentInfo__ctor_m3140128459,
	ContentInfo__ctor_m4164959615,
	ContentInfo_get_ASN1_m166893374,
	ContentInfo_get_Content_m1913362825,
	ContentInfo_set_Content_m1406202593,
	ContentInfo_get_ContentType_m110609955,
	ContentInfo_set_ContentType_m3631529987,
	ContentInfo_GetASN1_m201596048,
	EncryptedData__ctor_m1898214232,
	EncryptedData__ctor_m3497954096,
	EncryptedData_get_EncryptionAlgorithm_m3445649904,
	EncryptedData_get_EncryptedContent_m2948139942,
	StrongName__cctor_m294083825,
	StrongName_get_PublicKey_m1706935160,
	StrongName_get_PublicKeyToken_m719854356,
	StrongName_get_TokenAlgorithm_m4024404966,
	PKCS12__ctor_m2607338998,
	PKCS12__ctor_m319934187,
	PKCS12__ctor_m2663475186,
	PKCS12__cctor_m1290954702,
	PKCS12_Decode_m268156216,
	PKCS12_Finalize_m2608254785,
	PKCS12_set_Password_m2199572200,
	PKCS12_get_IterationCount_m3773304382,
	PKCS12_set_IterationCount_m2132687009,
	PKCS12_get_Certificates_m1381826362,
	PKCS12_get_RNG_m3472201106,
	PKCS12_Compare_m2307221893,
	PKCS12_GetSymmetricAlgorithm_m3020658701,
	PKCS12_Decrypt_m191955830,
	PKCS12_Decrypt_m572625802,
	PKCS12_Encrypt_m3932021359,
	PKCS12_GetExistingParameters_m2032210035,
	PKCS12_AddPrivateKey_m1320150318,
	PKCS12_ReadSafeBag_m4279133587,
	PKCS12_CertificateSafeBag_m3727737016,
	PKCS12_MAC_m2855112721,
	PKCS12_GetBytes_m3443008688,
	PKCS12_EncryptedContentInfo_m1107912104,
	PKCS12_AddCertificate_m463544853,
	PKCS12_AddCertificate_m3561584230,
	PKCS12_RemoveCertificate_m870596409,
	PKCS12_RemoveCertificate_m1025206712,
	PKCS12_Clone_m1313211850,
	PKCS12_get_MaximumPasswordLength_m1938263851,
	DeriveBytes__ctor_m1344968137,
	DeriveBytes__cctor_m3280374767,
	DeriveBytes_set_HashName_m3610593785,
	DeriveBytes_set_IterationCount_m3841365578,
	DeriveBytes_set_Password_m3989191716,
	DeriveBytes_set_Salt_m3743207440,
	DeriveBytes_Adjust_m3420119091,
	DeriveBytes_Derive_m2793777471,
	DeriveBytes_DeriveKey_m2144372235,
	DeriveBytes_DeriveIV_m406641218,
	DeriveBytes_DeriveMAC_m3603767249,
	SafeBag__ctor_m1363243494,
	SafeBag_get_BagOID_m160591319,
	SafeBag_get_ASN1_m91629621,
	X501__cctor_m400093648,
	X501_ToString_m536875646,
	X501_ToString_m2552468539,
	X501_AppendEntry_m3313183578,
	X509Certificate__ctor_m86942042,
	X509Certificate__cctor_m2591603522,
	X509Certificate_Parse_m79522769,
	X509Certificate_GetUnsignedBigInteger_m103534235,
	X509Certificate_get_DSA_m125307315,
	X509Certificate_get_IssuerName_m1372933285,
	X509Certificate_get_KeyAlgorithmParameters_m259126965,
	X509Certificate_get_PublicKey_m903953322,
	X509Certificate_get_RawData_m3072015885,
	X509Certificate_get_SubjectName_m2916400271,
	X509Certificate_get_ValidFrom_m1988458040,
	X509Certificate_get_ValidUntil_m3972607305,
	X509Certificate_GetIssuerName_m3495765435,
	X509Certificate_GetSubjectName_m4220029087,
	X509Certificate_GetObjectData_m3812944410,
	X509Certificate_PEM_m530892051,
	X509CertificateCollection__ctor_m606653116,
	X509CertificateCollection_System_Collections_IEnumerable_GetEnumerator_m2410698127,
	X509CertificateCollection_get_Item_m3186270884,
	X509CertificateCollection_Add_m1462393188,
	X509CertificateCollection_GetEnumerator_m4046104381,
	X509CertificateCollection_GetHashCode_m1380129870,
	X509CertificateEnumerator__ctor_m1274818248,
	X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m3062908215,
	X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m2645324201,
	X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m2508570363,
	X509CertificateEnumerator_get_Current_m4235283862,
	X509CertificateEnumerator_MoveNext_m2034424191,
	X509CertificateEnumerator_Reset_m1034788171,
	X509Extension__ctor_m1463351804,
	X509Extension_Decode_m2035257366,
	X509Extension_Equals_m2104989699,
	X509Extension_GetHashCode_m2090282208,
	X509Extension_WriteLine_m3232243657,
	X509Extension_ToString_m4137855591,
	X509ExtensionCollection__ctor_m2269405799,
	X509ExtensionCollection__ctor_m2440266315,
	X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m3430909382,
	SecurityParser__ctor_m1273613094,
	SecurityParser_LoadXml_m1797635359,
	SecurityParser_ToXml_m3602313894,
	SecurityParser_OnStartParsing_m1744558128,
	SecurityParser_OnProcessingInstruction_m3895856679,
	SecurityParser_OnIgnorableWhitespace_m296220286,
	SecurityParser_OnStartElement_m916634736,
	SecurityParser_OnEndElement_m1435563271,
	SecurityParser_OnChars_m1997930175,
	SecurityParser_OnEndParsing_m361052126,
	SmallXmlParser__ctor_m2714448770,
	SmallXmlParser_Error_m3310666497,
	SmallXmlParser_UnexpectedEndError_m1697868618,
	SmallXmlParser_IsNameChar_m3586087961,
	SmallXmlParser_IsWhitespace_m2373230202,
	SmallXmlParser_SkipWhitespaces_m3529124521,
	SmallXmlParser_HandleWhitespaces_m1522810214,
	SmallXmlParser_SkipWhitespaces_m1748557517,
	SmallXmlParser_Peek_m3468987475,
	SmallXmlParser_Read_m3051998616,
	SmallXmlParser_Expect_m1605783117,
	SmallXmlParser_ReadUntil_m3037577210,
	SmallXmlParser_ReadName_m1236298014,
	SmallXmlParser_Parse_m1329943518,
	SmallXmlParser_Cleanup_m413266235,
	SmallXmlParser_ReadContent_m2421724154,
	SmallXmlParser_HandleBufferedContent_m727380410,
	SmallXmlParser_ReadCharacters_m991777765,
	SmallXmlParser_ReadReference_m422931399,
	SmallXmlParser_ReadCharacterReference_m154840048,
	SmallXmlParser_ReadAttribute_m1940026198,
	SmallXmlParser_ReadCDATASection_m2631873034,
	SmallXmlParser_ReadComment_m921257417,
	AttrListImpl__ctor_m3819032856,
	AttrListImpl_get_Length_m3324056078,
	AttrListImpl_GetName_m3288491946,
	AttrListImpl_GetValue_m2040757343,
	AttrListImpl_GetValue_m1746824538,
	AttrListImpl_get_Names_m242773466,
	AttrListImpl_get_Values_m3954266095,
	AttrListImpl_Clear_m495494231,
	AttrListImpl_Add_m361290632,
	SmallXmlParserException__ctor_m2671100442,
	__Il2CppComDelegate_Finalize_m3194155022,
	__Il2CppComObject_Finalize_m472148246,
	AccessViolationException__ctor_m3997653685,
	AccessViolationException__ctor_m809197134,
	ActivationContext_System_Runtime_Serialization_ISerializable_GetObjectData_m1919074653,
	ActivationContext_Finalize_m3174481347,
	ActivationContext_Dispose_m1269565227,
	ActivationContext_Dispose_m3011612522,
	Activator_CreateInstance_m2419494272,
	Activator_CreateInstance_m444130951,
	Activator_CreateInstance_m2510174607,
	Activator_CreateInstance_m3570299959,
	Activator_CreateInstance_m191354027,
	Activator_CheckType_m2851234608,
	Activator_CheckAbstractType_m2572289794,
	Activator_CreateInstanceInternal_m2226342982,
	AppDomain_getFriendlyName_m983563881,
	AppDomain_getCurDomain_m2930406338,
	AppDomain_get_CurrentDomain_m2846368349,
	AppDomain_LoadAssembly_m1553013027,
	AppDomain_Load_m2443754192,
	AppDomain_Load_m3338809057,
	AppDomain_InternalSetContext_m624087841,
	AppDomain_InternalGetContext_m1818197205,
	AppDomain_InternalGetDefaultContext_m1487816137,
	AppDomain_InternalGetProcessGuid_m1562017383,
	AppDomain_GetProcessGuid_m3012047762,
	AppDomain_ToString_m974557331,
	AppDomain_DoTypeResolve_m2118823759,
	AppDomainInitializer__ctor_m782952305,
	AppDomainInitializer_Invoke_m934188694,
	AppDomainInitializer_BeginInvoke_m2280557570,
	AppDomainInitializer_EndInvoke_m3937990410,
	AppDomainSetup__ctor_m2358764403,
	ApplicationException__ctor_m2495185969,
	ApplicationException__ctor_m3367108494,
	ApplicationException__ctor_m158055564,
	ApplicationIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m2267909380,
	ApplicationIdentity_ToString_m3128027746,
	ArgIterator_Equals_m1058506493_AdjustorThunk,
	ArgIterator_GetHashCode_m3507889379_AdjustorThunk,
	ArgumentException__ctor_m917890632,
	ArgumentException__ctor_m1701432879,
	ArgumentException__ctor_m2600437157,
	ArgumentException__ctor_m2347857543,
	ArgumentException__ctor_m1940164295,
	ArgumentException__ctor_m3975556065,
	ArgumentException_get_ParamName_m3589050748,
	ArgumentException_get_Message_m1764127082,
	ArgumentException_GetObjectData_m2722433088,
	ArgumentNullException__ctor_m915127396,
	ArgumentNullException__ctor_m4205025980,
	ArgumentNullException__ctor_m4284127825,
	ArgumentNullException__ctor_m2667105974,
	ArgumentOutOfRangeException__ctor_m2230262647,
	ArgumentOutOfRangeException__ctor_m3511757557,
	ArgumentOutOfRangeException__ctor_m361638018,
	ArgumentOutOfRangeException__ctor_m4208192147,
	ArgumentOutOfRangeException__ctor_m2463331922,
	ArgumentOutOfRangeException_get_Message_m1307317189,
	ArgumentOutOfRangeException_GetObjectData_m2906848175,
	ArithmeticException__ctor_m160911504,
	ArithmeticException__ctor_m1603322801,
	ArithmeticException__ctor_m314251061,
	Array__ctor_m1209187327,
	Array_System_Collections_IList_get_Item_m1062386384,
	Array_System_Collections_IList_set_Item_m2964370625,
	Array_System_Collections_IList_Add_m2805768866,
	Array_System_Collections_IList_Clear_m2749207785,
	Array_System_Collections_IList_Contains_m2850619077,
	Array_System_Collections_IList_IndexOf_m4113384025,
	Array_System_Collections_IList_Insert_m3768045023,
	Array_System_Collections_IList_Remove_m2149856583,
	Array_System_Collections_IList_RemoveAt_m2920498054,
	Array_System_Collections_ICollection_get_Count_m3978114653,
	Array_InternalArray__ICollection_get_Count_m2312395473,
	Array_InternalArray__ICollection_get_IsReadOnly_m3484210382,
	Array_InternalArray__ICollection_Clear_m2645052154,
	Array_InternalArray__RemoveAt_m1098161393,
	Array_get_Length_m1237849133,
	Array_get_LongLength_m3574060956,
	Array_get_Rank_m4210679277,
	Array_GetRank_m2678416706,
	Array_GetLength_m765962577,
	Array_GetLongLength_m1831760985,
	Array_GetLowerBound_m3549496906,
	Array_GetValue_m2729068147,
	Array_SetValue_m3241852505,
	Array_GetValueImpl_m2886657017,
	Array_SetValueImpl_m3938984347,
	Array_FastCopy_m2430275015,
	Array_CreateInstanceImpl_m3302315738,
	Array_get_IsSynchronized_m1719268192,
	Array_get_SyncRoot_m4203173386,
	Array_get_IsFixedSize_m2241026129,
	Array_get_IsReadOnly_m3320326657,
	Array_GetEnumerator_m3833411737,
	Array_GetUpperBound_m3033662308,
	Array_GetValue_m1884911572,
	Array_GetValue_m133190562,
	Array_GetValue_m3481955035,
	Array_GetValue_m1672823197,
	Array_GetValue_m3499512431,
	Array_GetValue_m170746175,
	Array_SetValue_m63377824,
	Array_SetValue_m485573868,
	Array_SetValue_m1031266616,
	Array_SetValue_m1575116602,
	Array_SetValue_m214456090,
	Array_SetValue_m3710452129,
	Array_CreateInstance_m1019985487,
	Array_CreateInstance_m2264326752,
	Array_CreateInstance_m549464094,
	Array_CreateInstance_m917197603,
	Array_CreateInstance_m1901379298,
	Array_GetIntArray_m2999725396,
	Array_CreateInstance_m3507446064,
	Array_GetValue_m2322609327,
	Array_SetValue_m193787568,
	Array_BinarySearch_m545470185,
	Array_BinarySearch_m2794424496,
	Array_BinarySearch_m787838226,
	Array_BinarySearch_m3034756551,
	Array_DoBinarySearch_m535885162,
	Array_Clear_m3931267648,
	Array_ClearInternal_m103549485,
	Array_Clone_m75013923,
	Array_Copy_m3083719085,
	Array_Copy_m1665823352,
	Array_Copy_m3124468677,
	Array_Copy_m795970186,
	Array_IndexOf_m1347597055,
	Array_IndexOf_m955672662,
	Array_IndexOf_m4006329155,
	Array_Initialize_m2964546196,
	Array_LastIndexOf_m3392868261,
	Array_LastIndexOf_m1832984276,
	Array_LastIndexOf_m191882863,
	Array_get_swapper_m350703700,
	Array_Reverse_m1652786737,
	Array_Reverse_m2907565334,
	Array_Sort_m4258351672,
	Array_Sort_m1768924099,
	Array_Sort_m2963189028,
	Array_Sort_m3451521996,
	Array_Sort_m2647962771,
	Array_Sort_m4051743636,
	Array_Sort_m1552933164,
	Array_Sort_m3631368508,
	Array_int_swapper_m4216640094,
	Array_obj_swapper_m2273014594,
	Array_slow_swapper_m1367639156,
	Array_double_swapper_m2405493383,
	Array_new_gap_m2764239473,
	Array_combsort_m9958672,
	Array_combsort_m3504304741,
	Array_combsort_m1698085190,
	Array_qsort_m2567273609,
	Array_swap_m1454175609,
	Array_compare_m1463750278,
	Array_CopyTo_m2156848031,
	Array_CopyTo_m3827090518,
	Array_ConstrainedCopy_m2507976525,
	SimpleEnumerator__ctor_m700162411,
	SimpleEnumerator_get_Current_m1082998432,
	SimpleEnumerator_MoveNext_m2557818901,
	SimpleEnumerator_Reset_m3441273370,
	SimpleEnumerator_Clone_m1283088169,
	Swapper__ctor_m2076169497,
	Swapper_Invoke_m704171303,
	Swapper_BeginInvoke_m3902783594,
	Swapper_EndInvoke_m1400482523,
	ArrayTypeMismatchException__ctor_m693030731,
	ArrayTypeMismatchException__ctor_m3549357969,
	ArrayTypeMismatchException__ctor_m4117155091,
	AssemblyLoadEventHandler__ctor_m2895683782,
	AssemblyLoadEventHandler_Invoke_m4239709152,
	AssemblyLoadEventHandler_BeginInvoke_m1552964803,
	AssemblyLoadEventHandler_EndInvoke_m2252211627,
	AsyncCallback__ctor_m250615163,
	AsyncCallback_Invoke_m3489379354,
	AsyncCallback_BeginInvoke_m2371063382,
	AsyncCallback_EndInvoke_m199067018,
	Attribute__ctor_m2510047006,
	Attribute_CheckParameters_m3890139648,
	Attribute_GetCustomAttribute_m2649713033,
	Attribute_GetCustomAttribute_m767122931,
	Attribute_GetHashCode_m2233302810,
	Attribute_IsDefined_m41000727,
	Attribute_IsDefined_m3038256223,
	Attribute_IsDefined_m3101618329,
	Attribute_IsDefined_m520826945,
	Attribute_Equals_m3887674838,
	AttributeUsageAttribute__ctor_m250482755,
	AttributeUsageAttribute_get_AllowMultiple_m1373505120,
	AttributeUsageAttribute_set_AllowMultiple_m3716379228,
	AttributeUsageAttribute_get_Inherited_m2698594048,
	AttributeUsageAttribute_set_Inherited_m2568117843,
	BitConverter__cctor_m772220037,
	BitConverter_AmILittleEndian_m3548951445,
	BitConverter_DoubleWordsAreSwapped_m2886911556,
	BitConverter_DoubleToInt64Bits_m3487324405,
	BitConverter_GetBytes_m679788222,
	BitConverter_GetBytes_m3390757298,
	BitConverter_PutBytes_m1032922327,
	BitConverter_ToInt64_m2350763810,
	BitConverter_ToString_m1424207950,
	BitConverter_ToString_m682142286,
	Boolean__cctor_m2960660260,
	Boolean_System_IConvertible_ToType_m3575264036_AdjustorThunk,
	Boolean_System_IConvertible_ToBoolean_m2843312221_AdjustorThunk,
	Boolean_System_IConvertible_ToByte_m3154011034_AdjustorThunk,
	Boolean_System_IConvertible_ToChar_m463812418_AdjustorThunk,
	Boolean_System_IConvertible_ToDateTime_m2560029344_AdjustorThunk,
	Boolean_System_IConvertible_ToDecimal_m2933246224_AdjustorThunk,
	Boolean_System_IConvertible_ToDouble_m3674645531_AdjustorThunk,
	Boolean_System_IConvertible_ToInt16_m1262197955_AdjustorThunk,
	Boolean_System_IConvertible_ToInt32_m1439073499_AdjustorThunk,
	Boolean_System_IConvertible_ToInt64_m2177417439_AdjustorThunk,
	Boolean_System_IConvertible_ToSByte_m1378217193_AdjustorThunk,
	Boolean_System_IConvertible_ToSingle_m4205260307_AdjustorThunk,
	Boolean_System_IConvertible_ToUInt16_m3266496623_AdjustorThunk,
	Boolean_System_IConvertible_ToUInt32_m1981649399_AdjustorThunk,
	Boolean_System_IConvertible_ToUInt64_m4279218169_AdjustorThunk,
	Boolean_CompareTo_m3210426891_AdjustorThunk,
	Boolean_Equals_m2568005781_AdjustorThunk,
	Boolean_CompareTo_m355555321_AdjustorThunk,
	Boolean_Equals_m2447193697_AdjustorThunk,
	Boolean_GetHashCode_m3342500017_AdjustorThunk,
	Boolean_Parse_m2343626245,
	Boolean_ToString_m1641143563_AdjustorThunk,
	Boolean_ToString_m2668319895_AdjustorThunk,
	Buffer_ByteLength_m3432156039,
	Buffer_BlockCopy_m3342110362,
	Buffer_ByteLengthInternal_m1169895470,
	Buffer_BlockCopyInternal_m2215447715,
	Byte_System_IConvertible_ToType_m282257076_AdjustorThunk,
	Byte_System_IConvertible_ToBoolean_m2144421286_AdjustorThunk,
	Byte_System_IConvertible_ToByte_m2863304106_AdjustorThunk,
	Byte_System_IConvertible_ToChar_m203885835_AdjustorThunk,
	Byte_System_IConvertible_ToDateTime_m4058337789_AdjustorThunk,
	Byte_System_IConvertible_ToDecimal_m2081691731_AdjustorThunk,
	Byte_System_IConvertible_ToDouble_m4171630369_AdjustorThunk,
	Byte_System_IConvertible_ToInt16_m3743536406_AdjustorThunk,
	Byte_System_IConvertible_ToInt32_m3131424033_AdjustorThunk,
	Byte_System_IConvertible_ToInt64_m269272912_AdjustorThunk,
	Byte_System_IConvertible_ToSByte_m843068237_AdjustorThunk,
	Byte_System_IConvertible_ToSingle_m3009948894_AdjustorThunk,
	Byte_System_IConvertible_ToUInt16_m1452228093_AdjustorThunk,
	Byte_System_IConvertible_ToUInt32_m775575532_AdjustorThunk,
	Byte_System_IConvertible_ToUInt64_m2585642112_AdjustorThunk,
	Byte_CompareTo_m4258539704_AdjustorThunk,
	Byte_Equals_m3126389867_AdjustorThunk,
	Byte_GetHashCode_m3721817931_AdjustorThunk,
	Byte_CompareTo_m1892343665_AdjustorThunk,
	Byte_Equals_m1337305152_AdjustorThunk,
	Byte_Parse_m1814198899,
	Byte_Parse_m554247074,
	Byte_Parse_m868734818,
	Byte_TryParse_m2685450601,
	Byte_TryParse_m4209699724,
	Byte_ToString_m2616748329_AdjustorThunk,
	Byte_ToString_m671282125_AdjustorThunk,
	Byte_ToString_m2546846173_AdjustorThunk,
	Byte_ToString_m3577895365_AdjustorThunk,
	Char__cctor_m452321216,
	Char_System_IConvertible_ToType_m2538743012_AdjustorThunk,
	Char_System_IConvertible_ToBoolean_m537010113_AdjustorThunk,
	Char_System_IConvertible_ToByte_m368092121_AdjustorThunk,
	Char_System_IConvertible_ToChar_m3896722647_AdjustorThunk,
	Char_System_IConvertible_ToDateTime_m2921645934_AdjustorThunk,
	Char_System_IConvertible_ToDecimal_m1460935499_AdjustorThunk,
	Char_System_IConvertible_ToDouble_m2269302409_AdjustorThunk,
	Char_System_IConvertible_ToInt16_m3424988284_AdjustorThunk,
	Char_System_IConvertible_ToInt32_m2299257141_AdjustorThunk,
	Char_System_IConvertible_ToInt64_m2275506076_AdjustorThunk,
	Char_System_IConvertible_ToSByte_m2022971182_AdjustorThunk,
	Char_System_IConvertible_ToSingle_m582798654_AdjustorThunk,
	Char_System_IConvertible_ToUInt16_m539785571_AdjustorThunk,
	Char_System_IConvertible_ToUInt32_m1570679825_AdjustorThunk,
	Char_System_IConvertible_ToUInt64_m1789501143_AdjustorThunk,
	Char_GetDataTablePointers_m1405454895,
	Char_CompareTo_m2732644691_AdjustorThunk,
	Char_Equals_m1419514540_AdjustorThunk,
	Char_CompareTo_m1002092952_AdjustorThunk,
	Char_Equals_m1776645521_AdjustorThunk,
	Char_GetHashCode_m2979657488_AdjustorThunk,
	Char_GetUnicodeCategory_m2717630522,
	Char_IsDigit_m3338391214,
	Char_IsLetter_m3403728967,
	Char_IsLetterOrDigit_m3737247547,
	Char_IsLower_m1385832003,
	Char_IsSurrogate_m1060330939,
	Char_IsWhiteSpace_m2502232923,
	Char_IsWhiteSpace_m1302760694,
	Char_CheckParameter_m3148718057,
	Char_Parse_m3763735221,
	Char_ToLower_m533698221,
	Char_ToLowerInvariant_m3711249777,
	Char_ToLower_m3209221761,
	Char_ToUpper_m2799342664,
	Char_ToUpperInvariant_m715162991,
	Char_ToString_m2071629826_AdjustorThunk,
	Char_ToString_m4030094967_AdjustorThunk,
	CharEnumerator__ctor_m816598078,
	CharEnumerator_System_Collections_IEnumerator_get_Current_m2584858255,
	CharEnumerator_System_IDisposable_Dispose_m3736572190,
	CharEnumerator_get_Current_m3833544873,
	CharEnumerator_Clone_m1959063807,
	CharEnumerator_MoveNext_m3698672156,
	CharEnumerator_Reset_m2494774291,
	CLSCompliantAttribute__ctor_m737514648,
	ArrayList__ctor_m70425822,
	ArrayList__ctor_m2581062138,
	ArrayList__ctor_m4231495083,
	ArrayList__ctor_m1063251359,
	ArrayList__cctor_m4247768616,
	ArrayList_get_Item_m1355466954,
	ArrayList_set_Item_m1710296082,
	ArrayList_get_Count_m4127613678,
	ArrayList_get_Capacity_m1752503341,
	ArrayList_set_Capacity_m1006741663,
	ArrayList_get_IsReadOnly_m3126774583,
	ArrayList_get_IsSynchronized_m516421544,
	ArrayList_get_SyncRoot_m1474613974,
	ArrayList_EnsureCapacity_m2860619830,
	ArrayList_Shift_m570081894,
	ArrayList_Add_m157538779,
	ArrayList_Clear_m2610601776,
	ArrayList_Contains_m2499310892,
	ArrayList_IndexOf_m2232959246,
	ArrayList_IndexOf_m2621741218,
	ArrayList_IndexOf_m586361265,
	ArrayList_Insert_m2426273317,
	ArrayList_InsertRange_m2857979734,
	ArrayList_Remove_m3885363094,
	ArrayList_RemoveAt_m2796573225,
	ArrayList_CopyTo_m3012638111,
	ArrayList_CopyTo_m3145284264,
	ArrayList_CopyTo_m2961909916,
	ArrayList_GetEnumerator_m4023866036,
	ArrayList_AddRange_m1925203467,
	ArrayList_Sort_m1218270835,
	ArrayList_Sort_m3021096803,
	ArrayList_ToArray_m1200471464,
	ArrayList_ToArray_m1867007925,
	ArrayList_Clone_m100144916,
	ArrayList_ThrowNewArgumentOutOfRangeException_m2252161667,
	ArrayList_Synchronized_m2483064372,
	ArrayList_ReadOnly_m91252091,
	ArrayListWrapper__ctor_m3899135388,
	ArrayListWrapper_get_Item_m2139389851,
	ArrayListWrapper_set_Item_m2576274800,
	ArrayListWrapper_get_Count_m585664997,
	ArrayListWrapper_get_Capacity_m321457925,
	ArrayListWrapper_set_Capacity_m1854908382,
	ArrayListWrapper_get_IsReadOnly_m1516100188,
	ArrayListWrapper_get_IsSynchronized_m1380460345,
	ArrayListWrapper_get_SyncRoot_m1551171319,
	ArrayListWrapper_Add_m1618290023,
	ArrayListWrapper_Clear_m1968562395,
	ArrayListWrapper_Contains_m3388742496,
	ArrayListWrapper_IndexOf_m4032143405,
	ArrayListWrapper_IndexOf_m1380666464,
	ArrayListWrapper_IndexOf_m4005555211,
	ArrayListWrapper_Insert_m2350735743,
	ArrayListWrapper_InsertRange_m996305444,
	ArrayListWrapper_Remove_m1536517963,
	ArrayListWrapper_RemoveAt_m1604324386,
	ArrayListWrapper_CopyTo_m638148083,
	ArrayListWrapper_CopyTo_m55533230,
	ArrayListWrapper_CopyTo_m67152964,
	ArrayListWrapper_GetEnumerator_m462054671,
	ArrayListWrapper_AddRange_m3354276885,
	ArrayListWrapper_Clone_m3762341118,
	ArrayListWrapper_Sort_m2710892576,
	ArrayListWrapper_Sort_m3931576544,
	ArrayListWrapper_ToArray_m3610130614,
	ArrayListWrapper_ToArray_m2818105233,
	FixedSizeArrayListWrapper__ctor_m1339347849,
	FixedSizeArrayListWrapper_get_ErrorMessage_m598057428,
	FixedSizeArrayListWrapper_get_Capacity_m1143681750,
	FixedSizeArrayListWrapper_set_Capacity_m1786958233,
	FixedSizeArrayListWrapper_Add_m4013748259,
	FixedSizeArrayListWrapper_AddRange_m734417375,
	FixedSizeArrayListWrapper_Clear_m2323207240,
	FixedSizeArrayListWrapper_Insert_m2489443233,
	FixedSizeArrayListWrapper_InsertRange_m61442832,
	FixedSizeArrayListWrapper_Remove_m2839585768,
	FixedSizeArrayListWrapper_RemoveAt_m3801664381,
	ReadOnlyArrayListWrapper__ctor_m883851205,
	ReadOnlyArrayListWrapper_get_ErrorMessage_m1560397620,
	ReadOnlyArrayListWrapper_get_IsReadOnly_m1722342459,
	ReadOnlyArrayListWrapper_get_Item_m4156760050,
	ReadOnlyArrayListWrapper_set_Item_m2152307432,
	ReadOnlyArrayListWrapper_Sort_m2935735686,
	ReadOnlyArrayListWrapper_Sort_m2841153375,
	SimpleEnumerator__ctor_m1607516457,
	SimpleEnumerator__cctor_m688277358,
	SimpleEnumerator_Clone_m2545363783,
	SimpleEnumerator_MoveNext_m1479781237,
	SimpleEnumerator_get_Current_m4120015282,
	SimpleEnumerator_Reset_m972226863,
	SynchronizedArrayListWrapper__ctor_m2878473993,
	SynchronizedArrayListWrapper_get_Item_m358168471,
	SynchronizedArrayListWrapper_set_Item_m431710062,
	SynchronizedArrayListWrapper_get_Count_m1824482348,
	SynchronizedArrayListWrapper_get_Capacity_m494532482,
	SynchronizedArrayListWrapper_set_Capacity_m3751911178,
	SynchronizedArrayListWrapper_get_IsReadOnly_m382158438,
	SynchronizedArrayListWrapper_get_IsSynchronized_m2278830943,
	SynchronizedArrayListWrapper_get_SyncRoot_m946396334,
	SynchronizedArrayListWrapper_Add_m1304395445,
	SynchronizedArrayListWrapper_Clear_m2740166537,
	SynchronizedArrayListWrapper_Contains_m817992432,
	SynchronizedArrayListWrapper_IndexOf_m3481712645,
	SynchronizedArrayListWrapper_IndexOf_m3030774803,
	SynchronizedArrayListWrapper_IndexOf_m542789323,
	SynchronizedArrayListWrapper_Insert_m2908780893,
	SynchronizedArrayListWrapper_InsertRange_m616773182,
	SynchronizedArrayListWrapper_Remove_m451513,
	SynchronizedArrayListWrapper_RemoveAt_m3250877830,
	SynchronizedArrayListWrapper_CopyTo_m1203270203,
	SynchronizedArrayListWrapper_CopyTo_m4129451812,
	SynchronizedArrayListWrapper_CopyTo_m3469183378,
	SynchronizedArrayListWrapper_GetEnumerator_m3776320929,
	SynchronizedArrayListWrapper_AddRange_m468224541,
	SynchronizedArrayListWrapper_Clone_m1454917992,
	SynchronizedArrayListWrapper_Sort_m4054587096,
	SynchronizedArrayListWrapper_Sort_m2230728101,
	SynchronizedArrayListWrapper_ToArray_m1932530011,
	SynchronizedArrayListWrapper_ToArray_m3791919948,
	BitArray__ctor_m557858207,
	BitArray__ctor_m284741893,
	BitArray_getByte_m304351007,
	BitArray_get_Count_m718376312,
	BitArray_get_Item_m3173645844,
	BitArray_set_Item_m2690807699,
	BitArray_get_Length_m529007171,
	BitArray_get_SyncRoot_m2524613174,
	BitArray_Clone_m3731712203,
	BitArray_CopyTo_m1556941566,
	BitArray_Get_m1899066644,
	BitArray_Set_m4046644063,
	BitArray_GetEnumerator_m948738958,
	BitArrayEnumerator__ctor_m2931067439,
	BitArrayEnumerator_Clone_m80699169,
	BitArrayEnumerator_get_Current_m105604645,
	BitArrayEnumerator_MoveNext_m1136090680,
	BitArrayEnumerator_Reset_m1553789913,
	BitArrayEnumerator_checkVersion_m1310474920,
	CaseInsensitiveComparer__ctor_m3394790491,
	CaseInsensitiveComparer__ctor_m1540511401,
	CaseInsensitiveComparer__cctor_m1608601064,
	CaseInsensitiveComparer_get_DefaultInvariant_m1657624612,
	CaseInsensitiveComparer_Compare_m3521105559,
	CaseInsensitiveHashCodeProvider__ctor_m824792119,
	CaseInsensitiveHashCodeProvider__ctor_m53391934,
	CaseInsensitiveHashCodeProvider__cctor_m4056930009,
	CaseInsensitiveHashCodeProvider_AreEqual_m4116505741,
	CaseInsensitiveHashCodeProvider_AreEqual_m246872803,
	CaseInsensitiveHashCodeProvider_get_DefaultInvariant_m1271415162,
	CaseInsensitiveHashCodeProvider_GetHashCode_m1025902239,
	CollectionBase__ctor_m64526301,
	CollectionBase_System_Collections_ICollection_CopyTo_m1186223115,
	CollectionBase_System_Collections_ICollection_get_SyncRoot_m2009406771,
	CollectionBase_System_Collections_IList_Add_m3513351711,
	CollectionBase_System_Collections_IList_Contains_m3583405864,
	CollectionBase_System_Collections_IList_IndexOf_m1135629131,
	CollectionBase_System_Collections_IList_Insert_m1082419815,
	CollectionBase_System_Collections_IList_Remove_m3378308850,
	CollectionBase_System_Collections_IList_get_Item_m2445814078,
	CollectionBase_System_Collections_IList_set_Item_m4129363821,
	CollectionBase_get_Count_m2616627533,
	CollectionBase_GetEnumerator_m3044469114,
	CollectionBase_Clear_m263220074,
	CollectionBase_RemoveAt_m660112964,
	CollectionBase_get_InnerList_m2963615431,
	CollectionBase_get_List_m1608088501,
	CollectionBase_OnClear_m388760764,
	CollectionBase_OnClearComplete_m2008662635,
	CollectionBase_OnInsert_m3012729704,
	CollectionBase_OnInsertComplete_m2949237076,
	CollectionBase_OnRemove_m1044728288,
	CollectionBase_OnRemoveComplete_m2998598348,
	CollectionBase_OnSet_m1421124237,
	CollectionBase_OnSetComplete_m2165368507,
	CollectionBase_OnValidate_m131111051,
	Comparer__ctor_m323909656,
	Comparer__ctor_m2235688870,
	Comparer__cctor_m2014499048,
	Comparer_Compare_m1640866209,
	Comparer_GetObjectData_m1518991269,
	DictionaryEntry__ctor_m2063096505_AdjustorThunk,
	DictionaryEntry_get_Key_m905225745_AdjustorThunk,
	DictionaryEntry_get_Value_m2234983563_AdjustorThunk,
	KeyNotFoundException__ctor_m949509995,
	KeyNotFoundException__ctor_m1245077268,
	KeyNotFoundException__ctor_m4164238210,
	Hashtable__ctor_m845111805,
	Hashtable__ctor_m2531087936,
	Hashtable__ctor_m1409638163,
	Hashtable__ctor_m465423475,
	Hashtable__ctor_m3063561525,
	Hashtable__ctor_m4115579798,
	Hashtable__ctor_m2991153945,
	Hashtable__ctor_m3453182740,
	Hashtable__ctor_m2767843923,
	Hashtable__ctor_m951508135,
	Hashtable__ctor_m492426044,
	Hashtable__ctor_m3196409060,
	Hashtable__cctor_m1851349339,
	Hashtable_System_Collections_IEnumerable_GetEnumerator_m437113998,
	Hashtable_set_comparer_m2487397675,
	Hashtable_set_hcp_m3808793454,
	Hashtable_get_Count_m2964937294,
	Hashtable_get_SyncRoot_m4112442421,
	Hashtable_get_Keys_m2621026335,
	Hashtable_get_Values_m3348718762,
	Hashtable_get_Item_m4212788697,
	Hashtable_set_Item_m3837373968,
	Hashtable_CopyTo_m3145836984,
	Hashtable_Add_m2095220904,
	Hashtable_Clear_m4221147505,
	Hashtable_Contains_m942197096,
	Hashtable_GetEnumerator_m2066958023,
	Hashtable_Remove_m3318034014,
	Hashtable_ContainsKey_m1475605912,
	Hashtable_Clone_m2835046085,
	Hashtable_GetObjectData_m610578011,
	Hashtable_OnDeserialization_m2722627116,
	Hashtable_Synchronized_m4050155833,
	Hashtable_GetHash_m3196631685,
	Hashtable_KeyEquals_m1206006735,
	Hashtable_AdjustThreshold_m4151578734,
	Hashtable_SetTable_m2328234381,
	Hashtable_Find_m1372428189,
	Hashtable_Rehash_m1394039683,
	Hashtable_PutImpl_m1536427327,
	Hashtable_CopyToArray_m292146207,
	Hashtable_TestPrime_m150100682,
	Hashtable_CalcPrime_m3698159848,
	Hashtable_ToPrime_m4218640530,
	Enumerator__ctor_m2116331586,
	Enumerator__cctor_m160908549,
	Enumerator_FailFast_m3323592279,
	Enumerator_Reset_m2830298090,
	Enumerator_MoveNext_m605642959,
	Enumerator_get_Entry_m605716437,
	Enumerator_get_Key_m3505377930,
	Enumerator_get_Value_m2630880774,
	Enumerator_get_Current_m2016534146,
	HashKeys__ctor_m2069026984,
	HashKeys_get_Count_m803578660,
	HashKeys_get_SyncRoot_m1360220610,
	HashKeys_CopyTo_m3826682869,
	HashKeys_GetEnumerator_m2700559596,
	HashValues__ctor_m2856824715,
	HashValues_get_Count_m3268869044,
	HashValues_get_SyncRoot_m1468680878,
	HashValues_CopyTo_m3362116997,
	HashValues_GetEnumerator_m3272952739,
	KeyMarker__ctor_m1746200090,
	KeyMarker__cctor_m355977784,
	SyncHashtable__ctor_m1416406087,
	SyncHashtable__ctor_m4259573849,
	SyncHashtable_System_Collections_IEnumerable_GetEnumerator_m3567539983,
	SyncHashtable_GetObjectData_m2886177721,
	SyncHashtable_get_Count_m3914611452,
	SyncHashtable_get_SyncRoot_m1630311250,
	SyncHashtable_get_Keys_m3976306703,
	SyncHashtable_get_Values_m3263999743,
	SyncHashtable_get_Item_m3883387363,
	SyncHashtable_set_Item_m3140123867,
	SyncHashtable_CopyTo_m2922163603,
	SyncHashtable_Add_m2676378853,
	SyncHashtable_Clear_m644445575,
	SyncHashtable_Contains_m2611691164,
	SyncHashtable_GetEnumerator_m3088435708,
	SyncHashtable_Remove_m2135837390,
	SyncHashtable_ContainsKey_m2888735141,
	SyncHashtable_Clone_m1003912175,
	SortedList__ctor_m3018506472,
	SortedList__ctor_m2465239628,
	SortedList__ctor_m126780072,
	SortedList__ctor_m2326936499,
	SortedList__cctor_m2523980940,
	SortedList_System_Collections_IEnumerable_GetEnumerator_m3871906508,
	SortedList_get_Count_m3966073133,
	SortedList_get_SyncRoot_m1289287974,
	SortedList_get_IsFixedSize_m1492404192,
	SortedList_get_IsReadOnly_m3632497429,
	SortedList_get_Item_m3087767982,
	SortedList_set_Item_m4106950526,
	SortedList_get_Capacity_m468427824,
	SortedList_set_Capacity_m2666993721,
	SortedList_Add_m3773519169,
	SortedList_Contains_m2476056822,
	SortedList_GetEnumerator_m3806466162,
	SortedList_Remove_m2925628248,
	SortedList_CopyTo_m1975587912,
	SortedList_Clone_m649794916,
	SortedList_RemoveAt_m1692307306,
	SortedList_IndexOfKey_m4035592023,
	SortedList_ContainsKey_m70250271,
	SortedList_GetByIndex_m2974579137,
	SortedList_EnsureCapacity_m755143429,
	SortedList_PutImpl_m2910780230,
	SortedList_GetImpl_m573218660,
	SortedList_InitTable_m3274319759,
	SortedList_Find_m2120694659,
	Enumerator__ctor_m899540130,
	Enumerator__cctor_m2471822497,
	Enumerator_Reset_m1021019657,
	Enumerator_MoveNext_m427993968,
	Enumerator_get_Entry_m3247439187,
	Enumerator_get_Key_m581327934,
	Enumerator_get_Value_m905791323,
	Enumerator_get_Current_m3792662002,
	Enumerator_Clone_m2132804677,
	Stack__ctor_m226659344,
	Stack__ctor_m1585753039,
	Stack__ctor_m4037460071,
	Stack_Resize_m3618767241,
	Stack_get_Count_m1451039529,
	Stack_get_SyncRoot_m12094254,
	Stack_Clear_m1214438660,
	Stack_Clone_m2977777692,
	Stack_CopyTo_m223801485,
	Stack_GetEnumerator_m2293825770,
	Stack_Peek_m1718230687,
	Stack_Pop_m3135319567,
	Stack_Push_m1840909377,
	Enumerator__ctor_m57585216,
	Enumerator_Clone_m2688689214,
	Enumerator_get_Current_m785454466,
	Enumerator_MoveNext_m951516890,
	Enumerator_Reset_m4254584650,
	Console__cctor_m3665180519,
	Console_SetEncodings_m3388682721,
	Console_get_Error_m2959955103,
	Console_Open_m2222222234,
	Console_OpenStandardError_m3945139383,
	Console_OpenStandardInput_m4255021723,
	Console_OpenStandardOutput_m4244304095,
	ContextBoundObject__ctor_m2389594085,
	Convert__cctor_m1348217113,
	Convert_InternalFromBase64String_m1999808388,
	Convert_FromBase64String_m1814398667,
	Convert_ToBase64String_m1844775360,
	Convert_ToBase64String_m3328115434,
	Convert_ToBoolean_m1910542813,
	Convert_ToBoolean_m1131559381,
	Convert_ToBoolean_m1621594009,
	Convert_ToBoolean_m2918377884,
	Convert_ToBoolean_m2062582429,
	Convert_ToBoolean_m3415677277,
	Convert_ToBoolean_m1887725282,
	Convert_ToBoolean_m4032852316,
	Convert_ToBoolean_m1974261568,
	Convert_ToBoolean_m707738265,
	Convert_ToBoolean_m1122829536,
	Convert_ToBoolean_m3283955427,
	Convert_ToBoolean_m141721054,
	Convert_ToBoolean_m2126966028,
	Convert_ToByte_m2418019072,
	Convert_ToByte_m1629144100,
	Convert_ToByte_m943279547,
	Convert_ToByte_m2006661353,
	Convert_ToByte_m2688521858,
	Convert_ToByte_m720591656,
	Convert_ToByte_m428988434,
	Convert_ToByte_m1519340743,
	Convert_ToByte_m1994836698,
	Convert_ToByte_m61718991,
	Convert_ToByte_m1661043916,
	Convert_ToByte_m1674698270,
	Convert_ToByte_m3099814251,
	Convert_ToByte_m2153487333,
	Convert_ToByte_m2328740238,
	Convert_ToChar_m341655201,
	Convert_ToChar_m1417206938,
	Convert_ToChar_m2194714762,
	Convert_ToChar_m2289024986,
	Convert_ToChar_m1568898469,
	Convert_ToChar_m341774582,
	Convert_ToChar_m2449990607,
	Convert_ToChar_m337390725,
	Convert_ToChar_m2214938048,
	Convert_ToChar_m453700468,
	Convert_ToChar_m1502158591,
	Convert_ToDateTime_m3022706915,
	Convert_ToDateTime_m3123344040,
	Convert_ToDateTime_m2349462082,
	Convert_ToDateTime_m144170519,
	Convert_ToDateTime_m3523522050,
	Convert_ToDateTime_m2080905788,
	Convert_ToDateTime_m3011399261,
	Convert_ToDateTime_m1737814825,
	Convert_ToDateTime_m3526800699,
	Convert_ToDateTime_m1351566174,
	Convert_ToDecimal_m917895651,
	Convert_ToDecimal_m1035337631,
	Convert_ToDecimal_m3992210978,
	Convert_ToDecimal_m346154981,
	Convert_ToDecimal_m2765597768,
	Convert_ToDecimal_m1301317035,
	Convert_ToDecimal_m3074456322,
	Convert_ToDecimal_m3255111027,
	Convert_ToDecimal_m3776158860,
	Convert_ToDecimal_m71072042,
	Convert_ToDecimal_m362315142,
	Convert_ToDecimal_m690090213,
	Convert_ToDecimal_m1381390199,
	Convert_ToDecimal_m4261852857,
	Convert_ToDouble_m1756601764,
	Convert_ToDouble_m3163203741,
	Convert_ToDouble_m603356361,
	Convert_ToDouble_m3378959113,
	Convert_ToDouble_m1478598732,
	Convert_ToDouble_m2832031852,
	Convert_ToDouble_m2711196326,
	Convert_ToDouble_m2409248499,
	Convert_ToDouble_m897723048,
	Convert_ToDouble_m2204999786,
	Convert_ToDouble_m2406944942,
	Convert_ToDouble_m132850532,
	Convert_ToDouble_m2474254574,
	Convert_ToDouble_m2045000883,
	Convert_ToInt16_m168570275,
	Convert_ToInt16_m3628395616,
	Convert_ToInt16_m4032762688,
	Convert_ToInt16_m3551750683,
	Convert_ToInt16_m1306446694,
	Convert_ToInt16_m2684953918,
	Convert_ToInt16_m4075378878,
	Convert_ToInt16_m2073193617,
	Convert_ToInt16_m3142197079,
	Convert_ToInt16_m613514068,
	Convert_ToInt16_m2943709440,
	Convert_ToInt16_m3910677062,
	Convert_ToInt16_m4194599106,
	Convert_ToInt16_m2462923612,
	Convert_ToInt16_m2376763746,
	Convert_ToInt16_m1068380511,
	Convert_ToInt32_m1913871629,
	Convert_ToInt32_m269108287,
	Convert_ToInt32_m2887001068,
	Convert_ToInt32_m3621959368,
	Convert_ToInt32_m3479988113,
	Convert_ToInt32_m539814434,
	Convert_ToInt32_m2094411742,
	Convert_ToInt32_m2414750495,
	Convert_ToInt32_m916183032,
	Convert_ToInt32_m1734262585,
	Convert_ToInt32_m2422887349,
	Convert_ToInt32_m2545494139,
	Convert_ToInt32_m1812481528,
	Convert_ToInt32_m4119363714,
	Convert_ToInt32_m2423655579,
	Convert_ToInt64_m2482280580,
	Convert_ToInt64_m214907410,
	Convert_ToInt64_m1580918798,
	Convert_ToInt64_m914666505,
	Convert_ToInt64_m2761514965,
	Convert_ToInt64_m1737805477,
	Convert_ToInt64_m198370789,
	Convert_ToInt64_m1189889578,
	Convert_ToInt64_m2719224162,
	Convert_ToInt64_m3285416634,
	Convert_ToInt64_m363300557,
	Convert_ToInt64_m420957009,
	Convert_ToInt64_m513460999,
	Convert_ToInt64_m1220027300,
	Convert_ToInt64_m3686795582,
	Convert_ToInt64_m3118196590,
	Convert_ToInt64_m753440118,
	Convert_ToSByte_m3654808220,
	Convert_ToSByte_m2221295796,
	Convert_ToSByte_m1198711592,
	Convert_ToSByte_m4039538944,
	Convert_ToSByte_m2255796510,
	Convert_ToSByte_m1171878403,
	Convert_ToSByte_m2364369564,
	Convert_ToSByte_m2473384867,
	Convert_ToSByte_m1899553949,
	Convert_ToSByte_m1260639261,
	Convert_ToSByte_m3263476780,
	Convert_ToSByte_m621137857,
	Convert_ToSByte_m502382709,
	Convert_ToSByte_m1923387717,
	Convert_ToSingle_m3318222669,
	Convert_ToSingle_m497029939,
	Convert_ToSingle_m3061264469,
	Convert_ToSingle_m2124907566,
	Convert_ToSingle_m1485709412,
	Convert_ToSingle_m3497393878,
	Convert_ToSingle_m3170522883,
	Convert_ToSingle_m2927637723,
	Convert_ToSingle_m3251546179,
	Convert_ToSingle_m333023240,
	Convert_ToSingle_m263664334,
	Convert_ToSingle_m108240803,
	Convert_ToSingle_m4264044771,
	Convert_ToSingle_m1813734906,
	Convert_ToString_m3326707857,
	Convert_ToString_m3608477782,
	Convert_ToUInt16_m3589406227,
	Convert_ToUInt16_m262507043,
	Convert_ToUInt16_m1916842140,
	Convert_ToUInt16_m1590911059,
	Convert_ToUInt16_m1460061451,
	Convert_ToUInt16_m2605846227,
	Convert_ToUInt16_m3441577881,
	Convert_ToUInt16_m2315016985,
	Convert_ToUInt16_m3851674843,
	Convert_ToUInt16_m598870541,
	Convert_ToUInt16_m1969507677,
	Convert_ToUInt16_m271993144,
	Convert_ToUInt16_m3417160479,
	Convert_ToUInt16_m848830585,
	Convert_ToUInt32_m2890507400,
	Convert_ToUInt32_m4225679663,
	Convert_ToUInt32_m1139469487,
	Convert_ToUInt32_m899358007,
	Convert_ToUInt32_m3538128733,
	Convert_ToUInt32_m2750411885,
	Convert_ToUInt32_m1509256923,
	Convert_ToUInt32_m413938554,
	Convert_ToUInt32_m3371003386,
	Convert_ToUInt32_m1967326106,
	Convert_ToUInt32_m3357398318,
	Convert_ToUInt32_m2624224331,
	Convert_ToUInt32_m4087217800,
	Convert_ToUInt32_m441301288,
	Convert_ToUInt64_m3421432777,
	Convert_ToUInt64_m588351329,
	Convert_ToUInt64_m1305628260,
	Convert_ToUInt64_m152153280,
	Convert_ToUInt64_m1532445467,
	Convert_ToUInt64_m332078237,
	Convert_ToUInt64_m2034597942,
	Convert_ToUInt64_m2644784328,
	Convert_ToUInt64_m1758528004,
	Convert_ToUInt64_m4235029228,
	Convert_ToUInt64_m441916607,
	Convert_ToUInt64_m2608704228,
	Convert_ToUInt64_m2802651835,
	Convert_ToUInt64_m2087886788,
	Convert_ToUInt64_m2300482675,
	Convert_ChangeType_m4075677086,
	Convert_ToType_m1179773789,
	CultureAwareComparer__ctor_m1207791012,
	CultureAwareComparer_Compare_m3648725758,
	CultureAwareComparer_Equals_m2362988938,
	CultureAwareComparer_GetHashCode_m570187225,
	CurrentSystemTimeZone__ctor_m3019315113,
	CurrentSystemTimeZone__ctor_m2626520283,
	CurrentSystemTimeZone_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m259544414,
	CurrentSystemTimeZone_GetTimeZoneData_m215114922,
	CurrentSystemTimeZone_GetDaylightChanges_m2566143843,
	CurrentSystemTimeZone_GetUtcOffset_m2935116097,
	CurrentSystemTimeZone_OnDeserialization_m4190759288,
	CurrentSystemTimeZone_GetDaylightTimeFromData_m3408586635,
	DateTime__ctor_m1027259371_AdjustorThunk,
	DateTime__ctor_m3541836835_AdjustorThunk,
	DateTime__ctor_m2644107222_AdjustorThunk,
	DateTime__ctor_m1926671090_AdjustorThunk,
	DateTime__ctor_m1384254117_AdjustorThunk,
	DateTime__cctor_m3460172510,
	DateTime_System_IConvertible_ToBoolean_m3632788782_AdjustorThunk,
	DateTime_System_IConvertible_ToByte_m140177676_AdjustorThunk,
	DateTime_System_IConvertible_ToChar_m664934809_AdjustorThunk,
	DateTime_System_IConvertible_ToDateTime_m1263645741_AdjustorThunk,
	DateTime_System_IConvertible_ToDecimal_m3890829851_AdjustorThunk,
	DateTime_System_IConvertible_ToDouble_m1162257995_AdjustorThunk,
	DateTime_System_IConvertible_ToInt16_m1402526305_AdjustorThunk,
	DateTime_System_IConvertible_ToInt32_m3197463939_AdjustorThunk,
	DateTime_System_IConvertible_ToInt64_m1064366169_AdjustorThunk,
	DateTime_System_IConvertible_ToSByte_m4208861919_AdjustorThunk,
	DateTime_System_IConvertible_ToSingle_m2351654096_AdjustorThunk,
	DateTime_System_IConvertible_ToType_m768938949_AdjustorThunk,
	DateTime_System_IConvertible_ToUInt16_m2777441341_AdjustorThunk,
	DateTime_System_IConvertible_ToUInt32_m1274319574_AdjustorThunk,
	DateTime_System_IConvertible_ToUInt64_m1734005549_AdjustorThunk,
	DateTime_AbsoluteDays_m662719526,
	DateTime_FromTicks_m485172754_AdjustorThunk,
	DateTime_get_Month_m4165080545_AdjustorThunk,
	DateTime_get_Day_m896245515_AdjustorThunk,
	DateTime_get_DayOfWeek_m2939993125_AdjustorThunk,
	DateTime_get_Hour_m2800068934_AdjustorThunk,
	DateTime_get_Minute_m2080337245_AdjustorThunk,
	DateTime_get_Second_m1756323831_AdjustorThunk,
	DateTime_GetTimeMonotonic_m3455016556,
	DateTime_GetNow_m4053549187,
	DateTime_get_Now_m1925541424,
	DateTime_get_Ticks_m1568760618_AdjustorThunk,
	DateTime_get_Today_m3230239018,
	DateTime_get_UtcNow_m3828112662,
	DateTime_get_Year_m4152477509_AdjustorThunk,
	DateTime_get_Kind_m1602235531_AdjustorThunk,
	DateTime_Add_m592174673_AdjustorThunk,
	DateTime_AddTicks_m1235861880_AdjustorThunk,
	DateTime_AddMilliseconds_m2189489516_AdjustorThunk,
	DateTime_AddSeconds_m916727128_AdjustorThunk,
	DateTime_Compare_m453481671,
	DateTime_CompareTo_m39293199_AdjustorThunk,
	DateTime_CompareTo_m2611454681_AdjustorThunk,
	DateTime_Equals_m2876590215_AdjustorThunk,
	DateTime_FromBinary_m2399234721,
	DateTime_SpecifyKind_m3350820625,
	DateTime_DaysInMonth_m2570372843,
	DateTime_Equals_m3711038146_AdjustorThunk,
	DateTime_CheckDateTimeKind_m1552287883_AdjustorThunk,
	DateTime_GetHashCode_m3696582555_AdjustorThunk,
	DateTime_IsLeapYear_m3299279581,
	DateTime_Parse_m1095371782,
	DateTime_Parse_m2695626789,
	DateTime_CoreParse_m557529197,
	DateTime_YearMonthDayFormats_m741320887,
	DateTime__ParseNumber_m4238331684,
	DateTime__ParseEnum_m2419676920,
	DateTime__ParseString_m2294737794,
	DateTime__ParseAmPm_m2558690232,
	DateTime__ParseTimeSeparator_m1035910457,
	DateTime__ParseDateSeparator_m1823941406,
	DateTime_IsLetter_m2365043383,
	DateTime__DoParse_m1912887474,
	DateTime_ParseExact_m2553678435,
	DateTime_ParseExact_m3456146807,
	DateTime_CheckStyle_m3808154593,
	DateTime_ParseExact_m3984936769,
	DateTime_Subtract_m3350263303_AdjustorThunk,
	DateTime_ToString_m3729341423_AdjustorThunk,
	DateTime_ToString_m1414090114_AdjustorThunk,
	DateTime_ToString_m3183648526_AdjustorThunk,
	DateTime_ToLocalTime_m4017440156_AdjustorThunk,
	DateTime_ToUniversalTime_m2779765572_AdjustorThunk,
	DateTime_op_Addition_m1787700689,
	DateTime_op_Equality_m3013014607,
	DateTime_op_GreaterThan_m1806441651,
	DateTime_op_GreaterThanOrEqual_m914020694,
	DateTime_op_Inequality_m4036645441,
	DateTime_op_LessThan_m3146868751,
	DateTime_op_LessThanOrEqual_m1144734147,
	DateTime_op_Subtraction_m646944166,
	DateTimeOffset__ctor_m393815523_AdjustorThunk,
	DateTimeOffset__ctor_m690748493_AdjustorThunk,
	DateTimeOffset__ctor_m2315704004_AdjustorThunk,
	DateTimeOffset__ctor_m3565797660_AdjustorThunk,
	DateTimeOffset__cctor_m4092712168,
	DateTimeOffset_System_IComparable_CompareTo_m2751518275_AdjustorThunk,
	DateTimeOffset_System_Runtime_Serialization_ISerializable_GetObjectData_m2791453454_AdjustorThunk,
	DateTimeOffset_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m2865451658_AdjustorThunk,
	DateTimeOffset_CompareTo_m2878534399_AdjustorThunk,
	DateTimeOffset_Equals_m1208643636_AdjustorThunk,
	DateTimeOffset_Equals_m3867471892_AdjustorThunk,
	DateTimeOffset_GetHashCode_m1491551126_AdjustorThunk,
	DateTimeOffset_ToString_m573727808_AdjustorThunk,
	DateTimeOffset_ToString_m268102416_AdjustorThunk,
	DateTimeOffset_get_DateTime_m3102418896_AdjustorThunk,
	DateTimeOffset_get_Offset_m2501267323_AdjustorThunk,
	DateTimeOffset_get_UtcDateTime_m4198775470_AdjustorThunk,
	DateTimeUtils_CountRepeat_m1875087316,
	DateTimeUtils_ZeroPad_m4061994436,
	DateTimeUtils_ParseQuotedString_m1500812331,
	DateTimeUtils_GetStandardPattern_m899129541,
	DateTimeUtils_GetStandardPattern_m3209988641,
	DateTimeUtils_ToString_m943113255,
	DateTimeUtils_ToString_m1660361122,
	DBNull__ctor_m1760941697,
	DBNull__ctor_m3761983109,
	DBNull__cctor_m24967054,
	DBNull_System_IConvertible_ToBoolean_m2364984202,
	DBNull_System_IConvertible_ToByte_m3424062133,
	DBNull_System_IConvertible_ToChar_m2773824425,
	DBNull_System_IConvertible_ToDateTime_m1876132951,
	DBNull_System_IConvertible_ToDecimal_m1768131063,
	DBNull_System_IConvertible_ToDouble_m4030181152,
	DBNull_System_IConvertible_ToInt16_m4130785595,
	DBNull_System_IConvertible_ToInt32_m3582990580,
	DBNull_System_IConvertible_ToInt64_m2437803837,
	DBNull_System_IConvertible_ToSByte_m2927018638,
	DBNull_System_IConvertible_ToSingle_m1319016320,
	DBNull_System_IConvertible_ToType_m2866590128,
	DBNull_System_IConvertible_ToUInt16_m3550134390,
	DBNull_System_IConvertible_ToUInt32_m165681718,
	DBNull_System_IConvertible_ToUInt64_m3568278568,
	DBNull_GetObjectData_m1645577515,
	DBNull_ToString_m852284939,
	DBNull_ToString_m1304363896,
	Decimal__ctor_m2375467100_AdjustorThunk,
	Decimal__ctor_m1233034355_AdjustorThunk,
	Decimal__ctor_m2545903267_AdjustorThunk,
	Decimal__ctor_m1632238500_AdjustorThunk,
	Decimal__ctor_m3377077937_AdjustorThunk,
	Decimal__ctor_m1426586083_AdjustorThunk,
	Decimal__ctor_m3781718484_AdjustorThunk,
	Decimal__cctor_m952889160,
	Decimal_System_IConvertible_ToType_m1041976950_AdjustorThunk,
	Decimal_System_IConvertible_ToBoolean_m448140043_AdjustorThunk,
	Decimal_System_IConvertible_ToByte_m3090076580_AdjustorThunk,
	Decimal_System_IConvertible_ToChar_m29672976_AdjustorThunk,
	Decimal_System_IConvertible_ToDateTime_m64040985_AdjustorThunk,
	Decimal_System_IConvertible_ToDecimal_m2186204236_AdjustorThunk,
	Decimal_System_IConvertible_ToDouble_m3800580116_AdjustorThunk,
	Decimal_System_IConvertible_ToInt16_m72561042_AdjustorThunk,
	Decimal_System_IConvertible_ToInt32_m3196844544_AdjustorThunk,
	Decimal_System_IConvertible_ToInt64_m1310352674_AdjustorThunk,
	Decimal_System_IConvertible_ToSByte_m1240667516_AdjustorThunk,
	Decimal_System_IConvertible_ToSingle_m1684053230_AdjustorThunk,
	Decimal_System_IConvertible_ToUInt16_m1392242618_AdjustorThunk,
	Decimal_System_IConvertible_ToUInt32_m1541164744_AdjustorThunk,
	Decimal_System_IConvertible_ToUInt64_m1292652844_AdjustorThunk,
	Decimal_GetBits_m2327903701,
	Decimal_Add_m2113577551,
	Decimal_Subtract_m3576317969,
	Decimal_GetHashCode_m3714536886_AdjustorThunk,
	Decimal_u64_m989125512,
	Decimal_s64_m2348649978,
	Decimal_Equals_m747729212,
	Decimal_Equals_m631014508_AdjustorThunk,
	Decimal_IsZero_m40595514_AdjustorThunk,
	Decimal_Floor_m2290876548,
	Decimal_Multiply_m3373936600,
	Decimal_Divide_m2503346782,
	Decimal_Compare_m3646660628,
	Decimal_CompareTo_m2097498843_AdjustorThunk,
	Decimal_CompareTo_m3857970533_AdjustorThunk,
	Decimal_Equals_m3693295319_AdjustorThunk,
	Decimal_Parse_m178433692,
	Decimal_ThrowAtPos_m4275655439,
	Decimal_ThrowInvalidExp_m2284341434,
	Decimal_stripStyles_m3902823558,
	Decimal_Parse_m3400819519,
	Decimal_PerformParse_m2858098378,
	Decimal_ToString_m3060605991_AdjustorThunk,
	Decimal_ToString_m2927434073_AdjustorThunk,
	Decimal_ToString_m3544392991_AdjustorThunk,
	Decimal_decimal2UInt64_m2672947272,
	Decimal_decimal2Int64_m2561288189,
	Decimal_decimalIncr_m2154115687,
	Decimal_string2decimal_m1084491150,
	Decimal_decimalSetExponent_m568585892,
	Decimal_decimal2double_m703402254,
	Decimal_decimalFloorAndTrunc_m1022640108,
	Decimal_decimalMult_m2114411602,
	Decimal_decimalDiv_m300208215,
	Decimal_decimalCompare_m1863112118,
	Decimal_op_Increment_m1974443191,
	Decimal_op_Subtraction_m930621160,
	Decimal_op_Multiply_m3784923707,
	Decimal_op_Division_m4273106878,
	Decimal_op_Explicit_m1253500197,
	Decimal_op_Explicit_m1503313322,
	Decimal_op_Explicit_m284229644,
	Decimal_op_Explicit_m1521124198,
	Decimal_op_Explicit_m4264442304,
	Decimal_op_Explicit_m1054949672,
	Decimal_op_Explicit_m1320737014,
	Decimal_op_Explicit_m2818597674,
	Decimal_op_Implicit_m1321015723,
	Decimal_op_Implicit_m1540208279,
	Decimal_op_Implicit_m2474035815,
	Decimal_op_Implicit_m980199957,
	Decimal_op_Implicit_m2978332954,
	Decimal_op_Implicit_m881253395,
	Decimal_op_Implicit_m3473468664,
	Decimal_op_Implicit_m809477236,
	Decimal_op_Explicit_m3470941409,
	Decimal_op_Explicit_m2236159626,
	Decimal_op_Explicit_m4098952179,
	Decimal_op_Explicit_m1643748915,
	Decimal_op_Inequality_m2362282707,
	Decimal_op_Equality_m63189074,
	Decimal_op_GreaterThan_m1575087537,
	Decimal_op_LessThan_m2754705003,
	Delegate_get_Method_m722699673,
	Delegate_get_Target_m4255055791,
	Delegate_CreateDelegate_internal_m1804039199,
	Delegate_SetMulticastInvoke_m2431511429,
	Delegate_arg_type_match_m3839365790,
	Delegate_return_type_match_m35901976,
	Delegate_CreateDelegate_m1528872118,
	Delegate_CreateDelegate_m1475733018,
	Delegate_CreateDelegate_m1719653086,
	Delegate_CreateDelegate_m2037718425,
	Delegate_GetCandidateMethod_m3741128559,
	Delegate_CreateDelegate_m2565795613,
	Delegate_CreateDelegate_m1955057739,
	Delegate_CreateDelegate_m1770444889,
	Delegate_CreateDelegate_m3279529823,
	Delegate_Clone_m631165656,
	Delegate_Equals_m1707779987,
	Delegate_GetHashCode_m2388227318,
	Delegate_GetObjectData_m1078969361,
	Delegate_GetInvocationList_m2881246543,
	Delegate_Combine_m1818817617,
	Delegate_Combine_m1500603169,
	Delegate_CombineImpl_m233686841,
	Delegate_Remove_m2436345873,
	Delegate_RemoveImpl_m4202643787,
	DelegateSerializationHolder__ctor_m2950190668,
	DelegateSerializationHolder_GetDelegateData_m1287770054,
	DelegateSerializationHolder_GetObjectData_m2048210184,
	DelegateSerializationHolder_GetRealObject_m2761320795,
	DelegateEntry__ctor_m596353592,
	DelegateEntry_DeserializeDelegate_m179836656,
	DebuggableAttribute__ctor_m2582985872,
	DebuggerBrowsableAttribute__ctor_m2340592270,
	DebuggerDisplayAttribute__ctor_m4023377227,
	DebuggerDisplayAttribute_set_Name_m528775879,
	DebuggerHiddenAttribute__ctor_m1902081030,
	DebuggerStepThroughAttribute__ctor_m4239143502,
	DebuggerTypeProxyAttribute__ctor_m716875895,
	StackFrame__ctor_m3047066617,
	StackFrame__ctor_m2822438684,
	StackFrame_get_frame_info_m1855966903,
	StackFrame_GetFileLineNumber_m2815894532,
	StackFrame_GetFileName_m1839350649,
	StackFrame_GetSecureFileName_m5595071,
	StackFrame_GetILOffset_m242737610,
	StackFrame_GetMethod_m3559755628,
	StackFrame_GetNativeOffset_m225286671,
	StackFrame_GetInternalMethodName_m3598100589,
	StackFrame_ToString_m353061470,
	StackTrace__ctor_m3421260247,
	StackTrace__ctor_m2586972645,
	StackTrace__ctor_m1174316567,
	StackTrace__ctor_m2775913378,
	StackTrace__ctor_m4038793957,
	StackTrace_init_frames_m451976113,
	StackTrace_get_trace_m87107404,
	StackTrace_get_FrameCount_m3366875035,
	StackTrace_GetFrame_m3312688971,
	StackTrace_ToString_m324270236,
	DivideByZeroException__ctor_m686050583,
	DivideByZeroException__ctor_m33029225,
	DllNotFoundException__ctor_m1841441813,
	DllNotFoundException__ctor_m1149151497,
	Double_System_IConvertible_ToType_m950968201_AdjustorThunk,
	Double_System_IConvertible_ToBoolean_m156639669_AdjustorThunk,
	Double_System_IConvertible_ToByte_m3237704766_AdjustorThunk,
	Double_System_IConvertible_ToChar_m4163693792_AdjustorThunk,
	Double_System_IConvertible_ToDateTime_m2408138350_AdjustorThunk,
	Double_System_IConvertible_ToDecimal_m2112247527_AdjustorThunk,
	Double_System_IConvertible_ToDouble_m2588339855_AdjustorThunk,
	Double_System_IConvertible_ToInt16_m2545112260_AdjustorThunk,
	Double_System_IConvertible_ToInt32_m2575974537_AdjustorThunk,
	Double_System_IConvertible_ToInt64_m951275453_AdjustorThunk,
	Double_System_IConvertible_ToSByte_m4038606575_AdjustorThunk,
	Double_System_IConvertible_ToSingle_m2268595922_AdjustorThunk,
	Double_System_IConvertible_ToUInt16_m289568425_AdjustorThunk,
	Double_System_IConvertible_ToUInt32_m2811496434_AdjustorThunk,
	Double_System_IConvertible_ToUInt64_m1064701039_AdjustorThunk,
	Double_CompareTo_m1498322386_AdjustorThunk,
	Double_Equals_m2453452523_AdjustorThunk,
	Double_CompareTo_m1296920832_AdjustorThunk,
	Double_Equals_m1537334590_AdjustorThunk,
	Double_GetHashCode_m2774968031_AdjustorThunk,
	Double_IsInfinity_m3491993807,
	Double_IsNaN_m372022469,
	Double_IsNegativeInfinity_m2038118090,
	Double_IsPositiveInfinity_m1010549376,
	Double_Parse_m2069326782,
	Double_Parse_m3156113049,
	Double_Parse_m2014590239,
	Double_Parse_m1455251062,
	Double_TryParseStringConstant_m2044222428,
	Double_ParseImpl_m652289071,
	Double_ToString_m3526598450_AdjustorThunk,
	Double_ToString_m3425342682_AdjustorThunk,
	Double_ToString_m498721196_AdjustorThunk,
	EntryPointNotFoundException__ctor_m3921716307,
	EntryPointNotFoundException__ctor_m1098388418,
	Enum__ctor_m4213025137,
	Enum__cctor_m2049588518,
	Enum_System_IConvertible_ToBoolean_m1850576853,
	Enum_System_IConvertible_ToByte_m1253629655,
	Enum_System_IConvertible_ToChar_m2632223723,
	Enum_System_IConvertible_ToDateTime_m4226917540,
	Enum_System_IConvertible_ToDecimal_m2519275684,
	Enum_System_IConvertible_ToDouble_m1455222111,
	Enum_System_IConvertible_ToInt16_m3169802136,
	Enum_System_IConvertible_ToInt32_m1691541055,
	Enum_System_IConvertible_ToInt64_m2002405858,
	Enum_System_IConvertible_ToSByte_m128325077,
	Enum_System_IConvertible_ToSingle_m2765862699,
	Enum_System_IConvertible_ToType_m1457416255,
	Enum_System_IConvertible_ToUInt16_m1201277658,
	Enum_System_IConvertible_ToUInt32_m3371194579,
	Enum_System_IConvertible_ToUInt64_m464125294,
	Enum_GetTypeCode_m2021821451,
	Enum_get_value_m4175244741,
	Enum_get_Value_m53431365,
	Enum_FindPosition_m265007466,
	Enum_GetName_m874261310,
	Enum_IsDefined_m680461013,
	Enum_get_underlying_type_m3626539537,
	Enum_GetUnderlyingType_m1443556329,
	Enum_FindName_m1104374038,
	Enum_GetValue_m4025338855,
	Enum_Parse_m2788862954,
	Enum_compare_value_to_m3888943458,
	Enum_CompareTo_m1687633388,
	Enum_ToString_m4292412120,
	Enum_ToString_m4269924258,
	Enum_ToString_m3441869701,
	Enum_ToString_m3300782106,
	Enum_ToObject_m78379513,
	Enum_ToObject_m4274442607,
	Enum_ToObject_m2048232900,
	Enum_ToObject_m3196673333,
	Enum_ToObject_m2696618385,
	Enum_ToObject_m887634324,
	Enum_ToObject_m2147101483,
	Enum_ToObject_m1741150068,
	Enum_ToObject_m3978950197,
	Enum_Equals_m823693965,
	Enum_get_hashcode_m2444713561,
	Enum_GetHashCode_m2610622810,
	Enum_FormatSpecifier_X_m3029026223,
	Enum_FormatFlags_m2409305353,
	Enum_Format_m1584462606,
	Environment_get_SocketSecurityEnabled_m544320776,
	Environment_get_NewLine_m3932835213,
	Environment_get_Platform_m849787314,
	Environment_GetOSVersionString_m1737537524,
	Environment_get_OSVersion_m609277843,
	Environment_internalGetEnvironmentVariable_m2005550798,
	Environment_GetEnvironmentVariable_m217924105,
	Environment_GetWindowsFolderPath_m3651701357,
	Environment_GetFolderPath_m932095549,
	Environment_ReadXdgUserDir_m1690141482,
	Environment_InternalGetFolderPath_m3667664563,
	Environment_get_IsRunningOnWindows_m394340488,
	Environment_GetMachineConfigPath_m441963722,
	Environment_internalGetHome_m2584361417,
	EventArgs__ctor_m45418584,
	EventArgs__cctor_m3062301783,
	EventHandler__ctor_m1973508153,
	EventHandler_Invoke_m2463096176,
	EventHandler_BeginInvoke_m3931632318,
	EventHandler_EndInvoke_m3496186603,
	Exception__ctor_m1963162063,
	Exception__ctor_m3522669789,
	Exception__ctor_m3004450192,
	Exception__ctor_m4213837374,
	Exception_get_InnerException_m2520160954,
	Exception_get_HResult_m3981263987,
	Exception_set_HResult_m3582735346,
	Exception_get_ClassName_m2614214744,
	Exception_get_Message_m571842362,
	Exception_get_Source_m2477393952,
	Exception_get_StackTrace_m1179238353,
	Exception_GetObjectData_m4118996056,
	Exception_ToString_m653446967,
	Exception_GetFullNameForStackTrace_m2913020021,
	Exception_GetType_m3778669904,
	ExecutionEngineException__ctor_m131762956,
	ExecutionEngineException__ctor_m1849804984,
	FieldAccessException__ctor_m3252623332,
	FieldAccessException__ctor_m1439472429,
	FieldAccessException__ctor_m3101973560,
	FlagsAttribute__ctor_m1689062726,
	FormatException__ctor_m2526052426,
	FormatException__ctor_m3427739798,
	FormatException__ctor_m2521959026,
	GC_SuppressFinalize_m2436602860,
	Calendar__ctor_m4252530830,
	Calendar_Clone_m339556131,
	Calendar_CheckReadOnly_m1443013959,
	Calendar_get_EraNames_m119638893,
	CCFixed_FromDateTime_m3601535931,
	CCFixed_day_of_week_m2094560398,
	CCGregorianCalendar_is_leap_year_m2352458385,
	CCGregorianCalendar_fixed_from_dmy_m954821772,
	CCGregorianCalendar_year_from_fixed_m733920312,
	CCGregorianCalendar_my_from_fixed_m553562571,
	CCGregorianCalendar_dmy_from_fixed_m3954005869,
	CCGregorianCalendar_month_from_fixed_m259489726,
	CCGregorianCalendar_day_from_fixed_m4237301666,
	CCGregorianCalendar_GetDayOfMonth_m3715926045,
	CCGregorianCalendar_GetMonth_m294498333,
	CCGregorianCalendar_GetYear_m2300336658,
	CCMath_div_m2825256666,
	CCMath_mod_m2191621029,
	CCMath_div_mod_m3469524691,
	CompareInfo__ctor_m1267878636,
	CompareInfo__ctor_m3083190225,
	CompareInfo__cctor_m1359236201,
	CompareInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m4213073829,
	CompareInfo_get_UseManagedCollation_m3854275125,
	CompareInfo_construct_compareinfo_m1203849545,
	CompareInfo_free_internal_collator_m1219030985,
	CompareInfo_internal_compare_m138559236,
	CompareInfo_assign_sortkey_m4278962796,
	CompareInfo_internal_index_m1140031158,
	CompareInfo_Finalize_m340112025,
	CompareInfo_internal_compare_managed_m2182411895,
	CompareInfo_internal_compare_switch_m1609918365,
	CompareInfo_Compare_m3932333838,
	CompareInfo_Compare_m2627226942,
	CompareInfo_Compare_m2201188574,
	CompareInfo_Equals_m1097688160,
	CompareInfo_GetHashCode_m1281902164,
	CompareInfo_GetSortKey_m1445508551,
	CompareInfo_IndexOf_m226749063,
	CompareInfo_internal_index_managed_m593633239,
	CompareInfo_internal_index_switch_m3526247840,
	CompareInfo_IndexOf_m2306060771,
	CompareInfo_IsPrefix_m2747811208,
	CompareInfo_IsSuffix_m3717393673,
	CompareInfo_LastIndexOf_m4148412737,
	CompareInfo_LastIndexOf_m3067704173,
	CompareInfo_ToString_m3146053996,
	CompareInfo_get_LCID_m318761828,
	CultureInfo__ctor_m1901159171,
	CultureInfo__ctor_m3763344666,
	CultureInfo__ctor_m2929979851,
	CultureInfo__ctor_m1991789257,
	CultureInfo__ctor_m385466406,
	CultureInfo__cctor_m2379690457,
	CultureInfo_get_InvariantCulture_m2703857018,
	CultureInfo_get_CurrentCulture_m3825006640,
	CultureInfo_get_CurrentUICulture_m4078896923,
	CultureInfo_ConstructCurrentCulture_m2590567962,
	CultureInfo_ConstructCurrentUICulture_m1469273297,
	CultureInfo_get_LCID_m3817325705,
	CultureInfo_get_Name_m1725862915,
	CultureInfo_get_Parent_m3935099926,
	CultureInfo_get_TextInfo_m1735258217,
	CultureInfo_get_IcuName_m1272887519,
	CultureInfo_Clone_m1865674518,
	CultureInfo_Equals_m997543062,
	CultureInfo_GetHashCode_m1877941735,
	CultureInfo_ToString_m2906022157,
	CultureInfo_get_CompareInfo_m4273505092,
	CultureInfo_get_IsNeutralCulture_m27834099,
	CultureInfo_CheckNeutral_m1206549274,
	CultureInfo_get_NumberFormat_m2033804725,
	CultureInfo_set_NumberFormat_m3286432673,
	CultureInfo_get_DateTimeFormat_m2788164208,
	CultureInfo_set_DateTimeFormat_m3462553177,
	CultureInfo_get_IsReadOnly_m2576711096,
	CultureInfo_GetFormat_m2988593869,
	CultureInfo_Construct_m2088591410,
	CultureInfo_ConstructInternalLocaleFromName_m3836733798,
	CultureInfo_ConstructInternalLocaleFromLcid_m1660685822,
	CultureInfo_ConstructInternalLocaleFromCurrentLocale_m3508427564,
	CultureInfo_construct_internal_locale_from_lcid_m1705957113,
	CultureInfo_construct_internal_locale_from_name_m498853986,
	CultureInfo_construct_internal_locale_from_current_locale_m279034963,
	CultureInfo_construct_datetime_format_m3134253742,
	CultureInfo_construct_number_format_m926162420,
	CultureInfo_ConstructInvariant_m748079512,
	CultureInfo_CreateTextInfo_m1905477652,
	CultureInfo_CreateCulture_m1951261937,
	DateTimeFormatInfo__ctor_m1064973436,
	DateTimeFormatInfo__ctor_m4067902793,
	DateTimeFormatInfo__cctor_m2312692094,
	DateTimeFormatInfo_GetInstance_m3501920895,
	DateTimeFormatInfo_get_IsReadOnly_m3887541955,
	DateTimeFormatInfo_ReadOnly_m1827068842,
	DateTimeFormatInfo_Clone_m212216615,
	DateTimeFormatInfo_GetFormat_m949390545,
	DateTimeFormatInfo_GetAbbreviatedMonthName_m1384042871,
	DateTimeFormatInfo_GetEraName_m2370973419,
	DateTimeFormatInfo_GetMonthName_m580830951,
	DateTimeFormatInfo_get_RawAbbreviatedDayNames_m771339539,
	DateTimeFormatInfo_get_RawAbbreviatedMonthNames_m3313163664,
	DateTimeFormatInfo_get_RawDayNames_m813648654,
	DateTimeFormatInfo_get_RawMonthNames_m2737417785,
	DateTimeFormatInfo_get_AMDesignator_m3344343874,
	DateTimeFormatInfo_get_PMDesignator_m302707128,
	DateTimeFormatInfo_get_DateSeparator_m716221337,
	DateTimeFormatInfo_get_TimeSeparator_m1661466174,
	DateTimeFormatInfo_get_LongDatePattern_m2705252258,
	DateTimeFormatInfo_get_ShortDatePattern_m554218357,
	DateTimeFormatInfo_get_ShortTimePattern_m3942384882,
	DateTimeFormatInfo_get_LongTimePattern_m3610205894,
	DateTimeFormatInfo_get_MonthDayPattern_m1818175938,
	DateTimeFormatInfo_get_YearMonthPattern_m3767604897,
	DateTimeFormatInfo_get_FullDateTimePattern_m3977924960,
	DateTimeFormatInfo_get_CurrentInfo_m1517247120,
	DateTimeFormatInfo_get_InvariantInfo_m2896349598,
	DateTimeFormatInfo_get_Calendar_m3249748714,
	DateTimeFormatInfo_set_Calendar_m4204099551,
	DateTimeFormatInfo_get_RFC1123Pattern_m2280292587,
	DateTimeFormatInfo_get_RoundtripPattern_m1737362490,
	DateTimeFormatInfo_get_SortableDateTimePattern_m1688789742,
	DateTimeFormatInfo_get_UniversalSortableDateTimePattern_m3187108552,
	DateTimeFormatInfo_GetAllDateTimePatternsInternal_m2245060199,
	DateTimeFormatInfo_FillAllDateTimePatterns_m3641747943,
	DateTimeFormatInfo_GetAllRawDateTimePatterns_m383470066,
	DateTimeFormatInfo_GetDayName_m3886558945,
	DateTimeFormatInfo_GetAbbreviatedDayName_m2980152815,
	DateTimeFormatInfo_FillInvariantPatterns_m4210018192,
	DateTimeFormatInfo_PopulateCombinedList_m580969887,
	DaylightTime__ctor_m3952422893,
	DaylightTime_get_Start_m1617525025,
	DaylightTime_get_End_m4047658457,
	DaylightTime_get_Delta_m347033140,
	GregorianCalendar__ctor_m118695340,
	GregorianCalendar__ctor_m2574627420,
	GregorianCalendar_get_Eras_m3677190740,
	GregorianCalendar_set_CalendarType_m2401608579,
	GregorianCalendar_GetDayOfMonth_m3249599849,
	GregorianCalendar_GetDayOfWeek_m2029231875,
	GregorianCalendar_GetEra_m1148855638,
	GregorianCalendar_GetMonth_m3540651416,
	GregorianCalendar_GetYear_m4044223495,
	NumberFormatInfo__ctor_m2749641968,
	NumberFormatInfo__ctor_m640347805,
	NumberFormatInfo__ctor_m2233308711,
	NumberFormatInfo__cctor_m951634967,
	NumberFormatInfo_get_CurrencyDecimalDigits_m3386147374,
	NumberFormatInfo_get_CurrencyDecimalSeparator_m301819200,
	NumberFormatInfo_get_CurrencyGroupSeparator_m3551634584,
	NumberFormatInfo_get_RawCurrencyGroupSizes_m1103619441,
	NumberFormatInfo_get_CurrencyNegativePattern_m3399374263,
	NumberFormatInfo_get_CurrencyPositivePattern_m1855739149,
	NumberFormatInfo_get_CurrencySymbol_m1993166409,
	NumberFormatInfo_get_CurrentInfo_m3962739977,
	NumberFormatInfo_get_InvariantInfo_m2020392346,
	NumberFormatInfo_get_NaNSymbol_m2462412584,
	NumberFormatInfo_get_NegativeInfinitySymbol_m3044548863,
	NumberFormatInfo_get_NegativeSign_m304021131,
	NumberFormatInfo_get_NumberDecimalDigits_m3231800403,
	NumberFormatInfo_get_NumberDecimalSeparator_m1579432527,
	NumberFormatInfo_get_NumberGroupSeparator_m3116325849,
	NumberFormatInfo_get_RawNumberGroupSizes_m139744770,
	NumberFormatInfo_get_NumberNegativePattern_m3784302135,
	NumberFormatInfo_set_NumberNegativePattern_m2710420588,
	NumberFormatInfo_get_PercentDecimalDigits_m697654847,
	NumberFormatInfo_get_PercentDecimalSeparator_m2303567846,
	NumberFormatInfo_get_PercentGroupSeparator_m4081103831,
	NumberFormatInfo_get_RawPercentGroupSizes_m2158439602,
	NumberFormatInfo_get_PercentNegativePattern_m1825402758,
	NumberFormatInfo_get_PercentPositivePattern_m1676569335,
	NumberFormatInfo_get_PercentSymbol_m4225002416,
	NumberFormatInfo_get_PerMilleSymbol_m3108752395,
	NumberFormatInfo_get_PositiveInfinitySymbol_m525671517,
	NumberFormatInfo_get_PositiveSign_m3777856571,
	NumberFormatInfo_GetFormat_m3221635202,
	NumberFormatInfo_Clone_m516656634,
	NumberFormatInfo_GetInstance_m464741399,
	SortKey__ctor_m2186020651,
	SortKey__ctor_m1265572398,
	SortKey_Compare_m1528777764,
	SortKey_get_OriginalString_m3942611402,
	SortKey_get_KeyData_m3882341771,
	SortKey_Equals_m2613032493,
	SortKey_GetHashCode_m2119632448,
	SortKey_ToString_m3597365547,
	TextInfo__ctor_m2743443081,
	TextInfo__ctor_m909355147,
	TextInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m3019484889,
	TextInfo_get_ListSeparator_m3791815108,
	TextInfo_get_CultureName_m3977656513,
	TextInfo_Equals_m742173566,
	TextInfo_GetHashCode_m3293153969,
	TextInfo_ToString_m3487185234,
	TextInfo_ToLower_m1674718553,
	TextInfo_ToUpper_m1689424880,
	TextInfo_ToLower_m2933028113,
	TextInfo_Clone_m808132933,
	Guid__ctor_m863034180_AdjustorThunk,
	Guid__ctor_m64311516_AdjustorThunk,
	Guid__ctor_m3914967784_AdjustorThunk,
	Guid__ctor_m4104065248_AdjustorThunk,
	Guid__cctor_m720166842,
	Guid_CheckNull_m1244079130,
	Guid_CheckLength_m339047510,
	Guid_CheckArray_m1158178513,
	Guid_Compare_m1114556690,
	Guid_CompareTo_m1281599267_AdjustorThunk,
	Guid_Equals_m569984024_AdjustorThunk,
	Guid_CompareTo_m601707037_AdjustorThunk,
	Guid_Equals_m3462938272_AdjustorThunk,
	Guid_GetHashCode_m2438320146_AdjustorThunk,
	Guid_ToHex_m1755027096,
	Guid_NewGuid_m2831319107,
	Guid_AppendInt_m1964984663,
	Guid_AppendShort_m2185748500,
	Guid_AppendByte_m3270752582,
	Guid_BaseToString_m1958182798_AdjustorThunk,
	Guid_ToString_m2413444111_AdjustorThunk,
	Guid_ToString_m3682994952_AdjustorThunk,
	Guid_ToString_m2480233691_AdjustorThunk,
	Guid_op_Equality_m3232899884,
	GuidParser__ctor_m1875340791,
	GuidParser_Reset_m3446695483,
	GuidParser_AtEnd_m894422050,
	GuidParser_ThrowFormatException_m3592788942,
	GuidParser_ParseHex_m1488080526,
	GuidParser_ParseOptChar_m3263489376,
	GuidParser_ParseChar_m224736205,
	GuidParser_ParseGuid1_m529274067,
	GuidParser_ParseHexPrefix_m2663518229,
	GuidParser_ParseGuid2_m1534974221,
	GuidParser_Parse_m3175475972,
	IndexOutOfRangeException__ctor_m3853417735,
	IndexOutOfRangeException__ctor_m90218927,
	IndexOutOfRangeException__ctor_m3328578087,
	Int16_System_IConvertible_ToBoolean_m1258257395_AdjustorThunk,
	Int16_System_IConvertible_ToByte_m2047265631_AdjustorThunk,
	Int16_System_IConvertible_ToChar_m2059138803_AdjustorThunk,
	Int16_System_IConvertible_ToDateTime_m3256244351_AdjustorThunk,
	Int16_System_IConvertible_ToDecimal_m3246902503_AdjustorThunk,
	Int16_System_IConvertible_ToDouble_m2690798103_AdjustorThunk,
	Int16_System_IConvertible_ToInt16_m276356287_AdjustorThunk,
	Int16_System_IConvertible_ToInt32_m2249015168_AdjustorThunk,
	Int16_System_IConvertible_ToInt64_m478817829_AdjustorThunk,
	Int16_System_IConvertible_ToSByte_m3576027355_AdjustorThunk,
	Int16_System_IConvertible_ToSingle_m2912735131_AdjustorThunk,
	Int16_System_IConvertible_ToType_m2023455022_AdjustorThunk,
	Int16_System_IConvertible_ToUInt16_m4185862917_AdjustorThunk,
	Int16_System_IConvertible_ToUInt32_m55848512_AdjustorThunk,
	Int16_System_IConvertible_ToUInt64_m1715011417_AdjustorThunk,
	Int16_CompareTo_m4024223808_AdjustorThunk,
	Int16_Equals_m3822415117_AdjustorThunk,
	Int16_GetHashCode_m1828654929_AdjustorThunk,
	Int16_CompareTo_m141684664_AdjustorThunk,
	Int16_Equals_m1153284509_AdjustorThunk,
	Int16_Parse_m2627575781,
	Int16_Parse_m2026714680,
	Int16_Parse_m775125160,
	Int16_TryParse_m321727795,
	Int16_ToString_m1232102406_AdjustorThunk,
	Int16_ToString_m1509215832_AdjustorThunk,
	Int16_ToString_m3409160761_AdjustorThunk,
	Int16_ToString_m1443892894_AdjustorThunk,
	Int32_System_IConvertible_ToBoolean_m3258957888_AdjustorThunk,
	Int32_System_IConvertible_ToByte_m2070645424_AdjustorThunk,
	Int32_System_IConvertible_ToChar_m3088783839_AdjustorThunk,
	Int32_System_IConvertible_ToDateTime_m2219281517_AdjustorThunk,
	Int32_System_IConvertible_ToDecimal_m3396258874_AdjustorThunk,
	Int32_System_IConvertible_ToDouble_m3772203874_AdjustorThunk,
	Int32_System_IConvertible_ToInt16_m1067875339_AdjustorThunk,
	Int32_System_IConvertible_ToInt32_m618586708_AdjustorThunk,
	Int32_System_IConvertible_ToInt64_m847339591_AdjustorThunk,
	Int32_System_IConvertible_ToSByte_m2152861902_AdjustorThunk,
	Int32_System_IConvertible_ToSingle_m1947062248_AdjustorThunk,
	Int32_System_IConvertible_ToType_m1509005928_AdjustorThunk,
	Int32_System_IConvertible_ToUInt16_m3662245354_AdjustorThunk,
	Int32_System_IConvertible_ToUInt32_m1952288927_AdjustorThunk,
	Int32_System_IConvertible_ToUInt64_m1534412572_AdjustorThunk,
	Int32_CompareTo_m2108777184_AdjustorThunk,
	Int32_Equals_m1472643624_AdjustorThunk,
	Int32_GetHashCode_m2878632975_AdjustorThunk,
	Int32_CompareTo_m3032984351_AdjustorThunk,
	Int32_Equals_m1171805382_AdjustorThunk,
	Int32_ProcessTrailingWhitespace_m3281536092,
	Int32_Parse_m2255291836,
	Int32_Parse_m2436415266,
	Int32_CheckStyle_m4200511423,
	Int32_JumpOverWhite_m3402590262,
	Int32_FindSign_m2017552105,
	Int32_FindCurrency_m57662827,
	Int32_FindExponent_m3328029059,
	Int32_FindOther_m965379402,
	Int32_ValidDigit_m1336563760,
	Int32_GetFormatException_m3862582761,
	Int32_Parse_m4189501286,
	Int32_Parse_m4103558534,
	Int32_Parse_m306671424,
	Int32_TryParse_m277953443,
	Int32_TryParse_m481432822,
	Int32_ToString_m4174161400_AdjustorThunk,
	Int32_ToString_m1361605161_AdjustorThunk,
	Int32_ToString_m3663029280_AdjustorThunk,
	Int32_ToString_m3533529712_AdjustorThunk,
	Int64_System_IConvertible_ToBoolean_m2295333455_AdjustorThunk,
	Int64_System_IConvertible_ToByte_m1392815635_AdjustorThunk,
	Int64_System_IConvertible_ToChar_m3228587634_AdjustorThunk,
	Int64_System_IConvertible_ToDateTime_m943848141_AdjustorThunk,
	Int64_System_IConvertible_ToDecimal_m2204058327_AdjustorThunk,
	Int64_System_IConvertible_ToDouble_m2475420994_AdjustorThunk,
	Int64_System_IConvertible_ToInt16_m3964579642_AdjustorThunk,
	Int64_System_IConvertible_ToInt32_m388817291_AdjustorThunk,
	Int64_System_IConvertible_ToInt64_m2195678983_AdjustorThunk,
	Int64_System_IConvertible_ToSByte_m96230497_AdjustorThunk,
	Int64_System_IConvertible_ToSingle_m2198186823_AdjustorThunk,
	Int64_System_IConvertible_ToType_m38176658_AdjustorThunk,
	Int64_System_IConvertible_ToUInt16_m2877320216_AdjustorThunk,
	Int64_System_IConvertible_ToUInt32_m3679147888_AdjustorThunk,
	Int64_System_IConvertible_ToUInt64_m1765812422_AdjustorThunk,
	Int64_CompareTo_m3258845120_AdjustorThunk,
	Int64_Equals_m1972435155_AdjustorThunk,
	Int64_GetHashCode_m647083287_AdjustorThunk,
	Int64_CompareTo_m1266407916_AdjustorThunk,
	Int64_Equals_m2668032080_AdjustorThunk,
	Int64_Parse_m1780576393,
	Int64_Parse_m1940098924,
	Int64_Parse_m825191817,
	Int64_Parse_m3225783458,
	Int64_Parse_m1796909491,
	Int64_TryParse_m2364289788,
	Int64_TryParse_m4162357809,
	Int64_ToString_m4270274408_AdjustorThunk,
	Int64_ToString_m2602785239_AdjustorThunk,
	Int64_ToString_m2243382644_AdjustorThunk,
	Int64_ToString_m1262429736_AdjustorThunk,
	IntPtr__ctor_m2251341938_AdjustorThunk,
	IntPtr__ctor_m2356916849_AdjustorThunk,
	IntPtr__ctor_m3657584931_AdjustorThunk,
	IntPtr__ctor_m516753180_AdjustorThunk,
	IntPtr_System_Runtime_Serialization_ISerializable_GetObjectData_m3532600940_AdjustorThunk,
	IntPtr_get_Size_m2786508229,
	IntPtr_Equals_m256578012_AdjustorThunk,
	IntPtr_GetHashCode_m3456713861_AdjustorThunk,
	IntPtr_ToInt64_m1557689473_AdjustorThunk,
	IntPtr_ToPointer_m237804402_AdjustorThunk,
	IntPtr_ToString_m2234603100_AdjustorThunk,
	IntPtr_ToString_m3428022440_AdjustorThunk,
	IntPtr_op_Equality_m2182604147,
	IntPtr_op_Inequality_m3520486347,
	IntPtr_op_Explicit_m509961701,
	IntPtr_op_Explicit_m267845794,
	IntPtr_op_Explicit_m1997376062,
	IntPtr_op_Explicit_m2084967252,
	IntPtr_op_Explicit_m2617312562,
	InvalidCastException__ctor_m1844616025,
	InvalidCastException__ctor_m434084184,
	InvalidCastException__ctor_m2429454138,
	InvalidOperationException__ctor_m1407392843,
	InvalidOperationException__ctor_m1898731946,
	InvalidOperationException__ctor_m2949829146,
	InvalidOperationException__ctor_m1650147031,
	BinaryReader__ctor_m127904526,
	BinaryReader__ctor_m508621868,
	BinaryReader_System_IDisposable_Dispose_m4193894860,
	BinaryReader_get_BaseStream_m779836333,
	BinaryReader_Close_m3328725372,
	BinaryReader_Dispose_m1538121967,
	BinaryReader_FillBuffer_m2330151936,
	BinaryReader_Read_m1785560935,
	BinaryReader_Read_m935245691,
	BinaryReader_Read_m2004985024,
	BinaryReader_ReadCharBytes_m1517619070,
	BinaryReader_Read7BitEncodedInt_m1499153484,
	BinaryReader_ReadBoolean_m1042722974,
	BinaryReader_ReadByte_m1646621174,
	BinaryReader_ReadBytes_m3764775317,
	BinaryReader_ReadChar_m3621400607,
	BinaryReader_ReadDecimal_m1204388083,
	BinaryReader_ReadDouble_m534280174,
	BinaryReader_ReadInt16_m2698845981,
	BinaryReader_ReadInt32_m1355074789,
	BinaryReader_ReadInt64_m2454328709,
	BinaryReader_ReadSByte_m3974961331,
	BinaryReader_ReadString_m3512432278,
	BinaryReader_ReadSingle_m2289939537,
	BinaryReader_ReadUInt16_m1631681507,
	BinaryReader_ReadUInt32_m3322182293,
	BinaryReader_ReadUInt64_m723726215,
	BinaryReader_CheckBuffer_m3790516384,
	Directory_CreateDirectory_m3622336168,
	Directory_CreateDirectoriesInternal_m3499929365,
	Directory_Exists_m286263487,
	Directory_GetCurrentDirectory_m480039028,
	Directory_GetFiles_m1041759854,
	Directory_GetFileSystemEntries_m255688542,
	DirectoryInfo__ctor_m890681190,
	DirectoryInfo__ctor_m2258013287,
	DirectoryInfo__ctor_m838735434,
	DirectoryInfo_Initialize_m2498797325,
	DirectoryInfo_get_Exists_m629159675,
	DirectoryInfo_get_Parent_m2557650280,
	DirectoryInfo_Create_m2034435267,
	DirectoryInfo_ToString_m3006265559,
	DirectoryNotFoundException__ctor_m2619724215,
	DirectoryNotFoundException__ctor_m2363294465,
	DirectoryNotFoundException__ctor_m2354623603,
	EndOfStreamException__ctor_m2065854546,
	EndOfStreamException__ctor_m2887185695,
	File_Delete_m2544592848,
	File_Exists_m3793058406,
	File_Open_m3068617715,
	File_OpenRead_m1308289889,
	File_OpenText_m2736292869,
	FileLoadException__ctor_m923884332,
	FileLoadException__ctor_m1090799071,
	FileLoadException_get_Message_m944617484,
	FileLoadException_GetObjectData_m2307742994,
	FileLoadException_ToString_m34549924,
	FileNotFoundException__ctor_m3208471487,
	FileNotFoundException__ctor_m3553372217,
	FileNotFoundException__ctor_m983032520,
	FileNotFoundException_get_Message_m3978484121,
	FileNotFoundException_GetObjectData_m2478998761,
	FileNotFoundException_ToString_m3182305104,
	FileStream__ctor_m3046344057,
	FileStream__ctor_m2734166934,
	FileStream__ctor_m1140102067,
	FileStream__ctor_m2709936877,
	FileStream__ctor_m2116713316,
	FileStream_get_CanRead_m666643764,
	FileStream_get_CanWrite_m186121616,
	FileStream_get_CanSeek_m2311366262,
	FileStream_get_Length_m1713916082,
	FileStream_get_Position_m3714403878,
	FileStream_set_Position_m1694103145,
	FileStream_ReadByte_m3615959641,
	FileStream_WriteByte_m2506315408,
	FileStream_Read_m2860719275,
	FileStream_ReadInternal_m2997987951,
	FileStream_BeginRead_m2954422331,
	FileStream_EndRead_m1205138216,
	FileStream_Write_m2223228153,
	FileStream_WriteInternal_m3820674018,
	FileStream_BeginWrite_m2423455615,
	FileStream_EndWrite_m221857023,
	FileStream_Seek_m997384136,
	FileStream_SetLength_m39513663,
	FileStream_Flush_m1921908460,
	FileStream_Finalize_m881020330,
	FileStream_Dispose_m1737393572,
	FileStream_ReadSegment_m495286510,
	FileStream_WriteSegment_m4215388663,
	FileStream_FlushBuffer_m3842147122,
	FileStream_FlushBuffer_m3511979903,
	FileStream_FlushBufferIfDirty_m289846570,
	FileStream_RefillBuffer_m2458517104,
	FileStream_ReadData_m2038918228,
	FileStream_InitBuffer_m3035975423,
	FileStream_GetSecureFileName_m3450104283,
	FileStream_GetSecureFileName_m2178803856,
	ReadDelegate__ctor_m2896200933,
	ReadDelegate_Invoke_m1435222661,
	ReadDelegate_BeginInvoke_m3682657179,
	ReadDelegate_EndInvoke_m3922614789,
	WriteDelegate__ctor_m2217994847,
	WriteDelegate_Invoke_m2081157572,
	WriteDelegate_BeginInvoke_m2549882639,
	WriteDelegate_EndInvoke_m1743509461,
	FileStreamAsyncResult__ctor_m4018330226,
	FileStreamAsyncResult_CBWrapper_m1314311834,
	FileStreamAsyncResult_get_AsyncState_m501126754,
	FileStreamAsyncResult_get_AsyncWaitHandle_m2498636443,
	FileStreamAsyncResult_get_IsCompleted_m1169080242,
	FileSystemInfo__ctor_m1107743831,
	FileSystemInfo__ctor_m3949366445,
	FileSystemInfo_GetObjectData_m2634626544,
	FileSystemInfo_get_FullName_m981435160,
	FileSystemInfo_Refresh_m1493407733,
	FileSystemInfo_InternalRefresh_m522189018,
	FileSystemInfo_CheckPath_m3615706202,
	IOException__ctor_m254247112,
	IOException__ctor_m1331548362,
	IOException__ctor_m60105582,
	IOException__ctor_m2917865815,
	IOException__ctor_m2914775989,
	IsolatedStorageException__ctor_m2399319154,
	IsolatedStorageException__ctor_m2355975989,
	IsolatedStorageException__ctor_m2595576856,
	MemoryStream__ctor_m1153506571,
	MemoryStream__ctor_m2245000628,
	MemoryStream__ctor_m377488078,
	MemoryStream_InternalConstructor_m764544276,
	MemoryStream_CheckIfClosedThrowDisposed_m2360140578,
	MemoryStream_get_CanRead_m3835421718,
	MemoryStream_get_CanSeek_m1628625286,
	MemoryStream_get_CanWrite_m1686271500,
	MemoryStream_set_Capacity_m1883230090,
	MemoryStream_get_Length_m437856634,
	MemoryStream_get_Position_m3120176485,
	MemoryStream_set_Position_m339672209,
	MemoryStream_Dispose_m4136771425,
	MemoryStream_Flush_m44869571,
	MemoryStream_Read_m1003576465,
	MemoryStream_ReadByte_m3310399510,
	MemoryStream_Seek_m4210270740,
	MemoryStream_CalculateNewCapacity_m1885293639,
	MemoryStream_Expand_m1736095174,
	MemoryStream_SetLength_m1317118839,
	MemoryStream_ToArray_m33743234,
	MemoryStream_Write_m1872118689,
	MemoryStream_WriteByte_m487133489,
	MonoIO__cctor_m2274322288,
	MonoIO_GetException_m325073311,
	MonoIO_GetException_m3873616703,
	MonoIO_CreateDirectory_m690223787,
	MonoIO_GetFileSystemEntries_m4228557655,
	MonoIO_GetCurrentDirectory_m2440528746,
	MonoIO_DeleteFile_m1747178908,
	MonoIO_GetFileAttributes_m1330330292,
	MonoIO_GetFileType_m3548209312,
	MonoIO_ExistsFile_m4083328030,
	MonoIO_ExistsDirectory_m460199877,
	MonoIO_GetFileStat_m1421349297,
	MonoIO_Open_m2707446436,
	MonoIO_Close_m4094611200,
	MonoIO_Read_m717585534,
	MonoIO_Write_m1714668158,
	MonoIO_Seek_m1453563591,
	MonoIO_GetLength_m2748600653,
	MonoIO_SetLength_m1395012412,
	MonoIO_get_ConsoleOutput_m381562867,
	MonoIO_get_ConsoleInput_m2790956149,
	MonoIO_get_ConsoleError_m458167241,
	MonoIO_get_VolumeSeparatorChar_m3290860617,
	MonoIO_get_DirectorySeparatorChar_m460683398,
	MonoIO_get_AltDirectorySeparatorChar_m2410372317,
	MonoIO_get_PathSeparator_m1187498872,
	MonoIO_RemapPath_m4108562258,
	NullStream__ctor_m333121183,
	NullStream_get_CanRead_m2203648577,
	NullStream_get_CanSeek_m1963679271,
	NullStream_get_CanWrite_m1009926118,
	NullStream_get_Length_m2279762536,
	NullStream_get_Position_m1949705829,
	NullStream_set_Position_m212895867,
	NullStream_Flush_m3434052532,
	NullStream_Read_m3022202162,
	NullStream_ReadByte_m2679416287,
	NullStream_Seek_m2325342734,
	NullStream_SetLength_m4241737735,
	NullStream_Write_m2734052681,
	NullStream_WriteByte_m180574711,
	Path__cctor_m1182673417,
	Path_Combine_m3715734842,
	Path_CleanPath_m587000654,
	Path_GetDirectoryName_m1793648012,
	Path_GetFileName_m2078448260,
	Path_GetFullPath_m2850694796,
	Path_WindowsDriveAdjustment_m1323197026,
	Path_InsecureGetFullPath_m2142429469,
	Path_IsDsc_m4006149363,
	Path_GetPathRoot_m2257742348,
	Path_IsPathRooted_m706315654,
	Path_GetInvalidPathChars_m3949158031,
	Path_GetServerAndShare_m3189850192,
	Path_SameRoot_m2719937575,
	Path_CanonicalizePath_m2252383871,
	PathTooLongException__ctor_m2875851057,
	PathTooLongException__ctor_m199774354,
	PathTooLongException__ctor_m1802317265,
	SearchPattern__cctor_m1731488231,
	Stream__ctor_m2595165611,
	Stream__cctor_m2352701457,
	Stream_Dispose_m58345995,
	Stream_Dispose_m1235184734,
	Stream_Close_m1145425113,
	Stream_ReadByte_m3089211635,
	Stream_WriteByte_m2358830811,
	Stream_BeginRead_m2801101087,
	Stream_BeginWrite_m576023021,
	Stream_EndRead_m3875765555,
	Stream_EndWrite_m2170505350,
	StreamAsyncResult__ctor_m61719578,
	StreamAsyncResult_SetComplete_m2436775525,
	StreamAsyncResult_SetComplete_m4072396035,
	StreamAsyncResult_get_AsyncState_m805763934,
	StreamAsyncResult_get_AsyncWaitHandle_m859050593,
	StreamAsyncResult_get_IsCompleted_m2647936814,
	StreamAsyncResult_get_Exception_m1408707861,
	StreamAsyncResult_get_NBytes_m1503908349,
	StreamAsyncResult_get_Done_m273449559,
	StreamAsyncResult_set_Done_m3728050232,
	StreamReader__ctor_m3800634455,
	StreamReader__ctor_m1497427721,
	StreamReader__ctor_m564890970,
	StreamReader__ctor_m1971096640,
	StreamReader__ctor_m2046924606,
	StreamReader__cctor_m2686676160,
	StreamReader_Initialize_m1648093038,
	StreamReader_Dispose_m1135259915,
	StreamReader_DoChecks_m3130795215,
	StreamReader_ReadBuffer_m822987110,
	StreamReader_Peek_m1418454313,
	StreamReader_Read_m2817380199,
	StreamReader_Read_m354217778,
	StreamReader_FindNextEOL_m75521239,
	StreamReader_ReadLine_m301472656,
	StreamReader_ReadToEnd_m2357875299,
	NullStreamReader__ctor_m606238235,
	NullStreamReader_Peek_m1178216914,
	NullStreamReader_Read_m2266751787,
	NullStreamReader_Read_m1008032484,
	NullStreamReader_ReadLine_m527468385,
	NullStreamReader_ReadToEnd_m302770095,
	StreamWriter__ctor_m124665850,
	StreamWriter__ctor_m4259096562,
	StreamWriter__cctor_m2068848624,
	StreamWriter_Initialize_m3517952154,
	StreamWriter_set_AutoFlush_m2218912199,
	StreamWriter_Dispose_m364251551,
	StreamWriter_Flush_m3873327639,
	StreamWriter_FlushBytes_m4187352853,
	StreamWriter_Decode_m2435057951,
	StreamWriter_Write_m3354196155,
	StreamWriter_LowLevelWrite_m144202440,
	StreamWriter_LowLevelWrite_m3922460505,
	StreamWriter_Write_m3344855415,
	StreamWriter_Write_m2722904093,
	StreamWriter_Write_m2124480708,
	StreamWriter_Close_m3216061938,
	StreamWriter_Finalize_m4238823298,
	StringReader__ctor_m2120792881,
	StringReader_Dispose_m2676840628,
	StringReader_Peek_m3887889536,
	StringReader_Read_m1410818423,
	StringReader_Read_m1914673056,
	StringReader_ReadLine_m3959855225,
	StringReader_ReadToEnd_m3512472260,
	StringReader_CheckObjectDisposedException_m1770092018,
	SynchronizedReader__ctor_m1030671232,
	SynchronizedReader_Peek_m619731398,
	SynchronizedReader_ReadLine_m2317712253,
	SynchronizedReader_ReadToEnd_m3687710920,
	SynchronizedReader_Read_m3695306612,
	SynchronizedReader_Read_m3004765982,
	SynchronizedWriter__ctor_m656543725,
	SynchronizedWriter_Close_m2714436712,
	SynchronizedWriter_Flush_m2386487644,
	SynchronizedWriter_Write_m653603145,
	SynchronizedWriter_Write_m2490425531,
	SynchronizedWriter_Write_m1955696259,
	SynchronizedWriter_Write_m4177981633,
	SynchronizedWriter_WriteLine_m3539201113,
	SynchronizedWriter_WriteLine_m1392051891,
	TextReader__ctor_m599549953,
	TextReader__cctor_m1262050920,
	TextReader_Dispose_m66265068,
	TextReader_Dispose_m2869876759,
	TextReader_Peek_m207028174,
	TextReader_Read_m2964955915,
	TextReader_Read_m2769771062,
	TextReader_ReadLine_m1029983807,
	TextReader_ReadToEnd_m3688262859,
	TextReader_Synchronized_m2590778601,
	NullTextReader__ctor_m2827947410,
	NullTextReader_ReadLine_m3401445917,
	TextWriter__ctor_m3198288955,
	TextWriter__cctor_m1164139462,
	TextWriter_Close_m2431604359,
	TextWriter_Dispose_m2158707338,
	TextWriter_Dispose_m1649717177,
	TextWriter_Flush_m3553256967,
	TextWriter_Synchronized_m3396118739,
	TextWriter_Write_m2765732211,
	TextWriter_Write_m3990727909,
	TextWriter_Write_m390537503,
	TextWriter_Write_m1017611963,
	TextWriter_WriteLine_m3233856660,
	TextWriter_WriteLine_m1279192657,
	NullTextWriter__ctor_m1141280443,
	NullTextWriter_Write_m2013765556,
	NullTextWriter_Write_m3721300509,
	NullTextWriter_Write_m2890047477,
	UnexceptionalStreamReader__ctor_m2400344532,
	UnexceptionalStreamReader__cctor_m939786749,
	UnexceptionalStreamReader_Peek_m3198482924,
	UnexceptionalStreamReader_Read_m2061779030,
	UnexceptionalStreamReader_Read_m264409809,
	UnexceptionalStreamReader_CheckEOL_m408300536,
	UnexceptionalStreamReader_ReadLine_m3933581905,
	UnexceptionalStreamReader_ReadToEnd_m2904473082,
	UnexceptionalStreamWriter__ctor_m842043168,
	UnexceptionalStreamWriter_Flush_m1884199508,
	UnexceptionalStreamWriter_Write_m2199944806,
	UnexceptionalStreamWriter_Write_m3279663103,
	UnexceptionalStreamWriter_Write_m768806348,
	UnexceptionalStreamWriter_Write_m697134477,
	UnmanagedMemoryStream_get_CanRead_m1304620089,
	UnmanagedMemoryStream_get_CanSeek_m3540385675,
	UnmanagedMemoryStream_get_CanWrite_m2155137361,
	UnmanagedMemoryStream_get_Length_m4293573839,
	UnmanagedMemoryStream_get_Position_m1378643060,
	UnmanagedMemoryStream_set_Position_m143695479,
	UnmanagedMemoryStream_Read_m2842003147,
	UnmanagedMemoryStream_ReadByte_m3683539487,
	UnmanagedMemoryStream_Seek_m737032287,
	UnmanagedMemoryStream_SetLength_m1082836360,
	UnmanagedMemoryStream_Flush_m2972825353,
	UnmanagedMemoryStream_Dispose_m1287975383,
	UnmanagedMemoryStream_Write_m1342820066,
	UnmanagedMemoryStream_WriteByte_m3664716057,
	LocalDataStoreSlot__ctor_m3601079004,
	LocalDataStoreSlot__cctor_m3219163729,
	LocalDataStoreSlot_Finalize_m2106500550,
	MarshalByRefObject__ctor_m2656117921,
	MarshalByRefObject_get_ObjectIdentity_m3157415857,
	Math_Abs_m4155529320,
	Math_Abs_m3490815430,
	Math_Abs_m2050689009,
	Math_Floor_m2868312863,
	Math_Max_m1737240539,
	Math_Min_m2898138409,
	Math_Round_m2043849412,
	Math_Round_m941190684,
	Math_Pow_m902859463,
	Math_Sqrt_m2669192963,
	MemberAccessException__ctor_m1707653143,
	MemberAccessException__ctor_m2393542836,
	MemberAccessException__ctor_m2104154496,
	MethodAccessException__ctor_m541442477,
	MethodAccessException__ctor_m387096366,
	MissingFieldException__ctor_m1894240175,
	MissingFieldException__ctor_m1065923864,
	MissingFieldException__ctor_m1196397121,
	MissingFieldException_get_Message_m3790336791,
	MissingMemberException__ctor_m887262038,
	MissingMemberException__ctor_m1872643809,
	MissingMemberException__ctor_m3294640669,
	MissingMemberException__ctor_m901947305,
	MissingMemberException_GetObjectData_m3181088585,
	MissingMemberException_get_Message_m3201407794,
	MissingMethodException__ctor_m3700049892,
	MissingMethodException__ctor_m1666152282,
	MissingMethodException__ctor_m2795898928,
	MissingMethodException__ctor_m3288422073,
	MissingMethodException_get_Message_m2284016000,
	MonoAsyncCall__ctor_m68498696,
	MonoCustomAttrs__cctor_m4209563544,
	MonoCustomAttrs_IsUserCattrProvider_m3612979105,
	MonoCustomAttrs_GetCustomAttributesInternal_m3841876774,
	MonoCustomAttrs_GetPseudoCustomAttributes_m2838295616,
	MonoCustomAttrs_GetCustomAttributesBase_m3227454488,
	MonoCustomAttrs_GetCustomAttribute_m4179188478,
	MonoCustomAttrs_GetCustomAttributes_m1371831434,
	MonoCustomAttrs_GetCustomAttributes_m2800682580,
	MonoCustomAttrs_GetCustomAttributesDataInternal_m2766077647,
	MonoCustomAttrs_GetCustomAttributesData_m385677270,
	MonoCustomAttrs_IsDefined_m3898681234,
	MonoCustomAttrs_IsDefinedInternal_m4148818414,
	MonoCustomAttrs_GetBasePropertyDefinition_m2982228497,
	MonoCustomAttrs_GetBase_m3517810493,
	MonoCustomAttrs_RetrieveAttributeUsage_m2311843294,
	AttributeInfo__ctor_m1285857649,
	AttributeInfo_get_Usage_m3451927341,
	AttributeInfo_get_InheritanceLevel_m2838015478,
	MonoDocumentationNoteAttribute__ctor_m379452513,
	MonoEnumInfo__ctor_m3759939735_AdjustorThunk,
	MonoEnumInfo__cctor_m905335985,
	MonoEnumInfo_get_enum_info_m3635941699,
	MonoEnumInfo_get_Cache_m1936268453,
	MonoEnumInfo_GetInfo_m780052133,
	IntComparer__ctor_m4172929216,
	IntComparer_Compare_m1795183550,
	IntComparer_Compare_m1337468578,
	LongComparer__ctor_m2498885971,
	LongComparer_Compare_m1369937197,
	LongComparer_Compare_m2375503760,
	SByteComparer__ctor_m3472120687,
	SByteComparer_Compare_m2015588729,
	SByteComparer_Compare_m3848149989,
	ShortComparer__ctor_m2177469571,
	ShortComparer_Compare_m3346626937,
	ShortComparer_Compare_m2949238292,
	MonoTODOAttribute__ctor_m2653149720,
	MonoTODOAttribute__ctor_m956981832,
	MonoTouchAOTHelper__cctor_m1042324298,
	MonoType_get_attributes_m2323874482,
	MonoType_GetDefaultConstructor_m594730275,
	MonoType_GetAttributeFlagsImpl_m131780615,
	MonoType_GetConstructorImpl_m1430011647,
	MonoType_GetConstructors_internal_m489164918,
	MonoType_GetConstructors_m3120839409,
	MonoType_InternalGetEvent_m645336830,
	MonoType_GetEvent_m531418575,
	MonoType_GetField_m243859047,
	MonoType_GetFields_internal_m4230754638,
	MonoType_GetFields_m3131050110,
	MonoType_GetInterfaces_m20969877,
	MonoType_GetMethodsByName_m503705917,
	MonoType_GetMethods_m2896668102,
	MonoType_GetMethodImpl_m2201018062,
	MonoType_GetPropertiesByName_m4032150621,
	MonoType_GetPropertyImpl_m534107472,
	MonoType_HasElementTypeImpl_m1249231950,
	MonoType_IsArrayImpl_m2325143669,
	MonoType_IsByRefImpl_m3718174569,
	MonoType_IsPointerImpl_m775147452,
	MonoType_IsPrimitiveImpl_m904878720,
	MonoType_IsSubclassOf_m2482488910,
	MonoType_InvokeMember_m821314901,
	MonoType_GetElementType_m1199886691,
	MonoType_get_UnderlyingSystemType_m4185992851,
	MonoType_get_Assembly_m3574224325,
	MonoType_get_AssemblyQualifiedName_m3302040083,
	MonoType_getFullName_m4097914536,
	MonoType_get_BaseType_m1099037884,
	MonoType_get_FullName_m301492687,
	MonoType_IsDefined_m4240219457,
	MonoType_GetCustomAttributes_m686864684,
	MonoType_GetCustomAttributes_m738241830,
	MonoType_get_MemberType_m1401244132,
	MonoType_get_Name_m2741664745,
	MonoType_get_Namespace_m1830594842,
	MonoType_get_Module_m2229062923,
	MonoType_get_DeclaringType_m1218811919,
	MonoType_get_ReflectedType_m1224953211,
	MonoType_get_TypeHandle_m2009845375,
	MonoType_GetObjectData_m3392713679,
	MonoType_ToString_m1302937548,
	MonoType_GetGenericArguments_m1363088236,
	MonoType_get_ContainsGenericParameters_m189307499,
	MonoType_get_IsGenericParameter_m4210877970,
	MonoType_GetGenericTypeDefinition_m2954034139,
	MonoType_CheckMethodSecurity_m804682546,
	MonoType_ReorderParamArrayArguments_m593941294,
	MonoTypeInfo__ctor_m854997146,
	MulticastDelegate_GetObjectData_m3131968880,
	MulticastDelegate_Equals_m2391386839,
	MulticastDelegate_GetHashCode_m2058342921,
	MulticastDelegate_GetInvocationList_m1852279961,
	MulticastDelegate_CombineImpl_m1072590429,
	MulticastDelegate_BaseEquals_m823385438,
	MulticastDelegate_KPM_m2742084548,
	MulticastDelegate_RemoveImpl_m4247123837,
	MulticastNotSupportedException__ctor_m2417755598,
	MulticastNotSupportedException__ctor_m2123402185,
	MulticastNotSupportedException__ctor_m3670332278,
	NonSerializedAttribute__ctor_m4871865,
	NotImplementedException__ctor_m477983135,
	NotImplementedException__ctor_m1986325158,
	NotImplementedException__ctor_m2077187522,
	NotSupportedException__ctor_m2114463680,
	NotSupportedException__ctor_m52747721,
	NotSupportedException__ctor_m553951563,
	NullReferenceException__ctor_m1701905725,
	NullReferenceException__ctor_m1593493702,
	NullReferenceException__ctor_m1027837455,
	NumberFormatter__ctor_m2141086463,
	NumberFormatter__cctor_m3557929081,
	NumberFormatter_GetFormatterTables_m1747175642,
	NumberFormatter_GetTenPowerOf_m3984735441,
	NumberFormatter_InitDecHexDigits_m3889389778,
	NumberFormatter_InitDecHexDigits_m2111430985,
	NumberFormatter_InitDecHexDigits_m311440294,
	NumberFormatter_FastToDecHex_m2768083532,
	NumberFormatter_ToDecHex_m3635356694,
	NumberFormatter_FastDecHexLen_m1915455962,
	NumberFormatter_DecHexLen_m2832070964,
	NumberFormatter_DecHexLen_m2991250998,
	NumberFormatter_ScaleOrder_m1600433103,
	NumberFormatter_InitialFloatingPrecision_m2143252711,
	NumberFormatter_ParsePrecision_m2195832396,
	NumberFormatter_Init_m2127310494,
	NumberFormatter_InitHex_m342996610,
	NumberFormatter_Init_m3034217123,
	NumberFormatter_Init_m3308044450,
	NumberFormatter_Init_m1573483274,
	NumberFormatter_Init_m1522536577,
	NumberFormatter_Init_m3133291034,
	NumberFormatter_Init_m3692836545,
	NumberFormatter_ResetCharBuf_m3836151110,
	NumberFormatter_Resize_m2682803153,
	NumberFormatter_Append_m2076015538,
	NumberFormatter_Append_m3734637667,
	NumberFormatter_Append_m2050012530,
	NumberFormatter_GetNumberFormatInstance_m4113520079,
	NumberFormatter_set_CurrentCulture_m457134014,
	NumberFormatter_get_IntegerDigits_m3979329271,
	NumberFormatter_get_DecimalDigits_m439285849,
	NumberFormatter_get_IsFloatingSource_m3207893958,
	NumberFormatter_get_IsZero_m3359311934,
	NumberFormatter_get_IsZeroInteger_m3301715141,
	NumberFormatter_RoundPos_m3370784681,
	NumberFormatter_RoundDecimal_m3479538926,
	NumberFormatter_RoundBits_m3941675070,
	NumberFormatter_RemoveTrailingZeros_m1918889960,
	NumberFormatter_AddOneToDecHex_m3078903462,
	NumberFormatter_AddOneToDecHex_m3256818506,
	NumberFormatter_CountTrailingZeros_m3038126719,
	NumberFormatter_CountTrailingZeros_m3723111709,
	NumberFormatter_GetInstance_m2996663744,
	NumberFormatter_Release_m3167542947,
	NumberFormatter_SetThreadCurrentCulture_m1560040450,
	NumberFormatter_NumberToString_m3602657613,
	NumberFormatter_NumberToString_m2827109763,
	NumberFormatter_NumberToString_m2035901810,
	NumberFormatter_NumberToString_m1571641651,
	NumberFormatter_NumberToString_m1284178353,
	NumberFormatter_NumberToString_m2823217568,
	NumberFormatter_NumberToString_m245735860,
	NumberFormatter_NumberToString_m2831724402,
	NumberFormatter_NumberToString_m3382855546,
	NumberFormatter_NumberToString_m4102438340,
	NumberFormatter_NumberToString_m1020354641,
	NumberFormatter_NumberToString_m1943835558,
	NumberFormatter_NumberToString_m3333956848,
	NumberFormatter_NumberToString_m3638641212,
	NumberFormatter_NumberToString_m2293810547,
	NumberFormatter_NumberToString_m203036247,
	NumberFormatter_NumberToString_m1540346080,
	NumberFormatter_FastIntegerToString_m1838326482,
	NumberFormatter_IntegerToString_m4107262335,
	NumberFormatter_NumberToString_m3666786693,
	NumberFormatter_FormatCurrency_m3243895876,
	NumberFormatter_FormatDecimal_m166154075,
	NumberFormatter_FormatHexadecimal_m2304102207,
	NumberFormatter_FormatFixedPoint_m220031850,
	NumberFormatter_FormatRoundtrip_m1272243764,
	NumberFormatter_FormatRoundtrip_m1316422312,
	NumberFormatter_FormatGeneral_m2796695385,
	NumberFormatter_FormatNumber_m4039511018,
	NumberFormatter_FormatPercent_m4266096735,
	NumberFormatter_FormatExponential_m2833791326,
	NumberFormatter_FormatExponential_m2034033465,
	NumberFormatter_FormatCustom_m3042909951,
	NumberFormatter_ZeroTrimEnd_m2783222906,
	NumberFormatter_IsZeroOnly_m2946960116,
	NumberFormatter_AppendNonNegativeNumber_m2686673915,
	NumberFormatter_AppendIntegerString_m2282719652,
	NumberFormatter_AppendIntegerString_m1425281297,
	NumberFormatter_AppendDecimalString_m1458383674,
	NumberFormatter_AppendDecimalString_m1348504882,
	NumberFormatter_AppendIntegerStringWithGroupSeparator_m1458322188,
	NumberFormatter_AppendExponent_m3408681762,
	NumberFormatter_AppendOneDigit_m3784616382,
	NumberFormatter_FastAppendDigits_m2343094226,
	NumberFormatter_AppendDigits_m2647593189,
	NumberFormatter_AppendDigits_m827927027,
	NumberFormatter_Multiply10_m4000997921,
	NumberFormatter_Divide10_m685560461,
	NumberFormatter_GetClone_m2058870544,
	CustomInfo__ctor_m3353878986,
	CustomInfo_GetActiveSection_m4277983857,
	CustomInfo_Parse_m3253903869,
	CustomInfo_Format_m1367832183,
	Object__ctor_m3570689169,
	Object_Equals_m1589733813,
	Object_Equals_m1653553012,
	Object_Finalize_m3819013302,
	Object_GetHashCode_m75012116,
	Object_GetType_m824619215,
	Object_MemberwiseClone_m1637840242,
	Object_ToString_m1243246388,
	Object_ReferenceEquals_m1745896791,
	Object_InternalGetHashCode_m3239484227,
	ObjectDisposedException__ctor_m2874627009,
	ObjectDisposedException__ctor_m2916448319,
	ObjectDisposedException__ctor_m2830566228,
	ObjectDisposedException_get_Message_m3020538918,
	ObjectDisposedException_GetObjectData_m173037097,
	ObsoleteAttribute__ctor_m2346818104,
	ObsoleteAttribute__ctor_m3649443664,
	ObsoleteAttribute__ctor_m74976096,
	OperatingSystem__ctor_m1938051607,
	OperatingSystem_get_Platform_m3327222881,
	OperatingSystem_Clone_m3011752554,
	OperatingSystem_GetObjectData_m2864715462,
	OperatingSystem_ToString_m1327952677,
	OrdinalComparer__ctor_m795122326,
	OrdinalComparer_Compare_m649554243,
	OrdinalComparer_Equals_m1349310104,
	OrdinalComparer_GetHashCode_m2290661839,
	OutOfMemoryException__ctor_m1205545298,
	OutOfMemoryException__ctor_m3178126794,
	OutOfMemoryException__ctor_m3628315802,
	OverflowException__ctor_m287420521,
	OverflowException__ctor_m3309379331,
	OverflowException__ctor_m3967190257,
	ParamArrayAttribute__ctor_m1476893411,
	PlatformNotSupportedException__ctor_m2011956139,
	PlatformNotSupportedException__ctor_m438435675,
	RankException__ctor_m3047453347,
	RankException__ctor_m357593887,
	RankException__ctor_m3181261104,
	AmbiguousMatchException__ctor_m1650682271,
	AmbiguousMatchException__ctor_m3363049417,
	AmbiguousMatchException__ctor_m3268112286,
	Assembly__ctor_m1129759937,
	Assembly_get_code_base_m127033788,
	Assembly_get_fullname_m4270733977,
	Assembly_get_location_m3770795522,
	Assembly_GetCodeBase_m6707203,
	Assembly_get_FullName_m3956258934,
	Assembly_get_Location_m2676569818,
	Assembly_IsDefined_m3344635396,
	Assembly_GetCustomAttributes_m2556799392,
	Assembly_GetManifestResourceInternal_m664493768,
	Assembly_GetTypes_m1716081216,
	Assembly_GetTypes_m2231873833,
	Assembly_GetType_m2914302819,
	Assembly_GetType_m2170979294,
	Assembly_InternalGetType_m1071048114,
	Assembly_GetType_m3488314699,
	Assembly_FillName_m778112029,
	Assembly_GetName_m2496216313,
	Assembly_GetName_m1496227622,
	Assembly_UnprotectedGetName_m389720229,
	Assembly_ToString_m3415840225,
	Assembly_Load_m3107598193,
	Assembly_GetModule_m1920455931,
	Assembly_GetModulesInternal_m3041328967,
	Assembly_GetModules_m2887076454,
	Assembly_GetExecutingAssembly_m582814672,
	ResolveEventHolder__ctor_m607253803,
	AssemblyCompanyAttribute__ctor_m1961203133,
	AssemblyCopyrightAttribute__ctor_m2442777966,
	AssemblyDefaultAliasAttribute__ctor_m1008481974,
	AssemblyDelaySignAttribute__ctor_m792735968,
	AssemblyDescriptionAttribute__ctor_m863331373,
	AssemblyFileVersionAttribute__ctor_m104636996,
	AssemblyInformationalVersionAttribute__ctor_m2606705742,
	AssemblyKeyFileAttribute__ctor_m515360797,
	AssemblyName__ctor_m1606482411,
	AssemblyName__ctor_m2165385509,
	AssemblyName_get_Name_m1622178965,
	AssemblyName_get_Flags_m743173569,
	AssemblyName_get_FullName_m1324125095,
	AssemblyName_get_Version_m1348671957,
	AssemblyName_set_Version_m1402967326,
	AssemblyName_ToString_m2129407468,
	AssemblyName_get_IsPublicKeyValid_m3478360955,
	AssemblyName_InternalGetPublicKeyToken_m4256419726,
	AssemblyName_ComputePublicKeyToken_m2212213111,
	AssemblyName_SetPublicKey_m3853417853,
	AssemblyName_SetPublicKeyToken_m3125749103,
	AssemblyName_GetObjectData_m4048799064,
	AssemblyName_Clone_m67236874,
	AssemblyName_OnDeserialization_m1855099319,
	AssemblyProductAttribute__ctor_m2179734435,
	AssemblyTitleAttribute__ctor_m2280157225,
	Binder__ctor_m2914744643,
	Binder__cctor_m3419827066,
	Binder_get_DefaultBinder_m93799448,
	Binder_ConvertArgs_m3209251020,
	Binder_GetDerivedLevel_m3080703552,
	Binder_FindMostDerivedMatch_m321679317,
	Default__ctor_m2884560628,
	Default_BindToMethod_m1424112417,
	Default_ReorderParameters_m932957755,
	Default_IsArrayAssignable_m690722658,
	Default_ChangeType_m607399848,
	Default_ReorderArgumentArray_m1230275780,
	Default_check_type_m1599279309,
	Default_check_arguments_m2241121707,
	Default_SelectMethod_m2203110393,
	Default_SelectMethod_m2065722860,
	Default_GetBetterMethod_m2039851047,
	Default_CompareCloserType_m303877795,
	Default_SelectProperty_m4180238434,
	Default_check_arguments_with_score_m2268626604,
	Default_check_type_with_score_m2837505628,
	ConstructorInfo__ctor_m33952912,
	ConstructorInfo__cctor_m2349776223,
	ConstructorInfo_get_MemberType_m452596585,
	ConstructorInfo_Invoke_m2121930581,
	CustomAttributeData__ctor_m4204343487,
	CustomAttributeData_get_Constructor_m1392415606,
	CustomAttributeData_get_ConstructorArguments_m3516412943,
	CustomAttributeData_get_NamedArguments_m3735702561,
	CustomAttributeData_GetCustomAttributes_m2925805381,
	CustomAttributeData_GetCustomAttributes_m2504614822,
	CustomAttributeData_GetCustomAttributes_m1321853079,
	CustomAttributeData_GetCustomAttributes_m436637582,
	CustomAttributeData_ToString_m890844682,
	CustomAttributeData_Equals_m3367973531,
	CustomAttributeData_GetHashCode_m2200382294,
	CustomAttributeNamedArgument_ToString_m1730663428_AdjustorThunk,
	CustomAttributeNamedArgument_Equals_m2667330995_AdjustorThunk,
	CustomAttributeNamedArgument_GetHashCode_m451651329_AdjustorThunk,
	CustomAttributeTypedArgument_ToString_m4251600315_AdjustorThunk,
	CustomAttributeTypedArgument_Equals_m3427675425_AdjustorThunk,
	CustomAttributeTypedArgument_GetHashCode_m3252838495_AdjustorThunk,
	DefaultMemberAttribute__ctor_m1668906589,
	DefaultMemberAttribute_get_MemberName_m1805847907,
	AssemblyBuilder_get_Location_m731197943,
	AssemblyBuilder_GetModulesInternal_m2140896078,
	AssemblyBuilder_GetTypes_m485354545,
	AssemblyBuilder_get_IsCompilerContext_m4268419819,
	AssemblyBuilder_not_supported_m1259221233,
	AssemblyBuilder_UnprotectedGetName_m1954650636,
	ConstructorBuilder__ctor_m1109760205,
	ConstructorBuilder_get_CallingConvention_m1485716714,
	ConstructorBuilder_get_TypeBuilder_m348576299,
	ConstructorBuilder_GetParameters_m2580118339,
	ConstructorBuilder_GetParametersInternal_m3427358513,
	ConstructorBuilder_GetParameterCount_m2491355488,
	ConstructorBuilder_Invoke_m4267349784,
	ConstructorBuilder_Invoke_m2950671586,
	ConstructorBuilder_get_MethodHandle_m3481765851,
	ConstructorBuilder_get_Attributes_m2180218649,
	ConstructorBuilder_get_ReflectedType_m83279888,
	ConstructorBuilder_get_DeclaringType_m913596390,
	ConstructorBuilder_get_Name_m2197591737,
	ConstructorBuilder_IsDefined_m1820164848,
	ConstructorBuilder_GetCustomAttributes_m3924080049,
	ConstructorBuilder_GetCustomAttributes_m368928065,
	ConstructorBuilder_GetILGenerator_m4076496357,
	ConstructorBuilder_GetILGenerator_m4273795898,
	ConstructorBuilder_GetToken_m1485580701,
	ConstructorBuilder_get_Module_m3395962136,
	ConstructorBuilder_ToString_m3882603010,
	ConstructorBuilder_fixup_m3681136798,
	ConstructorBuilder_get_next_table_index_m2412271123,
	ConstructorBuilder_get_IsCompilerContext_m1823032054,
	ConstructorBuilder_not_supported_m3113087006,
	ConstructorBuilder_not_created_m2593555328,
	EnumBuilder_get_Assembly_m355013314,
	EnumBuilder_get_AssemblyQualifiedName_m2677384494,
	EnumBuilder_get_BaseType_m1724791672,
	EnumBuilder_get_DeclaringType_m3414694952,
	EnumBuilder_get_FullName_m289521373,
	EnumBuilder_get_Module_m430470637,
	EnumBuilder_get_Name_m701559818,
	EnumBuilder_get_Namespace_m2974690056,
	EnumBuilder_get_ReflectedType_m3363631725,
	EnumBuilder_get_TypeHandle_m317711653,
	EnumBuilder_get_UnderlyingSystemType_m119970781,
	EnumBuilder_GetAttributeFlagsImpl_m606822698,
	EnumBuilder_GetConstructorImpl_m3945935172,
	EnumBuilder_GetConstructors_m4236007330,
	EnumBuilder_GetCustomAttributes_m1145053795,
	EnumBuilder_GetCustomAttributes_m2952891353,
	EnumBuilder_GetElementType_m375234762,
	EnumBuilder_GetEvent_m494472581,
	EnumBuilder_GetField_m1193459080,
	EnumBuilder_GetFields_m3875416208,
	EnumBuilder_GetInterfaces_m2323579277,
	EnumBuilder_GetMethodImpl_m84945609,
	EnumBuilder_GetMethods_m2124000878,
	EnumBuilder_GetPropertyImpl_m3879058494,
	EnumBuilder_HasElementTypeImpl_m4135987772,
	EnumBuilder_InvokeMember_m40776934,
	EnumBuilder_IsArrayImpl_m2829518040,
	EnumBuilder_IsByRefImpl_m2277826720,
	EnumBuilder_IsPointerImpl_m1997301688,
	EnumBuilder_IsPrimitiveImpl_m1814564375,
	EnumBuilder_IsValueTypeImpl_m3129477556,
	EnumBuilder_IsDefined_m3982557818,
	EnumBuilder_CreateNotSupportedException_m1570169503,
	FieldBuilder_get_Attributes_m2171613738,
	FieldBuilder_get_DeclaringType_m2499047695,
	FieldBuilder_get_FieldHandle_m2001735098,
	FieldBuilder_get_FieldType_m462820209,
	FieldBuilder_get_Name_m281129090,
	FieldBuilder_get_ReflectedType_m4186495894,
	FieldBuilder_GetCustomAttributes_m4061980295,
	FieldBuilder_GetCustomAttributes_m570688289,
	FieldBuilder_GetValue_m3811999812,
	FieldBuilder_IsDefined_m179997776,
	FieldBuilder_GetFieldOffset_m4153895622,
	FieldBuilder_SetValue_m3449164453,
	FieldBuilder_get_UMarshal_m1984011598,
	FieldBuilder_CreateNotSupportedException_m3232073932,
	FieldBuilder_get_Module_m1965601633,
	GenericTypeParameterBuilder_IsSubclassOf_m353142104,
	GenericTypeParameterBuilder_GetAttributeFlagsImpl_m1839213924,
	GenericTypeParameterBuilder_GetConstructorImpl_m3636295158,
	GenericTypeParameterBuilder_GetConstructors_m3284886085,
	GenericTypeParameterBuilder_GetEvent_m2342415410,
	GenericTypeParameterBuilder_GetField_m1550196833,
	GenericTypeParameterBuilder_GetFields_m3294053138,
	GenericTypeParameterBuilder_GetInterfaces_m104749576,
	GenericTypeParameterBuilder_GetMethods_m29397225,
	GenericTypeParameterBuilder_GetMethodImpl_m547015455,
	GenericTypeParameterBuilder_GetPropertyImpl_m1157110034,
	GenericTypeParameterBuilder_HasElementTypeImpl_m2616217087,
	GenericTypeParameterBuilder_IsAssignableFrom_m2851625581,
	GenericTypeParameterBuilder_IsInstanceOfType_m1660697006,
	GenericTypeParameterBuilder_IsArrayImpl_m376392290,
	GenericTypeParameterBuilder_IsByRefImpl_m997941508,
	GenericTypeParameterBuilder_IsPointerImpl_m3596100288,
	GenericTypeParameterBuilder_IsPrimitiveImpl_m53642826,
	GenericTypeParameterBuilder_IsValueTypeImpl_m2839751211,
	GenericTypeParameterBuilder_InvokeMember_m2129857298,
	GenericTypeParameterBuilder_GetElementType_m3106765030,
	GenericTypeParameterBuilder_get_UnderlyingSystemType_m1049760852,
	GenericTypeParameterBuilder_get_Assembly_m3256314693,
	GenericTypeParameterBuilder_get_AssemblyQualifiedName_m930142857,
	GenericTypeParameterBuilder_get_BaseType_m2038220919,
	GenericTypeParameterBuilder_get_FullName_m113867323,
	GenericTypeParameterBuilder_IsDefined_m3083113094,
	GenericTypeParameterBuilder_GetCustomAttributes_m1784509669,
	GenericTypeParameterBuilder_GetCustomAttributes_m516723103,
	GenericTypeParameterBuilder_get_Name_m2329592136,
	GenericTypeParameterBuilder_get_Namespace_m115401056,
	GenericTypeParameterBuilder_get_Module_m4243919340,
	GenericTypeParameterBuilder_get_DeclaringType_m4161880422,
	GenericTypeParameterBuilder_get_ReflectedType_m1498626203,
	GenericTypeParameterBuilder_get_TypeHandle_m2981587387,
	GenericTypeParameterBuilder_GetGenericArguments_m1548145364,
	GenericTypeParameterBuilder_GetGenericTypeDefinition_m2308065503,
	GenericTypeParameterBuilder_get_ContainsGenericParameters_m29159950,
	GenericTypeParameterBuilder_get_IsGenericParameter_m3114374385,
	GenericTypeParameterBuilder_get_IsGenericType_m3781708032,
	GenericTypeParameterBuilder_get_IsGenericTypeDefinition_m2389046390,
	GenericTypeParameterBuilder_not_supported_m1731476325,
	GenericTypeParameterBuilder_ToString_m787137575,
	GenericTypeParameterBuilder_Equals_m4250412984,
	GenericTypeParameterBuilder_GetHashCode_m2384437160,
	GenericTypeParameterBuilder_MakeGenericType_m92865730,
	ILGenerator__ctor_m3831821068,
	ILGenerator__cctor_m1016473741,
	ILGenerator_add_token_fixup_m1724091381,
	ILGenerator_make_room_m444464353,
	ILGenerator_emit_int_m2794944108,
	ILGenerator_ll_emit_m709490707,
	ILGenerator_Emit_m649449510,
	ILGenerator_Emit_m1397855461,
	ILGenerator_label_fixup_m2220310279,
	ILGenerator_Mono_GetCurrentOffset_m1965052903,
	MethodBuilder_get_ContainsGenericParameters_m558997801,
	MethodBuilder_get_MethodHandle_m1478074017,
	MethodBuilder_get_ReturnType_m1039020030,
	MethodBuilder_get_ReflectedType_m2006317078,
	MethodBuilder_get_DeclaringType_m135867346,
	MethodBuilder_get_Name_m3558084903,
	MethodBuilder_get_Attributes_m3974070431,
	MethodBuilder_get_CallingConvention_m3240118774,
	MethodBuilder_GetBaseDefinition_m2891328059,
	MethodBuilder_GetParameters_m78256597,
	MethodBuilder_GetParameterCount_m432668952,
	MethodBuilder_Invoke_m3372071101,
	MethodBuilder_IsDefined_m1520062565,
	MethodBuilder_GetCustomAttributes_m473377132,
	MethodBuilder_GetCustomAttributes_m3351245388,
	MethodBuilder_check_override_m2061218982,
	MethodBuilder_fixup_m1382183758,
	MethodBuilder_ToString_m3845707716,
	MethodBuilder_Equals_m2649897076,
	MethodBuilder_GetHashCode_m2275982589,
	MethodBuilder_get_next_table_index_m999917900,
	MethodBuilder_NotSupported_m4035176812,
	MethodBuilder_MakeGenericMethod_m1194343307,
	MethodBuilder_get_IsGenericMethodDefinition_m1404273627,
	MethodBuilder_get_IsGenericMethod_m4027418537,
	MethodBuilder_GetGenericArguments_m2143170801,
	MethodBuilder_get_Module_m2723726460,
	MethodToken__ctor_m4038133375_AdjustorThunk,
	MethodToken__cctor_m768804040,
	MethodToken_Equals_m3797630749_AdjustorThunk,
	MethodToken_GetHashCode_m2040477620_AdjustorThunk,
	MethodToken_get_Token_m699050427_AdjustorThunk,
	ModuleBuilder__cctor_m2057277080,
	ModuleBuilder_get_next_table_index_m3753842447,
	ModuleBuilder_GetTypes_m3938547762,
	ModuleBuilder_getToken_m959987480,
	ModuleBuilder_GetToken_m2353291662,
	ModuleBuilder_RegisterToken_m567790628,
	ModuleBuilder_GetTokenGenerator_m4097658340,
	ModuleBuilderTokenGenerator__ctor_m896014926,
	ModuleBuilderTokenGenerator_GetToken_m1763381870,
	OpCode__ctor_m3124025053_AdjustorThunk,
	OpCode_GetHashCode_m188093846_AdjustorThunk,
	OpCode_Equals_m3409306657_AdjustorThunk,
	OpCode_ToString_m1642375114_AdjustorThunk,
	OpCode_get_Name_m1352624527_AdjustorThunk,
	OpCode_get_Size_m654700322_AdjustorThunk,
	OpCode_get_StackBehaviourPop_m2319974318_AdjustorThunk,
	OpCode_get_StackBehaviourPush_m2342360980_AdjustorThunk,
	OpCodeNames__cctor_m1379507976,
	OpCodes__cctor_m2732960412,
	ParameterBuilder_get_Attributes_m3870211422,
	ParameterBuilder_get_Name_m2092199752,
	ParameterBuilder_get_Position_m1847690366,
	TypeBuilder_GetAttributeFlagsImpl_m2920211965,
	TypeBuilder_setup_internal_class_m2244704536,
	TypeBuilder_create_generic_class_m4285558031,
	TypeBuilder_get_Assembly_m3299514451,
	TypeBuilder_get_AssemblyQualifiedName_m1412739845,
	TypeBuilder_get_BaseType_m3817395349,
	TypeBuilder_get_DeclaringType_m1223871182,
	TypeBuilder_get_UnderlyingSystemType_m2961106457,
	TypeBuilder_get_FullName_m3626162747,
	TypeBuilder_get_Module_m1866101650,
	TypeBuilder_get_Name_m2090121023,
	TypeBuilder_get_Namespace_m332380446,
	TypeBuilder_get_ReflectedType_m767353663,
	TypeBuilder_GetConstructorImpl_m2746299425,
	TypeBuilder_IsDefined_m3327317460,
	TypeBuilder_GetCustomAttributes_m2547225084,
	TypeBuilder_GetCustomAttributes_m989064033,
	TypeBuilder_DefineConstructor_m3569992820,
	TypeBuilder_DefineConstructor_m467803885,
	TypeBuilder_DefineDefaultConstructor_m1244102928,
	TypeBuilder_create_runtime_class_m2008555911,
	TypeBuilder_is_nested_in_m2139302697,
	TypeBuilder_has_ctor_method_m2846430015,
	TypeBuilder_CreateType_m3351196612,
	TypeBuilder_GetConstructors_m3718991123,
	TypeBuilder_GetConstructorsInternal_m368288422,
	TypeBuilder_GetElementType_m1570270004,
	TypeBuilder_GetEvent_m973045957,
	TypeBuilder_GetField_m2062793076,
	TypeBuilder_GetFields_m4186988355,
	TypeBuilder_GetInterfaces_m2536132964,
	TypeBuilder_GetMethodsByName_m2893159309,
	TypeBuilder_GetMethods_m2941619924,
	TypeBuilder_GetMethodImpl_m2363962104,
	TypeBuilder_GetPropertyImpl_m527397799,
	TypeBuilder_HasElementTypeImpl_m1352051324,
	TypeBuilder_InvokeMember_m981872043,
	TypeBuilder_IsArrayImpl_m3754106921,
	TypeBuilder_IsByRefImpl_m1688605928,
	TypeBuilder_IsPointerImpl_m2119945128,
	TypeBuilder_IsPrimitiveImpl_m1394730752,
	TypeBuilder_IsValueTypeImpl_m2957956512,
	TypeBuilder_MakeGenericType_m1825409448,
	TypeBuilder_get_TypeHandle_m1131290943,
	TypeBuilder_SetParent_m511590099,
	TypeBuilder_get_next_table_index_m3795850917,
	TypeBuilder_get_IsCompilerContext_m380125708,
	TypeBuilder_get_is_created_m3806364821,
	TypeBuilder_not_supported_m4035202484,
	TypeBuilder_check_not_created_m398775119,
	TypeBuilder_check_created_m768973979,
	TypeBuilder_ToString_m2453558611,
	TypeBuilder_IsAssignableFrom_m3041852661,
	TypeBuilder_IsSubclassOf_m2811257152,
	TypeBuilder_IsAssignableTo_m1907754253,
	TypeBuilder_GetGenericArguments_m123452731,
	TypeBuilder_GetGenericTypeDefinition_m183072622,
	TypeBuilder_get_ContainsGenericParameters_m2527904564,
	TypeBuilder_get_IsGenericParameter_m3977989423,
	TypeBuilder_get_IsGenericTypeDefinition_m4055168744,
	TypeBuilder_get_IsGenericType_m2048561606,
	UnmanagedMarshal_ToMarshalAsAttribute_m515448510,
	EventInfo__ctor_m3830324722,
	EventInfo_get_EventHandlerType_m2669943566,
	EventInfo_get_MemberType_m3045779206,
	AddEventAdapter__ctor_m2936189202,
	AddEventAdapter_Invoke_m1903394599,
	AddEventAdapter_BeginInvoke_m4267541168,
	AddEventAdapter_EndInvoke_m1140548722,
	FieldInfo__ctor_m3053970987,
	FieldInfo_get_MemberType_m922465815,
	FieldInfo_get_IsLiteral_m1190605584,
	FieldInfo_get_IsStatic_m3509250687,
	FieldInfo_get_IsNotSerialized_m2193323076,
	FieldInfo_SetValue_m3184768154,
	FieldInfo_internal_from_handle_type_m2092753019,
	FieldInfo_GetFieldFromHandle_m2696435896,
	FieldInfo_GetFieldOffset_m3612678663,
	FieldInfo_GetUnmanagedMarshal_m584782143,
	FieldInfo_get_UMarshal_m1375567641,
	FieldInfo_GetPseudoCustomAttributes_m56998992,
	MemberFilter__ctor_m3294589552,
	MemberFilter_Invoke_m883704118,
	MemberFilter_BeginInvoke_m719276847,
	MemberFilter_EndInvoke_m667200611,
	MemberInfo__ctor_m2895172263,
	MemberInfo_get_Module_m2318214504,
	MemberInfoSerializationHolder__ctor_m3584691757,
	MemberInfoSerializationHolder_Serialize_m1886087251,
	MemberInfoSerializationHolder_Serialize_m1707562648,
	MemberInfoSerializationHolder_GetObjectData_m2308673721,
	MemberInfoSerializationHolder_GetRealObject_m333774208,
	MethodBase__ctor_m914644895,
	MethodBase_GetMethodFromHandleNoGenericCheck_m2913373160,
	MethodBase_GetMethodFromIntPtr_m3175053392,
	MethodBase_GetMethodFromHandle_m1957760829,
	MethodBase_GetMethodFromHandleInternalType_m291748205,
	MethodBase_GetParameterCount_m3721378648,
	MethodBase_Invoke_m1733031813,
	MethodBase_get_CallingConvention_m3072461124,
	MethodBase_get_IsPublic_m1144995937,
	MethodBase_get_IsStatic_m3254123256,
	MethodBase_get_IsVirtual_m3405858414,
	MethodBase_get_IsAbstract_m2894117648,
	MethodBase_get_next_table_index_m1429744308,
	MethodBase_GetGenericArguments_m3649313813,
	MethodBase_get_ContainsGenericParameters_m1058418413,
	MethodBase_get_IsGenericMethodDefinition_m1322528031,
	MethodBase_get_IsGenericMethod_m181568085,
	MethodInfo__ctor_m3355489345,
	MethodInfo_get_MemberType_m1375837193,
	MethodInfo_get_ReturnType_m1381443358,
	MethodInfo_MakeGenericMethod_m386620528,
	MethodInfo_GetGenericArguments_m3810648776,
	MethodInfo_get_IsGenericMethod_m921554736,
	MethodInfo_get_IsGenericMethodDefinition_m3340704956,
	MethodInfo_get_ContainsGenericParameters_m2598133705,
	Missing__ctor_m4289576884,
	Missing__cctor_m2565184059,
	Missing_System_Runtime_Serialization_ISerializable_GetObjectData_m3892491128,
	Module__ctor_m3036718125,
	Module__cctor_m2458341886,
	Module_get_Assembly_m1122675775,
	Module_get_ScopeName_m1235275893,
	Module_GetCustomAttributes_m2263679618,
	Module_GetObjectData_m2031407505,
	Module_InternalGetTypes_m1279518627,
	Module_GetTypes_m1078392553,
	Module_IsDefined_m699307601,
	Module_IsResource_m1671226801,
	Module_ToString_m3206737166,
	Module_filter_by_type_name_m3362081677,
	Module_filter_by_type_name_ignore_case_m1377657907,
	MonoCMethod__ctor_m1368515011,
	MonoCMethod_GetParameters_m2185608004,
	MonoCMethod_InternalInvoke_m926685991,
	MonoCMethod_Invoke_m1176335855,
	MonoCMethod_Invoke_m1899956600,
	MonoCMethod_get_MethodHandle_m1426101540,
	MonoCMethod_get_Attributes_m2031015977,
	MonoCMethod_get_CallingConvention_m2663884831,
	MonoCMethod_get_ReflectedType_m359869482,
	MonoCMethod_get_DeclaringType_m1134080785,
	MonoCMethod_get_Name_m2549379589,
	MonoCMethod_IsDefined_m2758653357,
	MonoCMethod_GetCustomAttributes_m1468537363,
	MonoCMethod_GetCustomAttributes_m3506054775,
	MonoCMethod_ToString_m3471500585,
	MonoCMethod_GetObjectData_m2316862133,
	MonoEvent__ctor_m2633135540,
	MonoEvent_get_Attributes_m1918740251,
	MonoEvent_GetAddMethod_m4281263188,
	MonoEvent_get_DeclaringType_m3540285216,
	MonoEvent_get_ReflectedType_m4138508682,
	MonoEvent_get_Name_m2644209411,
	MonoEvent_ToString_m93515601,
	MonoEvent_IsDefined_m1491615391,
	MonoEvent_GetCustomAttributes_m4167148841,
	MonoEvent_GetCustomAttributes_m3650299405,
	MonoEvent_GetObjectData_m584957029,
	MonoEventInfo_get_event_info_m4045553184,
	MonoEventInfo_GetEventInfo_m44209219,
	MonoField__ctor_m3815878254,
	MonoField_get_Attributes_m4066504495,
	MonoField_get_FieldHandle_m1267921003,
	MonoField_get_FieldType_m2857925770,
	MonoField_GetParentType_m958274503,
	MonoField_get_ReflectedType_m3574480981,
	MonoField_get_DeclaringType_m3892021042,
	MonoField_get_Name_m2743852047,
	MonoField_IsDefined_m2573678378,
	MonoField_GetCustomAttributes_m1612478183,
	MonoField_GetCustomAttributes_m2460206797,
	MonoField_GetFieldOffset_m151961242,
	MonoField_GetValueInternal_m775233678,
	MonoField_GetValue_m1128051181,
	MonoField_ToString_m1158774068,
	MonoField_SetValueInternal_m687129371,
	MonoField_SetValue_m2020324035,
	MonoField_GetObjectData_m3538855411,
	MonoField_CheckGeneric_m2176366112,
	MonoGenericCMethod__ctor_m333579013,
	MonoGenericCMethod_get_ReflectedType_m621354,
	MonoGenericMethod__ctor_m108676012,
	MonoGenericMethod_get_ReflectedType_m1588296328,
	MonoMethod__ctor_m2394553335,
	MonoMethod_get_name_m2996022605,
	MonoMethod_get_base_definition_m3434665674,
	MonoMethod_GetBaseDefinition_m26679534,
	MonoMethod_get_ReturnType_m1418708448,
	MonoMethod_GetParameters_m2049036167,
	MonoMethod_InternalInvoke_m3495962619,
	MonoMethod_Invoke_m597221130,
	MonoMethod_get_MethodHandle_m1665293443,
	MonoMethod_get_Attributes_m2537532032,
	MonoMethod_get_CallingConvention_m2809250670,
	MonoMethod_get_ReflectedType_m3250902944,
	MonoMethod_get_DeclaringType_m226148929,
	MonoMethod_get_Name_m3603474228,
	MonoMethod_IsDefined_m3702183531,
	MonoMethod_GetCustomAttributes_m2351603402,
	MonoMethod_GetCustomAttributes_m2457172789,
	MonoMethod_GetDllImportAttribute_m1901190805,
	MonoMethod_GetPseudoCustomAttributes_m2692758498,
	MonoMethod_ShouldPrintFullName_m2935901902,
	MonoMethod_ToString_m3887950899,
	MonoMethod_GetObjectData_m441826518,
	MonoMethod_MakeGenericMethod_m2027759215,
	MonoMethod_MakeGenericMethod_impl_m608204904,
	MonoMethod_GetGenericArguments_m3396008493,
	MonoMethod_get_IsGenericMethodDefinition_m430528877,
	MonoMethod_get_IsGenericMethod_m2752274537,
	MonoMethod_get_ContainsGenericParameters_m132612449,
	MonoMethodInfo_get_method_info_m4041399695,
	MonoMethodInfo_GetMethodInfo_m1130553512,
	MonoMethodInfo_GetDeclaringType_m3171456324,
	MonoMethodInfo_GetReturnType_m4023614880,
	MonoMethodInfo_GetAttributes_m275559530,
	MonoMethodInfo_GetCallingConvention_m1539455965,
	MonoMethodInfo_get_parameter_info_m3207129851,
	MonoMethodInfo_GetParametersInfo_m2379324589,
	MonoProperty__ctor_m3749131868,
	MonoProperty_CachePropertyInfo_m2203593361,
	MonoProperty_get_Attributes_m788547603,
	MonoProperty_get_CanRead_m2714628776,
	MonoProperty_get_CanWrite_m1110418558,
	MonoProperty_get_PropertyType_m3552246100,
	MonoProperty_get_ReflectedType_m1569187598,
	MonoProperty_get_DeclaringType_m3201336604,
	MonoProperty_get_Name_m4214358520,
	MonoProperty_GetAccessors_m2636385166,
	MonoProperty_GetGetMethod_m1200130706,
	MonoProperty_GetIndexParameters_m1064406362,
	MonoProperty_GetSetMethod_m2480910565,
	MonoProperty_IsDefined_m2926514180,
	MonoProperty_GetCustomAttributes_m2693909456,
	MonoProperty_GetCustomAttributes_m606671689,
	MonoProperty_CreateGetterDelegate_m2312737886,
	MonoProperty_GetValue_m3026733966,
	MonoProperty_GetValue_m3864069366,
	MonoProperty_SetValue_m1983498753,
	MonoProperty_ToString_m82409001,
	MonoProperty_GetOptionalCustomModifiers_m2078442524,
	MonoProperty_GetRequiredCustomModifiers_m78783095,
	MonoProperty_GetObjectData_m2146788892,
	GetterAdapter__ctor_m1012554090,
	GetterAdapter_Invoke_m274341202,
	GetterAdapter_BeginInvoke_m1418105378,
	GetterAdapter_EndInvoke_m4038673688,
	MonoPropertyInfo_get_property_info_m2619364300,
	MonoPropertyInfo_GetTypeModifiers_m3896701535,
	ParameterInfo__ctor_m1259672684,
	ParameterInfo__ctor_m4093661503,
	ParameterInfo__ctor_m1491210204,
	ParameterInfo_ToString_m657579133,
	ParameterInfo_get_ParameterType_m1392854300,
	ParameterInfo_get_Attributes_m4228374328,
	ParameterInfo_get_IsIn_m3130393014,
	ParameterInfo_get_IsOptional_m3016593533,
	ParameterInfo_get_IsOut_m4053388324,
	ParameterInfo_get_IsRetval_m981319851,
	ParameterInfo_get_Member_m703771809,
	ParameterInfo_get_Name_m3844246097,
	ParameterInfo_get_Position_m1016390727,
	ParameterInfo_GetCustomAttributes_m2620927559,
	ParameterInfo_IsDefined_m1898312502,
	ParameterInfo_GetPseudoCustomAttributes_m3010230487,
	Pointer__ctor_m3237441921,
	Pointer_System_Runtime_Serialization_ISerializable_GetObjectData_m1139492117,
	Pointer_Box_m3312154931,
	PropertyInfo__ctor_m701561300,
	PropertyInfo_get_MemberType_m503325555,
	PropertyInfo_GetValue_m3754113982,
	PropertyInfo_SetValue_m3700075641,
	PropertyInfo_GetOptionalCustomModifiers_m1048434156,
	PropertyInfo_GetRequiredCustomModifiers_m10361816,
	StrongNameKeyPair__ctor_m32462396,
	StrongNameKeyPair_System_Runtime_Serialization_ISerializable_GetObjectData_m2820598375,
	StrongNameKeyPair_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m2070263637,
	TargetException__ctor_m822694954,
	TargetException__ctor_m3271977883,
	TargetException__ctor_m2483985350,
	TargetInvocationException__ctor_m837454776,
	TargetInvocationException__ctor_m3194966783,
	TargetParameterCountException__ctor_m2743742885,
	TargetParameterCountException__ctor_m124206017,
	TargetParameterCountException__ctor_m2871128293,
	TypeFilter__ctor_m299289324,
	TypeFilter_Invoke_m965484192,
	TypeFilter_BeginInvoke_m2198754576,
	TypeFilter_EndInvoke_m122362554,
	ResolveEventArgs__ctor_m3960362713,
	ResolveEventHandler__ctor_m3364537882,
	ResolveEventHandler_Invoke_m2076389584,
	ResolveEventHandler_BeginInvoke_m4075502633,
	ResolveEventHandler_EndInvoke_m3596368155,
	NeutralResourcesLanguageAttribute__ctor_m1705398382,
	ResourceManager__ctor_m2377996755,
	ResourceManager__cctor_m3369413866,
	ResourceReader__ctor_m2992668569,
	ResourceReader__ctor_m2898836350,
	ResourceReader_System_Collections_IEnumerable_GetEnumerator_m1273544185,
	ResourceReader_System_IDisposable_Dispose_m2871216432,
	ResourceReader_ReadHeaders_m3788459369,
	ResourceReader_CreateResourceInfo_m2385156689,
	ResourceReader_Read7BitEncodedInt_m3940796910,
	ResourceReader_ReadValueVer2_m491773434,
	ResourceReader_ReadValueVer1_m1712931252,
	ResourceReader_ReadNonPredefinedValue_m3987838549,
	ResourceReader_LoadResourceValues_m3900593382,
	ResourceReader_Close_m2367136949,
	ResourceReader_GetEnumerator_m674542934,
	ResourceReader_Dispose_m2330356043,
	ResourceCacheItem__ctor_m2141503584_AdjustorThunk,
	ResourceEnumerator__ctor_m2161138338,
	ResourceEnumerator_get_Entry_m2788443893,
	ResourceEnumerator_get_Key_m3490384347,
	ResourceEnumerator_get_Value_m690942934,
	ResourceEnumerator_get_Current_m3599228775,
	ResourceEnumerator_MoveNext_m3061705329,
	ResourceEnumerator_Reset_m1094270379,
	ResourceEnumerator_FillCache_m1461526679,
	ResourceInfo__ctor_m29313275_AdjustorThunk,
	ResourceSet__ctor_m3064702632,
	ResourceSet__ctor_m3926974598,
	ResourceSet__ctor_m2843759256,
	ResourceSet__ctor_m3716415605,
	ResourceSet_System_Collections_IEnumerable_GetEnumerator_m3787282306,
	ResourceSet_Dispose_m997817438,
	ResourceSet_Dispose_m3909104616,
	ResourceSet_GetEnumerator_m2056913480,
	ResourceSet_GetObjectInternal_m3498257566,
	ResourceSet_GetObject_m1749535546,
	ResourceSet_GetObject_m800002112,
	ResourceSet_ReadResources_m1247711666,
	RuntimeResourceSet__ctor_m2600464097,
	RuntimeResourceSet__ctor_m3701588765,
	RuntimeResourceSet__ctor_m663308246,
	RuntimeResourceSet_GetObject_m1211470855,
	RuntimeResourceSet_GetObject_m4004481700,
	RuntimeResourceSet_CloneDisposableObjectIfPossible_m1954735340,
	SatelliteContractVersionAttribute__ctor_m3848511474,
	CompilationRelaxationsAttribute__ctor_m3343263694,
	CompilerGeneratedAttribute__ctor_m1329859730,
	DecimalConstantAttribute__ctor_m65841775,
	DefaultDependencyAttribute__ctor_m2434010332,
	FixedBufferAttribute__ctor_m504397755,
	FixedBufferAttribute_get_ElementType_m1143901886,
	FixedBufferAttribute_get_Length_m965624054,
	InternalsVisibleToAttribute__ctor_m3585987778,
	RuntimeCompatibilityAttribute__ctor_m1077459611,
	RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2097818566,
	RuntimeHelpers_InitializeArray_m1875588582,
	RuntimeHelpers_InitializeArray_m4208405769,
	RuntimeHelpers_get_OffsetToStringData_m3635924201,
	StringFreezingAttribute__ctor_m327960799,
	CriticalFinalizerObject__ctor_m2030151810,
	CriticalFinalizerObject_Finalize_m1139807466,
	ReliabilityContractAttribute__ctor_m1584311890,
	ClassInterfaceAttribute__ctor_m1041561158,
	ComDefaultInterfaceAttribute__ctor_m585413508,
	COMException__ctor_m1724775782,
	COMException__ctor_m3235920267,
	COMException_ToString_m1844260211,
	ComImportAttribute__ctor_m1135573434,
	ComVisibleAttribute__ctor_m3177107244,
	DispIdAttribute__ctor_m787871839,
	DllImportAttribute__ctor_m3240233065,
	DllImportAttribute_get_Value_m2261338912,
	ExternalException__ctor_m2503986190,
	ExternalException__ctor_m463019174,
	FieldOffsetAttribute__ctor_m1651212589,
	GCHandle__ctor_m778347281_AdjustorThunk,
	GCHandle_get_IsAllocated_m4178866460_AdjustorThunk,
	GCHandle_get_Target_m1404668502_AdjustorThunk,
	GCHandle_Alloc_m2569753928,
	GCHandle_Free_m516436441_AdjustorThunk,
	GCHandle_GetTarget_m2486407089,
	GCHandle_GetTargetHandle_m1314632647,
	GCHandle_FreeHandle_m3959163090,
	GCHandle_Equals_m2849443044_AdjustorThunk,
	GCHandle_GetHashCode_m2912917812_AdjustorThunk,
	GuidAttribute__ctor_m2076129958,
	InAttribute__ctor_m2228312299,
	InterfaceTypeAttribute__ctor_m458747174,
	Marshal__cctor_m4104258811,
	Marshal_copy_from_unmanaged_m2804320864,
	Marshal_Copy_m2093961536,
	Marshal_Copy_m2701261851,
	Marshal_ReadByte_m2604965135,
	Marshal_WriteByte_m1621362122,
	MarshalAsAttribute__ctor_m767061736,
	MarshalDirectiveException__ctor_m1071837358,
	MarshalDirectiveException__ctor_m1659829488,
	OptionalAttribute__ctor_m2750181596,
	OutAttribute__ctor_m3241134633,
	PreserveSigAttribute__ctor_m2060022429,
	SafeHandle__ctor_m783613520,
	SafeHandle_Close_m1681605028,
	SafeHandle_DangerousAddRef_m1891015601,
	SafeHandle_DangerousGetHandle_m1375610744,
	SafeHandle_DangerousRelease_m3378349730,
	SafeHandle_Dispose_m2973664238,
	SafeHandle_Dispose_m2534630911,
	SafeHandle_SetHandle_m662183779,
	SafeHandle_Finalize_m1085970670,
	TypeLibImportClassAttribute__ctor_m1625403865,
	TypeLibVersionAttribute__ctor_m3709773259,
	UnmanagedFunctionPointerAttribute__ctor_m3384177810,
	ActivatedClientTypeEntry__ctor_m961700077,
	ActivatedClientTypeEntry_get_ApplicationUrl_m65674309,
	ActivatedClientTypeEntry_get_ContextAttributes_m1891553033,
	ActivatedClientTypeEntry_get_ObjectType_m4210984781,
	ActivatedClientTypeEntry_ToString_m1615275276,
	ActivatedServiceTypeEntry__ctor_m2993206676,
	ActivatedServiceTypeEntry_get_ObjectType_m1427973026,
	ActivatedServiceTypeEntry_ToString_m843014576,
	ActivationServices_get_ConstructionActivator_m4240976655,
	ActivationServices_CreateProxyFromAttributes_m3130040993,
	ActivationServices_CreateConstructionCall_m1739289852,
	ActivationServices_AllocateUninitializedClassInstance_m1041577079,
	ActivationServices_EnableProxyActivation_m3061095704,
	AppDomainLevelActivator__ctor_m1752711285,
	ConstructionLevelActivator__ctor_m1866604337,
	ContextLevelActivator__ctor_m2887329662,
	UrlAttribute_get_UrlValue_m3695705807,
	UrlAttribute_Equals_m3242123363,
	UrlAttribute_GetHashCode_m1126142254,
	UrlAttribute_GetPropertiesForNewContext_m1689720063,
	UrlAttribute_IsContextOK_m2408897339,
	ChannelData__ctor_m3724019093,
	ChannelData_get_ServerProviders_m2346420728,
	ChannelData_get_ClientProviders_m2647766900,
	ChannelData_get_CustomProperties_m3201616328,
	ChannelData_CopyFrom_m3048959718,
	ChannelInfo__ctor_m3458956171,
	ChannelInfo_get_ChannelData_m1721234000,
	ChannelServices__cctor_m2925605698,
	ChannelServices_CreateClientChannelSinkChain_m2299002996,
	ChannelServices_CreateClientChannelSinkChain_m1830317104,
	ChannelServices_RegisterChannel_m619736505,
	ChannelServices_RegisterChannel_m3776073786,
	ChannelServices_RegisterChannelConfig_m620916206,
	ChannelServices_CreateProvider_m2383308334,
	ChannelServices_GetCurrentChannelInfo_m2697201746,
	CrossAppDomainChannel__ctor_m922148798,
	CrossAppDomainChannel__cctor_m61205201,
	CrossAppDomainChannel_RegisterCrossAppDomainChannel_m3549328991,
	CrossAppDomainChannel_get_ChannelName_m1966890542,
	CrossAppDomainChannel_get_ChannelPriority_m2508057774,
	CrossAppDomainChannel_get_ChannelData_m2946439121,
	CrossAppDomainChannel_StartListening_m799869571,
	CrossAppDomainChannel_CreateMessageSink_m3478549795,
	CrossAppDomainData__ctor_m3603375222,
	CrossAppDomainData_get_DomainID_m1381698640,
	CrossAppDomainData_get_ProcessID_m1025542747,
	CrossAppDomainSink__ctor_m3221079242,
	CrossAppDomainSink__cctor_m2829594424,
	CrossAppDomainSink_GetSink_m223269928,
	CrossAppDomainSink_get_TargetDomainId_m3142859908,
	SinkProviderData__ctor_m338897737,
	SinkProviderData_get_Children_m3566980833,
	SinkProviderData_get_Properties_m1085815932,
	ClientActivatedIdentity_GetServerObject_m146141043,
	ClientIdentity__ctor_m401680993,
	ClientIdentity_get_ClientProxy_m3707620840,
	ClientIdentity_set_ClientProxy_m3489345640,
	ClientIdentity_CreateObjRef_m2812888787,
	ClientIdentity_get_TargetUri_m2343617238,
	ConfigHandler__ctor_m2131886541,
	ConfigHandler_ValidatePath_m3488759860,
	ConfigHandler_CheckPath_m2765851308,
	ConfigHandler_OnStartParsing_m2591807998,
	ConfigHandler_OnProcessingInstruction_m610470747,
	ConfigHandler_OnIgnorableWhitespace_m1043832771,
	ConfigHandler_OnStartElement_m3059487790,
	ConfigHandler_ParseElement_m2853712773,
	ConfigHandler_OnEndElement_m3555551528,
	ConfigHandler_ReadCustomProviderData_m2138933965,
	ConfigHandler_ReadLifetine_m1383959793,
	ConfigHandler_ParseTime_m915090830,
	ConfigHandler_ReadChannel_m3087762983,
	ConfigHandler_ReadProvider_m2756436168,
	ConfigHandler_ReadClientActivated_m4074147023,
	ConfigHandler_ReadServiceActivated_m2953899804,
	ConfigHandler_ReadClientWellKnown_m141186075,
	ConfigHandler_ReadServiceWellKnown_m1548650707,
	ConfigHandler_ReadInteropXml_m1706145686,
	ConfigHandler_ReadPreload_m3645960259,
	ConfigHandler_GetNotNull_m1929319944,
	ConfigHandler_ExtractAssembly_m46994864,
	ConfigHandler_OnChars_m2335751675,
	ConfigHandler_OnEndParsing_m3955900569,
	Context__ctor_m3838186117,
	Context__cctor_m1686361362,
	Context_Finalize_m2707923909,
	Context_get_DefaultContext_m1757982623,
	Context_get_ContextID_m1405591127,
	Context_get_ContextProperties_m3311229519,
	Context_get_IsDefaultContext_m3747889133,
	Context_get_NeedsContextSink_m873051291,
	Context_RegisterDynamicProperty_m3074051190,
	Context_UnregisterDynamicProperty_m2338404966,
	Context_GetDynamicPropertyCollection_m1082450921,
	Context_NotifyGlobalDynamicSinks_m1914139369,
	Context_get_HasGlobalDynamicSinks_m1840794589,
	Context_NotifyDynamicSinks_m4010548312,
	Context_get_HasDynamicSinks_m876233005,
	Context_get_HasExitSinks_m2218417582,
	Context_GetProperty_m1984995929,
	Context_SetProperty_m232332861,
	Context_Freeze_m772166489,
	Context_ToString_m2437055406,
	Context_GetServerContextSinkChain_m2786094134,
	Context_GetClientContextSinkChain_m3476566830,
	Context_CreateServerObjectSinkChain_m731523930,
	Context_CreateEnvoySink_m2384793104,
	Context_SwitchToContext_m2435378473,
	Context_CreateNewContext_m484094750,
	Context_DoCallBack_m2209911274,
	Context_AllocateDataSlot_m2895667391,
	Context_AllocateNamedDataSlot_m2522743541,
	Context_FreeNamedDataSlot_m3013717957,
	Context_GetData_m1650081915,
	Context_GetNamedDataSlot_m2125513560,
	Context_SetData_m930255550,
	ContextAttribute__ctor_m1193606705,
	ContextAttribute_get_Name_m3666631151,
	ContextAttribute_Equals_m880661481,
	ContextAttribute_Freeze_m4237110078,
	ContextAttribute_GetHashCode_m1783548121,
	ContextAttribute_GetPropertiesForNewContext_m3927899656,
	ContextAttribute_IsContextOK_m807706287,
	ContextAttribute_IsNewContextOK_m2437025709,
	ContextCallbackObject__ctor_m3155241849,
	ContextCallbackObject_DoCallBack_m2489864602,
	CrossContextChannel__ctor_m230624169,
	CrossContextDelegate__ctor_m3150806701,
	CrossContextDelegate_Invoke_m3346279658,
	CrossContextDelegate_BeginInvoke_m3506025905,
	CrossContextDelegate_EndInvoke_m856896361,
	DynamicPropertyCollection__ctor_m3275052761,
	DynamicPropertyCollection_get_HasProperties_m564239650,
	DynamicPropertyCollection_RegisterDynamicProperty_m2990332387,
	DynamicPropertyCollection_UnregisterDynamicProperty_m1202699648,
	DynamicPropertyCollection_NotifyMessage_m399106134,
	DynamicPropertyCollection_FindProperty_m1611935282,
	DynamicPropertyReg__ctor_m483988335,
	SynchronizationAttribute__ctor_m754806361,
	SynchronizationAttribute__ctor_m2850967056,
	SynchronizationAttribute_set_Locked_m1952643074,
	SynchronizationAttribute_ReleaseLock_m3429901459,
	SynchronizationAttribute_GetPropertiesForNewContext_m3510013590,
	SynchronizationAttribute_GetClientContextSink_m13625270,
	SynchronizationAttribute_GetServerContextSink_m3935992027,
	SynchronizationAttribute_IsContextOK_m1799431817,
	SynchronizationAttribute_ExitContext_m1351064750,
	SynchronizationAttribute_EnterContext_m1794141384,
	SynchronizedClientContextSink__ctor_m3074650272,
	SynchronizedServerContextSink__ctor_m1274353107,
	EnvoyInfo__ctor_m2138777162,
	EnvoyInfo_get_EnvoySinks_m3098746731,
	FormatterData__ctor_m1386663475,
	Identity__ctor_m557501921,
	Identity_get_ChannelSink_m3563421219,
	Identity_set_ChannelSink_m3361282506,
	Identity_get_ObjectUri_m4198864041,
	Identity_get_Disposed_m942418569,
	Identity_set_Disposed_m664277977,
	Identity_get_ClientDynamicProperties_m1621923289,
	Identity_get_ServerDynamicProperties_m100764717,
	InternalRemotingServices__cctor_m1051948496,
	InternalRemotingServices_GetCachedSoapAttribute_m547594056,
	LeaseManager__ctor_m4166399689,
	LeaseManager_SetPollTime_m2692443769,
	LeaseSink__ctor_m3451823952,
	LifetimeServices__cctor_m490172128,
	LifetimeServices_set_LeaseManagerPollTime_m2733098311,
	LifetimeServices_set_LeaseTime_m4187707445,
	LifetimeServices_set_RenewOnCallTime_m2572614698,
	LifetimeServices_set_SponsorshipTimeout_m1926202911,
	ArgInfo__ctor_m2065871060,
	ArgInfo_GetInOutArgs_m3466727859,
	AsyncResult__ctor_m2209868077,
	AsyncResult_get_AsyncState_m2700488195,
	AsyncResult_get_AsyncWaitHandle_m2951059697,
	AsyncResult_get_CompletedSynchronously_m674195806,
	AsyncResult_get_IsCompleted_m2438030310,
	AsyncResult_get_EndInvokeCalled_m2941151778,
	AsyncResult_set_EndInvokeCalled_m829674032,
	AsyncResult_get_AsyncDelegate_m3530734011,
	AsyncResult_get_NextSink_m46927345,
	AsyncResult_AsyncProcessMessage_m22892000,
	AsyncResult_GetReplyMessage_m2466755290,
	AsyncResult_SetMessageCtrl_m4280675270,
	AsyncResult_SetCompletedSynchronously_m825468251,
	AsyncResult_EndInvoke_m1653541135,
	AsyncResult_SyncProcessMessage_m3119234226,
	AsyncResult_get_CallMessage_m3771784926,
	AsyncResult_set_CallMessage_m216266389,
	CallContextRemotingData__ctor_m1331046353,
	CallContextRemotingData_Clone_m2495159650,
	ClientContextTerminatorSink__ctor_m2539508169,
	ConstructionCall__ctor_m3466893612,
	ConstructionCall__ctor_m2142921764,
	ConstructionCall_InitDictionary_m1651665349,
	ConstructionCall_set_IsContextOk_m1285431228,
	ConstructionCall_get_ActivationType_m1377015468,
	ConstructionCall_get_ActivationTypeName_m3161202982,
	ConstructionCall_get_Activator_m154943756,
	ConstructionCall_set_Activator_m1835718599,
	ConstructionCall_get_CallSiteActivationAttributes_m2238433931,
	ConstructionCall_SetActivationAttributes_m2199093722,
	ConstructionCall_get_ContextProperties_m906482931,
	ConstructionCall_InitMethodProperty_m3108654040,
	ConstructionCall_GetObjectData_m2015931236,
	ConstructionCall_get_Properties_m1549127719,
	ConstructionCallDictionary__ctor_m2492889596,
	ConstructionCallDictionary__cctor_m3231094952,
	ConstructionCallDictionary_GetMethodProperty_m690519747,
	ConstructionCallDictionary_SetMethodProperty_m1713421783,
	EnvoyTerminatorSink__ctor_m3953491455,
	EnvoyTerminatorSink__cctor_m701708909,
	Header__ctor_m3914572230,
	Header__ctor_m272790498,
	Header__ctor_m2746884126,
	HeaderHandler__ctor_m3976795712,
	HeaderHandler_Invoke_m2831067375,
	HeaderHandler_BeginInvoke_m2995178583,
	HeaderHandler_EndInvoke_m968934439,
	LogicalCallContext__ctor_m1163298286,
	LogicalCallContext__ctor_m1170822759,
	LogicalCallContext_GetObjectData_m4052825173,
	LogicalCallContext_SetData_m1821488439,
	LogicalCallContext_Clone_m1259859386,
	MethodCall__ctor_m415036708,
	MethodCall__ctor_m939263252,
	MethodCall__ctor_m476029139,
	MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m3786604827,
	MethodCall_InitMethodProperty_m1633379551,
	MethodCall_GetObjectData_m740960429,
	MethodCall_get_Args_m3959193076,
	MethodCall_get_LogicalCallContext_m3492300167,
	MethodCall_get_MethodBase_m4004745274,
	MethodCall_get_MethodName_m690348348,
	MethodCall_get_MethodSignature_m3050585430,
	MethodCall_get_Properties_m1136036514,
	MethodCall_InitDictionary_m762103735,
	MethodCall_get_TypeName_m2628791529,
	MethodCall_get_Uri_m2689236272,
	MethodCall_set_Uri_m4084674782,
	MethodCall_Init_m47204717,
	MethodCall_ResolveMethod_m4086104164,
	MethodCall_CastTo_m728181532,
	MethodCall_GetTypeNameFromAssemblyQualifiedName_m273889598,
	MethodCall_get_GenericArguments_m3852295719,
	MethodCallDictionary__ctor_m2802526823,
	MethodCallDictionary__cctor_m2460609733,
	MethodDictionary__ctor_m1781993430,
	MethodDictionary_System_Collections_IEnumerable_GetEnumerator_m3562925644,
	MethodDictionary_set_MethodKeys_m1080197003,
	MethodDictionary_AllocInternalProperties_m3366171218,
	MethodDictionary_GetInternalProperties_m4025173702,
	MethodDictionary_IsOverridenKey_m2159926719,
	MethodDictionary_get_Item_m959319473,
	MethodDictionary_set_Item_m203484086,
	MethodDictionary_GetMethodProperty_m2698644386,
	MethodDictionary_SetMethodProperty_m2556365533,
	MethodDictionary_get_Values_m2864171127,
	MethodDictionary_Add_m3203360238,
	MethodDictionary_Remove_m571527225,
	MethodDictionary_get_Count_m2276481542,
	MethodDictionary_get_SyncRoot_m1665468154,
	MethodDictionary_CopyTo_m4023794854,
	MethodDictionary_GetEnumerator_m462316350,
	DictionaryEnumerator__ctor_m46703506,
	DictionaryEnumerator_get_Current_m851028571,
	DictionaryEnumerator_MoveNext_m2917595099,
	DictionaryEnumerator_Reset_m1324461869,
	DictionaryEnumerator_get_Entry_m688138041,
	DictionaryEnumerator_get_Key_m1291444917,
	DictionaryEnumerator_get_Value_m457270540,
	MethodReturnDictionary__ctor_m1109184831,
	MethodReturnDictionary__cctor_m1532423255,
	MonoMethodMessage_get_Args_m4197779504,
	MonoMethodMessage_get_LogicalCallContext_m3002289517,
	MonoMethodMessage_get_MethodBase_m3221508894,
	MonoMethodMessage_get_MethodName_m3182476596,
	MonoMethodMessage_get_MethodSignature_m1697153679,
	MonoMethodMessage_get_TypeName_m1795907018,
	MonoMethodMessage_get_Uri_m91319704,
	MonoMethodMessage_set_Uri_m3533759863,
	MonoMethodMessage_get_Exception_m114422168,
	MonoMethodMessage_get_OutArgCount_m1777813996,
	MonoMethodMessage_get_OutArgs_m3309919187,
	MonoMethodMessage_get_ReturnValue_m654888810,
	ObjRefSurrogate__ctor_m780691929,
	ObjRefSurrogate_SetObjectData_m588521599,
	RemotingSurrogate__ctor_m2070167194,
	RemotingSurrogate_SetObjectData_m3933222664,
	RemotingSurrogateSelector__ctor_m2739539366,
	RemotingSurrogateSelector__cctor_m2479395107,
	RemotingSurrogateSelector_GetSurrogate_m4075568739,
	ReturnMessage__ctor_m585853403,
	ReturnMessage__ctor_m3407677129,
	ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m4261914537,
	ReturnMessage_get_Args_m4250458202,
	ReturnMessage_get_LogicalCallContext_m2795444970,
	ReturnMessage_get_MethodBase_m3826743104,
	ReturnMessage_get_MethodName_m3938791954,
	ReturnMessage_get_MethodSignature_m3174578052,
	ReturnMessage_get_Properties_m2160042302,
	ReturnMessage_get_TypeName_m752749841,
	ReturnMessage_get_Uri_m1271224052,
	ReturnMessage_set_Uri_m1515029532,
	ReturnMessage_get_Exception_m1147782502,
	ReturnMessage_get_OutArgs_m2626479784,
	ReturnMessage_get_ReturnValue_m337270066,
	ServerContextTerminatorSink__ctor_m499022319,
	ServerObjectTerminatorSink__ctor_m1659403710,
	StackBuilderSink__ctor_m576942155,
	SoapAttribute__ctor_m1306946280,
	SoapAttribute_get_UseAttribute_m1300208059,
	SoapAttribute_get_XmlNamespace_m1520332408,
	SoapAttribute_SetReflectionObject_m4117039302,
	SoapFieldAttribute__ctor_m348678892,
	SoapFieldAttribute_get_XmlElementName_m2947819553,
	SoapFieldAttribute_IsInteropXmlElement_m4172772882,
	SoapFieldAttribute_SetReflectionObject_m2500062081,
	SoapMethodAttribute__ctor_m3606291552,
	SoapMethodAttribute_get_UseAttribute_m2633944108,
	SoapMethodAttribute_get_XmlNamespace_m3002077767,
	SoapMethodAttribute_SetReflectionObject_m734446699,
	SoapParameterAttribute__ctor_m3166664116,
	SoapTypeAttribute__ctor_m1748412569,
	SoapTypeAttribute_get_UseAttribute_m4043801432,
	SoapTypeAttribute_get_XmlElementName_m3856270789,
	SoapTypeAttribute_get_XmlNamespace_m3158991572,
	SoapTypeAttribute_get_XmlTypeName_m3547608960,
	SoapTypeAttribute_get_XmlTypeNamespace_m2663572758,
	SoapTypeAttribute_get_IsInteropXmlElement_m4150796203,
	SoapTypeAttribute_get_IsInteropXmlType_m58579444,
	SoapTypeAttribute_SetReflectionObject_m3374443417,
	ObjRef__ctor_m2201506127,
	ObjRef__ctor_m516056283,
	ObjRef__cctor_m4053166273,
	ObjRef_get_IsReferenceToWellKnow_m2899488919,
	ObjRef_get_ChannelInfo_m2012758559,
	ObjRef_get_EnvoyInfo_m2369958823,
	ObjRef_set_EnvoyInfo_m475830191,
	ObjRef_get_TypeInfo_m2162062585,
	ObjRef_set_TypeInfo_m2940278911,
	ObjRef_get_URI_m3161471344,
	ObjRef_set_URI_m222403039,
	ObjRef_GetObjectData_m725082537,
	ObjRef_GetRealObject_m925820486,
	ObjRef_UpdateChannelInfo_m2391705399,
	ObjRef_get_ServerType_m56993821,
	ProviderData__ctor_m3415210490,
	ProviderData_CopyFrom_m3006936805,
	ProxyAttribute_CreateInstance_m3346069638,
	ProxyAttribute_CreateProxy_m2609399614,
	ProxyAttribute_GetPropertiesForNewContext_m2921967682,
	ProxyAttribute_IsContextOK_m2900797900,
	RealProxy__ctor_m4047939971,
	RealProxy__ctor_m1219875204,
	RealProxy__ctor_m643728101,
	RealProxy_InternalGetProxyType_m1757270186,
	RealProxy_GetProxiedType_m874982819,
	RealProxy_get_ObjectIdentity_m2464753590,
	RealProxy_InternalGetTransparentProxy_m3162398806,
	RealProxy_GetTransparentProxy_m2284490092,
	RealProxy_SetTargetDomain_m2331264622,
	RemotingProxy__ctor_m2148441992,
	RemotingProxy__ctor_m3935036851,
	RemotingProxy__cctor_m2396862393,
	RemotingProxy_get_TypeName_m1121862913,
	RemotingProxy_Finalize_m3734033920,
	RemotingConfiguration__cctor_m2311209514,
	RemotingConfiguration_get_ApplicationName_m672944369,
	RemotingConfiguration_set_ApplicationName_m792542103,
	RemotingConfiguration_get_ProcessId_m1656665657,
	RemotingConfiguration_LoadDefaultDelayedChannels_m618815769,
	RemotingConfiguration_IsRemotelyActivatedClientType_m503546012,
	RemotingConfiguration_RegisterActivatedClientType_m3041958400,
	RemotingConfiguration_RegisterActivatedServiceType_m1490903857,
	RemotingConfiguration_RegisterWellKnownClientType_m2781688209,
	RemotingConfiguration_RegisterWellKnownServiceType_m1677471129,
	RemotingConfiguration_RegisterChannelTemplate_m184465224,
	RemotingConfiguration_RegisterClientProviderTemplate_m2381947447,
	RemotingConfiguration_RegisterServerProviderTemplate_m3536257028,
	RemotingConfiguration_RegisterChannels_m261577395,
	RemotingConfiguration_RegisterTypes_m100450006,
	RemotingConfiguration_SetCustomErrorsMode_m677597509,
	RemotingException__ctor_m3721773766,
	RemotingException__ctor_m707171175,
	RemotingException__ctor_m3933416140,
	RemotingException__ctor_m3896880630,
	RemotingServices__cctor_m3778079804,
	RemotingServices_GetVirtualMethod_m652022987,
	RemotingServices_IsTransparentProxy_m279338587,
	RemotingServices_GetServerTypeForUri_m4277211104,
	RemotingServices_Unmarshal_m3017263782,
	RemotingServices_Unmarshal_m3419487221,
	RemotingServices_GetRealProxy_m280469471,
	RemotingServices_GetMethodBaseFromMethodMessage_m3573931760,
	RemotingServices_GetMethodBaseFromName_m621270620,
	RemotingServices_FindInterfaceMethod_m2755295661,
	RemotingServices_CreateClientProxy_m3730760804,
	RemotingServices_CreateClientProxy_m2260470495,
	RemotingServices_CreateClientProxyForContextBound_m1156816168,
	RemotingServices_GetIdentityForUri_m1525529537,
	RemotingServices_RemoveAppNameFromUri_m2783715653,
	RemotingServices_GetOrCreateClientIdentity_m1811768247,
	RemotingServices_GetClientChannelSinkChain_m493244133,
	RemotingServices_CreateWellKnownServerIdentity_m67274966,
	RemotingServices_RegisterServerIdentity_m3843373474,
	RemotingServices_GetProxyForRemoteObject_m2032832169,
	RemotingServices_GetRemoteObject_m401742822,
	RemotingServices_RegisterInternalChannels_m3328389237,
	RemotingServices_DisposeIdentity_m2311273193,
	RemotingServices_GetNormalizedUri_m2695347677,
	ServerIdentity__ctor_m532254845,
	ServerIdentity_get_ObjectType_m990614504,
	ServerIdentity_CreateObjRef_m3549161024,
	TrackingServices__cctor_m3046150965,
	TrackingServices_NotifyUnmarshaledObject_m909404297,
	SingleCallIdentity__ctor_m3629585548,
	SingletonIdentity__ctor_m641328939,
	SoapServices__cctor_m3893749875,
	SoapServices_get_XmlNsForClrTypeWithAssembly_m255710703,
	SoapServices_get_XmlNsForClrTypeWithNs_m2681437479,
	SoapServices_get_XmlNsForClrTypeWithNsAndAssembly_m3163592569,
	SoapServices_CodeXmlNamespaceForClrTypeNamespace_m2713593429,
	SoapServices_GetNameKey_m1699605387,
	SoapServices_GetAssemblyName_m3132444504,
	SoapServices_GetXmlElementForInteropType_m2691027766,
	SoapServices_GetXmlNamespaceForMethodCall_m3612287677,
	SoapServices_GetXmlNamespaceForMethodResponse_m2122162288,
	SoapServices_GetXmlTypeForInteropType_m3922130045,
	SoapServices_PreLoad_m3096575915,
	SoapServices_PreLoad_m2963871411,
	SoapServices_RegisterInteropXmlElement_m3273918327,
	SoapServices_RegisterInteropXmlType_m3782208866,
	SoapServices_EncodeNs_m3623626875,
	TypeInfo__ctor_m749005430,
	TypeEntry__ctor_m299864581,
	TypeEntry_get_AssemblyName_m1609650271,
	TypeEntry_set_AssemblyName_m72117852,
	TypeEntry_get_TypeName_m846966246,
	TypeEntry_set_TypeName_m3142650263,
	TypeInfo__ctor_m1222490081,
	TypeInfo_get_TypeName_m2953131114,
	WellKnownClientTypeEntry__ctor_m1247784010,
	WellKnownClientTypeEntry_get_ApplicationUrl_m3928198598,
	WellKnownClientTypeEntry_get_ObjectType_m586290458,
	WellKnownClientTypeEntry_get_ObjectUrl_m431903055,
	WellKnownClientTypeEntry_ToString_m3134498117,
	WellKnownServiceTypeEntry__ctor_m2537961663,
	WellKnownServiceTypeEntry_get_Mode_m724663084,
	WellKnownServiceTypeEntry_get_ObjectType_m256079547,
	WellKnownServiceTypeEntry_get_ObjectUri_m1845332693,
	WellKnownServiceTypeEntry_ToString_m1565416192,
	ArrayFixupRecord__ctor_m3836393882,
	ArrayFixupRecord_FixupImpl_m2851003963,
	BaseFixupRecord__ctor_m2609189912,
	BaseFixupRecord_DoFixup_m2617577611,
	DelayedFixupRecord__ctor_m4014918533,
	DelayedFixupRecord_FixupImpl_m1877769505,
	FixupRecord__ctor_m1957389285,
	FixupRecord_FixupImpl_m1620782233,
	FormatterConverter__ctor_m2135716800,
	FormatterConverter_Convert_m3684785726,
	FormatterConverter_ToBoolean_m479120073,
	FormatterConverter_ToInt16_m3479858435,
	FormatterConverter_ToInt32_m3722320607,
	FormatterConverter_ToInt64_m3595075555,
	FormatterConverter_ToString_m241015643,
	BinaryCommon__cctor_m3004868178,
	BinaryCommon_IsPrimitive_m2616910507,
	BinaryCommon_GetTypeFromCode_m131918506,
	BinaryCommon_SwapBytes_m2432230699,
	BinaryFormatter__ctor_m3146562200,
	BinaryFormatter__ctor_m2851663452,
	BinaryFormatter_get_DefaultSurrogateSelector_m854521798,
	BinaryFormatter_set_AssemblyFormat_m1189284053,
	BinaryFormatter_get_Binder_m2039458805,
	BinaryFormatter_get_Context_m3731928774,
	BinaryFormatter_get_SurrogateSelector_m3168333247,
	BinaryFormatter_get_FilterLevel_m2369297993,
	BinaryFormatter_Deserialize_m462089466,
	BinaryFormatter_NoCheckDeserialize_m4098423934,
	BinaryFormatter_ReadBinaryHeader_m206187517,
	MessageFormatter_ReadMethodCall_m2321634515,
	MessageFormatter_ReadMethodResponse_m3085665395,
	ObjectReader__ctor_m1273001858,
	ObjectReader_ReadObjectGraph_m3902162721,
	ObjectReader_ReadObjectGraph_m1685992435,
	ObjectReader_ReadNextObject_m795245237,
	ObjectReader_ReadNextObject_m2541422008,
	ObjectReader_get_CurrentObject_m360305727,
	ObjectReader_ReadObject_m199288650,
	ObjectReader_ReadAssembly_m1539730531,
	ObjectReader_ReadObjectInstance_m2151687868,
	ObjectReader_ReadRefTypeObjectInstance_m1891840481,
	ObjectReader_ReadObjectContent_m2317908275,
	ObjectReader_RegisterObject_m3571110076,
	ObjectReader_ReadStringIntance_m3521752300,
	ObjectReader_ReadGenericArray_m3349314585,
	ObjectReader_ReadBoxedPrimitiveTypeValue_m2878618397,
	ObjectReader_ReadArrayOfPrimitiveType_m1993495055,
	ObjectReader_BlockRead_m412730463,
	ObjectReader_ReadArrayOfObject_m3759609410,
	ObjectReader_ReadArrayOfString_m2353638103,
	ObjectReader_ReadSimpleArray_m3777056613,
	ObjectReader_ReadTypeMetadata_m1403168639,
	ObjectReader_ReadValue_m411602587,
	ObjectReader_SetObjectValue_m4161835366,
	ObjectReader_RecordFixup_m175190372,
	ObjectReader_GetDeserializationType_m1976087801,
	ObjectReader_ReadType_m3109025754,
	ObjectReader_ReadPrimitiveTypeValue_m1847732724,
	ArrayNullFiller__ctor_m1731819938,
	TypeMetadata__ctor_m3098590023,
	FormatterServices_GetUninitializedObject_m4187463930,
	FormatterServices_GetSafeUninitializedObject_m1378558216,
	MultiArrayFixupRecord__ctor_m649923862,
	MultiArrayFixupRecord_FixupImpl_m3758679554,
	ObjectManager__ctor_m3601834391,
	ObjectManager_DoFixups_m3290753670,
	ObjectManager_GetObjectRecord_m3668965817,
	ObjectManager_GetObject_m3360629357,
	ObjectManager_RaiseDeserializationEvent_m3355231024,
	ObjectManager_RaiseOnDeserializingEvent_m1847096661,
	ObjectManager_RaiseOnDeserializedEvent_m3014513403,
	ObjectManager_AddFixup_m2279770251,
	ObjectManager_RecordArrayElementFixup_m2313711327,
	ObjectManager_RecordArrayElementFixup_m1616535972,
	ObjectManager_RecordDelayedFixup_m3185204348,
	ObjectManager_RecordFixup_m228983078,
	ObjectManager_RegisterObjectInternal_m1854943049,
	ObjectManager_RegisterObject_m2926210872,
	ObjectRecord__ctor_m1438414803,
	ObjectRecord_SetMemberValue_m686143867,
	ObjectRecord_SetArrayValue_m1820344001,
	ObjectRecord_SetMemberValue_m2609372451,
	ObjectRecord_get_IsInstanceReady_m724320986,
	ObjectRecord_get_IsUnsolvedObjectReference_m841138941,
	ObjectRecord_get_IsRegistered_m355656857,
	ObjectRecord_DoFixups_m893086713,
	ObjectRecord_RemoveFixup_m2186927737,
	ObjectRecord_UnchainFixup_m1977281516,
	ObjectRecord_ChainFixup_m2043725430,
	ObjectRecord_LoadData_m68651069,
	ObjectRecord_get_HasPendingFixups_m3021207880,
	SerializationBinder__ctor_m1078952796,
	SerializationCallbacks__ctor_m3384310389,
	SerializationCallbacks__cctor_m1813319232,
	SerializationCallbacks_get_HasDeserializedCallbacks_m1082288191,
	SerializationCallbacks_GetMethodsByAttribute_m1078102764,
	SerializationCallbacks_Invoke_m1531280676,
	SerializationCallbacks_RaiseOnDeserializing_m1542357703,
	SerializationCallbacks_RaiseOnDeserialized_m1994674013,
	SerializationCallbacks_GetSerializationCallbacks_m845878201,
	CallbackHandler__ctor_m1461418459,
	CallbackHandler_Invoke_m1359829553,
	CallbackHandler_BeginInvoke_m2676435091,
	CallbackHandler_EndInvoke_m3197008604,
	SerializationEntry__ctor_m790429572_AdjustorThunk,
	SerializationEntry_get_Name_m2420372003_AdjustorThunk,
	SerializationEntry_get_Value_m511469057_AdjustorThunk,
	SerializationException__ctor_m2487770392,
	SerializationException__ctor_m543944324,
	SerializationException__ctor_m2473528184,
	SerializationInfo__ctor_m2387200337,
	SerializationInfo_AddValue_m759493278,
	SerializationInfo_GetValue_m2154590912,
	SerializationInfo_SetType_m4250326333,
	SerializationInfo_GetEnumerator_m2037478279,
	SerializationInfo_AddValue_m2914747780,
	SerializationInfo_AddValue_m3600311562,
	SerializationInfo_AddValue_m1250939204,
	SerializationInfo_AddValue_m1839889968,
	SerializationInfo_AddValue_m2293930930,
	SerializationInfo_AddValue_m1332533654,
	SerializationInfo_AddValue_m4204157667,
	SerializationInfo_AddValue_m289879288,
	SerializationInfo_GetBoolean_m921802057,
	SerializationInfo_GetInt16_m1776181798,
	SerializationInfo_GetInt32_m1778692989,
	SerializationInfo_GetInt64_m1823203327,
	SerializationInfo_GetString_m4161796836,
	SerializationInfoEnumerator__ctor_m998457667,
	SerializationInfoEnumerator_System_Collections_IEnumerator_get_Current_m968813573,
	SerializationInfoEnumerator_get_Current_m4238443440,
	SerializationInfoEnumerator_get_Name_m2588889941,
	SerializationInfoEnumerator_get_Value_m1906390789,
	SerializationInfoEnumerator_MoveNext_m1785816370,
	SerializationInfoEnumerator_Reset_m1174885035,
	StreamingContext__ctor_m3022477990_AdjustorThunk,
	StreamingContext__ctor_m312956436_AdjustorThunk,
	StreamingContext_get_State_m283394087_AdjustorThunk,
	StreamingContext_Equals_m933234336_AdjustorThunk,
	StreamingContext_GetHashCode_m2625011279_AdjustorThunk,
	RuntimeFieldHandle__ctor_m4172087370_AdjustorThunk,
	RuntimeFieldHandle_get_Value_m866086549_AdjustorThunk,
	RuntimeFieldHandle_GetObjectData_m2689093007_AdjustorThunk,
	RuntimeFieldHandle_Equals_m1997721335_AdjustorThunk,
	RuntimeFieldHandle_GetHashCode_m1029854444_AdjustorThunk,
	RuntimeMethodHandle__ctor_m1321128595_AdjustorThunk,
	RuntimeMethodHandle__ctor_m3935743526_AdjustorThunk,
	RuntimeMethodHandle_get_Value_m3451776408_AdjustorThunk,
	RuntimeMethodHandle_GetObjectData_m1453343446_AdjustorThunk,
	RuntimeMethodHandle_Equals_m694043567_AdjustorThunk,
	RuntimeMethodHandle_GetHashCode_m4152426864_AdjustorThunk,
	RuntimeTypeHandle__ctor_m105574446_AdjustorThunk,
	RuntimeTypeHandle_get_Value_m2841980210_AdjustorThunk,
	RuntimeTypeHandle_GetObjectData_m2737299150_AdjustorThunk,
	RuntimeTypeHandle_Equals_m3316377268_AdjustorThunk,
	RuntimeTypeHandle_GetHashCode_m229948238_AdjustorThunk,
	SByte_System_IConvertible_ToBoolean_m705044034_AdjustorThunk,
	SByte_System_IConvertible_ToByte_m1875040019_AdjustorThunk,
	SByte_System_IConvertible_ToChar_m2477566749_AdjustorThunk,
	SByte_System_IConvertible_ToDateTime_m3268135819_AdjustorThunk,
	SByte_System_IConvertible_ToDecimal_m3482021937_AdjustorThunk,
	SByte_System_IConvertible_ToDouble_m2507104885_AdjustorThunk,
	SByte_System_IConvertible_ToInt16_m297586731_AdjustorThunk,
	SByte_System_IConvertible_ToInt32_m1408482032_AdjustorThunk,
	SByte_System_IConvertible_ToInt64_m59703844_AdjustorThunk,
	SByte_System_IConvertible_ToSByte_m1395714978_AdjustorThunk,
	SByte_System_IConvertible_ToSingle_m3196659216_AdjustorThunk,
	SByte_System_IConvertible_ToType_m1425966275_AdjustorThunk,
	SByte_System_IConvertible_ToUInt16_m1156307957_AdjustorThunk,
	SByte_System_IConvertible_ToUInt32_m1630092365_AdjustorThunk,
	SByte_System_IConvertible_ToUInt64_m682207648_AdjustorThunk,
	SByte_CompareTo_m2779740121_AdjustorThunk,
	SByte_Equals_m4108147891_AdjustorThunk,
	SByte_GetHashCode_m3795742907_AdjustorThunk,
	SByte_CompareTo_m3951976715_AdjustorThunk,
	SByte_Equals_m2186545988_AdjustorThunk,
	SByte_Parse_m1765018877,
	SByte_Parse_m970256373,
	SByte_Parse_m512031140,
	SByte_TryParse_m2531638266,
	SByte_ToString_m2281364446_AdjustorThunk,
	SByte_ToString_m906610161_AdjustorThunk,
	SByte_ToString_m3415302163_AdjustorThunk,
	SByte_ToString_m1524252683_AdjustorThunk,
	AllowPartiallyTrustedCallersAttribute__ctor_m3140459627,
	CodeAccessPermission__ctor_m2433238787,
	CodeAccessPermission_Equals_m3953672351,
	CodeAccessPermission_GetHashCode_m539756730,
	CodeAccessPermission_ToString_m1334089401,
	CodeAccessPermission_Element_m2627688913,
	CodeAccessPermission_ThrowInvalidPermission_m3351613238,
	AsymmetricAlgorithm__ctor_m2287376669,
	AsymmetricAlgorithm_System_IDisposable_Dispose_m1738211272,
	AsymmetricAlgorithm_get_KeySize_m2661714387,
	AsymmetricAlgorithm_set_KeySize_m1791656823,
	AsymmetricAlgorithm_Clear_m3692737162,
	AsymmetricAlgorithm_GetNamedParam_m1740130169,
	AsymmetricKeyExchangeFormatter__ctor_m1023672232,
	AsymmetricSignatureDeformatter__ctor_m3988664358,
	AsymmetricSignatureFormatter__ctor_m1640818079,
	Base64Constants__cctor_m2107127471,
	CryptoConfig__cctor_m866309163,
	CryptoConfig_Initialize_m1734067327,
	CryptoConfig_CreateFromName_m231814076,
	CryptoConfig_CreateFromName_m3002182116,
	CryptoConfig_MapNameToOID_m3381960723,
	CryptoConfig_EncodeOID_m4065586783,
	CryptoConfig_EncodeLongNumber_m2216895718,
	CryptographicException__ctor_m2480918178,
	CryptographicException__ctor_m3631852793,
	CryptographicException__ctor_m3730179204,
	CryptographicException__ctor_m1959895321,
	CryptographicException__ctor_m487633063,
	CryptographicUnexpectedOperationException__ctor_m3738311784,
	CryptographicUnexpectedOperationException__ctor_m2082830875,
	CryptographicUnexpectedOperationException__ctor_m2071918291,
	CspParameters__ctor_m3702908281,
	CspParameters__ctor_m277089053,
	CspParameters__ctor_m289584655,
	CspParameters__ctor_m3792907619,
	CspParameters_get_Flags_m3417749665,
	CspParameters_set_Flags_m836186324,
	DES__ctor_m4233698758,
	DES__cctor_m3070684742,
	DES_Create_m3267808042,
	DES_Create_m1170661537,
	DES_IsWeakKey_m2312600013,
	DES_IsSemiWeakKey_m319738260,
	DES_get_Key_m268505297,
	DES_set_Key_m467923446,
	DESCryptoServiceProvider__ctor_m702944993,
	DESCryptoServiceProvider_CreateDecryptor_m3209468118,
	DESCryptoServiceProvider_CreateEncryptor_m3515578811,
	DESCryptoServiceProvider_GenerateIV_m4241668416,
	DESCryptoServiceProvider_GenerateKey_m3835533934,
	DESTransform__ctor_m3332211466,
	DESTransform__cctor_m2274726065,
	DESTransform_CipherFunct_m915571017,
	DESTransform_Permutation_m118653901,
	DESTransform_BSwap_m3115355213,
	DESTransform_SetKey_m1904852052,
	DESTransform_ProcessBlock_m3137656659,
	DESTransform_ECB_m1707917459,
	DESTransform_GetStrongKey_m3121830593,
	DSA__ctor_m536540930,
	DSA_Create_m2518185329,
	DSA_Create_m787108845,
	DSA_ZeroizePrivateKey_m3486340173,
	DSA_FromXmlString_m972829522,
	DSA_ToXmlString_m2192751897,
	DSACryptoServiceProvider__ctor_m1596488375,
	DSACryptoServiceProvider__ctor_m787349590,
	DSACryptoServiceProvider__ctor_m1947829840,
	DSACryptoServiceProvider__cctor_m1275456870,
	DSACryptoServiceProvider_Finalize_m278584479,
	DSACryptoServiceProvider_get_KeySize_m4020532355,
	DSACryptoServiceProvider_get_PublicOnly_m2126730996,
	DSACryptoServiceProvider_ExportParameters_m2011127564,
	DSACryptoServiceProvider_ImportParameters_m2807004223,
	DSACryptoServiceProvider_CreateSignature_m2245336314,
	DSACryptoServiceProvider_VerifySignature_m2722981406,
	DSACryptoServiceProvider_Dispose_m3939213751,
	DSACryptoServiceProvider_OnKeyGenerated_m1298791583,
	DSASignatureDeformatter__ctor_m1593180206,
	DSASignatureDeformatter__ctor_m1334927914,
	DSASignatureDeformatter_SetHashAlgorithm_m2463972379,
	DSASignatureDeformatter_SetKey_m2536713114,
	DSASignatureDeformatter_VerifySignature_m2106654280,
	DSASignatureDescription__ctor_m1909776961,
	DSASignatureFormatter__ctor_m955073984,
	DSASignatureFormatter_CreateSignature_m1272540439,
	DSASignatureFormatter_SetHashAlgorithm_m2407146058,
	DSASignatureFormatter_SetKey_m3442764047,
	HashAlgorithm__ctor_m584424507,
	HashAlgorithm_System_IDisposable_Dispose_m2507530935,
	HashAlgorithm_get_CanReuseTransform_m1058251057,
	HashAlgorithm_ComputeHash_m2877966704,
	HashAlgorithm_ComputeHash_m2249490520,
	HashAlgorithm_Create_m1468966163,
	HashAlgorithm_get_Hash_m2483127982,
	HashAlgorithm_get_HashSize_m2187072066,
	HashAlgorithm_Dispose_m397531773,
	HashAlgorithm_TransformBlock_m3993734057,
	HashAlgorithm_TransformFinalBlock_m1002009535,
	HMAC__ctor_m2121955378,
	HMAC_get_BlockSizeValue_m3123162733,
	HMAC_set_BlockSizeValue_m127665774,
	HMAC_set_HashName_m2430067301,
	HMAC_get_Key_m1979367088,
	HMAC_set_Key_m1846298930,
	HMAC_get_Block_m1079323359,
	HMAC_KeySetup_m347660145,
	HMAC_Dispose_m2279147198,
	HMAC_HashCore_m3360064661,
	HMAC_HashFinal_m1409071730,
	HMAC_Initialize_m3684336309,
	HMAC_Create_m2565963980,
	HMAC_Create_m3696050415,
	HMACMD5__ctor_m894105130,
	HMACMD5__ctor_m4027363171,
	HMACRIPEMD160__ctor_m2345098499,
	HMACRIPEMD160__ctor_m24840140,
	HMACSHA1__ctor_m1034545673,
	HMACSHA1__ctor_m4263724133,
	HMACSHA256__ctor_m3304286696,
	HMACSHA256__ctor_m32453075,
	HMACSHA384__ctor_m4041969840,
	HMACSHA384__ctor_m400753621,
	HMACSHA384__cctor_m1943010839,
	HMACSHA384_set_ProduceLegacyHmacValues_m1144342068,
	HMACSHA512__ctor_m805158160,
	HMACSHA512__ctor_m343337217,
	HMACSHA512__cctor_m652861467,
	HMACSHA512_set_ProduceLegacyHmacValues_m2734681597,
	KeyedHashAlgorithm__ctor_m2738969915,
	KeyedHashAlgorithm_Finalize_m1060205184,
	KeyedHashAlgorithm_get_Key_m3269097206,
	KeyedHashAlgorithm_set_Key_m1091398052,
	KeyedHashAlgorithm_Dispose_m3711504753,
	KeyedHashAlgorithm_ZeroizeKey_m1358463092,
	KeySizes__ctor_m2363976682,
	KeySizes_get_MaxSize_m2534537201,
	KeySizes_get_MinSize_m2751942049,
	KeySizes_get_SkipSize_m3329564690,
	KeySizes_IsLegal_m4141793984,
	KeySizes_IsLegalKeySize_m169156417,
	MACTripleDES__ctor_m3860786401,
	MACTripleDES_Setup_m1983097667,
	MACTripleDES_Finalize_m2823221823,
	MACTripleDES_Dispose_m3932196328,
	MACTripleDES_Initialize_m3226985574,
	MACTripleDES_HashCore_m2634199206,
	MACTripleDES_HashFinal_m538999467,
	MD5__ctor_m1323562619,
	MD5_Create_m2385042514,
	MD5_Create_m2869875857,
	MD5CryptoServiceProvider__ctor_m214915886,
	MD5CryptoServiceProvider__cctor_m1939351890,
	MD5CryptoServiceProvider_Finalize_m970178194,
	MD5CryptoServiceProvider_Dispose_m852817958,
	MD5CryptoServiceProvider_HashCore_m1311421323,
	MD5CryptoServiceProvider_HashFinal_m2571030067,
	MD5CryptoServiceProvider_Initialize_m2823586746,
	MD5CryptoServiceProvider_ProcessBlock_m895304490,
	MD5CryptoServiceProvider_ProcessFinalBlock_m2821355884,
	MD5CryptoServiceProvider_AddLength_m512335437,
	RandomNumberGenerator__ctor_m3939249654,
	RandomNumberGenerator_Create_m1431169500,
	RandomNumberGenerator_Create_m3503708628,
	RC2__ctor_m4204072771,
	RC2_Create_m4004729600,
	RC2_Create_m3881730986,
	RC2_get_EffectiveKeySize_m904204713,
	RC2_get_KeySize_m1880714395,
	RC2_set_KeySize_m1090717279,
	RC2CryptoServiceProvider__ctor_m653119750,
	RC2CryptoServiceProvider_get_EffectiveKeySize_m650737987,
	RC2CryptoServiceProvider_CreateDecryptor_m373084290,
	RC2CryptoServiceProvider_CreateEncryptor_m3935846208,
	RC2CryptoServiceProvider_GenerateIV_m4256672338,
	RC2CryptoServiceProvider_GenerateKey_m1091248491,
	RC2Transform__ctor_m2270872876,
	RC2Transform__cctor_m3954912500,
	RC2Transform_ECB_m777958400,
	Rijndael__ctor_m569547863,
	Rijndael_Create_m2043577928,
	Rijndael_Create_m256024357,
	RijndaelManaged__ctor_m1859549111,
	RijndaelManaged_GenerateIV_m1123037081,
	RijndaelManaged_GenerateKey_m423570930,
	RijndaelManaged_CreateDecryptor_m4215947421,
	RijndaelManaged_CreateEncryptor_m842685846,
	RijndaelManagedTransform__ctor_m1161577055,
	RijndaelManagedTransform_System_IDisposable_Dispose_m3156143058,
	RijndaelManagedTransform_get_CanReuseTransform_m2765034471,
	RijndaelManagedTransform_TransformBlock_m3409590100,
	RijndaelManagedTransform_TransformFinalBlock_m2589306319,
	RijndaelTransform__ctor_m2159698755,
	RijndaelTransform__cctor_m4224639698,
	RijndaelTransform_Clear_m923483040,
	RijndaelTransform_ECB_m1043320970,
	RijndaelTransform_SubByte_m379037516,
	RijndaelTransform_Encrypt128_m193641953,
	RijndaelTransform_Encrypt192_m2076300861,
	RijndaelTransform_Encrypt256_m2198473672,
	RijndaelTransform_Decrypt128_m2752989474,
	RijndaelTransform_Decrypt192_m3716986189,
	RijndaelTransform_Decrypt256_m3786109318,
	RIPEMD160__ctor_m458952317,
	RIPEMD160Managed__ctor_m4211343806,
	RIPEMD160Managed_Initialize_m3469028291,
	RIPEMD160Managed_HashCore_m238041734,
	RIPEMD160Managed_HashFinal_m1031199659,
	RIPEMD160Managed_Finalize_m1155918876,
	RIPEMD160Managed_ProcessBlock_m1882667436,
	RIPEMD160Managed_Compress_m2045615632,
	RIPEMD160Managed_CompressFinal_m4170573773,
	RIPEMD160Managed_ROL_m1090185248,
	RIPEMD160Managed_F_m1464279206,
	RIPEMD160Managed_G_m1667672529,
	RIPEMD160Managed_H_m3299186924,
	RIPEMD160Managed_I_m1554323262,
	RIPEMD160Managed_J_m4119682292,
	RIPEMD160Managed_FF_m994828637,
	RIPEMD160Managed_GG_m1861900783,
	RIPEMD160Managed_HH_m346411911,
	RIPEMD160Managed_II_m2684363707,
	RIPEMD160Managed_JJ_m2386545611,
	RIPEMD160Managed_FFF_m2028229179,
	RIPEMD160Managed_GGG_m137516215,
	RIPEMD160Managed_HHH_m1723579147,
	RIPEMD160Managed_III_m2117715712,
	RIPEMD160Managed_JJJ_m2587022283,
	RNGCryptoServiceProvider__ctor_m2029700126,
	RNGCryptoServiceProvider__cctor_m1919301485,
	RNGCryptoServiceProvider_Check_m552544446,
	RNGCryptoServiceProvider_RngOpen_m2616908683,
	RNGCryptoServiceProvider_RngInitialize_m2618561254,
	RNGCryptoServiceProvider_RngGetBytes_m918087422,
	RNGCryptoServiceProvider_RngClose_m533018497,
	RNGCryptoServiceProvider_GetBytes_m2938911782,
	RNGCryptoServiceProvider_GetNonZeroBytes_m2211806560,
	RNGCryptoServiceProvider_Finalize_m3612537545,
	RSA__ctor_m2516576077,
	RSA_Create_m2098378378,
	RSA_Create_m2167317622,
	RSA_ZeroizePrivateKey_m2699768189,
	RSA_FromXmlString_m3910835382,
	RSA_ToXmlString_m1368893058,
	RSACryptoServiceProvider__ctor_m494920222,
	RSACryptoServiceProvider__ctor_m1834871502,
	RSACryptoServiceProvider__ctor_m2651361429,
	RSACryptoServiceProvider__cctor_m1656044272,
	RSACryptoServiceProvider_Common_m971604078,
	RSACryptoServiceProvider_Finalize_m581596575,
	RSACryptoServiceProvider_get_KeySize_m14171628,
	RSACryptoServiceProvider_get_PublicOnly_m1322291509,
	RSACryptoServiceProvider_DecryptValue_m494881412,
	RSACryptoServiceProvider_EncryptValue_m3362633146,
	RSACryptoServiceProvider_ExportParameters_m2246352314,
	RSACryptoServiceProvider_ImportParameters_m2588335021,
	RSACryptoServiceProvider_Dispose_m2107529962,
	RSACryptoServiceProvider_OnKeyGenerated_m1365285689,
	RSAPKCS1KeyExchangeFormatter__ctor_m1245335096,
	RSAPKCS1KeyExchangeFormatter_CreateKeyExchange_m1314284802,
	RSAPKCS1KeyExchangeFormatter_SetRSAKey_m1965546122,
	RSAPKCS1SHA1SignatureDescription__ctor_m2106874314,
	RSAPKCS1SignatureDeformatter__ctor_m1986341172,
	RSAPKCS1SignatureDeformatter__ctor_m2532782780,
	RSAPKCS1SignatureDeformatter_SetHashAlgorithm_m1997399751,
	RSAPKCS1SignatureDeformatter_SetKey_m539761269,
	RSAPKCS1SignatureDeformatter_VerifySignature_m3268121280,
	RSAPKCS1SignatureFormatter__ctor_m1986635058,
	RSAPKCS1SignatureFormatter_CreateSignature_m2607393667,
	RSAPKCS1SignatureFormatter_SetHashAlgorithm_m2984544991,
	RSAPKCS1SignatureFormatter_SetKey_m2601050193,
	SHA1__ctor_m1969536635,
	SHA1_Create_m3946979285,
	SHA1_Create_m974371071,
	SHA1CryptoServiceProvider__ctor_m1967520929,
	SHA1CryptoServiceProvider_Finalize_m3718267469,
	SHA1CryptoServiceProvider_Dispose_m105661239,
	SHA1CryptoServiceProvider_HashCore_m2234117083,
	SHA1CryptoServiceProvider_HashFinal_m3803579073,
	SHA1CryptoServiceProvider_Initialize_m2261370112,
	SHA1Internal__ctor_m2994753244,
	SHA1Internal_HashCore_m1717092929,
	SHA1Internal_HashFinal_m1355532083,
	SHA1Internal_Initialize_m546222499,
	SHA1Internal_ProcessBlock_m4072397381,
	SHA1Internal_InitialiseBuff_m2649170437,
	SHA1Internal_FillBuff_m2630535725,
	SHA1Internal_ProcessFinalBlock_m2707203005,
	SHA1Internal_AddLength_m2262981079,
	SHA1Managed__ctor_m1921984796,
	SHA1Managed_HashCore_m2837280064,
	SHA1Managed_HashFinal_m2353453359,
	SHA1Managed_Initialize_m1342241130,
	SHA256__ctor_m4240254819,
	SHA256_Create_m462422102,
	SHA256_Create_m2238749554,
	SHA256Managed__ctor_m4106396050,
	SHA256Managed_HashCore_m3408643825,
	SHA256Managed_HashFinal_m3933879613,
	SHA256Managed_Initialize_m204270072,
	SHA256Managed_ProcessBlock_m753555195,
	SHA256Managed_ProcessFinalBlock_m1121500207,
	SHA256Managed_AddLength_m4284553060,
	SHA384__ctor_m334659379,
	SHA384_Create_m526495048,
	SHA384_Create_m4239756223,
	SHA384Managed__ctor_m3170837026,
	SHA384Managed_Initialize_m1476192725,
	SHA384Managed_Initialize_m1847819359,
	SHA384Managed_HashCore_m4173033847,
	SHA384Managed_HashFinal_m1753937062,
	SHA384Managed_update_m1141165968,
	SHA384Managed_processWord_m2618477847,
	SHA384Managed_unpackWord_m1957689207,
	SHA384Managed_adjustByteCounts_m566288436,
	SHA384Managed_processLength_m658249786,
	SHA384Managed_processBlock_m684140079,
	SHA512__ctor_m4036499772,
	SHA512_Create_m456504481,
	SHA512_Create_m1101996406,
	SHA512Managed__ctor_m3022883860,
	SHA512Managed_Initialize_m3277525724,
	SHA512Managed_Initialize_m766809252,
	SHA512Managed_HashCore_m2989249322,
	SHA512Managed_HashFinal_m2508134175,
	SHA512Managed_update_m1429757441,
	SHA512Managed_processWord_m4094117712,
	SHA512Managed_unpackWord_m3213888570,
	SHA512Managed_adjustByteCounts_m1398880188,
	SHA512Managed_processLength_m1576722253,
	SHA512Managed_processBlock_m2460866755,
	SHA512Managed_rotateRight_m805706266,
	SHA512Managed_Ch_m677772777,
	SHA512Managed_Maj_m423045056,
	SHA512Managed_Sum0_m502557237,
	SHA512Managed_Sum1_m3199977649,
	SHA512Managed_Sigma0_m179912122,
	SHA512Managed_Sigma1_m842511038,
	SHAConstants__cctor_m4272201901,
	SignatureDescription__ctor_m756568113,
	SignatureDescription_set_DeformatterAlgorithm_m2445338640,
	SignatureDescription_set_DigestAlgorithm_m4083166638,
	SignatureDescription_set_FormatterAlgorithm_m2903154629,
	SignatureDescription_set_KeyAlgorithm_m1930616075,
	SymmetricAlgorithm__ctor_m3530978002,
	SymmetricAlgorithm_System_IDisposable_Dispose_m2429136725,
	SymmetricAlgorithm_Finalize_m475352580,
	SymmetricAlgorithm_Clear_m4086940160,
	SymmetricAlgorithm_Dispose_m3284301350,
	SymmetricAlgorithm_get_BlockSize_m665076769,
	SymmetricAlgorithm_set_BlockSize_m2683310524,
	SymmetricAlgorithm_get_FeedbackSize_m480120971,
	SymmetricAlgorithm_get_IV_m1566235590,
	SymmetricAlgorithm_set_IV_m283538311,
	SymmetricAlgorithm_get_Key_m3263732574,
	SymmetricAlgorithm_set_Key_m2615539943,
	SymmetricAlgorithm_get_KeySize_m3842476726,
	SymmetricAlgorithm_set_KeySize_m3692049243,
	SymmetricAlgorithm_get_LegalKeySizes_m2105996708,
	SymmetricAlgorithm_get_Mode_m580803141,
	SymmetricAlgorithm_set_Mode_m1104711670,
	SymmetricAlgorithm_get_Padding_m540812409,
	SymmetricAlgorithm_set_Padding_m3038551471,
	SymmetricAlgorithm_CreateDecryptor_m224668375,
	SymmetricAlgorithm_CreateEncryptor_m970802849,
	SymmetricAlgorithm_Create_m2890948765,
	ToBase64Transform_System_IDisposable_Dispose_m471317583,
	ToBase64Transform_Finalize_m140506812,
	ToBase64Transform_get_CanReuseTransform_m3967355810,
	ToBase64Transform_get_InputBlockSize_m3765814599,
	ToBase64Transform_get_OutputBlockSize_m3044525699,
	ToBase64Transform_Dispose_m2612407126,
	ToBase64Transform_TransformBlock_m1712575818,
	ToBase64Transform_InternalTransformBlock_m1909386603,
	ToBase64Transform_TransformFinalBlock_m3042863047,
	ToBase64Transform_InternalTransformFinalBlock_m1455808496,
	TripleDES__ctor_m1962223256,
	TripleDES_get_Key_m3397880201,
	TripleDES_set_Key_m3691393715,
	TripleDES_IsWeakKey_m2759836646,
	TripleDES_Create_m1188329831,
	TripleDES_Create_m274258073,
	TripleDESCryptoServiceProvider__ctor_m4290068524,
	TripleDESCryptoServiceProvider_GenerateIV_m2268505232,
	TripleDESCryptoServiceProvider_GenerateKey_m3906262374,
	TripleDESCryptoServiceProvider_CreateDecryptor_m2003987385,
	TripleDESCryptoServiceProvider_CreateEncryptor_m797239158,
	TripleDESTransform__ctor_m36363670,
	TripleDESTransform_ECB_m3111392017,
	TripleDESTransform_GetStrongKey_m1266123329,
	X509Certificate__ctor_m3407924276,
	X509Certificate__ctor_m1548315145,
	X509Certificate__ctor_m3676038623,
	X509Certificate__ctor_m2718650002,
	X509Certificate_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m3612759154,
	X509Certificate_System_Runtime_Serialization_ISerializable_GetObjectData_m2599848675,
	X509Certificate_tostr_m2221058328,
	X509Certificate_Equals_m56391754,
	X509Certificate_GetCertHash_m836096880,
	X509Certificate_GetCertHashString_m938235395,
	X509Certificate_GetEffectiveDateString_m597661879,
	X509Certificate_GetExpirationDateString_m1031306912,
	X509Certificate_GetHashCode_m3873304085,
	X509Certificate_GetIssuerName_m985760924,
	X509Certificate_GetName_m839418740,
	X509Certificate_GetPublicKey_m13902926,
	X509Certificate_GetRawCertData_m139142862,
	X509Certificate_ToString_m3901050003,
	X509Certificate_ToString_m2906291789,
	X509Certificate_get_Issuer_m1004229346,
	X509Certificate_get_Subject_m2350827574,
	X509Certificate_Equals_m3424353702,
	X509Certificate_Import_m2684987799,
	X509Certificate_Reset_m4105901662,
	SecurityPermission__ctor_m4197502246,
	SecurityPermission_set_Flags_m339644,
	SecurityPermission_IsUnrestricted_m3354178782,
	SecurityPermission_IsSubsetOf_m566105140,
	SecurityPermission_ToXml_m1610766876,
	SecurityPermission_IsEmpty_m698687277,
	SecurityPermission_Cast_m2977698443,
	SecurityPermissionAttribute_set_SkipVerification_m3308373995,
	StrongNamePublicKeyBlob_Equals_m3462806622,
	StrongNamePublicKeyBlob_GetHashCode_m1621593698,
	StrongNamePublicKeyBlob_ToString_m3532563419,
	PermissionSet__ctor_m771135781,
	PermissionSet__ctor_m230458726,
	PermissionSet_set_DeclarativeSecurity_m644410636,
	PermissionSet_CreateFromBinaryFormat_m3580799913,
	ApplicationTrust__ctor_m3796110394,
	Evidence__ctor_m226600667,
	Evidence_get_Count_m3051625439,
	Evidence_get_SyncRoot_m2744837828,
	Evidence_get_HostEvidenceList_m3783616253,
	Evidence_get_AssemblyEvidenceList_m2815161303,
	Evidence_CopyTo_m1202507747,
	Evidence_Equals_m3868193673,
	Evidence_GetEnumerator_m2562761046,
	Evidence_GetHashCode_m3660855014,
	EvidenceEnumerator__ctor_m558010460,
	EvidenceEnumerator_MoveNext_m113582795,
	EvidenceEnumerator_Reset_m2273931871,
	EvidenceEnumerator_get_Current_m1416526449,
	Hash__ctor_m488556517,
	Hash__ctor_m699072506,
	Hash_GetObjectData_m3237225528,
	Hash_ToString_m2275256858,
	Hash_GetData_m1423422691,
	StrongName_get_Name_m984799822,
	StrongName_get_PublicKey_m276363371,
	StrongName_get_Version_m497732567,
	StrongName_Equals_m1955316562,
	StrongName_GetHashCode_m4077531007,
	StrongName_ToString_m3570293456,
	WindowsIdentity__ctor_m1811963814,
	WindowsIdentity__cctor_m4102338034,
	WindowsIdentity_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1019467441,
	WindowsIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m1044464041,
	WindowsIdentity_Dispose_m2729980567,
	WindowsIdentity_GetCurrentToken_m2751916831,
	WindowsIdentity_GetTokenName_m2704573011,
	SecurityContext__ctor_m1611332893,
	SecurityContext__ctor_m2441641144,
	SecurityContext_Capture_m2143019511,
	SecurityContext_get_FlowSuppressed_m4084430719,
	SecurityContext_get_CompressedStack_m925330154,
	SecurityCriticalAttribute__ctor_m4283676607,
	SecurityElement__ctor_m359142113,
	SecurityElement__ctor_m4136117828,
	SecurityElement__cctor_m1925771841,
	SecurityElement_get_Children_m4090366312,
	SecurityElement_get_Tag_m1217815539,
	SecurityElement_set_Text_m1068735059,
	SecurityElement_AddAttribute_m2785847673,
	SecurityElement_AddChild_m3042363596,
	SecurityElement_Escape_m314020543,
	SecurityElement_Unescape_m3061570899,
	SecurityElement_IsValidAttributeName_m779754135,
	SecurityElement_IsValidAttributeValue_m1368665728,
	SecurityElement_IsValidTag_m2084804419,
	SecurityElement_IsValidText_m3922265080,
	SecurityElement_SearchForChildByTag_m690528742,
	SecurityElement_ToString_m1864728802,
	SecurityElement_ToXml_m3571179917,
	SecurityElement_GetAttribute_m4050327145,
	SecurityAttribute__ctor_m453957305,
	SecurityAttribute_get_Name_m3885903818,
	SecurityAttribute_get_Value_m1764543067,
	SecurityException__ctor_m1530694241,
	SecurityException__ctor_m78750685,
	SecurityException__ctor_m4201478182,
	SecurityException_get_Demanded_m3265310211,
	SecurityException_get_FirstPermissionThatFailed_m1290931100,
	SecurityException_get_PermissionState_m3093263458,
	SecurityException_get_PermissionType_m2440776481,
	SecurityException_get_GrantedSet_m3491710904,
	SecurityException_get_RefusedSet_m556824700,
	SecurityException_GetObjectData_m3040244220,
	SecurityException_ToString_m241756719,
	SecurityFrame__ctor_m1941352356_AdjustorThunk,
	SecurityFrame__GetSecurityStack_m1571368125,
	SecurityFrame_InitFromRuntimeFrame_m819564435_AdjustorThunk,
	SecurityFrame_get_Assembly_m630022476_AdjustorThunk,
	SecurityFrame_get_Domain_m2621428839_AdjustorThunk,
	SecurityFrame_ToString_m961788698_AdjustorThunk,
	SecurityFrame_GetStack_m176825473,
	SecurityManager__cctor_m3229916011,
	SecurityManager_get_SecurityEnabled_m4152097806,
	SecurityManager_Decode_m2324823191,
	SecurityManager_Decode_m1619407822,
	SecuritySafeCriticalAttribute__ctor_m1104744884,
	SuppressUnmanagedCodeSecurityAttribute__ctor_m3765472890,
	UnverifiableCodeAttribute__ctor_m3350723594,
	SerializableAttribute__ctor_m1148700181,
	Single_System_IConvertible_ToBoolean_m720126349_AdjustorThunk,
	Single_System_IConvertible_ToByte_m2803268345_AdjustorThunk,
	Single_System_IConvertible_ToChar_m1561638046_AdjustorThunk,
	Single_System_IConvertible_ToDateTime_m3628856099_AdjustorThunk,
	Single_System_IConvertible_ToDecimal_m2695673545_AdjustorThunk,
	Single_System_IConvertible_ToDouble_m128862438_AdjustorThunk,
	Single_System_IConvertible_ToInt16_m818780161_AdjustorThunk,
	Single_System_IConvertible_ToInt32_m1944505068_AdjustorThunk,
	Single_System_IConvertible_ToInt64_m1593285566_AdjustorThunk,
	Single_System_IConvertible_ToSByte_m627657193_AdjustorThunk,
	Single_System_IConvertible_ToSingle_m4238518480_AdjustorThunk,
	Single_System_IConvertible_ToType_m3289199070_AdjustorThunk,
	Single_System_IConvertible_ToUInt16_m3232958982_AdjustorThunk,
	Single_System_IConvertible_ToUInt32_m2346289835_AdjustorThunk,
	Single_System_IConvertible_ToUInt64_m2640176904_AdjustorThunk,
	Single_CompareTo_m765087958_AdjustorThunk,
	Single_Equals_m1857255371_AdjustorThunk,
	Single_CompareTo_m910502481_AdjustorThunk,
	Single_Equals_m2717732029_AdjustorThunk,
	Single_GetHashCode_m2476090687_AdjustorThunk,
	Single_IsInfinity_m3098138255,
	Single_IsNaN_m3455339168,
	Single_IsNegativeInfinity_m1281133443,
	Single_IsPositiveInfinity_m570566160,
	Single_Parse_m3254821835,
	Single_ToString_m1479228193_AdjustorThunk,
	Single_ToString_m375149042_AdjustorThunk,
	Single_ToString_m519745137_AdjustorThunk,
	StackOverflowException__ctor_m2946028495,
	StackOverflowException__ctor_m2490333010,
	StackOverflowException__ctor_m1775831137,
	String__ctor_m3613415962,
	String__ctor_m1853482631,
	String__ctor_m885689136,
	String__ctor_m1709700635,
	String__cctor_m1603112650,
	String_System_IConvertible_ToBoolean_m2672471675,
	String_System_IConvertible_ToByte_m2760073804,
	String_System_IConvertible_ToChar_m3263129551,
	String_System_IConvertible_ToDateTime_m2805257558,
	String_System_IConvertible_ToDecimal_m2944717908,
	String_System_IConvertible_ToDouble_m2349890820,
	String_System_IConvertible_ToInt16_m1847522624,
	String_System_IConvertible_ToInt32_m3872748217,
	String_System_IConvertible_ToInt64_m533042989,
	String_System_IConvertible_ToSByte_m2535500817,
	String_System_IConvertible_ToSingle_m382301513,
	String_System_IConvertible_ToType_m862140462,
	String_System_IConvertible_ToUInt16_m1585851494,
	String_System_IConvertible_ToUInt32_m2467996462,
	String_System_IConvertible_ToUInt64_m2032133172,
	String_System_Collections_Generic_IEnumerableU3CcharU3E_GetEnumerator_m811657719,
	String_System_Collections_IEnumerable_GetEnumerator_m3147391984,
	String_Equals_m237333880,
	String_Equals_m3008033655,
	String_Equals_m1775812447,
	String_get_Chars_m1464339204,
	String_Clone_m2585077494,
	String_CopyTo_m892774036,
	String_ToCharArray_m3705451209,
	String_ToCharArray_m3268618965,
	String_Split_m1027048911,
	String_Split_m1944641878,
	String_Split_m752880514,
	String_Split_m2170789228,
	String_Split_m882935073,
	String_Substring_m1464020713,
	String_Substring_m226770159,
	String_SubstringUnchecked_m4096211738,
	String_Trim_m1844077571,
	String_Trim_m1892663701,
	String_TrimStart_m923266555,
	String_TrimEnd_m1178919651,
	String_FindNotWhiteSpace_m1711185691,
	String_FindNotInTable_m2137115857,
	String_Compare_m2471229855,
	String_Compare_m4147948046,
	String_Compare_m261071192,
	String_Compare_m2230433984,
	String_CompareTo_m3731283673,
	String_CompareTo_m2261209686,
	String_CompareOrdinal_m1991598530,
	String_CompareOrdinalUnchecked_m461278756,
	String_CompareOrdinalCaseInsensitiveUnchecked_m3635395240,
	String_EndsWith_m127493516,
	String_IndexOfAny_m1706062837,
	String_IndexOfAny_m134417335,
	String_IndexOfAny_m2260375589,
	String_IndexOfAnyUnchecked_m4046918375,
	String_IndexOf_m479525909,
	String_IndexOf_m944552323,
	String_IndexOfOrdinal_m2643824054,
	String_IndexOfOrdinalUnchecked_m639401954,
	String_IndexOfOrdinalIgnoreCaseUnchecked_m4077622449,
	String_IndexOf_m3894111918,
	String_IndexOf_m782950928,
	String_IndexOf_m3950528921,
	String_IndexOfUnchecked_m212985164,
	String_IndexOf_m2070038370,
	String_IndexOf_m265181594,
	String_IndexOf_m2102297132,
	String_LastIndexOfAny_m1287077974,
	String_LastIndexOfAnyUnchecked_m2313880315,
	String_LastIndexOf_m1732390103,
	String_LastIndexOf_m3891998254,
	String_LastIndexOf_m3705240145,
	String_LastIndexOfUnchecked_m1515191963,
	String_LastIndexOf_m2119563327,
	String_LastIndexOf_m794187726,
	String_IsNullOrEmpty_m1029040816,
	String_PadRight_m650210994,
	String_StartsWith_m2597381112,
	String_Replace_m3591414543,
	String_Replace_m3746132805,
	String_ReplaceUnchecked_m3373930118,
	String_ReplaceFallback_m3159344605,
	String_Remove_m633097816,
	String_ToLower_m2279212582,
	String_ToLower_m329058893,
	String_ToLowerInvariant_m3394568761,
	String_ToString_m1847718173,
	String_ToString_m1753332709,
	String_Format_m3184672671,
	String_Format_m88592014,
	String_Format_m3597410483,
	String_Format_m527561873,
	String_Format_m949849763,
	String_FormatHelper_m266143647,
	String_Concat_m2789586187,
	String_Concat_m1921247215,
	String_Concat_m3401430135,
	String_Concat_m800460250,
	String_Concat_m2337014626,
	String_Concat_m406606968,
	String_Concat_m2284411301,
	String_ConcatInternal_m776915844,
	String_Insert_m2831565133,
	String_Join_m3868188132,
	String_Join_m3179186149,
	String_JoinUnchecked_m977872119,
	String_get_Length_m198470169,
	String_ParseFormatSpecifier_m2647998464,
	String_ParseDecimal_m4080306657,
	String_InternalSetChar_m1298932216,
	String_InternalSetLength_m31814220,
	String_GetHashCode_m2446182979,
	String_GetCaseInsensitiveHashCode_m2544214933,
	String_CreateString_m2185920425,
	String_CreateString_m1582414959,
	String_CreateString_m2675909340,
	String_CreateString_m1994743835,
	String_CreateString_m2362463515,
	String_CreateString_m1821258248,
	String_CreateString_m3540783044,
	String_CreateString_m3131114500,
	String_memcpy4_m4200798455,
	String_memcpy2_m1208599571,
	String_memcpy1_m1226925708,
	String_memcpy_m1488033619,
	String_CharCopy_m2708895260,
	String_CharCopyReverse_m3113915607,
	String_CharCopy_m322526068,
	String_CharCopy_m2594291286,
	String_CharCopyReverse_m987294522,
	String_InternalSplit_m1810656421,
	String_InternalAllocateStr_m763533588,
	String_op_Equality_m2935810047,
	String_op_Inequality_m124341459,
	StringComparer__ctor_m3312622601,
	StringComparer__cctor_m799052589,
	StringComparer_get_InvariantCultureIgnoreCase_m2486156775,
	StringComparer_Compare_m561823171,
	StringComparer_Equals_m367569743,
	StringComparer_GetHashCode_m3001431150,
	SystemException__ctor_m3110433673,
	SystemException__ctor_m1383525515,
	SystemException__ctor_m2606713748,
	SystemException__ctor_m956841773,
	ASCIIEncoding__ctor_m2577114027,
	ASCIIEncoding_GetByteCount_m4032353408,
	ASCIIEncoding_GetByteCount_m1773219795,
	ASCIIEncoding_GetBytes_m199792205,
	ASCIIEncoding_GetBytes_m2887481599,
	ASCIIEncoding_GetBytes_m4210595265,
	ASCIIEncoding_GetBytes_m3306760563,
	ASCIIEncoding_GetCharCount_m3004304767,
	ASCIIEncoding_GetChars_m1246452100,
	ASCIIEncoding_GetChars_m4136426329,
	ASCIIEncoding_GetMaxByteCount_m2751391280,
	ASCIIEncoding_GetMaxCharCount_m2837964160,
	ASCIIEncoding_GetString_m2942901871,
	ASCIIEncoding_GetBytes_m1861174925,
	ASCIIEncoding_GetByteCount_m1104398450,
	ASCIIEncoding_GetDecoder_m4195996369,
	Decoder__ctor_m2119960144,
	Decoder_set_Fallback_m1774963671,
	Decoder_get_FallbackBuffer_m3655831519,
	DecoderExceptionFallback__ctor_m3930142307,
	DecoderExceptionFallback_CreateFallbackBuffer_m2504774350,
	DecoderExceptionFallback_Equals_m1611656537,
	DecoderExceptionFallback_GetHashCode_m1598361681,
	DecoderExceptionFallbackBuffer__ctor_m498479446,
	DecoderExceptionFallbackBuffer_get_Remaining_m398593133,
	DecoderExceptionFallbackBuffer_Fallback_m312317784,
	DecoderExceptionFallbackBuffer_GetNextChar_m1324206150,
	DecoderFallback__ctor_m1472523671,
	DecoderFallback__cctor_m4224747013,
	DecoderFallback_get_ExceptionFallback_m763182818,
	DecoderFallback_get_ReplacementFallback_m389680609,
	DecoderFallback_get_StandardSafeFallback_m1965538229,
	DecoderFallbackBuffer__ctor_m2657398271,
	DecoderFallbackBuffer_Reset_m1629595938,
	DecoderFallbackException__ctor_m4074062987,
	DecoderFallbackException__ctor_m346326103,
	DecoderFallbackException__ctor_m4264915677,
	DecoderReplacementFallback__ctor_m3322239076,
	DecoderReplacementFallback__ctor_m2067492076,
	DecoderReplacementFallback_get_DefaultString_m2686184964,
	DecoderReplacementFallback_CreateFallbackBuffer_m2039931449,
	DecoderReplacementFallback_Equals_m2356168832,
	DecoderReplacementFallback_GetHashCode_m4267878740,
	DecoderReplacementFallbackBuffer__ctor_m2624753494,
	DecoderReplacementFallbackBuffer_get_Remaining_m211987237,
	DecoderReplacementFallbackBuffer_Fallback_m1284124031,
	DecoderReplacementFallbackBuffer_GetNextChar_m2110169965,
	DecoderReplacementFallbackBuffer_Reset_m1786585707,
	EncoderExceptionFallback__ctor_m2465653200,
	EncoderExceptionFallback_CreateFallbackBuffer_m2873066032,
	EncoderExceptionFallback_Equals_m3426853426,
	EncoderExceptionFallback_GetHashCode_m1526303002,
	EncoderExceptionFallbackBuffer__ctor_m3193891897,
	EncoderExceptionFallbackBuffer_get_Remaining_m588064435,
	EncoderExceptionFallbackBuffer_Fallback_m1188975563,
	EncoderExceptionFallbackBuffer_Fallback_m777326293,
	EncoderExceptionFallbackBuffer_GetNextChar_m2105462580,
	EncoderFallback__ctor_m948719623,
	EncoderFallback__cctor_m4128339685,
	EncoderFallback_get_ExceptionFallback_m2915221018,
	EncoderFallback_get_ReplacementFallback_m1381460304,
	EncoderFallback_get_StandardSafeFallback_m1287253668,
	EncoderFallbackBuffer__ctor_m3828467897,
	EncoderFallbackException__ctor_m1749718132,
	EncoderFallbackException__ctor_m155720722,
	EncoderFallbackException__ctor_m1528160091,
	EncoderFallbackException__ctor_m2270281761,
	EncoderReplacementFallback__ctor_m2945244117,
	EncoderReplacementFallback__ctor_m3250070966,
	EncoderReplacementFallback_get_DefaultString_m4191062785,
	EncoderReplacementFallback_CreateFallbackBuffer_m1127069765,
	EncoderReplacementFallback_Equals_m1390013825,
	EncoderReplacementFallback_GetHashCode_m1615456044,
	EncoderReplacementFallbackBuffer__ctor_m958381355,
	EncoderReplacementFallbackBuffer_get_Remaining_m3977844014,
	EncoderReplacementFallbackBuffer_Fallback_m501992528,
	EncoderReplacementFallbackBuffer_Fallback_m3466722301,
	EncoderReplacementFallbackBuffer_Fallback_m599858352,
	EncoderReplacementFallbackBuffer_GetNextChar_m3453233277,
	Encoding__ctor_m4008410528,
	Encoding__ctor_m2875911424,
	Encoding__cctor_m3484296081,
	Encoding___m1793497461,
	Encoding_get_IsReadOnly_m2121072446,
	Encoding_get_DecoderFallback_m3065083615,
	Encoding_set_DecoderFallback_m4267870351,
	Encoding_get_EncoderFallback_m3188170455,
	Encoding_SetFallbackInternal_m2442298156,
	Encoding_Equals_m3288962300,
	Encoding_GetByteCount_m3135173168,
	Encoding_GetByteCount_m2922393167,
	Encoding_GetBytes_m1236628218,
	Encoding_GetBytes_m2340210978,
	Encoding_GetBytes_m3931697097,
	Encoding_GetBytes_m249472607,
	Encoding_GetChars_m1532679131,
	Encoding_GetDecoder_m3502379790,
	Encoding_InvokeI18N_m2682327131,
	Encoding_GetEncoding_m2298077044,
	Encoding_Clone_m4233455263,
	Encoding_GetEncoding_m3290780891,
	Encoding_GetHashCode_m212417971,
	Encoding_GetPreamble_m867157703,
	Encoding_GetString_m1125439182,
	Encoding_GetString_m4093922631,
	Encoding_get_ASCII_m2724255296,
	Encoding_get_BigEndianUnicode_m149122260,
	Encoding_InternalCodePage_m2712836197,
	Encoding_get_Default_m2372458680,
	Encoding_get_ISOLatin1_m1300345248,
	Encoding_get_UTF7_m2280152873,
	Encoding_get_UTF8_m70465880,
	Encoding_get_UTF8Unmarked_m1499185185,
	Encoding_get_UTF8UnmarkedUnsafe_m497255164,
	Encoding_get_Unicode_m2398772331,
	Encoding_get_UTF32_m623218688,
	Encoding_get_BigEndianUTF32_m2377347238,
	Encoding_GetByteCount_m4183085963,
	Encoding_GetBytes_m1474736915,
	ForwardingDecoder__ctor_m1247364898,
	ForwardingDecoder_GetChars_m1850329998,
	Latin1Encoding__ctor_m589232024,
	Latin1Encoding_GetByteCount_m13660016,
	Latin1Encoding_GetByteCount_m3376283681,
	Latin1Encoding_GetBytes_m647929659,
	Latin1Encoding_GetBytes_m1052678065,
	Latin1Encoding_GetBytes_m3050336403,
	Latin1Encoding_GetBytes_m2000467629,
	Latin1Encoding_GetCharCount_m1964788892,
	Latin1Encoding_GetChars_m3531591516,
	Latin1Encoding_GetMaxByteCount_m393329894,
	Latin1Encoding_GetMaxCharCount_m2844776601,
	Latin1Encoding_GetString_m3077621880,
	Latin1Encoding_GetString_m2890245530,
	StringBuilder__ctor_m1428493168,
	StringBuilder__ctor_m2740731313,
	StringBuilder__ctor_m175499341,
	StringBuilder__ctor_m3845806063,
	StringBuilder__ctor_m3798948217,
	StringBuilder__ctor_m371641165,
	StringBuilder__ctor_m773507880,
	StringBuilder_System_Runtime_Serialization_ISerializable_GetObjectData_m2272161868,
	StringBuilder_get_Capacity_m3453158625,
	StringBuilder_set_Capacity_m1732372483,
	StringBuilder_get_Length_m3907963072,
	StringBuilder_set_Length_m1315149044,
	StringBuilder_get_Chars_m3047187487,
	StringBuilder_set_Chars_m2127440972,
	StringBuilder_ToString_m244373136,
	StringBuilder_ToString_m2073934015,
	StringBuilder_Remove_m3905712325,
	StringBuilder_Replace_m4020735041,
	StringBuilder_Replace_m1009576108,
	StringBuilder_Append_m2543471079,
	StringBuilder_Append_m2359038886,
	StringBuilder_Append_m3506914505,
	StringBuilder_Append_m2521391494,
	StringBuilder_Append_m2785502290,
	StringBuilder_Append_m3779698721,
	StringBuilder_Append_m3734755781,
	StringBuilder_Append_m1756495403,
	StringBuilder_AppendFormat_m265867772,
	StringBuilder_AppendFormat_m170141315,
	StringBuilder_AppendFormat_m122939010,
	StringBuilder_AppendFormat_m4167342996,
	StringBuilder_AppendFormat_m1638161108,
	StringBuilder_Insert_m1379433688,
	StringBuilder_Insert_m3210412127,
	StringBuilder_Insert_m10459946,
	StringBuilder_InternalEnsureCapacity_m482675063,
	UnicodeEncoding__ctor_m3228903610,
	UnicodeEncoding__ctor_m877433414,
	UnicodeEncoding__ctor_m2462857434,
	UnicodeEncoding_GetByteCount_m4119381810,
	UnicodeEncoding_GetByteCount_m1935692450,
	UnicodeEncoding_GetByteCount_m2385439378,
	UnicodeEncoding_GetBytes_m692370369,
	UnicodeEncoding_GetBytes_m3218310618,
	UnicodeEncoding_GetBytes_m1035720983,
	UnicodeEncoding_GetBytesInternal_m3562693430,
	UnicodeEncoding_GetCharCount_m3091704602,
	UnicodeEncoding_GetChars_m2365064659,
	UnicodeEncoding_GetString_m2415827372,
	UnicodeEncoding_GetCharsInternal_m2415901033,
	UnicodeEncoding_GetMaxByteCount_m3203971272,
	UnicodeEncoding_GetMaxCharCount_m2832727484,
	UnicodeEncoding_GetDecoder_m1125098288,
	UnicodeEncoding_GetPreamble_m4076903843,
	UnicodeEncoding_Equals_m2221663842,
	UnicodeEncoding_GetHashCode_m2539936009,
	UnicodeEncoding_CopyChars_m445859045,
	UnicodeDecoder__ctor_m3792125802,
	UnicodeDecoder_GetChars_m1438681656,
	UTF32Encoding__ctor_m3014186082,
	UTF32Encoding__ctor_m1633634927,
	UTF32Encoding__ctor_m3886255025,
	UTF32Encoding_GetByteCount_m4237185367,
	UTF32Encoding_GetBytes_m2455949945,
	UTF32Encoding_GetCharCount_m1134574960,
	UTF32Encoding_GetChars_m924416857,
	UTF32Encoding_GetMaxByteCount_m2787654479,
	UTF32Encoding_GetMaxCharCount_m2910971801,
	UTF32Encoding_GetDecoder_m2857835937,
	UTF32Encoding_GetPreamble_m596913816,
	UTF32Encoding_Equals_m1691988153,
	UTF32Encoding_GetHashCode_m2641139996,
	UTF32Encoding_GetByteCount_m1376079431,
	UTF32Encoding_GetByteCount_m1642432044,
	UTF32Encoding_GetBytes_m3225718289,
	UTF32Encoding_GetBytes_m2920443696,
	UTF32Encoding_GetString_m1938510386,
	UTF32Decoder__ctor_m1404655395,
	UTF32Decoder_GetChars_m2487850939,
	UTF7Encoding__ctor_m2625031550,
	UTF7Encoding__ctor_m3655267641,
	UTF7Encoding__cctor_m3748824209,
	UTF7Encoding_GetHashCode_m2812161639,
	UTF7Encoding_Equals_m1452874225,
	UTF7Encoding_InternalGetByteCount_m215089974,
	UTF7Encoding_GetByteCount_m2061781832,
	UTF7Encoding_InternalGetBytes_m4089630742,
	UTF7Encoding_GetBytes_m2080970182,
	UTF7Encoding_InternalGetCharCount_m1686735135,
	UTF7Encoding_GetCharCount_m3625731790,
	UTF7Encoding_InternalGetChars_m1945515060,
	UTF7Encoding_GetChars_m2884036738,
	UTF7Encoding_GetMaxByteCount_m314080301,
	UTF7Encoding_GetMaxCharCount_m3939861284,
	UTF7Encoding_GetDecoder_m1285919430,
	UTF7Encoding_GetByteCount_m2506376274,
	UTF7Encoding_GetByteCount_m339441067,
	UTF7Encoding_GetBytes_m2044879498,
	UTF7Encoding_GetBytes_m578527611,
	UTF7Encoding_GetString_m3450959021,
	UTF7Decoder__ctor_m3816516457,
	UTF7Decoder_GetChars_m216473671,
	UTF8Encoding__ctor_m3506809644,
	UTF8Encoding__ctor_m3141913478,
	UTF8Encoding__ctor_m1562634020,
	UTF8Encoding_InternalGetByteCount_m1956688264,
	UTF8Encoding_InternalGetByteCount_m3481093678,
	UTF8Encoding_GetByteCount_m650098797,
	UTF8Encoding_GetByteCount_m2335716119,
	UTF8Encoding_InternalGetBytes_m3469452628,
	UTF8Encoding_InternalGetBytes_m539594093,
	UTF8Encoding_GetBytes_m2979318900,
	UTF8Encoding_GetBytes_m752272482,
	UTF8Encoding_GetBytes_m1516677235,
	UTF8Encoding_InternalGetCharCount_m163506631,
	UTF8Encoding_InternalGetCharCount_m1220056757,
	UTF8Encoding_Fallback_m1083879228,
	UTF8Encoding_Fallback_m2344474189,
	UTF8Encoding_GetCharCount_m1230578939,
	UTF8Encoding_InternalGetChars_m2496291495,
	UTF8Encoding_InternalGetChars_m972795790,
	UTF8Encoding_GetChars_m2428255045,
	UTF8Encoding_GetMaxByteCount_m501722113,
	UTF8Encoding_GetMaxCharCount_m2175098764,
	UTF8Encoding_GetDecoder_m3138288894,
	UTF8Encoding_GetPreamble_m1886809218,
	UTF8Encoding_Equals_m885845848,
	UTF8Encoding_GetHashCode_m3782708233,
	UTF8Encoding_GetByteCount_m1704160248,
	UTF8Encoding_GetString_m658301774,
	UTF8Decoder__ctor_m24980077,
	UTF8Decoder_GetChars_m2736415519,
	CompressedStack__ctor_m2532168140,
	CompressedStack__ctor_m447154863,
	CompressedStack_CreateCopy_m3982422829,
	CompressedStack_Capture_m768931220,
	CompressedStack_GetObjectData_m690500011,
	CompressedStack_IsEmpty_m683992633,
	EventWaitHandle__ctor_m2932705097,
	EventWaitHandle_IsManualReset_m2534496093,
	EventWaitHandle_Reset_m4122309515,
	EventWaitHandle_Set_m1926926539,
	ExecutionContext__ctor_m3696050508,
	ExecutionContext__ctor_m1439213123,
	ExecutionContext__ctor_m832962155,
	ExecutionContext_Capture_m3410755285,
	ExecutionContext_GetObjectData_m1523482666,
	ExecutionContext_get_SecurityContext_m2985052274,
	ExecutionContext_set_SecurityContext_m3668312566,
	ExecutionContext_get_FlowSuppressed_m1317252817,
	ExecutionContext_IsFlowSuppressed_m2418975955,
	Interlocked_CompareExchange_m2836937338,
	Interlocked_CompareExchange_m867509969,
	ManualResetEvent__ctor_m3272063800,
	Monitor_Enter_m38452667,
	Monitor_Exit_m1806149589,
	Monitor_Monitor_pulse_m238331246,
	Monitor_Monitor_test_synchronised_m2220174918,
	Monitor_Pulse_m2889454142,
	Monitor_Monitor_wait_m3905904418,
	Monitor_Wait_m856719031,
	Mutex__ctor_m1301030505,
	Mutex_CreateMutex_internal_m2160126498,
	Mutex_ReleaseMutex_internal_m1378384868,
	Mutex_ReleaseMutex_m4091486119,
	NativeEventCalls_CreateEvent_internal_m889177616,
	NativeEventCalls_SetEvent_internal_m2190178706,
	NativeEventCalls_ResetEvent_internal_m2582641831,
	NativeEventCalls_CloseEvent_internal_m602630379,
	SendOrPostCallback__ctor_m4095383272,
	SendOrPostCallback_Invoke_m1796811407,
	SendOrPostCallback_BeginInvoke_m2593995799,
	SendOrPostCallback_EndInvoke_m618896138,
	SynchronizationContext__ctor_m3662476266,
	SynchronizationContext_get_Current_m840992411,
	SynchronizationContext_SetSynchronizationContext_m3503083165,
	SynchronizationLockException__ctor_m3938079360,
	SynchronizationLockException__ctor_m2888689672,
	SynchronizationLockException__ctor_m3039052602,
	Thread__ctor_m2961764056,
	Thread__cctor_m658133795,
	Thread_get_CurrentContext_m2749902502,
	Thread_CurrentThread_internal_m261912641,
	Thread_get_CurrentThread_m2728607849,
	Thread_FreeLocalSlotValues_m623529402,
	Thread_GetDomainID_m1184134661,
	Thread_Thread_internal_m3767251588,
	Thread_Thread_init_m3177124217,
	Thread_GetCachedCurrentCulture_m2245605137,
	Thread_GetSerializedCurrentCulture_m3677779835,
	Thread_SetCachedCurrentCulture_m1966227962,
	Thread_GetCachedCurrentUICulture_m2995853991,
	Thread_GetSerializedCurrentUICulture_m766002516,
	Thread_SetCachedCurrentUICulture_m922720501,
	Thread_get_CurrentCulture_m522769991,
	Thread_get_CurrentUICulture_m1331814557,
	Thread_set_IsBackground_m3770057700,
	Thread_SetName_internal_m117264428,
	Thread_set_Name_m3115102052,
	Thread_Start_m2879827094,
	Thread_Thread_free_internal_m1301564801,
	Thread_Finalize_m1654384812,
	Thread_SetState_m2929757911,
	Thread_ClrState_m2152224579,
	Thread_GetNewManagedId_m3558386045,
	Thread_GetNewManagedId_internal_m733821386,
	Thread_get_ExecutionContext_m1768813807,
	Thread_get_ManagedThreadId_m2611241199,
	Thread_GetHashCode_m2708003321,
	Thread_GetCompressedStack_m1386275719,
	ThreadAbortException__ctor_m2121087087,
	ThreadAbortException__ctor_m1262341537,
	ThreadInterruptedException__ctor_m4112071000,
	ThreadInterruptedException__ctor_m3943542634,
	ThreadPool_QueueUserWorkItem_m1429580738,
	ThreadStart__ctor_m764849218,
	ThreadStart_Invoke_m1770126731,
	ThreadStart_BeginInvoke_m325667963,
	ThreadStart_EndInvoke_m1958419553,
	ThreadStateException__ctor_m697746599,
	ThreadStateException__ctor_m3084835994,
	Timer__cctor_m3635255388,
	Timer_Change_m3280661692,
	Timer_Dispose_m2272806547,
	Timer_Change_m4053603748,
	Scheduler__ctor_m3579330397,
	Scheduler__cctor_m3021403185,
	Scheduler_get_Instance_m2737017557,
	Scheduler_Remove_m99311860,
	Scheduler_Change_m538608898,
	Scheduler_Add_m3781962737,
	Scheduler_InternalRemove_m1021644107,
	Scheduler_SchedulerThread_m380140393,
	Scheduler_ShrinkIfNeeded_m1969639564,
	TimerComparer__ctor_m3165162825,
	TimerComparer_Compare_m2906216700,
	TimerCallback__ctor_m1469419909,
	TimerCallback_Invoke_m1696482865,
	TimerCallback_BeginInvoke_m2975344911,
	TimerCallback_EndInvoke_m2367493485,
	WaitCallback__ctor_m2152232241,
	WaitCallback_Invoke_m3326833418,
	WaitCallback_BeginInvoke_m2024194814,
	WaitCallback_EndInvoke_m3586669057,
	WaitHandle__ctor_m503027900,
	WaitHandle__cctor_m1653924360,
	WaitHandle_System_IDisposable_Dispose_m4272735226,
	WaitHandle_get_Handle_m2420807871,
	WaitHandle_set_Handle_m336908879,
	WaitHandle_WaitOne_internal_m3661738743,
	WaitHandle_Dispose_m3526411156,
	WaitHandle_WaitOne_m4034199657,
	WaitHandle_WaitOne_m1473965123,
	WaitHandle_CheckDisposed_m3085686943,
	WaitHandle_Finalize_m2135410771,
	ThreadStaticAttribute__ctor_m406231037,
	TimeSpan__ctor_m870041458_AdjustorThunk,
	TimeSpan__ctor_m2251893089_AdjustorThunk,
	TimeSpan__ctor_m200249364_AdjustorThunk,
	TimeSpan__cctor_m3387775234,
	TimeSpan_CalculateTicks_m3000279770,
	TimeSpan_get_Days_m1072484364_AdjustorThunk,
	TimeSpan_get_Hours_m317922503_AdjustorThunk,
	TimeSpan_get_Milliseconds_m3309834420_AdjustorThunk,
	TimeSpan_get_Minutes_m3625111541_AdjustorThunk,
	TimeSpan_get_Seconds_m2421464030_AdjustorThunk,
	TimeSpan_get_Ticks_m4068363378_AdjustorThunk,
	TimeSpan_get_TotalDays_m1715978830_AdjustorThunk,
	TimeSpan_get_TotalHours_m1351619258_AdjustorThunk,
	TimeSpan_get_TotalMilliseconds_m3880263801_AdjustorThunk,
	TimeSpan_get_TotalMinutes_m3144648976_AdjustorThunk,
	TimeSpan_get_TotalSeconds_m3729239458_AdjustorThunk,
	TimeSpan_Add_m904898194_AdjustorThunk,
	TimeSpan_Compare_m2033428183,
	TimeSpan_CompareTo_m3351405754_AdjustorThunk,
	TimeSpan_CompareTo_m291689286_AdjustorThunk,
	TimeSpan_Equals_m646882242_AdjustorThunk,
	TimeSpan_Duration_m1524814460_AdjustorThunk,
	TimeSpan_Equals_m2055998824_AdjustorThunk,
	TimeSpan_FromDays_m4000964373,
	TimeSpan_FromHours_m2014759844,
	TimeSpan_FromMinutes_m216571269,
	TimeSpan_FromSeconds_m2832576765,
	TimeSpan_FromMilliseconds_m3065244797,
	TimeSpan_From_m246185944,
	TimeSpan_GetHashCode_m823626829_AdjustorThunk,
	TimeSpan_Negate_m3839207271_AdjustorThunk,
	TimeSpan_Subtract_m4139361392_AdjustorThunk,
	TimeSpan_ToString_m919987235_AdjustorThunk,
	TimeSpan_op_Addition_m1693936150,
	TimeSpan_op_Equality_m3495453946,
	TimeSpan_op_GreaterThan_m916935962,
	TimeSpan_op_GreaterThanOrEqual_m1019326098,
	TimeSpan_op_Inequality_m68078519,
	TimeSpan_op_LessThan_m1028668437,
	TimeSpan_op_LessThanOrEqual_m3885187140,
	TimeSpan_op_Subtraction_m42918648,
	TimeZone__ctor_m2450978757,
	TimeZone__cctor_m3115066945,
	TimeZone_get_CurrentTimeZone_m891519357,
	TimeZone_IsDaylightSavingTime_m1272116738,
	TimeZone_IsDaylightSavingTime_m1403338817,
	TimeZone_ToLocalTime_m4197877126,
	TimeZone_ToUniversalTime_m2004835404,
	TimeZone_GetLocalTimeDiff_m431191048,
	TimeZone_GetLocalTimeDiff_m1410256051,
	Type__ctor_m3514625664,
	Type__cctor_m427325584,
	Type_FilterName_impl_m102860822,
	Type_FilterNameIgnoreCase_impl_m2584364550,
	Type_FilterAttribute_impl_m2244337626,
	Type_get_Attributes_m3445770387,
	Type_get_DeclaringType_m3957938188,
	Type_get_HasElementType_m1982409910,
	Type_get_IsAbstract_m2706022722,
	Type_get_IsArray_m1869780647,
	Type_get_IsByRef_m2632653652,
	Type_get_IsClass_m2562810909,
	Type_get_IsContextful_m3345788469,
	Type_get_IsEnum_m3216654447,
	Type_get_IsExplicitLayout_m3091686209,
	Type_get_IsInterface_m810115707,
	Type_get_IsMarshalByRef_m4289809468,
	Type_get_IsPointer_m2822765025,
	Type_get_IsPrimitive_m873255927,
	Type_get_IsSealed_m593857244,
	Type_get_IsSerializable_m3983305930,
	Type_get_IsValueType_m1599902602,
	Type_get_MemberType_m2285707662,
	Type_get_ReflectedType_m2518019791,
	Type_get_TypeHandle_m2853570791,
	Type_Equals_m1777835199,
	Type_Equals_m558412655,
	Type_EqualsInternal_m621957517,
	Type_internal_from_handle_m322157645,
	Type_internal_from_name_m3961128735,
	Type_GetType_m1880105665,
	Type_GetType_m495616535,
	Type_GetTypeCodeInternal_m887661258,
	Type_GetTypeCode_m3372530953,
	Type_GetTypeFromHandle_m2295595423,
	Type_GetTypeHandle_m1532429232,
	Type_type_is_subtype_of_m1951411367,
	Type_type_is_assignable_from_m2104149404,
	Type_IsSubclassOf_m3030212525,
	Type_IsAssignableFrom_m1556173396,
	Type_IsInstanceOfType_m2917238988,
	Type_GetField_m969861738,
	Type_GetHashCode_m2868298710,
	Type_GetMethod_m229901197,
	Type_GetMethod_m1087717536,
	Type_GetMethod_m788657706,
	Type_GetMethod_m1268634691,
	Type_GetProperty_m4192268900,
	Type_GetProperty_m3593981547,
	Type_GetProperty_m217098125,
	Type_GetProperty_m2905030504,
	Type_GetProperty_m504012450,
	Type_IsArrayImpl_m1401706624,
	Type_IsValueTypeImpl_m2680682106,
	Type_IsContextfulImpl_m2184405446,
	Type_IsMarshalByRefImpl_m751776591,
	Type_GetConstructor_m3166019052,
	Type_GetConstructor_m3093596752,
	Type_GetConstructor_m888409261,
	Type_ToString_m1098933952,
	Type_get_IsSystemType_m3689670840,
	Type_GetGenericArguments_m2670134621,
	Type_get_ContainsGenericParameters_m1440526760,
	Type_get_IsGenericTypeDefinition_m4270534531,
	Type_GetGenericTypeDefinition_impl_m3084830526,
	Type_GetGenericTypeDefinition_m1391916486,
	Type_get_IsGenericType_m1725685497,
	Type_MakeGenericType_m3657355304,
	Type_MakeGenericType_m2741335421,
	Type_get_IsGenericParameter_m3982329739,
	Type_get_IsNested_m1784827734,
	Type_GetPseudoCustomAttributes_m1095221136,
	TypedReference_Equals_m1534014288_AdjustorThunk,
	TypedReference_GetHashCode_m1281515118_AdjustorThunk,
	TypeInitializationException__ctor_m1767161251,
	TypeInitializationException_GetObjectData_m761223089,
	TypeLoadException__ctor_m605554810,
	TypeLoadException__ctor_m2127875797,
	TypeLoadException__ctor_m2902952148,
	TypeLoadException__ctor_m1861445896,
	TypeLoadException_get_Message_m2911451104,
	TypeLoadException_GetObjectData_m1445642080,
	UInt16_System_IConvertible_ToBoolean_m2938174643_AdjustorThunk,
	UInt16_System_IConvertible_ToByte_m2026142984_AdjustorThunk,
	UInt16_System_IConvertible_ToChar_m2076998351_AdjustorThunk,
	UInt16_System_IConvertible_ToDateTime_m4012943687_AdjustorThunk,
	UInt16_System_IConvertible_ToDecimal_m1895855844_AdjustorThunk,
	UInt16_System_IConvertible_ToDouble_m3636128198_AdjustorThunk,
	UInt16_System_IConvertible_ToInt16_m4163098757_AdjustorThunk,
	UInt16_System_IConvertible_ToInt32_m3570854327_AdjustorThunk,
	UInt16_System_IConvertible_ToInt64_m1753308647_AdjustorThunk,
	UInt16_System_IConvertible_ToSByte_m3408172411_AdjustorThunk,
	UInt16_System_IConvertible_ToSingle_m2826102608_AdjustorThunk,
	UInt16_System_IConvertible_ToType_m3909179681_AdjustorThunk,
	UInt16_System_IConvertible_ToUInt16_m1317600763_AdjustorThunk,
	UInt16_System_IConvertible_ToUInt32_m4054634694_AdjustorThunk,
	UInt16_System_IConvertible_ToUInt64_m2663253018_AdjustorThunk,
	UInt16_CompareTo_m598717551_AdjustorThunk,
	UInt16_Equals_m391233801_AdjustorThunk,
	UInt16_GetHashCode_m2287554426_AdjustorThunk,
	UInt16_CompareTo_m4063616443_AdjustorThunk,
	UInt16_Equals_m3955712414_AdjustorThunk,
	UInt16_Parse_m821794179,
	UInt16_Parse_m1827209548,
	UInt16_TryParse_m2161302458,
	UInt16_TryParse_m4175666418,
	UInt16_ToString_m3822407517_AdjustorThunk,
	UInt16_ToString_m30405293_AdjustorThunk,
	UInt16_ToString_m45506489_AdjustorThunk,
	UInt16_ToString_m3807504599_AdjustorThunk,
	UInt32_System_IConvertible_ToBoolean_m3340090418_AdjustorThunk,
	UInt32_System_IConvertible_ToByte_m2481938937_AdjustorThunk,
	UInt32_System_IConvertible_ToChar_m322114797_AdjustorThunk,
	UInt32_System_IConvertible_ToDateTime_m1448117779_AdjustorThunk,
	UInt32_System_IConvertible_ToDecimal_m1499107649_AdjustorThunk,
	UInt32_System_IConvertible_ToDouble_m415718190_AdjustorThunk,
	UInt32_System_IConvertible_ToInt16_m4220398773_AdjustorThunk,
	UInt32_System_IConvertible_ToInt32_m2565310438_AdjustorThunk,
	UInt32_System_IConvertible_ToInt64_m3977292974_AdjustorThunk,
	UInt32_System_IConvertible_ToSByte_m1504578294_AdjustorThunk,
	UInt32_System_IConvertible_ToSingle_m1896300003_AdjustorThunk,
	UInt32_System_IConvertible_ToType_m3185309404_AdjustorThunk,
	UInt32_System_IConvertible_ToUInt16_m3929246764_AdjustorThunk,
	UInt32_System_IConvertible_ToUInt32_m3211145308_AdjustorThunk,
	UInt32_System_IConvertible_ToUInt64_m3755722643_AdjustorThunk,
	UInt32_CompareTo_m1385037073_AdjustorThunk,
	UInt32_Equals_m2504152169_AdjustorThunk,
	UInt32_GetHashCode_m1074555290_AdjustorThunk,
	UInt32_CompareTo_m3135376739_AdjustorThunk,
	UInt32_Equals_m2164242329_AdjustorThunk,
	UInt32_Parse_m2570147847,
	UInt32_Parse_m1028925636,
	UInt32_Parse_m602751418,
	UInt32_Parse_m1560553326,
	UInt32_TryParse_m872480584,
	UInt32_TryParse_m2781189100,
	UInt32_ToString_m1044369565_AdjustorThunk,
	UInt32_ToString_m466102405_AdjustorThunk,
	UInt32_ToString_m2873034864_AdjustorThunk,
	UInt32_ToString_m1785453081_AdjustorThunk,
	UInt64_System_IConvertible_ToBoolean_m940072003_AdjustorThunk,
	UInt64_System_IConvertible_ToByte_m3349692439_AdjustorThunk,
	UInt64_System_IConvertible_ToChar_m4077346663_AdjustorThunk,
	UInt64_System_IConvertible_ToDateTime_m825240115_AdjustorThunk,
	UInt64_System_IConvertible_ToDecimal_m573006315_AdjustorThunk,
	UInt64_System_IConvertible_ToDouble_m234291922_AdjustorThunk,
	UInt64_System_IConvertible_ToInt16_m4190108701_AdjustorThunk,
	UInt64_System_IConvertible_ToInt32_m2065607744_AdjustorThunk,
	UInt64_System_IConvertible_ToInt64_m1438551110_AdjustorThunk,
	UInt64_System_IConvertible_ToSByte_m3762118253_AdjustorThunk,
	UInt64_System_IConvertible_ToSingle_m342787973_AdjustorThunk,
	UInt64_System_IConvertible_ToType_m3046026539_AdjustorThunk,
	UInt64_System_IConvertible_ToUInt16_m982389634_AdjustorThunk,
	UInt64_System_IConvertible_ToUInt32_m1482915438_AdjustorThunk,
	UInt64_System_IConvertible_ToUInt64_m559076774_AdjustorThunk,
	UInt64_CompareTo_m3064838862_AdjustorThunk,
	UInt64_Equals_m3307238183_AdjustorThunk,
	UInt64_GetHashCode_m1170046557_AdjustorThunk,
	UInt64_CompareTo_m2050311960_AdjustorThunk,
	UInt64_Equals_m559271450_AdjustorThunk,
	UInt64_Parse_m2837505384,
	UInt64_Parse_m1564256210,
	UInt64_Parse_m1838157675,
	UInt64_TryParse_m1875351864,
	UInt64_ToString_m3813799023_AdjustorThunk,
	UInt64_ToString_m1174253044_AdjustorThunk,
	UInt64_ToString_m601668999_AdjustorThunk,
	UInt64_ToString_m2220742856_AdjustorThunk,
	UIntPtr__ctor_m3478500531_AdjustorThunk,
	UIntPtr__ctor_m4105922456_AdjustorThunk,
	UIntPtr__ctor_m890287867_AdjustorThunk,
	UIntPtr__cctor_m3098084730,
	UIntPtr_System_Runtime_Serialization_ISerializable_GetObjectData_m2261738681_AdjustorThunk,
	UIntPtr_Equals_m2565501201_AdjustorThunk,
	UIntPtr_GetHashCode_m3117809595_AdjustorThunk,
	UIntPtr_ToUInt32_m1488255549_AdjustorThunk,
	UIntPtr_ToUInt64_m1446044739_AdjustorThunk,
	UIntPtr_ToPointer_m2330649849_AdjustorThunk,
	UIntPtr_ToString_m2349799160_AdjustorThunk,
	UIntPtr_get_Size_m4091950724,
	UIntPtr_op_Equality_m1590355935,
	UIntPtr_op_Inequality_m376990495,
	UIntPtr_op_Explicit_m3590246742,
	UIntPtr_op_Explicit_m3099530842,
	UIntPtr_op_Explicit_m2779336468,
	UIntPtr_op_Explicit_m4118586544,
	UIntPtr_op_Explicit_m1761774754,
	UIntPtr_op_Explicit_m1534923483,
	UnauthorizedAccessException__ctor_m3689916169,
	UnauthorizedAccessException__ctor_m300962893,
	UnauthorizedAccessException__ctor_m2339700578,
	UnhandledExceptionEventArgs__ctor_m29960797,
	UnhandledExceptionEventArgs_get_ExceptionObject_m4275923656,
	UnhandledExceptionEventArgs_get_IsTerminating_m3714614171,
	UnhandledExceptionEventHandler__ctor_m2199922652,
	UnhandledExceptionEventHandler_Invoke_m4186886379,
	UnhandledExceptionEventHandler_BeginInvoke_m1399476456,
	UnhandledExceptionEventHandler_EndInvoke_m1298953255,
	UnitySerializationHolder__ctor_m1034045059,
	UnitySerializationHolder_GetTypeData_m316232846,
	UnitySerializationHolder_GetDBNullData_m4272190497,
	UnitySerializationHolder_GetModuleData_m2344463278,
	UnitySerializationHolder_GetObjectData_m4063397316,
	UnitySerializationHolder_GetRealObject_m1459969038,
	ValueType__ctor_m2756058136,
	ValueType_InternalEquals_m1159190307,
	ValueType_DefaultEquals_m3478451992,
	ValueType_Equals_m239602267,
	ValueType_InternalGetHashCode_m3183595565,
	ValueType_GetHashCode_m2115687125,
	ValueType_ToString_m1086036397,
	Version__ctor_m3000072641,
	Version__ctor_m4079040315,
	Version__ctor_m2777383737,
	Version__ctor_m852799842,
	Version__ctor_m3884932599,
	Version_CheckedSet_m111653027,
	Version_get_Build_m2354003600,
	Version_get_Major_m2328730053,
	Version_get_Minor_m2929997196,
	Version_get_Revision_m608992238,
	Version_Clone_m3183706130,
	Version_CompareTo_m1235128625,
	Version_Equals_m4160560067,
	Version_CompareTo_m3125023153,
	Version_Equals_m3860247383,
	Version_GetHashCode_m3395513008,
	Version_ToString_m926326786,
	Version_CreateFromString_m3672463384,
	Version_op_Equality_m443314940,
	Version_op_Inequality_m2806992777,
	WeakReference__ctor_m773162140,
	WeakReference__ctor_m2124974099,
	WeakReference__ctor_m398759899,
	WeakReference__ctor_m2153339938,
	WeakReference_AllocateHandle_m1110798685,
	WeakReference_get_IsAlive_m2440580473,
	WeakReference_get_Target_m926440970,
	WeakReference_get_TrackResurrection_m91962753,
	WeakReference_Finalize_m2384180804,
	WeakReference_GetObjectData_m4174671114,
	Locale_GetText_m1647632488,
	Locale_GetText_m3231868817,
	HybridDictionary__ctor_m3653045782,
	HybridDictionary__ctor_m2147156402,
	HybridDictionary_System_Collections_IEnumerable_GetEnumerator_m926841030,
	HybridDictionary_get_inner_m4173737539,
	HybridDictionary_get_Count_m1847902913,
	HybridDictionary_get_Item_m791179778,
	HybridDictionary_set_Item_m1547193035,
	HybridDictionary_get_SyncRoot_m1441637939,
	HybridDictionary_Add_m3601456474,
	HybridDictionary_CopyTo_m2014314495,
	HybridDictionary_GetEnumerator_m3316769784,
	HybridDictionary_Remove_m3466274522,
	HybridDictionary_Switch_m3582035830,
	ListDictionary__ctor_m4252876715,
	ListDictionary__ctor_m576138091,
	ListDictionary_System_Collections_IEnumerable_GetEnumerator_m1131156923,
	ListDictionary_FindEntry_m1708015721,
	ListDictionary_FindEntry_m2871472386,
	ListDictionary_AddImpl_m1078813873,
	ListDictionary_get_Count_m654515562,
	ListDictionary_get_SyncRoot_m1057056687,
	ListDictionary_CopyTo_m1376306415,
	ListDictionary_get_Item_m682334219,
	ListDictionary_set_Item_m3311570113,
	ListDictionary_Add_m2512092114,
	ListDictionary_Clear_m2772407903,
	ListDictionary_GetEnumerator_m1192837366,
	ListDictionary_Remove_m1866677954,
	DictionaryNode__ctor_m3583809050,
	DictionaryNodeEnumerator__ctor_m3308198089,
	DictionaryNodeEnumerator_FailFast_m2080867333,
	DictionaryNodeEnumerator_MoveNext_m3257976381,
	DictionaryNodeEnumerator_Reset_m2537649624,
	DictionaryNodeEnumerator_get_Current_m2851874498,
	DictionaryNodeEnumerator_get_DictionaryNode_m1494027982,
	DictionaryNodeEnumerator_get_Entry_m1719842113,
	DictionaryNodeEnumerator_get_Key_m2349419451,
	DictionaryNodeEnumerator_get_Value_m3813667679,
	NameObjectCollectionBase__ctor_m1305041123,
	NameObjectCollectionBase__ctor_m27591930,
	NameObjectCollectionBase_System_Collections_ICollection_get_SyncRoot_m4022549244,
	NameObjectCollectionBase_System_Collections_ICollection_CopyTo_m189238480,
	NameObjectCollectionBase_Init_m3689157985,
	NameObjectCollectionBase_get_Keys_m1338563883,
	NameObjectCollectionBase_GetEnumerator_m2920527064,
	NameObjectCollectionBase_GetObjectData_m3062537340,
	NameObjectCollectionBase_get_Count_m2167539385,
	NameObjectCollectionBase_OnDeserialization_m399028257,
	NameObjectCollectionBase_get_IsReadOnly_m2917149711,
	NameObjectCollectionBase_BaseAdd_m2613686807,
	NameObjectCollectionBase_BaseGet_m1017030273,
	NameObjectCollectionBase_BaseGet_m1564870035,
	NameObjectCollectionBase_BaseGetKey_m2496215546,
	NameObjectCollectionBase_FindFirstMatchedItem_m2785248297,
	_Item__ctor_m4107454056,
	_KeysEnumerator__ctor_m515115223,
	_KeysEnumerator_get_Current_m2321820747,
	_KeysEnumerator_MoveNext_m506294014,
	_KeysEnumerator_Reset_m1803042365,
	KeysCollection__ctor_m2173697011,
	KeysCollection_System_Collections_ICollection_CopyTo_m1072205791,
	KeysCollection_System_Collections_ICollection_get_SyncRoot_m684690045,
	KeysCollection_get_Count_m2006320711,
	KeysCollection_GetEnumerator_m1640177526,
	NameValueCollection__ctor_m2278028677,
	NameValueCollection__ctor_m1373236513,
	NameValueCollection_Add_m1155069069,
	NameValueCollection_Get_m257741685,
	NameValueCollection_AsSingleString_m4102959917,
	NameValueCollection_GetKey_m2719855662,
	NameValueCollection_InvalidateCachedArrays_m1895956073,
	EditorBrowsableAttribute__ctor_m2659158224,
	EditorBrowsableAttribute_get_State_m3042163749,
	EditorBrowsableAttribute_Equals_m3235731104,
	EditorBrowsableAttribute_GetHashCode_m1104320344,
	TypeConverterAttribute__ctor_m565780092,
	TypeConverterAttribute__ctor_m2251610938,
	TypeConverterAttribute__cctor_m63856178,
	TypeConverterAttribute_Equals_m619429225,
	TypeConverterAttribute_GetHashCode_m3929170352,
	TypeConverterAttribute_get_ConverterTypeName_m908500315,
	DefaultUriParser__ctor_m4218342554,
	DefaultUriParser__ctor_m3423160560,
	MonoTODOAttribute__ctor_m937077758,
	MonoTODOAttribute__ctor_m741414698,
	DefaultCertificatePolicy__ctor_m2926301288,
	DefaultCertificatePolicy_CheckValidationResult_m675248107,
	FileWebRequest__ctor_m328140929,
	FileWebRequest__ctor_m331710361,
	FileWebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m1090276256,
	FileWebRequest_GetObjectData_m3786272976,
	FileWebRequestCreator__ctor_m3382062713,
	FileWebRequestCreator_Create_m3235750503,
	FtpRequestCreator__ctor_m1504958891,
	FtpRequestCreator_Create_m1210584353,
	FtpWebRequest__ctor_m1716432029,
	FtpWebRequest__cctor_m614165506,
	FtpWebRequest_U3CcallbackU3Em__B_m3498702001,
	GlobalProxySelection_get_Select_m2157273934,
	HttpRequestCreator__ctor_m3328396086,
	HttpRequestCreator_Create_m2394659706,
	HttpVersion__cctor_m3103263600,
	HttpWebRequest__ctor_m434731781,
	HttpWebRequest__ctor_m2901044332,
	HttpWebRequest__cctor_m2685482861,
	HttpWebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m3676360574,
	HttpWebRequest_get_Address_m7309902,
	HttpWebRequest_get_ServicePoint_m720606461,
	HttpWebRequest_GetServicePoint_m4013005630,
	HttpWebRequest_GetObjectData_m3141098937,
	IPAddress__ctor_m2425901205,
	IPAddress__ctor_m3327862736,
	IPAddress__cctor_m660017201,
	IPAddress_SwapShort_m2393026236,
	IPAddress_HostToNetworkOrder_m1077450846,
	IPAddress_NetworkToHostOrder_m675703911,
	IPAddress_Parse_m3574716329,
	IPAddress_TryParse_m3599578258,
	IPAddress_ParseIPV4_m2302493237,
	IPAddress_ParseIPV6_m1754153831,
	IPAddress_get_InternalIPv4Address_m450045632,
	IPAddress_get_ScopeId_m3054422697,
	IPAddress_get_AddressFamily_m3244967048,
	IPAddress_IsLoopback_m761081390,
	IPAddress_ToString_m2511897936,
	IPAddress_ToString_m3324380514,
	IPAddress_Equals_m1887710285,
	IPAddress_GetHashCode_m17845621,
	IPAddress_Hash_m3259784001,
	IPv6Address__ctor_m3248518714,
	IPv6Address__ctor_m2257874333,
	IPv6Address__ctor_m74903806,
	IPv6Address__cctor_m2752111042,
	IPv6Address_Parse_m3201407685,
	IPv6Address_Fill_m4090713947,
	IPv6Address_TryParse_m1927408658,
	IPv6Address_TryParse_m3203198026,
	IPv6Address_get_Address_m3386592422,
	IPv6Address_get_ScopeId_m1217333468,
	IPv6Address_set_ScopeId_m319634826,
	IPv6Address_IsLoopback_m2938267155,
	IPv6Address_SwapUShort_m2157039462,
	IPv6Address_AsIPv4Int_m3230172872,
	IPv6Address_IsIPv4Compatible_m1460932075,
	IPv6Address_IsIPv4Mapped_m3768654363,
	IPv6Address_ToString_m2749627050,
	IPv6Address_ToString_m1655328954,
	IPv6Address_Equals_m2918345306,
	IPv6Address_GetHashCode_m65255023,
	IPv6Address_Hash_m709643461,
	RemoteCertificateValidationCallback__ctor_m1528111085,
	RemoteCertificateValidationCallback_Invoke_m522374110,
	RemoteCertificateValidationCallback_BeginInvoke_m3285627105,
	RemoteCertificateValidationCallback_EndInvoke_m4104187126,
	ServicePoint__ctor_m3556548504,
	ServicePoint_get_Address_m3793322199,
	ServicePoint_get_CurrentConnections_m1981947194,
	ServicePoint_get_IdleSince_m739666800,
	ServicePoint_set_IdleSince_m2595005045,
	ServicePoint_set_Expect100Continue_m2505370509,
	ServicePoint_set_UseNagleAlgorithm_m3162047792,
	ServicePoint_set_SendContinue_m1181690970,
	ServicePoint_set_UsesProxy_m3283909725,
	ServicePoint_set_UseConnect_m504286873,
	ServicePoint_get_AvailableForRecycling_m425308459,
	ServicePointManager__cctor_m3138212209,
	ServicePointManager_get_CertificatePolicy_m3822685417,
	ServicePointManager_get_CheckCertificateRevocationList_m2512216872,
	ServicePointManager_get_SecurityProtocol_m1618197087,
	ServicePointManager_get_ServerCertificateValidationCallback_m3949280906,
	ServicePointManager_FindServicePoint_m1125235358,
	ServicePointManager_RecycleServicePoints_m2752261321,
	SPKey__ctor_m732745578,
	SPKey_GetHashCode_m1429544805,
	SPKey_Equals_m219844906,
	WebHeaderCollection__ctor_m3619487727,
	WebHeaderCollection__ctor_m1059550187,
	WebHeaderCollection__ctor_m989548309,
	WebHeaderCollection__cctor_m1613442010,
	WebHeaderCollection_System_Runtime_Serialization_ISerializable_GetObjectData_m8944261,
	WebHeaderCollection_Add_m1264164693,
	WebHeaderCollection_AddWithoutValidate_m606007058,
	WebHeaderCollection_IsRestricted_m3869734646,
	WebHeaderCollection_OnDeserialization_m3270564415,
	WebHeaderCollection_ToString_m391855276,
	WebHeaderCollection_GetObjectData_m594675392,
	WebHeaderCollection_get_Count_m2668601130,
	WebHeaderCollection_get_Keys_m188155367,
	WebHeaderCollection_Get_m2188960424,
	WebHeaderCollection_GetKey_m3346270839,
	WebHeaderCollection_GetEnumerator_m3936804387,
	WebHeaderCollection_IsHeaderValue_m1333711411,
	WebHeaderCollection_IsHeaderName_m3456245027,
	WebProxy__ctor_m748551541,
	WebProxy__ctor_m4040032087,
	WebProxy__ctor_m1388018577,
	WebProxy_System_Runtime_Serialization_ISerializable_GetObjectData_m1601589441,
	WebProxy_get_UseDefaultCredentials_m3972272783,
	WebProxy_GetProxy_m2250017237,
	WebProxy_IsBypassed_m2540390668,
	WebProxy_GetObjectData_m4048881970,
	WebProxy_CheckBypassList_m1167118873,
	WebRequest__ctor_m3085130597,
	WebRequest__ctor_m3421329469,
	WebRequest__cctor_m92070379,
	WebRequest_System_Runtime_Serialization_ISerializable_GetObjectData_m1656636354,
	WebRequest_AddDynamicPrefix_m689243842,
	WebRequest_GetMustImplement_m395385750,
	WebRequest_get_DefaultWebProxy_m1862724228,
	WebRequest_GetDefaultWebProxy_m2436480977,
	WebRequest_GetObjectData_m1843151265,
	WebRequest_AddPrefix_m68233748,
	AsnEncodedData__ctor_m2384778664,
	AsnEncodedData__ctor_m3737559252,
	AsnEncodedData__ctor_m3478274676,
	AsnEncodedData_get_Oid_m1755202606,
	AsnEncodedData_set_Oid_m428546322,
	AsnEncodedData_get_RawData_m1941753742,
	AsnEncodedData_set_RawData_m999695041,
	AsnEncodedData_CopyFrom_m4129437351,
	AsnEncodedData_ToString_m3184123992,
	AsnEncodedData_Default_m2232941155,
	AsnEncodedData_BasicConstraintsExtension_m3764584996,
	AsnEncodedData_EnhancedKeyUsageExtension_m3609456747,
	AsnEncodedData_KeyUsageExtension_m2665418060,
	AsnEncodedData_SubjectKeyIdentifierExtension_m2350885142,
	AsnEncodedData_SubjectAltName_m2746612239,
	AsnEncodedData_NetscapeCertType_m4258108562,
	Oid__ctor_m1845559200,
	Oid__ctor_m2872646922,
	Oid__ctor_m3316546995,
	Oid__ctor_m3596594614,
	Oid_get_FriendlyName_m3124218941,
	Oid_get_Value_m3061680761,
	Oid_GetName_m3146123539,
	OidCollection__ctor_m1418041579,
	OidCollection_System_Collections_ICollection_CopyTo_m1818992363,
	OidCollection_System_Collections_IEnumerable_GetEnumerator_m2282912456,
	OidCollection_get_Count_m3550869606,
	OidCollection_get_Item_m2370418372,
	OidCollection_get_SyncRoot_m1436628185,
	OidCollection_Add_m2772445532,
	OidEnumerator__ctor_m3914047703,
	OidEnumerator_System_Collections_IEnumerator_get_Current_m3083832048,
	OidEnumerator_MoveNext_m1204098737,
	OidEnumerator_Reset_m2338305976,
	PublicKey__ctor_m3018451802,
	PublicKey_get_EncodedKeyValue_m839105348,
	PublicKey_get_EncodedParameters_m221039915,
	PublicKey_get_Key_m1228042147,
	PublicKey_get_Oid_m2482011906,
	PublicKey_GetUnsignedBigInteger_m4097116804,
	PublicKey_DecodeDSA_m474144981,
	PublicKey_DecodeRSA_m3080821993,
	X500DistinguishedName__ctor_m4189237902,
	X500DistinguishedName_Decode_m3269481422,
	X500DistinguishedName_GetSeparator_m199732345,
	X500DistinguishedName_DecodeRawData_m4274092901,
	X500DistinguishedName_Canonize_m2715628542,
	X500DistinguishedName_AreEqual_m3439065037,
	X509BasicConstraintsExtension__ctor_m3473898820,
	X509BasicConstraintsExtension__ctor_m2800340189,
	X509BasicConstraintsExtension__ctor_m4111597117,
	X509BasicConstraintsExtension_get_CertificateAuthority_m4263835909,
	X509BasicConstraintsExtension_get_HasPathLengthConstraint_m1542188903,
	X509BasicConstraintsExtension_get_PathLengthConstraint_m573505714,
	X509BasicConstraintsExtension_CopyFrom_m964409699,
	X509BasicConstraintsExtension_Decode_m2148167021,
	X509BasicConstraintsExtension_Encode_m1342427522,
	X509BasicConstraintsExtension_ToString_m4228051348,
	X509Certificate2__ctor_m2926745132,
	X509Certificate2__cctor_m4102588900,
	X509Certificate2_get_Extensions_m3136800204,
	X509Certificate2_get_IssuerName_m1608133231,
	X509Certificate2_get_NotAfter_m1462478161,
	X509Certificate2_get_NotBefore_m461384883,
	X509Certificate2_get_PrivateKey_m796288645,
	X509Certificate2_get_PublicKey_m4121486856,
	X509Certificate2_get_SerialNumber_m3617614289,
	X509Certificate2_get_SignatureAlgorithm_m3895449782,
	X509Certificate2_get_SubjectName_m2101884752,
	X509Certificate2_get_Thumbprint_m3213978850,
	X509Certificate2_get_Version_m3742682081,
	X509Certificate2_GetNameInfo_m808913113,
	X509Certificate2_Find_m2628184362,
	X509Certificate2_GetValueAsString_m1803200042,
	X509Certificate2_ImportPkcs12_m3301136225,
	X509Certificate2_Import_m3534696989,
	X509Certificate2_Reset_m1544400693,
	X509Certificate2_ToString_m1172523465,
	X509Certificate2_ToString_m932704669,
	X509Certificate2_AppendBuffer_m4266606259,
	X509Certificate2_Verify_m284365349,
	X509Certificate2_get_MonoCertificate_m2373788936,
	X509Certificate2Collection__ctor_m3365711536,
	X509Certificate2Collection__ctor_m3624708096,
	X509Certificate2Collection_get_Item_m3631099683,
	X509Certificate2Collection_Add_m3021876451,
	X509Certificate2Collection_AddRange_m3857728710,
	X509Certificate2Collection_Contains_m67155110,
	X509Certificate2Collection_Find_m2757621005,
	X509Certificate2Collection_GetEnumerator_m1569313327,
	X509Certificate2Enumerator__ctor_m603220320,
	X509Certificate2Enumerator_System_Collections_IEnumerator_get_Current_m1285802559,
	X509Certificate2Enumerator_System_Collections_IEnumerator_MoveNext_m1046457630,
	X509Certificate2Enumerator_System_Collections_IEnumerator_Reset_m1381206356,
	X509Certificate2Enumerator_get_Current_m312763933,
	X509Certificate2Enumerator_MoveNext_m4204177854,
	X509Certificate2Enumerator_Reset_m1366892457,
	X509CertificateCollection__ctor_m1456408456,
	X509CertificateCollection__ctor_m3900377825,
	X509CertificateCollection_get_Item_m3671308570,
	X509CertificateCollection_AddRange_m2387664531,
	X509CertificateCollection_GetEnumerator_m3762497105,
	X509CertificateCollection_GetHashCode_m2514557430,
	X509CertificateEnumerator__ctor_m481851256,
	X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m3673524984,
	X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m137447140,
	X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m1922725236,
	X509CertificateEnumerator_get_Current_m2224343874,
	X509CertificateEnumerator_MoveNext_m3348388573,
	X509CertificateEnumerator_Reset_m4255168805,
	X509Chain__ctor_m583237922,
	X509Chain__ctor_m2382375899,
	X509Chain__cctor_m1233248096,
	X509Chain_get_ChainPolicy_m2937769194,
	X509Chain_Build_m1000713326,
	X509Chain_Reset_m4098829074,
	X509Chain_get_Roots_m2087621631,
	X509Chain_get_CertificateAuthorities_m2477380737,
	X509Chain_get_CertificateCollection_m2115847340,
	X509Chain_BuildChainFrom_m3124143205,
	X509Chain_SelectBestFromCollection_m3351987027,
	X509Chain_FindParent_m3698810595,
	X509Chain_IsChainComplete_m703687826,
	X509Chain_IsSelfIssued_m3689374980,
	X509Chain_ValidateChain_m2800009862,
	X509Chain_Process_m283031606,
	X509Chain_PrepareForNextCertificate_m1627882308,
	X509Chain_WrapUp_m1733160488,
	X509Chain_ProcessCertificateExtensions_m4144749770,
	X509Chain_IsSignedWith_m3777092682,
	X509Chain_GetSubjectKeyIdentifier_m1066335808,
	X509Chain_GetAuthorityKeyIdentifier_m2900205621,
	X509Chain_GetAuthorityKeyIdentifier_m917151907,
	X509Chain_GetAuthorityKeyIdentifier_m2685749841,
	X509Chain_CheckRevocationOnChain_m74590067,
	X509Chain_CheckRevocation_m2066152658,
	X509Chain_CheckRevocation_m1531381360,
	X509Chain_FindCrl_m2309199168,
	X509Chain_ProcessCrlExtensions_m1320700338,
	X509Chain_ProcessCrlEntryExtensions_m1432454835,
	X509ChainElement__ctor_m1880580410,
	X509ChainElement_get_Certificate_m3241871595,
	X509ChainElement_get_ChainElementStatus_m587278778,
	X509ChainElement_get_StatusFlags_m229459722,
	X509ChainElement_set_StatusFlags_m536621046,
	X509ChainElement_Count_m879236329,
	X509ChainElement_Set_m3136156342,
	X509ChainElement_UncompressFlags_m4160750824,
	X509ChainElementCollection__ctor_m1837933552,
	X509ChainElementCollection_System_Collections_ICollection_CopyTo_m3057694626,
	X509ChainElementCollection_System_Collections_IEnumerable_GetEnumerator_m109510445,
	X509ChainElementCollection_get_Count_m2869759041,
	X509ChainElementCollection_get_Item_m1081301532,
	X509ChainElementCollection_get_SyncRoot_m2227897855,
	X509ChainElementCollection_GetEnumerator_m3169469758,
	X509ChainElementCollection_Add_m4163208859,
	X509ChainElementCollection_Clear_m2370058916,
	X509ChainElementCollection_Contains_m3678300766,
	X509ChainElementEnumerator__ctor_m3655165220,
	X509ChainElementEnumerator_System_Collections_IEnumerator_get_Current_m4276540009,
	X509ChainElementEnumerator_get_Current_m2079232385,
	X509ChainElementEnumerator_MoveNext_m279597569,
	X509ChainElementEnumerator_Reset_m1754904740,
	X509ChainPolicy__ctor_m1621131493,
	X509ChainPolicy_get_ExtraStore_m3798730679,
	X509ChainPolicy_get_RevocationFlag_m2578342906,
	X509ChainPolicy_get_RevocationMode_m108590087,
	X509ChainPolicy_get_VerificationFlags_m1416596346,
	X509ChainPolicy_get_VerificationTime_m2471432300,
	X509ChainPolicy_Reset_m1836143270,
	X509ChainStatus__ctor_m3018128567_AdjustorThunk,
	X509ChainStatus_get_Status_m2150926311_AdjustorThunk,
	X509ChainStatus_set_Status_m1692295910_AdjustorThunk,
	X509ChainStatus_set_StatusInformation_m1702484074_AdjustorThunk,
	X509ChainStatus_GetInformation_m2234207597,
	X509EnhancedKeyUsageExtension__ctor_m3260908215,
	X509EnhancedKeyUsageExtension_CopyFrom_m3929728340,
	X509EnhancedKeyUsageExtension_Decode_m2745773589,
	X509EnhancedKeyUsageExtension_ToString_m3220087219,
	X509Extension__ctor_m2391813590,
	X509Extension__ctor_m2891239361,
	X509Extension_get_Critical_m975012775,
	X509Extension_set_Critical_m3714286755,
	X509Extension_CopyFrom_m3727910601,
	X509Extension_FormatUnkownData_m2636613681,
	X509ExtensionCollection__ctor_m618270890,
	X509ExtensionCollection_System_Collections_ICollection_CopyTo_m3060354564,
	X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m384132609,
	X509ExtensionCollection_get_Count_m1857330339,
	X509ExtensionCollection_get_SyncRoot_m2596941851,
	X509ExtensionCollection_get_Item_m3318656216,
	X509ExtensionCollection_GetEnumerator_m1416980249,
	X509ExtensionEnumerator__ctor_m48655285,
	X509ExtensionEnumerator_System_Collections_IEnumerator_get_Current_m1945278316,
	X509ExtensionEnumerator_get_Current_m4078292627,
	X509ExtensionEnumerator_MoveNext_m2429627246,
	X509ExtensionEnumerator_Reset_m3734752993,
	X509KeyUsageExtension__ctor_m4101631676,
	X509KeyUsageExtension__ctor_m4002560134,
	X509KeyUsageExtension__ctor_m942910524,
	X509KeyUsageExtension_get_KeyUsages_m3406415185,
	X509KeyUsageExtension_CopyFrom_m1527234626,
	X509KeyUsageExtension_GetValidFlags_m3365957747,
	X509KeyUsageExtension_Decode_m2890215189,
	X509KeyUsageExtension_Encode_m3258780823,
	X509KeyUsageExtension_ToString_m3524737243,
	X509Store__ctor_m2254016317,
	X509Store_get_Certificates_m4064399406,
	X509Store_get_Factory_m3038371408,
	X509Store_get_Store_m1972390865,
	X509Store_Close_m369655280,
	X509Store_Open_m2021193476,
	X509SubjectKeyIdentifierExtension__ctor_m3821445495,
	X509SubjectKeyIdentifierExtension__ctor_m1007866642,
	X509SubjectKeyIdentifierExtension__ctor_m2481719515,
	X509SubjectKeyIdentifierExtension__ctor_m2876160692,
	X509SubjectKeyIdentifierExtension__ctor_m1550638166,
	X509SubjectKeyIdentifierExtension__ctor_m2033331363,
	X509SubjectKeyIdentifierExtension_get_SubjectKeyIdentifier_m2217507528,
	X509SubjectKeyIdentifierExtension_CopyFrom_m2942703343,
	X509SubjectKeyIdentifierExtension_FromHexChar_m2113243667,
	X509SubjectKeyIdentifierExtension_FromHexChars_m1282499442,
	X509SubjectKeyIdentifierExtension_FromHex_m3075151455,
	X509SubjectKeyIdentifierExtension_Decode_m813371828,
	X509SubjectKeyIdentifierExtension_Encode_m558430525,
	X509SubjectKeyIdentifierExtension_ToString_m3894933131,
	BaseMachine__ctor_m4084020858,
	BaseMachine_Scan_m3268312916,
	Capture__ctor_m3641620806,
	Capture__ctor_m1068818810,
	Capture_get_Index_m338765806,
	Capture_get_Length_m2890330190,
	Capture_get_Value_m4065226265,
	Capture_ToString_m1617592058,
	Capture_get_Text_m999705200,
	CaptureCollection__ctor_m2434469797,
	CaptureCollection_get_Count_m2620041631,
	CaptureCollection_SetValue_m3580350314,
	CaptureCollection_get_SyncRoot_m1235288200,
	CaptureCollection_CopyTo_m476172626,
	CaptureCollection_GetEnumerator_m2751155309,
	CategoryUtils_CategoryFromName_m3454984674,
	CategoryUtils_IsCategory_m1954085905,
	CategoryUtils_IsCategory_m1631542215,
	FactoryCache__ctor_m3110918728,
	FactoryCache_Add_m333224650,
	FactoryCache_Cleanup_m2321743382,
	FactoryCache_Lookup_m1107376873,
	Key__ctor_m3271912660,
	Key_GetHashCode_m4029769586,
	Key_Equals_m2944673701,
	Key_ToString_m1916919406,
	Group__ctor_m1581832311,
	Group__ctor_m1380117201,
	Group__ctor_m974563356,
	Group__cctor_m745321436,
	Group_get_Captures_m3811459642,
	Group_get_Success_m2194759106,
	GroupCollection__ctor_m3960019923,
	GroupCollection_get_Count_m1310531683,
	GroupCollection_get_Item_m1153500950,
	GroupCollection_SetValue_m3255312432,
	GroupCollection_get_SyncRoot_m2726667879,
	GroupCollection_CopyTo_m4209509466,
	GroupCollection_GetEnumerator_m2022831241,
	Interpreter__ctor_m804634620,
	Interpreter_ReadProgramCount_m1005652950,
	Interpreter_Scan_m2287197984,
	Interpreter_Reset_m1045573326,
	Interpreter_Eval_m1396764476,
	Interpreter_EvalChar_m3505508938,
	Interpreter_TryMatch_m3206370614,
	Interpreter_IsPosition_m2416589926,
	Interpreter_IsWordChar_m1078367919,
	Interpreter_GetString_m1446051119,
	Interpreter_Open_m2367898279,
	Interpreter_Close_m3231684097,
	Interpreter_Balance_m1823429025,
	Interpreter_Checkpoint_m484310107,
	Interpreter_Backtrack_m4289283913,
	Interpreter_ResetGroups_m4240955779,
	Interpreter_GetLastDefined_m452748063,
	Interpreter_CreateMark_m2754475756,
	Interpreter_GetGroupInfo_m615692711,
	Interpreter_PopulateGroup_m4206034385,
	Interpreter_GenerateMatch_m2660368459,
	IntStack_Pop_m3722683769_AdjustorThunk,
	IntStack_Push_m1635691781_AdjustorThunk,
	IntStack_get_Count_m3039047661_AdjustorThunk,
	IntStack_set_Count_m2003476785_AdjustorThunk,
	RepeatContext__ctor_m2229900814,
	RepeatContext_get_Count_m2181802077,
	RepeatContext_set_Count_m2572177685,
	RepeatContext_get_Start_m1293738790,
	RepeatContext_set_Start_m990883173,
	RepeatContext_get_IsMinimum_m1953926463,
	RepeatContext_get_IsMaximum_m1324672030,
	RepeatContext_get_IsLazy_m2930525391,
	RepeatContext_get_Expression_m3316144173,
	RepeatContext_get_Previous_m1045665069,
	InterpreterFactory__ctor_m3863904418,
	InterpreterFactory_NewInstance_m2528127587,
	InterpreterFactory_get_GroupCount_m98333284,
	InterpreterFactory_get_Gap_m2707604386,
	InterpreterFactory_set_Gap_m3151466641,
	InterpreterFactory_get_Mapping_m3535354017,
	InterpreterFactory_set_Mapping_m166844383,
	InterpreterFactory_get_NamesMapping_m2772135229,
	InterpreterFactory_set_NamesMapping_m3924398020,
	Interval__ctor_m56080377_AdjustorThunk,
	Interval_get_Empty_m243986300,
	Interval_get_IsDiscontiguous_m801604911_AdjustorThunk,
	Interval_get_IsSingleton_m4216198275_AdjustorThunk,
	Interval_get_IsEmpty_m994480924_AdjustorThunk,
	Interval_get_Size_m608071487_AdjustorThunk,
	Interval_IsDisjoint_m2524723846_AdjustorThunk,
	Interval_IsAdjacent_m2556513672_AdjustorThunk,
	Interval_Contains_m1571606611_AdjustorThunk,
	Interval_Contains_m3342353116_AdjustorThunk,
	Interval_Intersects_m3216855994_AdjustorThunk,
	Interval_Merge_m2946312130_AdjustorThunk,
	Interval_CompareTo_m3815929644_AdjustorThunk,
	IntervalCollection__ctor_m1313218258,
	IntervalCollection_get_Item_m2537028855,
	IntervalCollection_Add_m1622943099,
	IntervalCollection_Normalize_m3628515323,
	IntervalCollection_GetMetaCollection_m1648565138,
	IntervalCollection_Optimize_m2102410078,
	IntervalCollection_get_Count_m1214350167,
	IntervalCollection_get_SyncRoot_m2297894933,
	IntervalCollection_CopyTo_m2391624220,
	IntervalCollection_GetEnumerator_m1462566,
	CostDelegate__ctor_m1641520847,
	CostDelegate_Invoke_m2352390745,
	CostDelegate_BeginInvoke_m4143628807,
	CostDelegate_EndInvoke_m2898868193,
	Enumerator__ctor_m731076298,
	Enumerator_get_Current_m400005700,
	Enumerator_MoveNext_m621925305,
	Enumerator_Reset_m1187950456,
	LinkRef__ctor_m115717970,
	LinkStack__ctor_m3590709140,
	LinkStack_Push_m1643249603,
	LinkStack_Pop_m2631501487,
	Mark_get_IsDefined_m3052049299_AdjustorThunk,
	Mark_get_Index_m3778528825_AdjustorThunk,
	Mark_get_Length_m1936833463_AdjustorThunk,
	Match__ctor_m4138167299,
	Match__ctor_m1230053901,
	Match__ctor_m4092008910,
	Match__cctor_m950904057,
	Match_get_Empty_m2989863553,
	Match_get_Groups_m2472995486,
	Match_NextMatch_m2724645654,
	Match_get_Regex_m3430681050,
	MatchCollection__ctor_m3291470240,
	MatchCollection_get_Count_m1252685359,
	MatchCollection_get_Item_m1236870324,
	MatchCollection_get_SyncRoot_m4141550550,
	MatchCollection_CopyTo_m3356170189,
	MatchCollection_GetEnumerator_m42466798,
	MatchCollection_TryToGet_m1484228680,
	MatchCollection_get_FullList_m501322905,
	Enumerator__ctor_m4142914143,
	Enumerator_System_Collections_IEnumerator_Reset_m41729423,
	Enumerator_System_Collections_IEnumerator_get_Current_m3948877931,
	Enumerator_System_Collections_IEnumerator_MoveNext_m2284117019,
	MRUList__ctor_m1781461164,
	MRUList_Use_m1901538896,
	MRUList_Evict_m1764791586,
	Node__ctor_m2776986241,
	PatternCompiler__ctor_m410115436,
	PatternCompiler_EncodeOp_m2901316554,
	PatternCompiler_GetMachineFactory_m2648131593,
	PatternCompiler_EmitFalse_m2640584393,
	PatternCompiler_EmitTrue_m1022795498,
	PatternCompiler_EmitCount_m3294248707,
	PatternCompiler_EmitCharacter_m2653938343,
	PatternCompiler_EmitCategory_m2518950337,
	PatternCompiler_EmitNotCategory_m1071501134,
	PatternCompiler_EmitRange_m2459956573,
	PatternCompiler_EmitSet_m1062023712,
	PatternCompiler_EmitString_m1185175630,
	PatternCompiler_EmitPosition_m1696976247,
	PatternCompiler_EmitOpen_m592558635,
	PatternCompiler_EmitClose_m1170569105,
	PatternCompiler_EmitBalanceStart_m2601415548,
	PatternCompiler_EmitBalance_m4112245197,
	PatternCompiler_EmitReference_m3950472736,
	PatternCompiler_EmitIfDefined_m3742773374,
	PatternCompiler_EmitSub_m1489955558,
	PatternCompiler_EmitTest_m2939752100,
	PatternCompiler_EmitBranch_m943585207,
	PatternCompiler_EmitJump_m3344301169,
	PatternCompiler_EmitRepeat_m1500105114,
	PatternCompiler_EmitUntil_m2024071189,
	PatternCompiler_EmitFastRepeat_m3606913334,
	PatternCompiler_EmitIn_m3864996455,
	PatternCompiler_EmitAnchor_m2942110370,
	PatternCompiler_EmitInfo_m2366746382,
	PatternCompiler_NewLink_m647017702,
	PatternCompiler_ResolveLink_m1268480421,
	PatternCompiler_EmitBranchEnd_m1675597919,
	PatternCompiler_EmitAlternationEnd_m3445383137,
	PatternCompiler_MakeFlags_m4079825653,
	PatternCompiler_Emit_m1702133176,
	PatternCompiler_Emit_m3786016948,
	PatternCompiler_Emit_m970277532,
	PatternCompiler_get_CurrentAddress_m1636342801,
	PatternCompiler_BeginLink_m3756888575,
	PatternCompiler_EmitLink_m668125758,
	PatternLinkStack__ctor_m3478661650,
	PatternLinkStack_set_BaseAddress_m2740867805,
	PatternLinkStack_get_OffsetAddress_m2597479309,
	PatternLinkStack_set_OffsetAddress_m843732842,
	PatternLinkStack_GetOffset_m3240753922,
	PatternLinkStack_GetCurrent_m3801736097,
	PatternLinkStack_SetCurrent_m1220160224,
	QuickSearch__ctor_m4059767917,
	QuickSearch__cctor_m2344235813,
	QuickSearch_get_Length_m399794991,
	QuickSearch_Search_m515408899,
	QuickSearch_SetupShiftTable_m858007187,
	QuickSearch_GetShiftDistance_m12615168,
	QuickSearch_GetChar_m4230039001,
	Regex__ctor_m2152913977,
	Regex__ctor_m1710967937,
	Regex__ctor_m3286392212,
	Regex__ctor_m349172803,
	Regex__cctor_m297163374,
	Regex_System_Runtime_Serialization_ISerializable_GetObjectData_m4270565887,
	Regex_validate_options_m3934692030,
	Regex_Init_m2144493458,
	Regex_InitNewRegex_m778207142,
	Regex_CreateMachineFactory_m3188339410,
	Regex_get_Options_m2702568210,
	Regex_get_RightToLeft_m391807453,
	Regex_GetGroupIndex_m1445574727,
	Regex_default_startat_m3082441407,
	Regex_IsMatch_m2092521843,
	Regex_IsMatch_m3684892322,
	Regex_Match_m1845182378,
	Regex_Matches_m145108686,
	Regex_Matches_m2227589686,
	Regex_ToString_m1187978950,
	Regex_get_Gap_m3479581456,
	Regex_CreateMachine_m1313339656,
	Regex_GetGroupNamesArray_m1682668965,
	Regex_get_GroupNumbers_m770788777,
	Alternation__ctor_m1928818157,
	Alternation_get_Alternatives_m1120962893,
	Alternation_AddAlternative_m1617589135,
	Alternation_Compile_m20073373,
	Alternation_GetWidth_m1207664397,
	AnchorInfo__ctor_m824858336,
	AnchorInfo__ctor_m2851148696,
	AnchorInfo__ctor_m1473803883,
	AnchorInfo_get_Offset_m1319987204,
	AnchorInfo_get_Width_m493853670,
	AnchorInfo_get_Length_m1465965650,
	AnchorInfo_get_IsUnknownWidth_m662726343,
	AnchorInfo_get_IsComplete_m1743357072,
	AnchorInfo_get_Substring_m1684539014,
	AnchorInfo_get_IgnoreCase_m437969666,
	AnchorInfo_get_Position_m3190094805,
	AnchorInfo_get_IsSubstring_m4002693124,
	AnchorInfo_get_IsPosition_m3021919887,
	AnchorInfo_GetInterval_m2655761101,
	Assertion__ctor_m398595606,
	Assertion_get_TrueExpression_m2259873105,
	Assertion_set_TrueExpression_m1985969396,
	Assertion_get_FalseExpression_m330764519,
	Assertion_set_FalseExpression_m3409248562,
	Assertion_GetWidth_m1502322795,
	BackslashNumber__ctor_m3447276269,
	BackslashNumber_ResolveReference_m3158307001,
	BackslashNumber_Compile_m984574971,
	BalancingGroup__ctor_m2831526052,
	BalancingGroup_set_Balance_m1137491036,
	BalancingGroup_Compile_m722938181,
	CaptureAssertion__ctor_m3123794115,
	CaptureAssertion_set_CapturingGroup_m973632836,
	CaptureAssertion_Compile_m2292386304,
	CaptureAssertion_IsComplex_m859291764,
	CaptureAssertion_get_Alternate_m3292690552,
	CapturingGroup__ctor_m1629266381,
	CapturingGroup_get_Index_m106793448,
	CapturingGroup_set_Index_m1742842172,
	CapturingGroup_get_Name_m363976611,
	CapturingGroup_set_Name_m2976480153,
	CapturingGroup_get_IsNamed_m3740804414,
	CapturingGroup_Compile_m2827666078,
	CapturingGroup_IsComplex_m1142236473,
	CapturingGroup_CompareTo_m1522854790,
	CharacterClass__ctor_m887051867,
	CharacterClass__ctor_m2813845994,
	CharacterClass__cctor_m395790389,
	CharacterClass_AddCategory_m3684686996,
	CharacterClass_AddCharacter_m3247269656,
	CharacterClass_AddRange_m305568238,
	CharacterClass_Compile_m1290198257,
	CharacterClass_GetWidth_m656030323,
	CharacterClass_IsComplex_m3098294588,
	CharacterClass_GetIntervalCost_m2101477823,
	CompositeExpression__ctor_m1934809119,
	CompositeExpression_get_Expressions_m49895278,
	CompositeExpression_GetWidth_m1995740879,
	CompositeExpression_IsComplex_m1142190359,
	Expression__ctor_m2833584603,
	Expression_GetFixedWidth_m1958842952,
	Expression_GetAnchorInfo_m2896655711,
	ExpressionAssertion__ctor_m3257347577,
	ExpressionAssertion_set_Reverse_m518904159,
	ExpressionAssertion_set_Negate_m2956012353,
	ExpressionAssertion_get_TestExpression_m1394104218,
	ExpressionAssertion_set_TestExpression_m3171393795,
	ExpressionAssertion_Compile_m2065362775,
	ExpressionAssertion_IsComplex_m4133577483,
	ExpressionCollection__ctor_m1397747210,
	ExpressionCollection_Add_m1497088939,
	ExpressionCollection_get_Item_m3015047122,
	ExpressionCollection_set_Item_m899574536,
	ExpressionCollection_OnValidate_m834765135,
	Group__ctor_m3448404732,
	Group_AppendExpression_m755733818,
	Group_Compile_m534411174,
	Group_GetWidth_m511968788,
	Group_GetAnchorInfo_m3709280256,
	Literal__ctor_m3783101682,
	Literal_CompileLiteral_m467234476,
	Literal_Compile_m3984565343,
	Literal_GetWidth_m4116851574,
	Literal_GetAnchorInfo_m3654853643,
	Literal_IsComplex_m1701526983,
	NonBacktrackingGroup__ctor_m1434515617,
	NonBacktrackingGroup_Compile_m15580587,
	NonBacktrackingGroup_IsComplex_m3028987305,
	Parser__ctor_m1624682398,
	Parser_ParseDecimal_m2165142223,
	Parser_ParseOctal_m1575012645,
	Parser_ParseHex_m537456312,
	Parser_ParseNumber_m3552252646,
	Parser_ParseName_m3162581411,
	Parser_ParseRegularExpression_m1535595762,
	Parser_GetMapping_m3031693366,
	Parser_ParseGroup_m3055023692,
	Parser_ParseGroupingConstruct_m3582473049,
	Parser_ParseAssertionType_m3369870575,
	Parser_ParseOptions_m1380880684,
	Parser_ParseCharacterClass_m94403723,
	Parser_ParseRepetitionBounds_m310221816,
	Parser_ParseUnicodeCategory_m3196734900,
	Parser_ParseSpecial_m841116392,
	Parser_ParseEscape_m857679945,
	Parser_ParseName_m2170905461,
	Parser_IsNameChar_m2317119264,
	Parser_ParseNumber_m655594974,
	Parser_ParseDigit_m3652462519,
	Parser_ConsumeWhitespace_m508757941,
	Parser_ResolveReferences_m2213940638,
	Parser_HandleExplicitNumericGroups_m3519363816,
	Parser_IsIgnoreCase_m304301899,
	Parser_IsMultiline_m3866250345,
	Parser_IsExplicitCapture_m1338376295,
	Parser_IsSingleline_m1052655427,
	Parser_IsIgnorePatternWhitespace_m3572327486,
	Parser_IsECMAScript_m1081327743,
	Parser_NewParseException_m1848723036,
	PositionAssertion__ctor_m2403739134,
	PositionAssertion_Compile_m1316517346,
	PositionAssertion_GetWidth_m3342085669,
	PositionAssertion_IsComplex_m709315024,
	PositionAssertion_GetAnchorInfo_m2632727543,
	Reference__ctor_m1535544569,
	Reference_get_CapturingGroup_m1229793376,
	Reference_set_CapturingGroup_m2320303589,
	Reference_get_IgnoreCase_m1970330033,
	Reference_Compile_m1360992492,
	Reference_GetWidth_m3585605624,
	Reference_IsComplex_m3217857356,
	RegularExpression__ctor_m4104829235,
	RegularExpression_set_GroupCount_m257952646,
	RegularExpression_Compile_m3503254582,
	Repetition__ctor_m894351731,
	Repetition_get_Expression_m3416660833,
	Repetition_set_Expression_m1682832613,
	Repetition_get_Minimum_m3382307448,
	Repetition_Compile_m3524912164,
	Repetition_GetWidth_m1885879497,
	Repetition_GetAnchorInfo_m1246107493,
	Uri__ctor_m3348164601,
	Uri__ctor_m3232901013,
	Uri__ctor_m1296127773,
	Uri__ctor_m1252356203,
	Uri__ctor_m3676275920,
	Uri__cctor_m670386229,
	Uri_System_Runtime_Serialization_ISerializable_GetObjectData_m1787623764,
	Uri_Merge_m3329659150,
	Uri_get_AbsoluteUri_m2013121997,
	Uri_get_Authority_m2303303812,
	Uri_get_Host_m2432049313,
	Uri_get_IsFile_m3505615125,
	Uri_get_IsLoopback_m4019510841,
	Uri_get_IsUnc_m3264105637,
	Uri_get_Scheme_m3469071689,
	Uri_get_IsAbsoluteUri_m139224931,
	Uri_get_OriginalString_m3905916304,
	Uri_CheckHostName_m858702357,
	Uri_IsIPv4Address_m3276606606,
	Uri_IsDomainAddress_m1246829380,
	Uri_CheckSchemeName_m4037918197,
	Uri_IsAlpha_m1200488333,
	Uri_Equals_m2284165007,
	Uri_InternalEquals_m3302240146,
	Uri_GetHashCode_m1596773147,
	Uri_GetLeftPart_m86636703,
	Uri_FromHex_m3563680093,
	Uri_HexEscape_m3670676588,
	Uri_IsHexDigit_m4143014970,
	Uri_IsHexEncoding_m846496275,
	Uri_AppendQueryAndFragment_m770779446,
	Uri_ToString_m3161250604,
	Uri_EscapeString_m3040128922,
	Uri_EscapeString_m2069814481,
	Uri_ParseUri_m2241113980,
	Uri_Unescape_m772995138,
	Uri_Unescape_m247455015,
	Uri_ParseAsWindowsUNC_m4171604414,
	Uri_ParseAsWindowsAbsoluteFilePath_m239351627,
	Uri_ParseAsUnixAbsoluteFilePath_m685806022,
	Uri_Parse_m1835669794,
	Uri_ParseNoExceptions_m939127859,
	Uri_CompactEscaped_m1802822627,
	Uri_Reduce_m2274440801,
	Uri_HexUnescapeMultiByte_m1299350805,
	Uri_GetSchemeDelimiter_m1906926383,
	Uri_GetDefaultPort_m1490273727,
	Uri_GetOpaqueWiseSchemeDelimiter_m695787016,
	Uri_IsPredefinedScheme_m1610104302,
	Uri_get_Parser_m4049015381,
	Uri_EnsureAbsoluteUri_m3222131342,
	Uri_op_Equality_m2744738567,
	UriScheme__ctor_m490875041_AdjustorThunk,
	UriFormatException__ctor_m1696921716,
	UriFormatException__ctor_m24411027,
	UriFormatException__ctor_m814282742,
	UriFormatException_System_Runtime_Serialization_ISerializable_GetObjectData_m2999057613,
	UriParser__ctor_m1773679871,
	UriParser__cctor_m1593326550,
	UriParser_InitializeAndValidate_m1248295043,
	UriParser_OnRegister_m3840206273,
	UriParser_set_SchemeName_m3234468530,
	UriParser_get_DefaultPort_m1674135503,
	UriParser_set_DefaultPort_m1715738360,
	UriParser_CreateDefaults_m2561524976,
	UriParser_InternalRegister_m3668852610,
	UriParser_GetParser_m2093785923,
	Locale_GetText_m942401560,
	BigInteger__ctor_m3040047200,
	BigInteger__ctor_m4290790657,
	BigInteger__ctor_m3107529596,
	BigInteger__ctor_m2655203050,
	BigInteger__ctor_m2947591044,
	BigInteger__cctor_m925432748,
	BigInteger_get_Rng_m1252581024,
	BigInteger_GenerateRandom_m238978006,
	BigInteger_GenerateRandom_m2624136324,
	BigInteger_BitCount_m4273960697,
	BigInteger_TestBit_m3127499382,
	BigInteger_SetBit_m1548788441,
	BigInteger_SetBit_m2995356053,
	BigInteger_LowestSetBit_m1562554553,
	BigInteger_GetBytes_m828519052,
	BigInteger_ToString_m974324122,
	BigInteger_ToString_m2613494688,
	BigInteger_Normalize_m1168693604,
	BigInteger_Clear_m1006056064,
	BigInteger_GetHashCode_m2499559039,
	BigInteger_ToString_m1423031679,
	BigInteger_Equals_m1747576300,
	BigInteger_ModInverse_m2074417766,
	BigInteger_ModPow_m2422803179,
	BigInteger_GeneratePseudoPrime_m3903026346,
	BigInteger_Incr2_m2993801397,
	BigInteger_op_Implicit_m1053202820,
	BigInteger_op_Implicit_m2599149503,
	BigInteger_op_Addition_m4246822083,
	BigInteger_op_Subtraction_m2921645157,
	BigInteger_op_Modulus_m1699883937,
	BigInteger_op_Modulus_m2023755691,
	BigInteger_op_Division_m1613931499,
	BigInteger_op_Multiply_m714911343,
	BigInteger_op_LeftShift_m4103973491,
	BigInteger_op_RightShift_m3299250634,
	BigInteger_op_Equality_m294921050,
	BigInteger_op_Inequality_m1285189855,
	BigInteger_op_Equality_m850722513,
	BigInteger_op_Inequality_m4114052575,
	BigInteger_op_GreaterThan_m81356145,
	BigInteger_op_LessThan_m646428307,
	BigInteger_op_GreaterThanOrEqual_m3156148447,
	BigInteger_op_LessThanOrEqual_m3140405012,
	Kernel_AddSameSign_m2969372982,
	Kernel_Subtract_m1106059469,
	Kernel_MinusEq_m3085426594,
	Kernel_PlusEq_m3851100234,
	Kernel_Compare_m334500803,
	Kernel_SingleByteDivideInPlace_m1500186441,
	Kernel_DwordMod_m4269311808,
	Kernel_DwordDivMod_m4023601570,
	Kernel_multiByteDivide_m760606649,
	Kernel_LeftShift_m1732871444,
	Kernel_RightShift_m4142931590,
	Kernel_Multiply_m1928927344,
	Kernel_MultiplyMod2p32pmod_m2454258067,
	Kernel_modInverse_m1415510529,
	Kernel_modInverse_m3659691283,
	ModulusRing__ctor_m786617357,
	ModulusRing_BarrettReduction_m1658994967,
	ModulusRing_Multiply_m1279044268,
	ModulusRing_Difference_m1148123159,
	ModulusRing_Pow_m3336321534,
	ModulusRing_Pow_m4156652970,
	PrimeGeneratorBase__ctor_m2461768112,
	PrimeGeneratorBase_get_Confidence_m430559964,
	PrimeGeneratorBase_get_PrimalityTest_m1500128059,
	PrimeGeneratorBase_get_TrialDivisionBounds_m2021639477,
	SequentialSearchPrimeGeneratorBase__ctor_m1926266009,
	SequentialSearchPrimeGeneratorBase_GenerateSearchBase_m1640156251,
	SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m616189243,
	SequentialSearchPrimeGeneratorBase_GenerateNewPrime_m1410289324,
	SequentialSearchPrimeGeneratorBase_IsPrimeAcceptable_m4283101715,
	PrimalityTest__ctor_m1649143675,
	PrimalityTest_Invoke_m2505690669,
	PrimalityTest_BeginInvoke_m4252933746,
	PrimalityTest_EndInvoke_m2207734714,
	PrimalityTests_GetSPPRounds_m3858806831,
	PrimalityTests_RabinMillerTest_m3372622796,
	ASN1__ctor_m1530949167,
	ASN1__ctor_m2207550225,
	ASN1__ctor_m663943558,
	ASN1_get_Count_m3514133667,
	ASN1_get_Tag_m671763313,
	ASN1_get_Length_m3357792533,
	ASN1_get_Value_m1563037521,
	ASN1_set_Value_m3219014527,
	ASN1_CompareArray_m601385103,
	ASN1_CompareValue_m2380040405,
	ASN1_Add_m2935298555,
	ASN1_GetBytes_m1347548052,
	ASN1_Decode_m421083504,
	ASN1_DecodeTLV_m3033110137,
	ASN1_get_Item_m1219168070,
	ASN1_Element_m914257385,
	ASN1_ToString_m4000515052,
	ASN1Convert_FromInt32_m2200170205,
	ASN1Convert_FromOid_m934152182,
	ASN1Convert_ToInt32_m2352803718,
	ASN1Convert_ToOid_m1258403924,
	ASN1Convert_ToDateTime_m1328396727,
	BitConverterLE_GetUIntBytes_m1384569885,
	BitConverterLE_GetBytes_m2412841700,
	ARC4Managed__ctor_m2574020285,
	ARC4Managed_Finalize_m2148772049,
	ARC4Managed_Dispose_m2710895473,
	ARC4Managed_get_Key_m895766196,
	ARC4Managed_set_Key_m1143489015,
	ARC4Managed_get_CanReuseTransform_m3551629669,
	ARC4Managed_CreateEncryptor_m614861295,
	ARC4Managed_CreateDecryptor_m3676499029,
	ARC4Managed_GenerateIV_m2848265659,
	ARC4Managed_GenerateKey_m1412660680,
	ARC4Managed_KeySetup_m2603934730,
	ARC4Managed_CheckInput_m3888795245,
	ARC4Managed_TransformBlock_m249171651,
	ARC4Managed_InternalTransformBlock_m702959129,
	ARC4Managed_TransformFinalBlock_m85404601,
	CryptoConvert_ToHex_m2874115614,
	HMAC__ctor_m2350580409,
	HMAC_get_Key_m2145604251,
	HMAC_set_Key_m49633678,
	HMAC_Initialize_m2128632358,
	HMAC_HashFinal_m302978610,
	HMAC_HashCore_m902726834,
	HMAC_initializePad_m104781443,
	KeyBuilder_get_Rng_m390497396,
	KeyBuilder_Key_m1555863487,
	MD2__ctor_m1551032726,
	MD2_Create_m3228747869,
	MD2_Create_m320237521,
	MD2Managed__ctor_m3399753397,
	MD2Managed__cctor_m3778632564,
	MD2Managed_Padding_m2385175461,
	MD2Managed_Initialize_m1809936405,
	MD2Managed_HashCore_m783128322,
	MD2Managed_HashFinal_m1157314737,
	MD2Managed_MD2Transform_m3020703703,
	MD4__ctor_m3027213364,
	MD4_Create_m3258860119,
	MD4_Create_m3923361414,
	MD4Managed__ctor_m3926348398,
	MD4Managed_Initialize_m537126806,
	MD4Managed_HashCore_m3698561284,
	MD4Managed_HashFinal_m236989277,
	MD4Managed_Padding_m1030210229,
	MD4Managed_F_m4014378268,
	MD4Managed_G_m1583243911,
	MD4Managed_H_m213622522,
	MD4Managed_ROL_m4179454275,
	MD4Managed_FF_m3540939855,
	MD4Managed_GG_m4200015153,
	MD4Managed_HH_m3395074399,
	MD4Managed_Encode_m3938310465,
	MD4Managed_Decode_m3755082395,
	MD4Managed_MD4Transform_m2381702939,
	MD5SHA1__ctor_m2795497798,
	MD5SHA1_Initialize_m667354197,
	MD5SHA1_HashFinal_m1774759575,
	MD5SHA1_HashCore_m723438337,
	MD5SHA1_CreateSignature_m386328975,
	MD5SHA1_VerifySignature_m2021453399,
	PKCS1__cctor_m1181663908,
	PKCS1_Compare_m1604695389,
	PKCS1_I2OSP_m1521391326,
	PKCS1_OS2IP_m1998787336,
	PKCS1_RSASP1_m1693518040,
	PKCS1_RSAVP1_m2152666711,
	PKCS1_Sign_v15_m309973407,
	PKCS1_Verify_v15_m4288865952,
	PKCS1_Verify_v15_m1929947392,
	PKCS1_Encode_v15_m2755555715,
	EncryptedPrivateKeyInfo__ctor_m3590714673,
	EncryptedPrivateKeyInfo__ctor_m1843255414,
	EncryptedPrivateKeyInfo_get_Algorithm_m1079349399,
	EncryptedPrivateKeyInfo_get_EncryptedData_m2030517224,
	EncryptedPrivateKeyInfo_get_Salt_m1846754638,
	EncryptedPrivateKeyInfo_get_IterationCount_m4284424872,
	EncryptedPrivateKeyInfo_Decode_m3601396636,
	PrivateKeyInfo__ctor_m1237589692,
	PrivateKeyInfo__ctor_m4219676801,
	PrivateKeyInfo_get_PrivateKey_m3262798750,
	PrivateKeyInfo_Decode_m2276932701,
	PrivateKeyInfo_RemoveLeadingZero_m3182739459,
	PrivateKeyInfo_Normalize_m2035008135,
	PrivateKeyInfo_DecodeRSA_m1537516818,
	PrivateKeyInfo_DecodeDSA_m550432302,
	RC4__ctor_m4271839561,
	RC4__cctor_m1937931724,
	RC4_get_IV_m396864526,
	RC4_set_IV_m1338082778,
	RSAManaged__ctor_m2505588350,
	RSAManaged__ctor_m4060578812,
	RSAManaged_Finalize_m1973406382,
	RSAManaged_GenerateKeyPair_m210133981,
	RSAManaged_get_KeySize_m1513772531,
	RSAManaged_get_PublicOnly_m1997870060,
	RSAManaged_DecryptValue_m377747502,
	RSAManaged_EncryptValue_m3224637528,
	RSAManaged_ExportParameters_m4220341555,
	RSAManaged_ImportParameters_m116434100,
	RSAManaged_Dispose_m440951713,
	RSAManaged_ToXmlString_m3830541597,
	RSAManaged_GetPaddedValue_m3038337403,
	KeyGeneratedEventHandler__ctor_m591696252,
	KeyGeneratedEventHandler_Invoke_m2823279036,
	KeyGeneratedEventHandler_BeginInvoke_m229179016,
	KeyGeneratedEventHandler_EndInvoke_m3115686752,
	ContentInfo__ctor_m3422405402,
	ContentInfo__ctor_m2765343486,
	ContentInfo__ctor_m3211573373,
	ContentInfo__ctor_m434478412,
	ContentInfo_get_ASN1_m1578251455,
	ContentInfo_get_Content_m3252263860,
	ContentInfo_set_Content_m1482307621,
	ContentInfo_get_ContentType_m3232672236,
	ContentInfo_set_ContentType_m1498463555,
	ContentInfo_GetASN1_m1022320466,
	EncryptedData__ctor_m1197706297,
	EncryptedData__ctor_m2094635316,
	EncryptedData_get_EncryptionAlgorithm_m4107847107,
	EncryptedData_get_EncryptedContent_m1500872137,
	Alert__ctor_m3960313528,
	Alert__ctor_m2259743940,
	Alert_get_Level_m1211567354,
	Alert_get_Description_m3184731798,
	Alert_get_IsWarning_m196889914,
	Alert_get_IsCloseNotify_m644254786,
	Alert_inferAlertLevel_m4212996167,
	Alert_GetAlertMessage_m745264909,
	CertificateSelectionCallback__ctor_m1037063776,
	CertificateSelectionCallback_Invoke_m845045433,
	CertificateSelectionCallback_BeginInvoke_m386427038,
	CertificateSelectionCallback_EndInvoke_m1729707519,
	CertificateValidationCallback__ctor_m531022621,
	CertificateValidationCallback_Invoke_m3326233986,
	CertificateValidationCallback_BeginInvoke_m2551305279,
	CertificateValidationCallback_EndInvoke_m68592148,
	CertificateValidationCallback2__ctor_m1348748949,
	CertificateValidationCallback2_Invoke_m3750848618,
	CertificateValidationCallback2_BeginInvoke_m1026766960,
	CertificateValidationCallback2_EndInvoke_m2103952377,
	CipherSuite__ctor_m3238057673,
	CipherSuite__cctor_m2886247321,
	CipherSuite_get_EncryptionCipher_m3907182089,
	CipherSuite_get_DecryptionCipher_m1728914303,
	CipherSuite_get_ClientHMAC_m545977915,
	CipherSuite_get_ServerHMAC_m4179848733,
	CipherSuite_get_CipherAlgorithmType_m1369943773,
	CipherSuite_get_HashAlgorithmName_m2441595063,
	CipherSuite_get_HashAlgorithmType_m63516961,
	CipherSuite_get_HashSize_m3493484425,
	CipherSuite_get_ExchangeAlgorithmType_m2191904983,
	CipherSuite_get_CipherMode_m722281993,
	CipherSuite_get_Code_m3233650270,
	CipherSuite_get_Name_m146691250,
	CipherSuite_get_IsExportable_m3752663011,
	CipherSuite_get_KeyMaterialSize_m2547888576,
	CipherSuite_get_KeyBlockSize_m858464013,
	CipherSuite_get_ExpandedKeyMaterialSize_m2832732491,
	CipherSuite_get_EffectiveKeyBits_m1229195912,
	CipherSuite_get_IvSize_m3368985968,
	CipherSuite_get_Context_m2736770064,
	CipherSuite_set_Context_m2064029995,
	CipherSuite_Write_m676636739,
	CipherSuite_Write_m3889367699,
	CipherSuite_InitializeCipher_m33195514,
	CipherSuite_EncryptRecord_m3304923834,
	CipherSuite_DecryptRecord_m3624678067,
	CipherSuite_CreatePremasterSecret_m3240677517,
	CipherSuite_PRF_m224011433,
	CipherSuite_Expand_m124298141,
	CipherSuite_createEncryptionCipher_m1872228627,
	CipherSuite_createDecryptionCipher_m974093277,
	CipherSuiteCollection__ctor_m2912717739,
	CipherSuiteCollection_System_Collections_IList_get_Item_m1307094960,
	CipherSuiteCollection_System_Collections_IList_set_Item_m392670202,
	CipherSuiteCollection_System_Collections_ICollection_get_SyncRoot_m2380123721,
	CipherSuiteCollection_System_Collections_IEnumerable_GetEnumerator_m3457794598,
	CipherSuiteCollection_System_Collections_IList_Contains_m2253368777,
	CipherSuiteCollection_System_Collections_IList_IndexOf_m373506972,
	CipherSuiteCollection_System_Collections_IList_Insert_m2934430661,
	CipherSuiteCollection_System_Collections_IList_Remove_m1818202553,
	CipherSuiteCollection_System_Collections_IList_RemoveAt_m1577796664,
	CipherSuiteCollection_System_Collections_IList_Add_m1343552861,
	CipherSuiteCollection_get_Item_m1951170518,
	CipherSuiteCollection_get_Item_m3024799401,
	CipherSuiteCollection_set_Item_m1243143140,
	CipherSuiteCollection_get_Item_m1448468422,
	CipherSuiteCollection_get_Count_m2326692355,
	CipherSuiteCollection_CopyTo_m2265539659,
	CipherSuiteCollection_Clear_m194062517,
	CipherSuiteCollection_IndexOf_m2804224314,
	CipherSuiteCollection_IndexOf_m3646000520,
	CipherSuiteCollection_Add_m1162497026,
	CipherSuiteCollection_add_m1386009775,
	CipherSuiteCollection_add_m2193951846,
	CipherSuiteCollection_cultureAwareCompare_m1656419337,
	CipherSuiteFactory_GetSupportedCiphers_m3100505535,
	CipherSuiteFactory_GetTls1SupportedCiphers_m2307500680,
	CipherSuiteFactory_GetSsl3SupportedCiphers_m3037057534,
	ClientContext__ctor_m4206399174,
	ClientContext_get_SslStream_m3280236306,
	ClientContext_get_ClientHelloProtocol_m549457804,
	ClientContext_set_ClientHelloProtocol_m3002521062,
	ClientContext_Clear_m3011543115,
	ClientRecordProtocol__ctor_m2014520355,
	ClientRecordProtocol_GetMessage_m1005146182,
	ClientRecordProtocol_ProcessHandshakeMessage_m3835877856,
	ClientRecordProtocol_createClientHandshakeMessage_m517870575,
	ClientRecordProtocol_createServerHandshakeMessage_m4244780190,
	ClientSessionCache__cctor_m2017799205,
	ClientSessionCache_Add_m2763750836,
	ClientSessionCache_FromHost_m837030325,
	ClientSessionCache_FromContext_m196666535,
	ClientSessionCache_SetContextInCache_m3731615989,
	ClientSessionCache_SetContextFromCache_m4127032905,
	ClientSessionInfo__ctor_m3448346647,
	ClientSessionInfo__cctor_m4029916257,
	ClientSessionInfo_Finalize_m1903692174,
	ClientSessionInfo_get_HostName_m1813423510,
	ClientSessionInfo_get_Id_m1861651764,
	ClientSessionInfo_get_Valid_m108361290,
	ClientSessionInfo_GetContext_m2374376354,
	ClientSessionInfo_SetContext_m3996633527,
	ClientSessionInfo_KeepAlive_m1428910606,
	ClientSessionInfo_Dispose_m3364663612,
	ClientSessionInfo_Dispose_m2740391058,
	ClientSessionInfo_CheckDisposed_m3131695358,
	Context__ctor_m3487143758,
	Context_get_AbbreviatedHandshake_m2669858019,
	Context_set_AbbreviatedHandshake_m2710710445,
	Context_get_ProtocolNegotiated_m789604084,
	Context_set_ProtocolNegotiated_m3756570868,
	Context_get_SecurityProtocol_m2757912658,
	Context_set_SecurityProtocol_m3317356583,
	Context_get_SecurityProtocolFlags_m3524319652,
	Context_get_Protocol_m1042868808,
	Context_get_SessionId_m2455183004,
	Context_set_SessionId_m123662079,
	Context_get_CompressionMethod_m3396244842,
	Context_set_CompressionMethod_m3409746309,
	Context_get_ServerSettings_m665092935,
	Context_get_ClientSettings_m3639013314,
	Context_get_LastHandshakeMsg_m2955711067,
	Context_set_LastHandshakeMsg_m2090546789,
	Context_get_HandshakeState_m2458679945,
	Context_set_HandshakeState_m3386485285,
	Context_get_ReceivedConnectionEnd_m3128583971,
	Context_set_ReceivedConnectionEnd_m1451919546,
	Context_get_SentConnectionEnd_m700150566,
	Context_set_SentConnectionEnd_m3449731688,
	Context_get_SupportedCiphers_m1355455486,
	Context_set_SupportedCiphers_m1363192622,
	Context_get_HandshakeMessages_m1050441678,
	Context_get_WriteSequenceNumber_m3416479008,
	Context_set_WriteSequenceNumber_m963357767,
	Context_get_ReadSequenceNumber_m2387323861,
	Context_set_ReadSequenceNumber_m2845416021,
	Context_get_ClientRandom_m2305500516,
	Context_set_ClientRandom_m3044497698,
	Context_get_ServerRandom_m2613499485,
	Context_set_ServerRandom_m3928200091,
	Context_get_RandomCS_m2660362496,
	Context_set_RandomCS_m1286521761,
	Context_get_RandomSC_m3120784806,
	Context_set_RandomSC_m672398920,
	Context_get_MasterSecret_m441975730,
	Context_set_MasterSecret_m2764130687,
	Context_get_ClientWriteKey_m1688510987,
	Context_set_ClientWriteKey_m1144722876,
	Context_get_ServerWriteKey_m97178656,
	Context_set_ServerWriteKey_m3796044638,
	Context_get_ClientWriteIV_m4054803469,
	Context_set_ClientWriteIV_m3047460563,
	Context_get_ServerWriteIV_m258231173,
	Context_set_ServerWriteIV_m172124322,
	Context_get_RecordProtocol_m2454746427,
	Context_set_RecordProtocol_m1453028534,
	Context_GetUnixTime_m3476999680,
	Context_GetSecureRandomBytes_m1050390791,
	Context_Clear_m262551141,
	Context_ClearKeyInfo_m969907945,
	Context_DecodeProtocolCode_m4015438900,
	Context_ChangeProtocol_m2610365909,
	Context_get_Current_m3638905943,
	Context_get_Negotiating_m739161972,
	Context_get_Read_m1345235724,
	Context_get_Write_m3526842162,
	Context_StartSwitchingSecurityParameters_m2793916331,
	Context_EndSwitchingSecurityParameters_m1888801424,
	TlsClientCertificate__ctor_m4188345127,
	TlsClientCertificate_get_ClientCertificate_m2162810393,
	TlsClientCertificate_Update_m3893752988,
	TlsClientCertificate_GetClientCertificate_m3885367635,
	TlsClientCertificate_SendCertificates_m2667924708,
	TlsClientCertificate_ProcessAsSsl3_m1200484296,
	TlsClientCertificate_ProcessAsTls1_m2788357699,
	TlsClientCertificate_FindParentCertificate_m3532186312,
	TlsClientCertificateVerify__ctor_m338572956,
	TlsClientCertificateVerify_Update_m2511791151,
	TlsClientCertificateVerify_ProcessAsSsl3_m2765492448,
	TlsClientCertificateVerify_ProcessAsTls1_m2753986979,
	TlsClientCertificateVerify_getClientCertRSA_m3730379553,
	TlsClientCertificateVerify_getUnsignedBigInteger_m1458425385,
	TlsClientFinished__ctor_m516655734,
	TlsClientFinished__cctor_m1143607366,
	TlsClientFinished_Update_m3939044555,
	TlsClientFinished_ProcessAsSsl3_m4156123412,
	TlsClientFinished_ProcessAsTls1_m2479980324,
	TlsClientHello__ctor_m2277964250,
	TlsClientHello_Update_m2275537526,
	TlsClientHello_ProcessAsSsl3_m1637487823,
	TlsClientHello_ProcessAsTls1_m1595447014,
	TlsClientKeyExchange__ctor_m2822701268,
	TlsClientKeyExchange_ProcessAsSsl3_m2739916873,
	TlsClientKeyExchange_ProcessAsTls1_m602401587,
	TlsClientKeyExchange_ProcessCommon_m682895191,
	TlsServerCertificate__ctor_m282941458,
	TlsServerCertificate_Update_m1900628844,
	TlsServerCertificate_ProcessAsSsl3_m3278094808,
	TlsServerCertificate_ProcessAsTls1_m562387507,
	TlsServerCertificate_checkCertificateUsage_m4181540579,
	TlsServerCertificate_validateCertificates_m1126938502,
	TlsServerCertificate_checkServerIdentity_m2133010983,
	TlsServerCertificate_checkDomainName_m3213917459,
	TlsServerCertificate_Match_m3405733548,
	TlsServerCertificateRequest__ctor_m2645105734,
	TlsServerCertificateRequest_Update_m2630970912,
	TlsServerCertificateRequest_ProcessAsSsl3_m3911069156,
	TlsServerCertificateRequest_ProcessAsTls1_m4269715970,
	TlsServerFinished__ctor_m3230261975,
	TlsServerFinished__cctor_m1633508801,
	TlsServerFinished_Update_m1771319351,
	TlsServerFinished_ProcessAsSsl3_m2165526924,
	TlsServerFinished_ProcessAsTls1_m3714237769,
	TlsServerHello__ctor_m444591022,
	TlsServerHello_Update_m2629871195,
	TlsServerHello_ProcessAsSsl3_m393375042,
	TlsServerHello_ProcessAsTls1_m3486984712,
	TlsServerHello_processProtocol_m3391908470,
	TlsServerHelloDone__ctor_m3361320814,
	TlsServerHelloDone_ProcessAsSsl3_m857276614,
	TlsServerHelloDone_ProcessAsTls1_m951443237,
	TlsServerKeyExchange__ctor_m266967171,
	TlsServerKeyExchange_Update_m412825504,
	TlsServerKeyExchange_ProcessAsSsl3_m2599813925,
	TlsServerKeyExchange_ProcessAsTls1_m3396398902,
	TlsServerKeyExchange_verifySignature_m1928629356,
	HandshakeMessage__ctor_m187395287,
	HandshakeMessage__ctor_m2680747516,
	HandshakeMessage__ctor_m582056598,
	HandshakeMessage_get_Context_m1083485348,
	HandshakeMessage_get_HandshakeType_m2133048855,
	HandshakeMessage_get_ContentType_m914521830,
	HandshakeMessage_Process_m1991805942,
	HandshakeMessage_Update_m3717551506,
	HandshakeMessage_EncodeMessage_m320082085,
	HandshakeMessage_Compare_m1908730859,
	HttpsClientStream__ctor_m1064104888,
	HttpsClientStream_get_TrustFailure_m2709743809,
	HttpsClientStream_RaiseServerCertificateValidation_m3897092030,
	HttpsClientStream_U3CHttpsClientStreamU3Em__0_m2170627081,
	HttpsClientStream_U3CHttpsClientStreamU3Em__1_m1135820886,
	PrivateKeySelectionCallback__ctor_m3337344772,
	PrivateKeySelectionCallback_Invoke_m2047935261,
	PrivateKeySelectionCallback_BeginInvoke_m3340292590,
	PrivateKeySelectionCallback_EndInvoke_m2685876631,
	RecordProtocol__ctor_m2040317979,
	RecordProtocol__cctor_m4109051570,
	RecordProtocol_get_Context_m3495648327,
	RecordProtocol_SendRecord_m3856809599,
	RecordProtocol_ProcessChangeCipherSpec_m2460141099,
	RecordProtocol_GetMessage_m4076299694,
	RecordProtocol_BeginReceiveRecord_m1962336162,
	RecordProtocol_InternalReceiveRecordCallback_m93368051,
	RecordProtocol_EndReceiveRecord_m402307927,
	RecordProtocol_ReceiveRecord_m3686709362,
	RecordProtocol_ReadRecordBuffer_m2213213812,
	RecordProtocol_ReadClientHelloV2_m752890893,
	RecordProtocol_ReadStandardRecordBuffer_m1267363110,
	RecordProtocol_ProcessAlert_m294723356,
	RecordProtocol_SendAlert_m2958143399,
	RecordProtocol_SendAlert_m4165963710,
	RecordProtocol_SendAlert_m2052764902,
	RecordProtocol_SendChangeCipherSpec_m2587651596,
	RecordProtocol_BeginSendRecord_m1123863227,
	RecordProtocol_InternalSendRecordCallback_m3634123222,
	RecordProtocol_BeginSendRecord_m1393516835,
	RecordProtocol_EndSendRecord_m1123729343,
	RecordProtocol_SendRecord_m280973384,
	RecordProtocol_EncodeRecord_m878781190,
	RecordProtocol_EncodeRecord_m1965588201,
	RecordProtocol_encryptRecordFragment_m3505542538,
	RecordProtocol_decryptRecordFragment_m3121017180,
	RecordProtocol_Compare_m540163432,
	RecordProtocol_ProcessCipherSpecV2Buffer_m83749199,
	RecordProtocol_MapV2CipherCode_m3080704908,
	ReceiveRecordAsyncResult__ctor_m1757831986,
	ReceiveRecordAsyncResult_get_Record_m4281416090,
	ReceiveRecordAsyncResult_get_ResultingBuffer_m2327738099,
	ReceiveRecordAsyncResult_get_InitialBuffer_m2745225686,
	ReceiveRecordAsyncResult_get_AsyncState_m3875465955,
	ReceiveRecordAsyncResult_get_AsyncException_m1293664692,
	ReceiveRecordAsyncResult_get_CompletedWithError_m1130061612,
	ReceiveRecordAsyncResult_get_AsyncWaitHandle_m795523398,
	ReceiveRecordAsyncResult_get_IsCompleted_m1477966073,
	ReceiveRecordAsyncResult_SetComplete_m2761699087,
	ReceiveRecordAsyncResult_SetComplete_m3052701818,
	ReceiveRecordAsyncResult_SetComplete_m2322563145,
	SendRecordAsyncResult__ctor_m3939881511,
	SendRecordAsyncResult_get_Message_m2693739483,
	SendRecordAsyncResult_get_AsyncState_m2735412790,
	SendRecordAsyncResult_get_AsyncException_m629429291,
	SendRecordAsyncResult_get_CompletedWithError_m1424077404,
	SendRecordAsyncResult_get_AsyncWaitHandle_m3444932567,
	SendRecordAsyncResult_get_IsCompleted_m1978447102,
	SendRecordAsyncResult_SetComplete_m3767973408,
	SendRecordAsyncResult_SetComplete_m407898290,
	RSASslSignatureDeformatter__ctor_m485749795,
	RSASslSignatureDeformatter_VerifySignature_m2745594033,
	RSASslSignatureDeformatter_SetHashAlgorithm_m3833261103,
	RSASslSignatureDeformatter_SetKey_m3863158732,
	RSASslSignatureFormatter__ctor_m1000501437,
	RSASslSignatureFormatter_CreateSignature_m1971677772,
	RSASslSignatureFormatter_SetHashAlgorithm_m2496272067,
	RSASslSignatureFormatter_SetKey_m3623953786,
	SecurityParameters__ctor_m181771869,
	SecurityParameters_get_Cipher_m3930246943,
	SecurityParameters_set_Cipher_m1901519968,
	SecurityParameters_get_ClientWriteMAC_m350260151,
	SecurityParameters_set_ClientWriteMAC_m1663908222,
	SecurityParameters_get_ServerWriteMAC_m3828576339,
	SecurityParameters_set_ServerWriteMAC_m1009765799,
	SecurityParameters_Clear_m1749827366,
	SslCipherSuite__ctor_m968100862,
	SslCipherSuite_ComputeServerRecordMAC_m1999477721,
	SslCipherSuite_ComputeClientRecordMAC_m1337486433,
	SslCipherSuite_ComputeMasterSecret_m2033082143,
	SslCipherSuite_ComputeKeys_m3698646511,
	SslCipherSuite_prf_m2590711611,
	SslClientStream__ctor_m1433461746,
	SslClientStream__ctor_m2633889984,
	SslClientStream__ctor_m712711730,
	SslClientStream__ctor_m3514916655,
	SslClientStream__ctor_m2510462250,
	SslClientStream_add_ServerCertValidation_m1523778381,
	SslClientStream_remove_ServerCertValidation_m1297189878,
	SslClientStream_add_ClientCertSelection_m452774312,
	SslClientStream_remove_ClientCertSelection_m3667337044,
	SslClientStream_add_PrivateKeySelection_m2824039476,
	SslClientStream_remove_PrivateKeySelection_m3103873688,
	SslClientStream_add_ServerCertValidation2_m3028641733,
	SslClientStream_remove_ServerCertValidation2_m1700046162,
	SslClientStream_get_InputBuffer_m1646783146,
	SslClientStream_get_ClientCertificates_m2009517140,
	SslClientStream_get_SelectedClientCertificate_m924322606,
	SslClientStream_get_ServerCertValidationDelegate_m3612901859,
	SslClientStream_set_ServerCertValidationDelegate_m73621411,
	SslClientStream_get_ClientCertSelectionDelegate_m477769626,
	SslClientStream_set_ClientCertSelectionDelegate_m3631584828,
	SslClientStream_get_PrivateKeyCertSelectionDelegate_m288458638,
	SslClientStream_set_PrivateKeyCertSelectionDelegate_m2185355211,
	SslClientStream_Finalize_m3204804972,
	SslClientStream_Dispose_m2742423009,
	SslClientStream_OnBeginNegotiateHandshake_m3521994229,
	SslClientStream_SafeReceiveRecord_m970773830,
	SslClientStream_OnNegotiateHandshakeCallback_m346876372,
	SslClientStream_OnLocalCertificateSelection_m2419470968,
	SslClientStream_get_HaveRemoteValidation2Callback_m2400940629,
	SslClientStream_OnRemoteCertificateValidation2_m3541905573,
	SslClientStream_OnRemoteCertificateValidation_m189215702,
	SslClientStream_RaiseServerCertificateValidation_m4005846852,
	SslClientStream_RaiseServerCertificateValidation2_m2753141552,
	SslClientStream_RaiseClientCertificateSelection_m156904178,
	SslClientStream_OnLocalPrivateKeySelection_m2716108951,
	SslClientStream_RaisePrivateKeySelection_m489845487,
	SslHandshakeHash__ctor_m756898996,
	SslHandshakeHash_Initialize_m1791132127,
	SslHandshakeHash_HashFinal_m1701169298,
	SslHandshakeHash_HashCore_m3933865887,
	SslHandshakeHash_CreateSignature_m1939494048,
	SslHandshakeHash_initializePad_m250387769,
	SslStreamBase__ctor_m741205528,
	SslStreamBase__cctor_m3014705422,
	SslStreamBase_AsyncHandshakeCallback_m3294599590,
	SslStreamBase_get_MightNeedHandshake_m1992121943,
	SslStreamBase_NegotiateHandshake_m573491502,
	SslStreamBase_RaiseLocalCertificateSelection_m1433227057,
	SslStreamBase_RaiseRemoteCertificateValidation_m3341524304,
	SslStreamBase_RaiseRemoteCertificateValidation2_m4029917716,
	SslStreamBase_RaiseLocalPrivateKeySelection_m2735161685,
	SslStreamBase_get_CheckCertRevocationStatus_m77642209,
	SslStreamBase_set_CheckCertRevocationStatus_m4261866224,
	SslStreamBase_get_CipherAlgorithm_m3666529430,
	SslStreamBase_get_CipherStrength_m1580212736,
	SslStreamBase_get_HashAlgorithm_m1079516308,
	SslStreamBase_get_HashStrength_m2478322151,
	SslStreamBase_get_KeyExchangeStrength_m1541427818,
	SslStreamBase_get_KeyExchangeAlgorithm_m2863204591,
	SslStreamBase_get_SecurityProtocol_m2618450503,
	SslStreamBase_get_ServerCertificate_m2145681234,
	SslStreamBase_get_ServerCertificates_m939421281,
	SslStreamBase_BeginNegotiateHandshake_m547336995,
	SslStreamBase_EndNegotiateHandshake_m397829249,
	SslStreamBase_BeginRead_m2809800024,
	SslStreamBase_InternalBeginRead_m963539731,
	SslStreamBase_InternalReadCallback_m1305227365,
	SslStreamBase_InternalBeginWrite_m3598790627,
	SslStreamBase_InternalWriteCallback_m3296769839,
	SslStreamBase_BeginWrite_m2564053213,
	SslStreamBase_EndRead_m437026192,
	SslStreamBase_EndWrite_m2714332870,
	SslStreamBase_Close_m3709519320,
	SslStreamBase_Flush_m3658498653,
	SslStreamBase_Read_m2195290049,
	SslStreamBase_Read_m3643263392,
	SslStreamBase_Seek_m2054533330,
	SslStreamBase_SetLength_m1638416063,
	SslStreamBase_Write_m2025580464,
	SslStreamBase_Write_m2240111151,
	SslStreamBase_get_CanRead_m1991562813,
	SslStreamBase_get_CanSeek_m812627421,
	SslStreamBase_get_CanWrite_m1968128100,
	SslStreamBase_get_Length_m272340880,
	SslStreamBase_get_Position_m1000100995,
	SslStreamBase_set_Position_m1857423747,
	SslStreamBase_Finalize_m356284376,
	SslStreamBase_Dispose_m3739772543,
	SslStreamBase_resetBuffer_m3181034709,
	SslStreamBase_checkDisposed_m2906118924,
	InternalAsyncResult__ctor_m2214225954,
	InternalAsyncResult_get_ProceedAfterHandshake_m853048591,
	InternalAsyncResult_get_FromWrite_m218776078,
	InternalAsyncResult_get_Buffer_m2215177245,
	InternalAsyncResult_get_Offset_m769058131,
	InternalAsyncResult_get_Count_m1900339478,
	InternalAsyncResult_get_BytesRead_m1934347442,
	InternalAsyncResult_get_AsyncState_m1834753740,
	InternalAsyncResult_get_AsyncException_m4277553429,
	InternalAsyncResult_get_CompletedWithError_m692720727,
	InternalAsyncResult_get_AsyncWaitHandle_m2827246684,
	InternalAsyncResult_get_IsCompleted_m1809305310,
	InternalAsyncResult_SetComplete_m2954631375,
	InternalAsyncResult_SetComplete_m3383011526,
	InternalAsyncResult_SetComplete_m1311950338,
	InternalAsyncResult_SetComplete_m794196429,
	TlsCipherSuite__ctor_m694841098,
	TlsCipherSuite_ComputeServerRecordMAC_m2466325416,
	TlsCipherSuite_ComputeClientRecordMAC_m479855312,
	TlsCipherSuite_ComputeMasterSecret_m223547806,
	TlsCipherSuite_ComputeKeys_m2573681292,
	TlsClientSettings__ctor_m1606665757,
	TlsClientSettings_get_TargetHost_m3723711163,
	TlsClientSettings_set_TargetHost_m3968834781,
	TlsClientSettings_get_Certificates_m1566007174,
	TlsClientSettings_set_Certificates_m3957959786,
	TlsClientSettings_get_ClientCertificate_m3506843448,
	TlsClientSettings_set_ClientCertificate_m539682578,
	TlsClientSettings_UpdateCertificateRSA_m3858486671,
	TlsException__ctor_m3560232972,
	TlsException__ctor_m1727714823,
	TlsException__ctor_m2050029036,
	TlsException__ctor_m767832443,
	TlsException__ctor_m277556507,
	TlsException__ctor_m6896144,
	TlsException_get_Alert_m2866791725,
	TlsServerSettings__ctor_m1778605416,
	TlsServerSettings_get_ServerKeyExchange_m2147121151,
	TlsServerSettings_set_ServerKeyExchange_m542234116,
	TlsServerSettings_get_Certificates_m3650847764,
	TlsServerSettings_set_Certificates_m982364535,
	TlsServerSettings_get_CertificateRSA_m1034068925,
	TlsServerSettings_get_RsaParameters_m1572348672,
	TlsServerSettings_set_RsaParameters_m490478177,
	TlsServerSettings_set_SignedParams_m3377624622,
	TlsServerSettings_get_CertificateRequest_m90880896,
	TlsServerSettings_set_CertificateRequest_m976590898,
	TlsServerSettings_set_CertificateTypes_m3407305606,
	TlsServerSettings_set_DistinguisedNames_m1980717977,
	TlsServerSettings_UpdateCertificateRSA_m3191619471,
	TlsStream__ctor_m748448940,
	TlsStream__ctor_m3756011759,
	TlsStream_get_EOF_m340757178,
	TlsStream_get_CanWrite_m167831487,
	TlsStream_get_CanRead_m3288349133,
	TlsStream_get_CanSeek_m3944248432,
	TlsStream_get_Position_m2542488461,
	TlsStream_set_Position_m2207048000,
	TlsStream_get_Length_m3807077833,
	TlsStream_ReadSmallValue_m1022298559,
	TlsStream_ReadByte_m777518142,
	TlsStream_ReadInt16_m485537606,
	TlsStream_ReadInt24_m3090987673,
	TlsStream_ReadBytes_m378502065,
	TlsStream_Write_m2411452691,
	TlsStream_Write_m1006871602,
	TlsStream_WriteInt24_m1187607382,
	TlsStream_Write_m1457234136,
	TlsStream_Write_m2768379738,
	TlsStream_Reset_m2365541461,
	TlsStream_ToArray_m3134746106,
	TlsStream_Flush_m3962898263,
	TlsStream_SetLength_m3711323663,
	TlsStream_Seek_m145155004,
	TlsStream_Read_m1722448457,
	TlsStream_Write_m3440017277,
	ValidationResult_get_Trusted_m1345068309,
	ValidationResult_get_ErrorCode_m304391632,
	AuthorityKeyIdentifierExtension__ctor_m219033161,
	AuthorityKeyIdentifierExtension_Decode_m710183725,
	AuthorityKeyIdentifierExtension_get_Identifier_m209684292,
	AuthorityKeyIdentifierExtension_ToString_m2353194001,
	BasicConstraintsExtension__ctor_m1669247165,
	BasicConstraintsExtension_Decode_m2558178225,
	BasicConstraintsExtension_Encode_m3247810661,
	BasicConstraintsExtension_get_CertificateAuthority_m821405121,
	BasicConstraintsExtension_ToString_m3236584636,
	ExtendedKeyUsageExtension__ctor_m2334921451,
	ExtendedKeyUsageExtension_Decode_m3019927506,
	ExtendedKeyUsageExtension_Encode_m4180241165,
	ExtendedKeyUsageExtension_get_KeyPurpose_m861952333,
	ExtendedKeyUsageExtension_ToString_m385154138,
	GeneralNames__ctor_m342736606,
	GeneralNames_get_DNSNames_m175359186,
	GeneralNames_get_IPAddresses_m3029857601,
	GeneralNames_ToString_m2803221720,
	KeyUsageExtension__ctor_m1050328440,
	KeyUsageExtension_Decode_m694564864,
	KeyUsageExtension_Encode_m4206639500,
	KeyUsageExtension_Support_m4075266157,
	KeyUsageExtension_ToString_m1242530744,
	NetscapeCertTypeExtension__ctor_m3394330620,
	NetscapeCertTypeExtension_Decode_m39242487,
	NetscapeCertTypeExtension_Support_m1227706244,
	NetscapeCertTypeExtension_ToString_m112697774,
	SubjectAltNameExtension__ctor_m789892295,
	SubjectAltNameExtension_Decode_m3172834871,
	SubjectAltNameExtension_get_DNSNames_m1804554775,
	SubjectAltNameExtension_get_IPAddresses_m2089654521,
	SubjectAltNameExtension_ToString_m2914767436,
	PKCS12__ctor_m1777426012,
	PKCS12__ctor_m3659970847,
	PKCS12__ctor_m1656806803,
	PKCS12__cctor_m2775773295,
	PKCS12_Decode_m3317588035,
	PKCS12_Finalize_m2317608358,
	PKCS12_set_Password_m2427294934,
	PKCS12_get_IterationCount_m2087403858,
	PKCS12_set_IterationCount_m1788721540,
	PKCS12_get_Keys_m2167805586,
	PKCS12_get_Certificates_m240716806,
	PKCS12_get_RNG_m2558654591,
	PKCS12_Compare_m696746212,
	PKCS12_GetSymmetricAlgorithm_m1596743709,
	PKCS12_Decrypt_m1609151980,
	PKCS12_Decrypt_m2965366899,
	PKCS12_Encrypt_m3741127000,
	PKCS12_GetExistingParameters_m3068163633,
	PKCS12_AddPrivateKey_m1660821157,
	PKCS12_ReadSafeBag_m1793596352,
	PKCS12_CertificateSafeBag_m2039847126,
	PKCS12_MAC_m3906451347,
	PKCS12_GetBytes_m3278149050,
	PKCS12_EncryptedContentInfo_m1491957736,
	PKCS12_AddCertificate_m454954748,
	PKCS12_AddCertificate_m1974489930,
	PKCS12_RemoveCertificate_m1542146527,
	PKCS12_RemoveCertificate_m1500639714,
	PKCS12_Clone_m1234389164,
	PKCS12_get_MaximumPasswordLength_m883214155,
	DeriveBytes__ctor_m435594913,
	DeriveBytes__cctor_m2512241514,
	DeriveBytes_set_HashName_m1312849937,
	DeriveBytes_set_IterationCount_m375614940,
	DeriveBytes_set_Password_m1207022898,
	DeriveBytes_set_Salt_m1226625054,
	DeriveBytes_Adjust_m2230275790,
	DeriveBytes_Derive_m2164396782,
	DeriveBytes_DeriveKey_m2264034637,
	DeriveBytes_DeriveIV_m156619505,
	DeriveBytes_DeriveMAC_m2308622817,
	SafeBag__ctor_m149225940,
	SafeBag_get_BagOID_m2140085721,
	SafeBag_get_ASN1_m4116908763,
	X501__cctor_m215262883,
	X501_ToString_m1572535881,
	X501_ToString_m2425160069,
	X501_AppendEntry_m2829401085,
	X509Certificate__ctor_m2595420781,
	X509Certificate__cctor_m3387216631,
	X509Certificate_Parse_m2434019838,
	X509Certificate_GetUnsignedBigInteger_m3421969019,
	X509Certificate_get_DSA_m3900335029,
	X509Certificate_set_DSA_m2466949906,
	X509Certificate_get_Extensions_m168359828,
	X509Certificate_get_Hash_m4070304576,
	X509Certificate_get_IssuerName_m3125413837,
	X509Certificate_get_KeyAlgorithm_m1954217732,
	X509Certificate_get_KeyAlgorithmParameters_m3826010966,
	X509Certificate_set_KeyAlgorithmParameters_m1678336073,
	X509Certificate_get_PublicKey_m2789532076,
	X509Certificate_get_RSA_m444241086,
	X509Certificate_set_RSA_m2230677437,
	X509Certificate_get_RawData_m4264811715,
	X509Certificate_get_SerialNumber_m4150013632,
	X509Certificate_get_Signature_m1258977383,
	X509Certificate_get_SignatureAlgorithm_m134784522,
	X509Certificate_get_SubjectName_m1800094717,
	X509Certificate_get_ValidFrom_m1616190780,
	X509Certificate_get_ValidUntil_m3380278620,
	X509Certificate_get_Version_m2368604753,
	X509Certificate_get_IsCurrent_m3640852168,
	X509Certificate_WasCurrent_m917225642,
	X509Certificate_VerifySignature_m999087952,
	X509Certificate_VerifySignature_m3586768459,
	X509Certificate_VerifySignature_m1063367374,
	X509Certificate_get_IsSelfSigned_m2899197692,
	X509Certificate_GetIssuerName_m2725382997,
	X509Certificate_GetSubjectName_m3415136325,
	X509Certificate_GetObjectData_m477010876,
	X509Certificate_PEM_m893460658,
	X509CertificateCollection__ctor_m3814102197,
	X509CertificateCollection__ctor_m2831022880,
	X509CertificateCollection_System_Collections_IEnumerable_GetEnumerator_m2203928887,
	X509CertificateCollection_get_Item_m1037513158,
	X509CertificateCollection_Add_m3583025647,
	X509CertificateCollection_AddRange_m3947922443,
	X509CertificateCollection_Contains_m2689777087,
	X509CertificateCollection_GetEnumerator_m1488475952,
	X509CertificateCollection_GetHashCode_m3234395587,
	X509CertificateCollection_IndexOf_m1510539209,
	X509CertificateCollection_Remove_m953811859,
	X509CertificateCollection_Compare_m3326865369,
	X509CertificateEnumerator__ctor_m3390678879,
	X509CertificateEnumerator_System_Collections_IEnumerator_get_Current_m3624737776,
	X509CertificateEnumerator_System_Collections_IEnumerator_MoveNext_m4129821546,
	X509CertificateEnumerator_System_Collections_IEnumerator_Reset_m66253660,
	X509CertificateEnumerator_get_Current_m1278820965,
	X509CertificateEnumerator_MoveNext_m2399536456,
	X509CertificateEnumerator_Reset_m2618066962,
	X509Chain__ctor_m1855707435,
	X509Chain__ctor_m3929816338,
	X509Chain_get_Status_m3187776484,
	X509Chain_get_TrustAnchors_m3647194859,
	X509Chain_Build_m3816057649,
	X509Chain_IsValid_m3320576976,
	X509Chain_FindCertificateParent_m3084039956,
	X509Chain_FindCertificateRoot_m1594113095,
	X509Chain_IsTrusted_m4069065425,
	X509Chain_IsParent_m3921705034,
	X509Crl__ctor_m1405190782,
	X509Crl_Parse_m3443588132,
	X509Crl_get_Extensions_m3563247159,
	X509Crl_get_Hash_m3316606702,
	X509Crl_get_IssuerName_m2231565103,
	X509Crl_get_NextUpdate_m1955410512,
	X509Crl_Compare_m2769836244,
	X509Crl_GetCrlEntry_m2770982370,
	X509Crl_GetCrlEntry_m3898926927,
	X509Crl_GetHashName_m4172463918,
	X509Crl_VerifySignature_m1759125724,
	X509Crl_VerifySignature_m3654385869,
	X509Crl_VerifySignature_m1470503056,
	X509CrlEntry__ctor_m3292061466,
	X509CrlEntry_get_SerialNumber_m3129165863,
	X509CrlEntry_get_RevocationDate_m1741259245,
	X509CrlEntry_get_Extensions_m1273042024,
	X509Extension__ctor_m2037261217,
	X509Extension__ctor_m1596098138,
	X509Extension_Decode_m3688445819,
	X509Extension_Encode_m829172182,
	X509Extension_get_Oid_m362207092,
	X509Extension_get_Critical_m1041250559,
	X509Extension_get_Value_m1107597234,
	X509Extension_Equals_m430339191,
	X509Extension_GetHashCode_m1844371398,
	X509Extension_WriteLine_m3492795937,
	X509Extension_ToString_m2151664661,
	X509ExtensionCollection__ctor_m3456583624,
	X509ExtensionCollection__ctor_m4124179550,
	X509ExtensionCollection_System_Collections_IEnumerable_GetEnumerator_m3440118309,
	X509ExtensionCollection_IndexOf_m3436077092,
	X509ExtensionCollection_get_Item_m2499993247,
	X509Store__ctor_m2147993305,
	X509Store_get_Certificates_m3680783951,
	X509Store_get_Crls_m1033339264,
	X509Store_Load_m419224682,
	X509Store_LoadCertificate_m1545801903,
	X509Store_LoadCrl_m350580848,
	X509Store_CheckStore_m3326322670,
	X509Store_BuildCertificatesCollection_m888443411,
	X509Store_BuildCrlsCollection_m1230599691,
	X509StoreManager_get_CurrentUser_m3250790281,
	X509StoreManager_get_LocalMachine_m3513347572,
	X509StoreManager_get_TrustedRootCertificates_m1474110803,
	X509Stores__ctor_m265972325,
	X509Stores_get_TrustedRoot_m125247548,
	X509Stores_Open_m3469237229,
	Locale_GetText_m3061672467,
	Locale_GetText_m2212416198,
	KeyBuilder_get_Rng_m3489060129,
	KeyBuilder_Key_m1483187862,
	KeyBuilder_IV_m3594476528,
	SymmetricTransform__ctor_m479938328,
	SymmetricTransform_System_IDisposable_Dispose_m3467570388,
	SymmetricTransform_Finalize_m3831333474,
	SymmetricTransform_Dispose_m4199210298,
	SymmetricTransform_get_CanReuseTransform_m3198136831,
	SymmetricTransform_Transform_m1783309410,
	SymmetricTransform_CBC_m3108280695,
	SymmetricTransform_CFB_m913756151,
	SymmetricTransform_OFB_m3448407975,
	SymmetricTransform_CTS_m3137243433,
	SymmetricTransform_CheckInput_m889492017,
	SymmetricTransform_TransformBlock_m1133208178,
	SymmetricTransform_get_KeepLastBlock_m278696008,
	SymmetricTransform_InternalTransformBlock_m2757264515,
	SymmetricTransform_Random_m234530533,
	SymmetricTransform_ThrowBadPaddingException_m2239569074,
	SymmetricTransform_FinalEncrypt_m3511270614,
	SymmetricTransform_FinalDecrypt_m288191860,
	SymmetricTransform_TransformFinalBlock_m150874865,
	Action__ctor_m2628370505,
	Action_Invoke_m461827263,
	Action_BeginInvoke_m3723509046,
	Action_EndInvoke_m1255458958,
	Check_Source_m116682380,
	Check_SourceAndPredicate_m1967256554,
	ExtensionAttribute__ctor_m4086378263,
	Aes__ctor_m1953100512,
	AesManaged__ctor_m3652913943,
	AesManaged_GenerateIV_m1752581687,
	AesManaged_GenerateKey_m1663893024,
	AesManaged_CreateDecryptor_m1783063797,
	AesManaged_CreateEncryptor_m542327683,
	AesManaged_get_IV_m445337811,
	AesManaged_set_IV_m154541751,
	AesManaged_get_Key_m2188581155,
	AesManaged_set_Key_m1204862624,
	AesManaged_get_KeySize_m4026780749,
	AesManaged_set_KeySize_m2877665950,
	AesManaged_CreateDecryptor_m705463674,
	AesManaged_CreateEncryptor_m3828710756,
	AesManaged_Dispose_m2494358036,
	AesTransform__ctor_m3423405142,
	AesTransform__cctor_m59472272,
	AesTransform_ECB_m2941917479,
	AesTransform_SubByte_m1840584220,
	AesTransform_Encrypt128_m4225624107,
	AesTransform_Decrypt128_m2599523323,
	AddComponentMenu__ctor_m3547895745,
	Analytics_GetUnityAnalyticsHandler_m672127306,
	Analytics_CustomEvent_m2816162597,
	CustomEventData__ctor_m3827668383,
	CustomEventData_Finalize_m3487810534,
	CustomEventData_Dispose_m3383975513,
	CustomEventData_Add_m255379884,
	CustomEventData_Add_m4065400,
	CustomEventData_Add_m1177082793,
	CustomEventData_Add_m20789608,
	CustomEventData_Add_m1322416340,
	CustomEventData_Add_m3098094110,
	CustomEventData_Add_m1790469430,
	CustomEventData_Add_m427502212,
	CustomEventData_Add_m74255895,
	CustomEventData_Add_m2047600962,
	CustomEventData_Add_m1265658328,
	CustomEventData_Add_m3195527203,
	CustomEventData_Add_m4269902579,
	CustomEventData_Add_m2852648701,
	CustomEventData_Add_m716525696,
	CustomEventData_InternalCreate_m880206285,
	CustomEventData_InternalDestroy_m2519008968,
	CustomEventData_AddString_m659451336,
	CustomEventData_AddBool_m398788015,
	CustomEventData_AddChar_m319900760,
	CustomEventData_AddByte_m3717748694,
	CustomEventData_AddSByte_m3340687799,
	CustomEventData_AddInt16_m1608076704,
	CustomEventData_AddUInt16_m204323820,
	CustomEventData_AddInt32_m779198032,
	CustomEventData_AddUInt32_m2154319333,
	CustomEventData_AddInt64_m3524891666,
	CustomEventData_AddUInt64_m2735082319,
	CustomEventData_AddDouble_m1124663272,
	UnityAnalyticsHandler__ctor_m4061513566,
	UnityAnalyticsHandler_InternalCreate_m2671862836,
	UnityAnalyticsHandler_InternalDestroy_m304093635,
	UnityAnalyticsHandler_Finalize_m4007199557,
	UnityAnalyticsHandler_Dispose_m803102421,
	UnityAnalyticsHandler_CustomEvent_m2596088521,
	UnityAnalyticsHandler_CustomEvent_m4076413237,
	UnityAnalyticsHandler_SendCustomEventName_m3481945465,
	UnityAnalyticsHandler_SendCustomEvent_m3074734922,
	AnimationCurve__ctor_m1256678767,
	AnimationCurve__ctor_m3546708367,
	AnimationCurve_Cleanup_m870304867,
	AnimationCurve_Finalize_m1957706335,
	AnimationCurve_Init_m2288700569,
	Application_CallLowMemory_m950526118,
	Application_CallLogCallback_m1230073937,
	Application_InvokeOnBeforeRender_m367288211,
	LogCallback__ctor_m1474797444,
	LogCallback_Invoke_m1074473487,
	LogCallback_BeginInvoke_m1847524231,
	LogCallback_EndInvoke_m2170626810,
	LowMemoryCallback__ctor_m3261191279,
	LowMemoryCallback_Invoke_m531625589,
	LowMemoryCallback_BeginInvoke_m2392861162,
	LowMemoryCallback_EndInvoke_m1446466716,
	AssemblyIsEditorAssembly__ctor_m2630421681,
	AssetBundleCreateRequest__ctor_m3026219756,
	AssetBundleCreateRequest_get_assetBundle_m1127086494,
	AssetBundleCreateRequest_DisableCompatibilityChecks_m1123061109,
	AssetBundleRequest__ctor_m23332438,
	AssetBundleRequest_get_asset_m1618802054,
	AssetBundleRequest_get_allAssets_m4077343547,
	AsyncOperation__ctor_m4206607396,
	AsyncOperation_InternalDestroy_m989121897,
	AsyncOperation_Finalize_m1982367396,
	AsyncOperation_get_isDone_m2130057835,
	AsyncOperation_get_progress_m132026404,
	AsyncOperation_get_priority_m3349967333,
	AsyncOperation_set_priority_m2349794837,
	AsyncOperation_get_allowSceneActivation_m3755262598,
	AsyncOperation_set_allowSceneActivation_m384018621,
	AttributeHelperEngine_GetParentTypeDisallowingMultipleInclusion_m4119152402,
	AttributeHelperEngine_GetRequiredComponents_m942683377,
	AttributeHelperEngine_CheckIsEditorScript_m4061418281,
	AttributeHelperEngine_GetDefaultExecutionOrderFor_m3266095226,
	AttributeHelperEngine__cctor_m3478232574,
	AudioClipPlayable__ctor_m2695288751_AdjustorThunk,
	AudioClipPlayable_Create_m29077272,
	AudioClipPlayable_CreateHandle_m931567265,
	AudioClipPlayable_GetHandle_m943133440_AdjustorThunk,
	AudioClipPlayable_op_Implicit_m2314945005,
	AudioClipPlayable_op_Explicit_m3538157942,
	AudioClipPlayable_Equals_m3313539839_AdjustorThunk,
	AudioClipPlayable_GetClip_m2661793626_AdjustorThunk,
	AudioClipPlayable_GetClip_m2699613590_AdjustorThunk,
	AudioClipPlayable_GetClipInternal_m4242826736,
	AudioClipPlayable_INTERNAL_CALL_GetClipInternal_m317731256,
	AudioClipPlayable_SetClipInternal_m3963613185,
	AudioClipPlayable_INTERNAL_CALL_SetClipInternal_m1813683739,
	AudioClipPlayable_GetLooped_m794925563_AdjustorThunk,
	AudioClipPlayable_SetLooped_m3574008031_AdjustorThunk,
	AudioClipPlayable_GetLoopedInternal_m1212413764,
	AudioClipPlayable_INTERNAL_CALL_GetLoopedInternal_m3132985087,
	AudioClipPlayable_SetLoopedInternal_m3850217231,
	AudioClipPlayable_INTERNAL_CALL_SetLoopedInternal_m3163919323,
	AudioClipPlayable_IsPlaying_m3949290847_AdjustorThunk,
	AudioClipPlayable_GetIsPlayingInternal_m3277395055,
	AudioClipPlayable_INTERNAL_CALL_GetIsPlayingInternal_m3248130146,
	AudioClipPlayable_GetStartDelay_m2786469541_AdjustorThunk,
	AudioClipPlayable_SetStartDelay_m2489117208_AdjustorThunk,
	AudioClipPlayable_GetStartDelayInternal_m3603302465,
	AudioClipPlayable_INTERNAL_CALL_GetStartDelayInternal_m1864145844,
	AudioClipPlayable_SetStartDelayInternal_m4184808028,
	AudioClipPlayable_INTERNAL_CALL_SetStartDelayInternal_m3452625175,
	AudioClipPlayable_GetPauseDelay_m638109021_AdjustorThunk,
	AudioClipPlayable_GetPauseDelay_m663773613_AdjustorThunk,
	AudioClipPlayable_GetPauseDelayInternal_m1384934761,
	AudioClipPlayable_INTERNAL_CALL_GetPauseDelayInternal_m4032398432,
	AudioClipPlayable_SetPauseDelayInternal_m477818377,
	AudioClipPlayable_INTERNAL_CALL_SetPauseDelayInternal_m234566193,
	AudioClipPlayable_InternalCreateAudioClipPlayable_m314302546,
	AudioClipPlayable_INTERNAL_CALL_InternalCreateAudioClipPlayable_m496825388,
	AudioClipPlayable_ValidateType_m3846561236,
	AudioClipPlayable_INTERNAL_CALL_ValidateType_m2412648730,
	AudioClipPlayable_Seek_m1537206734_AdjustorThunk,
	AudioClipPlayable_Seek_m743928150_AdjustorThunk,
	AudioClipPlayable_ValidateStartDelayInternal_m2686481105_AdjustorThunk,
	AudioMixerPlayable__ctor_m1764792452_AdjustorThunk,
	AudioMixerPlayable_Create_m3148698328,
	AudioMixerPlayable_CreateHandle_m4263003578,
	AudioMixerPlayable_GetHandle_m615245243_AdjustorThunk,
	AudioMixerPlayable_op_Implicit_m2197344530,
	AudioMixerPlayable_op_Explicit_m231265208,
	AudioMixerPlayable_Equals_m348392712_AdjustorThunk,
	AudioMixerPlayable_GetAutoNormalizeVolumes_m4252571978_AdjustorThunk,
	AudioMixerPlayable_GetAutoNormalizeVolumes_m2835896126_AdjustorThunk,
	AudioMixerPlayable_GetAutoNormalizeInternal_m3913872939,
	AudioMixerPlayable_INTERNAL_CALL_GetAutoNormalizeInternal_m2057364040,
	AudioMixerPlayable_SetAutoNormalizeInternal_m3888761556,
	AudioMixerPlayable_INTERNAL_CALL_SetAutoNormalizeInternal_m987980948,
	AudioMixerPlayable_CreateAudioMixerPlayableInternal_m4213450386,
	AudioMixerPlayable_INTERNAL_CALL_CreateAudioMixerPlayableInternal_m290331118,
	AudioPlayableOutput__ctor_m1534356330_AdjustorThunk,
	AudioPlayableOutput_Create_m500163179,
	AudioPlayableOutput_get_Null_m2678190817,
	AudioPlayableOutput_GetHandle_m22607570_AdjustorThunk,
	AudioPlayableOutput_op_Implicit_m8343428,
	AudioPlayableOutput_op_Explicit_m2685709622,
	AudioPlayableOutput_GetTarget_m3546842241_AdjustorThunk,
	AudioPlayableOutput_SetTarget_m1484744610_AdjustorThunk,
	AudioPlayableOutput_InternalGetTarget_m2773003990,
	AudioPlayableOutput_INTERNAL_CALL_InternalGetTarget_m3249422738,
	AudioPlayableOutput_InternalSetTarget_m3993687925,
	AudioPlayableOutput_INTERNAL_CALL_InternalSetTarget_m3185628123,
	AudioClip_get_length_m2904044266,
	AudioClip_InvokePCMReaderCallback_Internal_m3969674143,
	AudioClip_InvokePCMSetPositionCallback_Internal_m4230058079,
	PCMReaderCallback__ctor_m2058237872,
	PCMReaderCallback_Invoke_m2813506989,
	PCMReaderCallback_BeginInvoke_m1187826492,
	PCMReaderCallback_EndInvoke_m3621326709,
	PCMSetPositionCallback__ctor_m393872308,
	PCMSetPositionCallback_Invoke_m1472347517,
	PCMSetPositionCallback_BeginInvoke_m2213357131,
	PCMSetPositionCallback_EndInvoke_m92441568,
	AudioSettings_InvokeOnAudioConfigurationChanged_m61046006,
	AudioConfigurationChangeHandler__ctor_m1448713277,
	AudioConfigurationChangeHandler_Invoke_m2768044174,
	AudioConfigurationChangeHandler_BeginInvoke_m3819714530,
	AudioConfigurationChangeHandler_EndInvoke_m1284988426,
	Behaviour__ctor_m645850146,
	Bounds_GetHashCode_m1439875941_AdjustorThunk,
	Bounds_Equals_m3721596139_AdjustorThunk,
	Bounds_get_center_m1258209247_AdjustorThunk,
	Bounds_get_extents_m3684240117_AdjustorThunk,
	Bounds_ToString_m3832647372_AdjustorThunk,
	BoxCollider__ctor_m597659220,
	BoxCollider_get_center_m2246712330,
	BoxCollider_set_center_m1938453905,
	BoxCollider_INTERNAL_get_center_m2108458525,
	BoxCollider_INTERNAL_set_center_m1608300232,
	BoxCollider_get_size_m1661589754,
	BoxCollider_set_size_m3117771882,
	BoxCollider_INTERNAL_get_size_m2915107625,
	BoxCollider_INTERNAL_set_size_m1069292286,
	BoxCollider_get_extents_m3203461350,
	BoxCollider_set_extents_m3715940525,
	Camera_get_nearClipPlane_m595687364,
	Camera_get_farClipPlane_m672532137,
	Camera_get_cullingMask_m1829245964,
	Camera_get_eventMask_m192041623,
	Camera_get_pixelRect_m2287979086,
	Camera_INTERNAL_get_pixelRect_m3579949699,
	Camera_get_targetTexture_m2343817798,
	Camera_get_clearFlags_m4107941227,
	Camera_ScreenPointToRay_m2037804860,
	Camera_INTERNAL_CALL_ScreenPointToRay_m1092094677,
	Camera_get_allCamerasCount_m202689974,
	Camera_GetAllCameras_m14780124,
	Camera_FireOnPreCull_m2833190726,
	Camera_FireOnPreRender_m3227173956,
	Camera_FireOnPostRender_m169492450,
	Camera_RaycastTry_m3445740383,
	Camera_INTERNAL_CALL_RaycastTry_m3176538179,
	Camera_RaycastTry2D_m2685151565,
	Camera_INTERNAL_CALL_RaycastTry2D_m1805928838,
	CameraCallback__ctor_m2934755836,
	CameraCallback_Invoke_m3818674482,
	CameraCallback_BeginInvoke_m996806004,
	CameraCallback_EndInvoke_m2209671123,
	CapsuleCollider__ctor_m2230392579,
	CapsuleCollider_get_center_m3903044238,
	CapsuleCollider_set_center_m2104777635,
	CapsuleCollider_INTERNAL_get_center_m343696755,
	CapsuleCollider_INTERNAL_set_center_m2335165673,
	CapsuleCollider_get_radius_m4172507562,
	CapsuleCollider_set_radius_m762145652,
	CapsuleCollider_get_height_m3662458997,
	CapsuleCollider_set_height_m2754457501,
	CapsuleCollider_get_direction_m2169980597,
	CapsuleCollider_set_direction_m3664861627,
	CharacterController_Move_m900161214,
	CharacterController_INTERNAL_CALL_Move_m2501923996,
	CharacterController_get_isGrounded_m3015943198,
	ClassLibraryInitializer_Init_m678390546,
	DeallocateOnJobCompletionAttribute__ctor_m447098597,
	NativeContainerAttribute__ctor_m119517009,
	NativeContainerSupportsAtomicWriteAttribute__ctor_m3977352624,
	NativeContainerSupportsMinMaxWriteRestrictionAttribute__ctor_m1692409002,
	ReadOnlyAttribute__ctor_m1624519052,
	ReadWriteAttribute__ctor_m68368940,
	WriteOnlyAttribute__ctor_m3959797925,
	Collider__ctor_m170727096,
	Collider_get_enabled_m1012249734,
	Collider_set_enabled_m3023772319,
	Collider_get_attachedRigidbody_m1223649037,
	Collider_get_isTrigger_m3411014092,
	Collider_set_isTrigger_m3915953166,
	Collider_get_contactOffset_m2439063487,
	Collider_set_contactOffset_m683432949,
	Collider_get_material_m1577688535,
	Collider_set_material_m1981090199,
	Collider_ClosestPointOnBounds_m408573294,
	Collider_INTERNAL_CALL_ClosestPointOnBounds_m983298871,
	Collider_ClosestPoint_m1034747586,
	Collider_INTERNAL_CALL_ClosestPoint_m1905885810,
	Collider_get_sharedMaterial_m3186711189,
	Collider_set_sharedMaterial_m378738133,
	Collider_get_bounds_m1843897070,
	Collider_INTERNAL_get_bounds_m924372968,
	Collider_Internal_Raycast_m3210677020,
	Collider_INTERNAL_CALL_Internal_Raycast_m935082044,
	Collider_Raycast_m1173729534,
	Collision__ctor_m2172552466,
	Collision_get_relativeVelocity_m1709376896,
	Collision_get_rigidbody_m3834349960,
	Collision_get_collider_m2199260191,
	Collision_get_transform_m2373443247,
	Collision_get_gameObject_m3532016414,
	Collision_get_contacts_m1067831838,
	Collision_GetEnumerator_m3074386304,
	Collision_get_impulse_m306856219,
	Collision_get_impactForceSum_m3470397102,
	Collision_get_frictionForceSum_m3332842272,
	Collision_get_other_m986277678,
	Component__ctor_m2987636441,
	Component_get_transform_m1991721595,
	Component_get_gameObject_m44324674,
	Component_GetComponent_m4065514490,
	Component_GetComponentFastPath_m2526947697,
	Component_GetComponent_m3003597536,
	Component_GetComponentInChildren_m174763428,
	Component_GetComponentInChildren_m916963883,
	Component_GetComponentsInChildren_m3617139144,
	Component_GetComponentsInChildren_m155792327,
	Component_GetComponentInParent_m3868731529,
	Component_GetComponentsInParent_m218516534,
	Component_GetComponentsInParent_m1469804712,
	Component_GetComponents_m2744603723,
	Component_GetComponentsForListInternal_m2222527641,
	Component_GetComponents_m1300823959,
	Component_get_tag_m3859973365,
	Component_set_tag_m1136149524,
	Component_CompareTag_m95749719,
	Component_SendMessageUpwards_m2783812412,
	Component_SendMessageUpwards_m2173372724,
	Component_SendMessageUpwards_m3268518138,
	Component_SendMessageUpwards_m3496715621,
	Component_SendMessage_m4289933507,
	Component_SendMessage_m3305852972,
	Component_SendMessage_m872975486,
	Component_SendMessage_m1196789683,
	Component_BroadcastMessage_m3258471174,
	Component_BroadcastMessage_m2127138074,
	Component_BroadcastMessage_m1539754661,
	Component_BroadcastMessage_m730653188,
	ContextMenu__ctor_m3700823191,
	ContextMenu__ctor_m333661367,
	ContextMenu__ctor_m1599691754,
	ControllerColliderHit__ctor_m2011202600,
	ControllerColliderHit_get_controller_m3364905897,
	ControllerColliderHit_get_collider_m2056607443,
	ControllerColliderHit_get_rigidbody_m1353039703,
	ControllerColliderHit_get_gameObject_m39384490,
	ControllerColliderHit_get_transform_m2298294070,
	ControllerColliderHit_get_point_m2077037566,
	ControllerColliderHit_get_normal_m3810580689,
	ControllerColliderHit_get_moveDirection_m1063174902,
	ControllerColliderHit_get_moveLength_m828560915,
	ControllerColliderHit_get_push_m815657938,
	ControllerColliderHit_set_push_m243530137,
	Coroutine__ctor_m2590443731,
	Coroutine_ReleaseCoroutine_m3781988635,
	Coroutine_Finalize_m1923989986,
	CSSMeasureFunc__ctor_m3533652191,
	CSSMeasureFunc_Invoke_m1154676219,
	CSSMeasureFunc_BeginInvoke_m2103229683,
	CSSMeasureFunc_EndInvoke_m2492587638,
	Native_CSSNodeGetMeasureFunc_m2687424442,
	Native_CSSNodeMeasureInvoke_m215891493,
	Native__cctor_m13459289,
	CullingGroup_Finalize_m1608050186,
	CullingGroup_Dispose_m1171631894,
	CullingGroup_SendEvents_m2564931990,
	CullingGroup_FinalizerFailure_m2017674841,
	StateChanged__ctor_m2918878156,
	StateChanged_Invoke_m1198352690,
	StateChanged_BeginInvoke_m2117606739,
	StateChanged_EndInvoke_m2248028175,
	Debug_get_unityLogger_m2347626683,
	Debug_Log_m612504508,
	Debug_LogError_m1111084917,
	Debug_LogWarning_m55671213,
	Debug__cctor_m1016060880,
	DebugLogHandler__ctor_m904623223,
	DebugLogHandler_Internal_Log_m2703551542,
	DebugLogHandler_LogFormat_m4019243538,
	DefaultExecutionOrder_get_order_m3764018895,
	Display__ctor_m2759347064,
	Display__ctor_m1477480308,
	Display_RecreateDisplayList_m1233426626,
	Display_FireDisplaysUpdated_m2028285549,
	Display__cctor_m3680899297,
	DisplaysUpdatedDelegate__ctor_m1617523608,
	DisplaysUpdatedDelegate_Invoke_m2649345203,
	DisplaysUpdatedDelegate_BeginInvoke_m3935524471,
	DisplaysUpdatedDelegate_EndInvoke_m341404626,
	ArgumentCache__ctor_m978772768,
	ArgumentCache_get_unityObjectArgument_m2085186913,
	ArgumentCache_get_unityObjectArgumentAssemblyTypeName_m3754631060,
	ArgumentCache_get_intArgument_m1138448651,
	ArgumentCache_get_floatArgument_m2018826893,
	ArgumentCache_get_stringArgument_m2246831120,
	ArgumentCache_get_boolArgument_m2101152089,
	ArgumentCache_TidyAssemblyTypeName_m3705917044,
	ArgumentCache_OnBeforeSerialize_m821915120,
	ArgumentCache_OnAfterDeserialize_m767341272,
	BaseInvokableCall__ctor_m3658191802,
	BaseInvokableCall_AllowInvoke_m472262968,
	InvokableCall__ctor_m3996529049,
	InvokableCall_add_Delegate_m2438976025,
	InvokableCall_remove_Delegate_m3721333387,
	InvokableCall_Invoke_m1289604502,
	InvokableCallList__ctor_m1888224612,
	InvokableCallList_AddPersistentInvokableCall_m2704573799,
	InvokableCallList_ClearPersistent_m2631436529,
	InvokableCallList_Invoke_m1328600370,
	PersistentCall__ctor_m756985338,
	PersistentCall_get_target_m2727150134,
	PersistentCall_get_methodName_m30496994,
	PersistentCall_get_mode_m3619043292,
	PersistentCall_get_arguments_m4221462882,
	PersistentCall_IsValid_m224654533,
	PersistentCall_GetRuntimeCall_m353611327,
	PersistentCall_GetObjectCall_m2089564283,
	PersistentCallGroup__ctor_m2284274197,
	PersistentCallGroup_Initialize_m1460089847,
	UnityAction__ctor_m3295801254,
	UnityAction_Invoke_m4258657167,
	UnityAction_BeginInvoke_m3553174952,
	UnityAction_EndInvoke_m879801910,
	UnityEvent__ctor_m709418737,
	UnityEvent_FindMethod_Impl_m1632288100,
	UnityEvent_GetDelegate_m254459601,
	UnityEventBase__ctor_m952299846,
	UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m3971120570,
	UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m647175948,
	UnityEventBase_FindMethod_m1865515850,
	UnityEventBase_FindMethod_m237643499,
	UnityEventBase_DirtyPersistentCalls_m2995072991,
	UnityEventBase_RebuildPersistentCallsIfNeeded_m3255273588,
	UnityEventBase_Invoke_m434153928,
	UnityEventBase_ToString_m3093412050,
	UnityEventBase_GetValidMethodInfo_m3311978107,
	RenderPipelineManager_get_currentPipeline_m3200673172,
	RenderPipelineManager_set_currentPipeline_m1673100204,
	RenderPipelineManager_CleanupRenderPipeline_m3163400220,
	RenderPipelineManager_DoRenderLoop_Internal_m2060351888,
	RenderPipelineManager_PrepareRenderPipeline_m2230027504,
	ScriptableRenderContext__ctor_m2560532740_AdjustorThunk,
	FailedToLoadScriptObject__ctor_m3446975753,
	Font_InvokeTextureRebuilt_Internal_m3404887950,
	FontTextureRebuildCallback__ctor_m2739639569,
	FontTextureRebuildCallback_Invoke_m647222893,
	FontTextureRebuildCallback_BeginInvoke_m1136377575,
	FontTextureRebuildCallback_EndInvoke_m3293464560,
	GameObject_GetComponent_m2381985773,
	GameObject_GetComponentInChildren_m1168178952,
	GameObject_GetComponentInParent_m576974860,
	GameObject_GetComponents_m133749314,
	GameObject_GetComponentsInChildren_m544289345,
	GameObject_GetComponentsInParent_m3716665394,
	GameObject_GetComponentsInternal_m3558330862,
	GameObject_get_transform_m3351892996,
	GameObject_SetActive_m924703582,
	GameObject_get_tag_m3253026982,
	GameObject_set_tag_m2601144065,
	GameObject_CompareTag_m4047912073,
	GameObject_FindGameObjectWithTag_m3016707382,
	GameObject_SendMessage_m1793137815,
	GameObject_Find_m357843493,
	GameObject_get_gameObject_m1404374750,
	Gradient__ctor_m3449608876,
	Gradient_Init_m665431756,
	Gradient_Cleanup_m3762357176,
	Gradient_Finalize_m3282868344,
	GUILayer_HitTest_m675486399,
	GUILayer_INTERNAL_CALL_HitTest_m169839011,
	Input_GetKeyDownInt_m634892559,
	Input_GetAxis_m1666418521,
	Input_GetKeyDown_m1509524102,
	Input_GetMouseButton_m3485621271,
	Input_GetMouseButtonDown_m3468031552,
	Input_get_mousePosition_m1929519408,
	Input_INTERNAL_get_mousePosition_m2607797593,
	Input__cctor_m1276431848,
	DefaultValueAttribute__ctor_m1493972517,
	DefaultValueAttribute_get_Value_m1750514521,
	DefaultValueAttribute_Equals_m28642653,
	DefaultValueAttribute_GetHashCode_m3039019552,
	ExcludeFromDocsAttribute__ctor_m1396943425,
	Keyframe__ctor_m3375943797_AdjustorThunk,
	Keyframe__ctor_m621010815_AdjustorThunk,
	Keyframe_get_time_m3515509166_AdjustorThunk,
	Keyframe_set_time_m4108362711_AdjustorThunk,
	Keyframe_get_value_m3983510015_AdjustorThunk,
	Keyframe_set_value_m3659278961_AdjustorThunk,
	Keyframe_get_inTangent_m867801259_AdjustorThunk,
	Keyframe_set_inTangent_m2022606981_AdjustorThunk,
	Keyframe_get_outTangent_m862308822_AdjustorThunk,
	Keyframe_set_outTangent_m5132678_AdjustorThunk,
	Keyframe_get_tangentMode_m4035898618_AdjustorThunk,
	Keyframe_set_tangentMode_m847764452_AdjustorThunk,
	Logger__ctor_m1843464247,
	Logger_get_logHandler_m1001975644,
	Logger_set_logHandler_m4221272157,
	Logger_get_logEnabled_m1878659891,
	Logger_set_logEnabled_m771198447,
	Logger_get_filterLogType_m3099848982,
	Logger_set_filterLogType_m602084239,
	Logger_IsLogTypeAllowed_m1927143829,
	Logger_GetString_m2607591468,
	Logger_Log_m3814276168,
	Logger_LogFormat_m2728955062,
	Mathf_Abs_m4037208640,
	Mathf_Max_m943320266,
	Mathf_Approximately_m952241212,
	Mathf__cctor_m3833489122,
	MeshCollider__ctor_m83612706,
	MeshCollider_get_sharedMesh_m3981733887,
	MeshCollider_set_sharedMesh_m1749649964,
	MeshCollider_get_convex_m3624458602,
	MeshCollider_set_convex_m3852711973,
	MeshCollider_get_inflateMesh_m3117051985,
	MeshCollider_set_inflateMesh_m3536367144,
	MeshCollider_get_skinWidth_m4113017802,
	MeshCollider_set_skinWidth_m480533321,
	MeshCollider_get_smoothSphereCollisions_m4022807522,
	MeshCollider_set_smoothSphereCollisions_m3702800312,
	MonoBehaviour__ctor_m1236242179,
	MonoBehaviour_Internal_CancelInvokeAll_m134567439,
	MonoBehaviour_Internal_IsInvokingAll_m2498687012,
	MonoBehaviour_Invoke_m1445658415,
	MonoBehaviour_InvokeRepeating_m1711920500,
	MonoBehaviour_CancelInvoke_m2492398622,
	MonoBehaviour_CancelInvoke_m3804726668,
	MonoBehaviour_IsInvoking_m878787515,
	MonoBehaviour_IsInvoking_m3111854111,
	MonoBehaviour_StartCoroutine_m987154008,
	MonoBehaviour_StartCoroutine_Auto_m597942758,
	MonoBehaviour_StartCoroutine_Auto_Internal_m1203968900,
	MonoBehaviour_StartCoroutine_m1532927778,
	MonoBehaviour_StartCoroutine_m2151747079,
	MonoBehaviour_StopCoroutine_m2372275704,
	MonoBehaviour_StopCoroutine_m1079755942,
	MonoBehaviour_StopCoroutine_m2707859735,
	MonoBehaviour_StopCoroutineViaEnumerator_Auto_m2517862605,
	MonoBehaviour_StopCoroutine_Auto_m1706763131,
	MonoBehaviour_StopAllCoroutines_m3012207369,
	MonoBehaviour_print_m134029734,
	MonoBehaviour_get_useGUILayout_m14506679,
	MonoBehaviour_set_useGUILayout_m3498661562,
	MonoBehaviour_GetScriptClassName_m574979679,
	NativeClassAttribute__ctor_m130061132,
	NativeClassAttribute_set_QualifiedNativeName_m293935591,
	MessageEventArgs__ctor_m1335534639,
	PlayerConnection__ctor_m3750197023,
	PlayerConnection_get_instance_m2181360178,
	PlayerConnection_CreateInstance_m3079562849,
	PlayerConnection_MessageCallbackInternal_m2888194805,
	PlayerConnection_ConnectedCallbackInternal_m989124288,
	PlayerConnection_DisconnectedCallback_m571541410,
	PlayerEditorConnectionEvents__ctor_m3505813805,
	PlayerEditorConnectionEvents_InvokeMessageIdSubscribers_m2164178597,
	U3CInvokeMessageIdSubscribersU3Ec__AnonStorey0__ctor_m2842646309,
	U3CInvokeMessageIdSubscribersU3Ec__AnonStorey0_U3CU3Em__0_m534577330,
	ConnectionChangeEvent__ctor_m3284882777,
	MessageEvent__ctor_m3747138721,
	MessageTypeSubscribers__ctor_m2191380784,
	MessageTypeSubscribers_get_MessageTypeId_m3512502684,
	Object__ctor_m753889125,
	Object_Internal_CloneSingle_m1112466195,
	Object_Internal_CloneSingleWithParent_m1578544937,
	Object_Internal_InstantiateSingle_m2703482481,
	Object_INTERNAL_CALL_Internal_InstantiateSingle_m2354361480,
	Object_Internal_InstantiateSingleWithParent_m253669687,
	Object_INTERNAL_CALL_Internal_InstantiateSingleWithParent_m3351340621,
	Object_GetOffsetOfInstanceIDInCPlusPlusObject_m2289052263,
	Object_EnsureRunningOnMainThread_m2181426889,
	Object_Destroy_m763870395,
	Object_Destroy_m2578737452,
	Object_DestroyImmediate_m3667352557,
	Object_DestroyImmediate_m3664569503,
	Object_FindObjectsOfType_m4065607311,
	Object_get_name_m4131808298,
	Object_set_name_m1574609734,
	Object_DontDestroyOnLoad_m3006908952,
	Object_get_hideFlags_m606243072,
	Object_set_hideFlags_m1764873955,
	Object_DestroyObject_m3415511966,
	Object_DestroyObject_m4157767402,
	Object_FindSceneObjectsOfType_m1789838274,
	Object_FindObjectsOfTypeIncludingAssets_m2898151650,
	Object_ToString_m1543712694,
	Object_DoesObjectWithInstanceIDExist_m249218142,
	Object_GetInstanceID_m2901521971,
	Object_GetHashCode_m3929092075,
	Object_Equals_m3089707722,
	Object_op_Implicit_m1617934672,
	Object_CompareBaseObjects_m2495735120,
	Object_IsNativeObjectAlive_m2398424896,
	Object_GetCachedPtr_m183934072,
	Object_Instantiate_m3626274236,
	Object_Instantiate_m499133587,
	Object_Instantiate_m2255325978,
	Object_Instantiate_m1560403475,
	Object_Instantiate_m2568982308,
	Object_CheckNullArgument_m3394949661,
	Object_FindObjectOfType_m1934888875,
	Object_op_Equality_m1841232993,
	Object_op_Inequality_m807138295,
	Object__cctor_m1330512343,
	Physics_Raycast_m3719768030,
	Physics_Raycast_m2350840452,
	Physics_Raycast_m913384994,
	Physics_Raycast_m3873687999,
	Physics_Raycast_m3877441014,
	Physics_Raycast_m3826659266,
	Physics_Raycast_m2170746783,
	Physics_Raycast_m2445896246,
	Physics_Raycast_m2802259901,
	Physics_Raycast_m2419782515,
	Physics_Raycast_m3871305434,
	Physics_Raycast_m3013423287,
	Physics_Raycast_m3076132749,
	Physics_Raycast_m1510999213,
	Physics_Raycast_m54040585,
	Physics_Raycast_m3887300606,
	Physics_RaycastAll_m3686607343,
	Physics_RaycastAll_m2500737461,
	Physics_RaycastAll_m4120885497,
	Physics_RaycastAll_m1735216570,
	Physics_RaycastAll_m2296021024,
	Physics_RaycastAll_m1144311404,
	Physics_RaycastAll_m98091116,
	Physics_RaycastAll_m1515184189,
	Physics_INTERNAL_CALL_RaycastAll_m3201440179,
	Physics_Internal_Raycast_m370680247,
	Physics_INTERNAL_CALL_Internal_Raycast_m2853825113,
	Physics_Internal_RaycastTest_m3350079960,
	Physics_INTERNAL_CALL_Internal_RaycastTest_m3339338234,
	AudioPlayableGraphExtensions_InternalCreateAudioOutput_m2760089805,
	AudioPlayableGraphExtensions_INTERNAL_CALL_InternalCreateAudioOutput_m2119112406,
	Playable__ctor_m3869525416_AdjustorThunk,
	Playable_get_Null_m1880508074,
	Playable_Create_m3130309429,
	Playable_GetHandle_m1873049269_AdjustorThunk,
	Playable_GetPlayableType_m1010025280_AdjustorThunk,
	Playable_Equals_m2026210489_AdjustorThunk,
	Playable__cctor_m2415123826,
	PlayableAsset__ctor_m2498857636,
	PlayableAsset_get_duration_m273148557,
	PlayableAsset_Internal_CreatePlayable_m3902392072,
	PlayableAsset_Internal_GetPlayableAssetDuration_m614503739,
	PlayableBehaviour__ctor_m1533023592,
	PlayableBehaviour_OnGraphStart_m3751382941,
	PlayableBehaviour_OnGraphStop_m807125375,
	PlayableBehaviour_OnPlayableCreate_m2568009617,
	PlayableBehaviour_OnPlayableDestroy_m3890844663,
	PlayableBehaviour_OnBehaviourPlay_m2743359125,
	PlayableBehaviour_OnBehaviourPause_m3831040736,
	PlayableBehaviour_PrepareFrame_m3099946399,
	PlayableBehaviour_ProcessFrame_m3633324633,
	PlayableBehaviour_Clone_m3611151540,
	PlayableBinding__cctor_m2720713679,
	PlayableGraph_CreateScriptOutputInternal_m2484796455,
	PlayableGraph_INTERNAL_CALL_CreateScriptOutputInternal_m2263530833,
	PlayableGraph_CreatePlayableHandle_m2762512469_AdjustorThunk,
	PlayableGraph_CreatePlayableHandleInternal_m2343702139,
	PlayableGraph_INTERNAL_CALL_CreatePlayableHandleInternal_m848171998,
	PlayableHandle_IsValid_m2443557981_AdjustorThunk,
	PlayableHandle_IsValidInternal_m4090848785,
	PlayableHandle_INTERNAL_CALL_IsValidInternal_m2904663435,
	PlayableHandle_GetPlayableTypeOf_m872040087,
	PlayableHandle_INTERNAL_CALL_GetPlayableTypeOf_m1882865113,
	PlayableHandle_GetPlayableType_m2542186169_AdjustorThunk,
	PlayableHandle_get_Null_m2427385690,
	PlayableHandle_SetInputCount_m56214378_AdjustorThunk,
	PlayableHandle_GetPlayState_m1627799370_AdjustorThunk,
	PlayableHandle_SetPlayState_m3741862175_AdjustorThunk,
	PlayableHandle_SetTime_m4155031655_AdjustorThunk,
	PlayableHandle_GetPlayStateInternal_m1805454215,
	PlayableHandle_INTERNAL_CALL_GetPlayStateInternal_m79066241,
	PlayableHandle_SetPlayStateInternal_m1980428610,
	PlayableHandle_INTERNAL_CALL_SetPlayStateInternal_m3501090634,
	PlayableHandle_SetTimeInternal_m2135663238,
	PlayableHandle_INTERNAL_CALL_SetTimeInternal_m207615318,
	PlayableHandle_SetDuration_m2271770484_AdjustorThunk,
	PlayableHandle_SetDurationInternal_m1685957906,
	PlayableHandle_INTERNAL_CALL_SetDurationInternal_m2581365362,
	PlayableHandle_SetInputCountInternal_m3252640859,
	PlayableHandle_INTERNAL_CALL_SetInputCountInternal_m4151268303,
	PlayableHandle_op_Equality_m2909715220,
	PlayableHandle_Equals_m576441965_AdjustorThunk,
	PlayableHandle_GetHashCode_m2709720462_AdjustorThunk,
	PlayableHandle_CompareVersion_m4054145532,
	PlayableOutput__ctor_m3062526119_AdjustorThunk,
	PlayableOutput_get_Null_m3698924701,
	PlayableOutput_GetHandle_m3642647841_AdjustorThunk,
	PlayableOutput_GetPlayableOutputType_m2773985409_AdjustorThunk,
	PlayableOutput_Equals_m3613042663_AdjustorThunk,
	PlayableOutput__cctor_m4075004488,
	PlayableOutputHandle_IsValid_m3916326617_AdjustorThunk,
	PlayableOutputHandle_IsValidInternal_m122093935,
	PlayableOutputHandle_INTERNAL_CALL_IsValidInternal_m2309803248,
	PlayableOutputHandle_get_Null_m3448815846,
	PlayableOutputHandle_GetPlayableOutputTypeOf_m1406648156,
	PlayableOutputHandle_INTERNAL_CALL_GetPlayableOutputTypeOf_m4071527298,
	PlayableOutputHandle_GetHashCode_m1652241056_AdjustorThunk,
	PlayableOutputHandle_op_Equality_m3525409465,
	PlayableOutputHandle_Equals_m807675596_AdjustorThunk,
	PlayableOutputHandle_CompareVersion_m1863899043,
	ScriptPlayableOutput__ctor_m286455169_AdjustorThunk,
	ScriptPlayableOutput_Create_m3744637025,
	ScriptPlayableOutput_get_Null_m3074915722,
	ScriptPlayableOutput_GetHandle_m3375046477_AdjustorThunk,
	ScriptPlayableOutput_op_Implicit_m2701921693,
	ScriptPlayableOutput_op_Explicit_m2632156067,
	PreferBinarySerialization__ctor_m1138231225,
	Quaternion__ctor_m131034559_AdjustorThunk,
	Quaternion_Inverse_m944315417,
	Quaternion_INTERNAL_CALL_Inverse_m2122284289,
	Quaternion_set_eulerAngles_m1585488089_AdjustorThunk,
	Quaternion_Euler_m523267498,
	Quaternion_Internal_FromEulerRad_m1804366691,
	Quaternion_INTERNAL_CALL_Internal_FromEulerRad_m1158394978,
	Quaternion_op_Multiply_m1893531635,
	Quaternion_GetHashCode_m135706246_AdjustorThunk,
	Quaternion_Equals_m303852547_AdjustorThunk,
	Quaternion_ToString_m521349143_AdjustorThunk,
	Quaternion__cctor_m3007313557,
	Ray_get_origin_m3751020661_AdjustorThunk,
	Ray_get_direction_m86554809_AdjustorThunk,
	Ray_ToString_m2023220715_AdjustorThunk,
	Rect_get_x_m1287081870_AdjustorThunk,
	Rect_get_y_m3638505275_AdjustorThunk,
	Rect_get_width_m2698079399_AdjustorThunk,
	Rect_get_height_m1296734715_AdjustorThunk,
	Rect_get_xMin_m4187551037_AdjustorThunk,
	Rect_get_yMin_m3526403013_AdjustorThunk,
	Rect_get_xMax_m1296688675_AdjustorThunk,
	Rect_get_yMax_m3195629982_AdjustorThunk,
	Rect_Contains_m387453500_AdjustorThunk,
	Rect_GetHashCode_m1396616131_AdjustorThunk,
	Rect_Equals_m3608516552_AdjustorThunk,
	Rect_ToString_m3206280085_AdjustorThunk,
	RectTransform_SendReapplyDrivenProperties_m1673235392,
	ReapplyDrivenProperties__ctor_m2556620373,
	ReapplyDrivenProperties_Invoke_m3966453462,
	ReapplyDrivenProperties_BeginInvoke_m3938025644,
	ReapplyDrivenProperties_EndInvoke_m2126455265,
	RemoteSettings_CallOnUpdate_m3230028317,
	UpdatedEventHandler__ctor_m2546761048,
	UpdatedEventHandler_Invoke_m2210614729,
	UpdatedEventHandler_BeginInvoke_m2860243907,
	UpdatedEventHandler_EndInvoke_m3311727003,
	RequireComponent__ctor_m715180030,
	ResourceRequest__ctor_m2395305398,
	ResourceRequest_get_asset_m3601521397,
	Resources_Load_m3111310461,
	Rigidbody_set_velocity_m44238466,
	Rigidbody_INTERNAL_set_velocity_m36759112,
	Rigidbody_get_isKinematic_m3289074417,
	Rigidbody_set_isKinematic_m3808468253,
	Rigidbody_set_constraints_m1675396742,
	Scene_get_handle_m2450444867_AdjustorThunk,
	Scene_GetHashCode_m3462008335_AdjustorThunk,
	Scene_Equals_m1417674842_AdjustorThunk,
	SceneManager_Internal_SceneLoaded_m4213089961,
	SceneManager_Internal_SceneUnloaded_m4274988325,
	SceneManager_Internal_ActiveSceneChanged_m237859709,
	ScriptableObject__ctor_m831057273,
	ScriptableObject_Internal_CreateScriptableObject_m497791512,
	ScriptableObject_CreateInstance_m1184682349,
	ScriptableObject_CreateInstance_m2572500432,
	ScriptableObject_CreateInstanceFromType_m1377228085,
	GeneratedByOldBindingsGeneratorAttribute__ctor_m2409581088,
	RequiredByNativeCodeAttribute__ctor_m3712479437,
	UsedByNativeCodeAttribute__ctor_m2169491047,
	SendMouseEvents_SetMouseMoved_m1615166369,
	SendMouseEvents_DoSendMouseEvents_m1673877171,
	SendMouseEvents_SendEvents_m895636432,
	SendMouseEvents__cctor_m1585552520,
	HitInfo_SendMessage_m1210191586_AdjustorThunk,
	HitInfo_op_Implicit_m2445466641,
	HitInfo_Compare_m921880542,
	FormerlySerializedAsAttribute__ctor_m2819130373,
	FormerlySerializedAsAttribute_get_oldName_m708849870,
	SerializeField__ctor_m3105624160,
	SerializePrivateVariables__ctor_m1720211868,
	SetupCoroutine_InvokeMoveNext_m2573614623,
	SetupCoroutine_InvokeMember_m3217874590,
	SphereCollider__ctor_m1465852125,
	SphereCollider_get_center_m1650807351,
	SphereCollider_set_center_m2457717084,
	SphereCollider_INTERNAL_get_center_m3462447041,
	SphereCollider_INTERNAL_set_center_m3242641947,
	SphereCollider_get_radius_m1946668759,
	SphereCollider_set_radius_m2008006599,
	StackTraceUtility_SetProjectFolder_m2868605785,
	StackTraceUtility_ExtractStackTrace_m1508434409,
	StackTraceUtility_IsSystemStacktraceType_m1940444886,
	StackTraceUtility_ExtractStringFromExceptionInternal_m3206191879,
	StackTraceUtility_PostprocessStacktrace_m8392584,
	StackTraceUtility_ExtractFormattedStackTrace_m2968975606,
	StackTraceUtility__cctor_m1266974634,
	ThreadAndSerializationSafeAttribute__ctor_m14339559,
	Time_get_deltaTime_m3885432000,
	Transform_get_position_m711175457,
	Transform_set_position_m3893147833,
	Transform_INTERNAL_get_position_m2271944548,
	Transform_INTERNAL_set_position_m2678488908,
	Transform_get_rotation_m1446247215,
	Transform_set_rotation_m3616398901,
	Transform_INTERNAL_get_rotation_m3993959474,
	Transform_INTERNAL_set_rotation_m3387907152,
	Transform_get_localRotation_m829296482,
	Transform_set_localRotation_m3913585663,
	Transform_INTERNAL_get_localRotation_m420822815,
	Transform_INTERNAL_set_localRotation_m365960821,
	Transform_Rotate_m2953437478,
	Transform_Rotate_m1099066500,
	Transform_Rotate_m678397658,
	Transform_get_childCount_m4116705935,
	Transform_GetEnumerator_m454680747,
	Transform_GetChild_m1662106098,
	Enumerator__ctor_m2577253463,
	Enumerator_get_Current_m2830446975,
	Enumerator_MoveNext_m3000436454,
	Enumerator_Reset_m2399314265,
	SpriteAtlasManager_RequestAtlas_m351979735,
	SpriteAtlasManager_Register_m3968478932,
	SpriteAtlasManager__cctor_m633847741,
	RequestAtlasCallback__ctor_m1940397596,
	RequestAtlasCallback_Invoke_m2260126922,
	RequestAtlasCallback_BeginInvoke_m2546690022,
	RequestAtlasCallback_EndInvoke_m4227810528,
	UnityException__ctor_m1555052860,
	UnityException__ctor_m3766139554,
	UnityException__ctor_m3034370437,
	UnityString_Format_m2073054251,
	UnitySynchronizationContext__ctor_m229789324,
	UnitySynchronizationContext_Exec_m3516798445,
	UnitySynchronizationContext_InitializeSynchronizationContext_m3655849499,
	UnitySynchronizationContext_ExecuteTasks_m691963302,
	WorkRequest_Invoke_m2250752811_AdjustorThunk,
	Vector2__ctor_m1379939419_AdjustorThunk,
	Vector2_ToString_m2249113751_AdjustorThunk,
	Vector2_GetHashCode_m3354548468_AdjustorThunk,
	Vector2_Equals_m730962973_AdjustorThunk,
	Vector2__cctor_m1950777118,
	Vector3__ctor_m4052953749_AdjustorThunk,
	Vector3_GetHashCode_m3133414896_AdjustorThunk,
	Vector3_Equals_m964850638_AdjustorThunk,
	Vector3_get_zero_m2204703071,
	Vector3_op_Addition_m1168168007,
	Vector3_op_Subtraction_m107949794,
	Vector3_op_Multiply_m1972684293,
	Vector3_op_Multiply_m3725125284,
	Vector3_ToString_m2214970796_AdjustorThunk,
	Vector3__cctor_m1893743815,
	WaitForEndOfFrame__ctor_m2543048271,
	WaitForFixedUpdate__ctor_m384654351,
	WaitForSeconds__ctor_m353700436,
	WritableAttribute__ctor_m2889669273,
	YieldInstruction__ctor_m4142490385,
	MathfInternal__cctor_m29666380,
	NetFxCoreExtensions_CreateDelegate_m1280007241,
	TypeInferenceRuleAttribute__ctor_m273865400,
	TypeInferenceRuleAttribute__ctor_m2633202458,
	TypeInferenceRuleAttribute_ToString_m2239167322,
	WebRequestUtils_RedirectTo_m1519057860,
	WebRequestUtils__cctor_m1127827934,
	AnalyticsTracker__ctor_m4036703947,
	AnalyticsTracker_get_eventName_m545508370,
	AnalyticsTracker_set_eventName_m2753990119,
	AnalyticsTracker_get_TP_m1357043539,
	AnalyticsTracker_set_TP_m895689910,
	AnalyticsTracker_Awake_m3429851212,
	AnalyticsTracker_Start_m3303986160,
	AnalyticsTracker_OnEnable_m48702781,
	AnalyticsTracker_OnDisable_m4191761106,
	AnalyticsTracker_OnApplicationPause_m3716850000,
	AnalyticsTracker_OnDestroy_m2511155376,
	AnalyticsTracker_TriggerEvent_m1510154244,
	AnalyticsTracker_SendEvent_m2472808613,
	AnalyticsTracker_BuildParameters_m1739240218,
	TrackableProperty__ctor_m2933150026,
	TrackableProperty_get_fields_m1105770405,
	TrackableProperty_set_fields_m279267918,
	TrackableProperty_GetHashCode_m2535425558,
	FieldWithTarget__ctor_m2879209876,
	FieldWithTarget_get_paramName_m787538260,
	FieldWithTarget_set_paramName_m167468789,
	FieldWithTarget_get_target_m2983307788,
	FieldWithTarget_set_target_m769246785,
	FieldWithTarget_get_fieldPath_m51400754,
	FieldWithTarget_set_fieldPath_m3902225503,
	FieldWithTarget_get_typeString_m3284553539,
	FieldWithTarget_set_typeString_m3894963277,
	FieldWithTarget_get_doStatic_m1887875852,
	FieldWithTarget_set_doStatic_m3503446641,
	FieldWithTarget_get_staticString_m2740384771,
	FieldWithTarget_set_staticString_m3960315724,
	FieldWithTarget_GetValue_m1351827778,
	BoxTrigger__ctor_m910405003,
	BoxTrigger_Start_m1361771495,
	BoxTrigger_OnTriggerEnter_m1134727060,
	BoxTrigger_OnTriggerExit_m1026518603,
	CameraScript__ctor_m2074972760,
	CameraScript_Start_m70798908,
	CameraScript_LateUpdate_m3780720276,
	FlipCharacter__ctor_m2323846137,
	FlipCharacter_Start_m1352720864,
	FlipCharacter_Flip_m936201690,
	LedgeTrigger__ctor_m3541567390,
	LedgeTrigger_Start_m3492426325,
	LedgeTrigger_OnTriggerEnter_m4103365985,
	MoveCharacter__ctor_m940492633,
	MoveCharacter_Start_m3159237758,
	MoveCharacter_Move_m3498876582,
	MoveCharacter_Jump_m768547604,
	MoveObject__ctor_m403285747,
	MoveObject_OnControllerColliderHit_m4083205808,
	PlatformTrigger__ctor_m684306013,
	PlatformTrigger_Start_m434823051,
	PlatformTrigger_OnTriggerEnter_m1123801430,
	PlayerInput__ctor_m634196471,
	PlayerInput_Update_m1542141274,
	PushObject__ctor_m3866911932,
	PushObject_OnControllerColliderHit_m3319051333,
	PushObject_test_m2222389076,
	PushObject__cctor_m933835445,
};
